O c�digo foi criado e executado em um windows 7 (n�o h� garantias que rodar� no linux)

Para executar, crie um arquivo de entrada parecido com o entrada.txt(sem esp�os entre virgulas e sem enter ap�s o �ltimo comando)

abra o python e digite os comandos
from Trabalho import *
a = pipeline ('entrada.txt',5)(5 � o tempo que cada intera�ao do pipeline ficara na tela em segundos)
a.main() (isso faz o programa comecar com o arquivo de entrada passado anteriormente)

Grupo:
Vinicius Volponi Ferreira 9039292
Marcus Araujo 9005871
Kairo Bonicenha 9019790