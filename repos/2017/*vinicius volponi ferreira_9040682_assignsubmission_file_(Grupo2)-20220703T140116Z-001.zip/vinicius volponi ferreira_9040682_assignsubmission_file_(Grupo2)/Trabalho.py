# -*- coding: utf-8 -*-

#Vinicius Volponi Ferreira 9039292
#Marcus Araujo 9005871
#Kairo Bonicenha 9019790

import string
import time
import os

#vamos criar uma classe para cada funcao 
#quando um codigo add, por exemplo, for dado
#uma classe do tipo add será criada
class add():
	#rDest = registrador destino
	#rOrigin1 = registrador com o primeiro valores
	#rOrigin2 = registrador com o segundo valores
	def __init__(self,rDest,rOrigin1,rOrigin2):
		self.c = 0
		self.ro1 = rOrigin1
		self.ro2 = rOrigin2
		self.rd = rDest
		self.list =['add:  ']
	#para saber de que tipo eh a instancia
	def tipo(self):
		return 'add'
	#a funcao clock eh quem dira em que estado o comando add esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,mem):
		#aqui a funcao add acabou de ser criada
		#ela vai alterar o valor apenas do registrador if/id quando eh criada
		if(self.c == 0):
			self.list.append('if  ')
			print(string.join(self.list))

			regs['ifId'] = {'IR':'000000'+self.ro1+self.ro2+self.rd+'00000100000','NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, quando as informacoes serao passadas
		#para o registrador id/ex e o ir sera separado
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			regs['idEx'] = {'A':self.ro1,'B':self.ro2,'IMM':'0000000000000000'+self.rd+'00000100000','IR':regs['ifId']['IR'],'NPC':regs['ifId']['NPC']}
		#terceiro clock, nessa parte sera a execucao, ou seja, os valores
		#serao passados do registrador id/ex para ex/mem e a operacao sera realizada
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			regs['exMem'] = {'Aluout':self.ro1+'100000'+self.ro2,'B':'','zero':'','IR':regs['idEx']['IR']}
		#no quarto clock, nao acontecera nada nesse caso, apenas algumas informacoes serao passadas
		#para o proximo registrados
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':regs['exMem']['Aluout'],'LMD':''}
		#quinto clock sera o write back, aqui o registrador destino(registradores[self.rd])
		#recebera o valor da soma dos registradores origem
		elif(self.c == 4):
			self.list.append('wb  ')
			print(string.join(self.list))
			registradores[self.rd] = registradores[self.ro1] + registradores[self.ro2]
		self.c = self.c + 1
		return regs
		
class sub():
	#rDest = registrador destino
	#rOrigin1 = registrador com o primeiro valores
	#rOrigin2 = registrador com o segundo valores
	def __init__(self,rDest,rOrigin1,rOrigin2):
		self.c = 0
		self.ro1 = rOrigin1
		self.ro2 = rOrigin2
		self.rd = rDest
		self.list =['sub:  ']
	#para sabermos de que tipo eh a instancia
	def tipo(self):
		return 'sub'
	#a funcao clock eh quem dira em que estado o comando sub esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,mem):
		#aqui a funcao sub acabou de ser criada
		#ela vai alterar o valor apenas do registrador if/id quando eh criada
		if(self.c == 0):
			self.list.append('if  ')
			print(string.join(self.list))
			regs['ifId'] = {'IR':'000000'+self.ro1+self.ro2+self.rd+'00000100010','NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, quando as informacoes serao passadas
		#para o registrador id/ex e o ir sera separado
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			regs['idEx'] = {'A':self.ro1,'B':self.ro2,'IMM':'0000000000000000'+self.rd+'00000100010','IR':regs['ifId']['IR'],'NPC':regs['ifId']['NPC']}
		#terceiro clock, nessa parte sera a execucao, ou seja, os valores
		#serao passados do registrador id/ex para ex/mem e a operacao sera realizada
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			regs['exMem'] = {'Aluout':self.ro1+'100010'+self.ro2,'B':'','zero':'','IR':regs['idEx']['IR']}
		#no quarto clock, nao acontecera nada nesse caso, apenas algumas informacoes serao passadas
		#para o proximo registrados
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':regs['exMem']['Aluout'],'LMD':''}
		#quinto clock sera o write back, aqui o registrador destino(registradores[self.rd])
		#recebera o valor da subtracao dos registradores origem
		elif(self.c == 4):
			self.list.append('wb  ')
			print(string.join(self.list))
			registradores[self.rd] = registradores[self.ro1] - registradores[self.ro2]
		self.c = self.c + 1
		return regs
		
class func_and():
	#rDest = registrador destino
	#rOrigin1 = registrador com o primeiro valores
	#rOrigin2 = registrador com o segundo valores
	def __init__(self,rDest,rOrigin1,rOrigin2):
		self.c = 0
		self.ro1 = rOrigin1
		self.ro2 = rOrigin2
		self.rd = rDest
		self.list =['and:  ']
	#para sabermos de que tipo eh a instancia
	def tipo(self):
		return 'and'
	#a funcao clock eh quem dira em que estado o comando and esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,mem):
		#aqui a funcao and acabou de ser criada
		#ela vai alterar o valor apenas do registrador if/id quando eh criada
		if(self.c == 0):
			self.list.append('if')
			print(string.join(self.list))
			regs['ifId'] = {'IR':'000000'+self.ro1+self.ro2+self.rd+'00000100100','NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, quando as informacoes serao passadas
		#para o registrador id/ex e o ir sera separado
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			regs['idEx'] = {'A':self.ro1,'B':self.ro2,'IMM':'0000000000000000'+self.rd+'00000100100','IR':regs['ifId']['IR'],'NPC':regs['ifId']['NPC']}
		#terceiro clock, nessa parte sera a execucao, ou seja, os valores
		#serao passados do registrador id/ex para ex/mem e a operacao sera realizada
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			regs['exMem'] = {'Aluout':self.ro1+'100100'+self.ro2,'B':'','zero':'','IR':regs['idEx']['IR']}
		#no quarto clock, nao acontecera nada nesse caso, apenas algumas informacoes serao passadas
		#para o proximo registrados
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':regs['exMem']['Aluout'],'LMD':''}
		#quinto clock sera o write back, aqui o registrador destino(registradores[self.rd])
		#recebera a resposta do and dos registradores origem
		elif(self.c == 4):
			self.list.append('wb')
			print(string.join(self.list))
			registradores[self.rd] = registradores[self.ro1] & registradores[self.ro2]
		self.c = self.c + 1
		return regs
		
class func_or():
	#rDest = registrador destino
	#rOrigin1 = registrador com o primeiro valores
	#rOrigin2 = registrador com o segundo valores
	def __init__(self,rDest,rOrigin1,rOrigin2):
		self.c = 0
		self.ro1 = rOrigin1
		self.ro2 = rOrigin2
		self.rd = rDest
		self.list =['or:  ']
	#para sabermos de que tipo eh a instancia
	def tipo(self):
		return 'or'
	#a funcao clock eh quem dira em que estado o comando or esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,mem):
		#aqui a funcao or acabou de ser criada
		#ela vai alterar o valor apenas do registrador if/id quando eh criada
		if(self.c == 0):
			self.list.append('if  ')
			print(string.join(self.list))
			regs['ifId'] = {'IR':'000000'+self.ro1+self.ro2+self.rd+'00000100101','NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, quando as informacoes serao passadas
		#para o registrador id/ex e o ir sera separado
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			regs['idEx'] = {'A':self.ro1,'B':self.ro2,'IMM':'0000000000000000'+self.rd+'00000100101','IR':regs['ifId']['IR']}
		#terceiro clock, nessa parte sera a execucao, ou seja, os valores
		#serao passados do registrador id/ex para ex/mem e a operacao sera realizada
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			regs['exMem'] = {'Aluout':self.ro1+'100101'+self.ro2,'B':'','zero':'','IR':regs['idEx']['IR'],'NPC':regs['idEx']['NPC']}
		#no quarto clock, nao acontecera nada nesse caso, apenas algumas informacoes serao passadas
		#para o proximo registrados
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':regs['exMem']['Aluout'],'LMD':''}
		#quinto clock sera o write back, aqui o registrador destino(registradores[self.rd])
		#recebera a resposta do or dos registradores origem
		elif(self.c == 4):
			self.list.append('wb  ')
			print(string.join(self.list))
			registradores[self.rd] = registradores[self.ro1] | registradores[self.ro2]
		self.c = self.c + 1
		return regs
		
class lw():
	#rDest = registrador destino
	#iSoma = valor imediato que sera somado ex: 0($t1) eh o 0
	#rSoma = registrador que sera somado ao valor imediato ex: 0($t1) eh o $t1
	def __init__(self,rDest,iSoma,rSoma):
		self.c = 0
		self.rs = rSoma
		self.vi = iSoma
		self.rd = rDest
		self.list=['lw :  ']
	#para sabermos de que tipo eh a instancia
	def tipo(self):
		return 'lw'
	#a funcao clock eh quem dira em que estado o comando lw esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,mem):
		#aqui a funcao lw acabou de ser criada
		#ela vai alterar o valor apenas do registrador if/id quando eh criada
		if(self.c == 0):
			self.list.append('if  ')
			print(string.join(self.list))
			#para criar o comando binario, usamos a variavel abin, pois ela tera
			#16 bits com o valor imediato embutido
			abin = '0'
			vib = bin(int(self.vi))
			vib = vib.replace('0b','')
			for i in range(0,15-len(vib)):
				abin = abin+'0'
			abin = abin + vib
			regs['ifId'] = {'IR':'100011'+self.rs+self.rd+abin,'NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, quando as informacoes serao passadas
		#para o registrador id/ex e o ir sera separado
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			#novamente o abin, ele sera usado para dar o sign_extend do valor imediato
			abin = '0'
			vib = bin(int(self.vi))
			vib = vib.replace('0b','')
			for i in range(0,31-len(vib)):
				abin = abin+'0'
			abin = abin + vib
			regs['idEx'] = {'A':self.rs,'B':self.rd,'IMM':abin,'IR':regs['ifId']['IR'],'NPC':regs['ifId']['NPC']}
		#terceiro clock, nessa parte sera a execucao, ou seja, o valor imediato e o valor do registrador
		#serao somados para obter a posicao da memoria que vamos pegar o valor
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			regs['exMem'] = {'Aluout':self.rs+'100000'+regs['idEx']['IMM'],'B':regs['idEx']['B'],'zero':'','IR':regs['idEx']['IR']}
		#no quarto clock, acessaremos a memória e resgataremos o valor que 
		#vira para o registrador destino
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':'','LMD':bin(mem[(int(registradores[self.rs])+int(self.vi))/4]).replace('0b','')}
		#quinto clock sera o write back, aqui o registrador destino(registradores[self.rd])
		#recebera o valor retirado da memoria
		elif(self.c == 4):
			self.list.append('wb  ')
			print(string.join(self.list))
			registradores[self.rd] = mem[(int(registradores[self.rs])+int(self.vi))/4]
		self.c = self.c + 1
		return regs
		
class sw():
	#rDest = registrador destino(eh o registrador que tera o valor salvo na memoria)
	#iSoma = valor imediato que sera somado ex: 0($t1) eh o 0
	#rSoma = registrador que sera somado ao valor imediato ex: 0($t1) eh o $t1
	def __init__(self,rDest,iSoma,rSoma):
		self.c = 0
		self.rs = rSoma
		self.vi = iSoma
		self.rd = rDest
		self.list=['sw :  ']
	#para sabermos de que tipo eh a instancia
	def tipo(self):
		return 'sw'
	#a funcao clock eh quem dira em que estado o comando sw esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,mem):
		#aqui a funcao sw acabou de ser criada
		#ela vai alterar o valor apenas do registrador if/id quando eh criada
		if(self.c == 0):
			self.list.append('if  ')
			print(string.join(self.list))
			#para criar o comando binario, usamos a variavel abin, pois ela tera
			#16 bits com o valor imediato embutido
			abin = '0'
			vib = bin(int(self.vi))
			vib = vib.replace('0b','')
			for i in range(0,15-len(vib)):
				abin = abin+'0'
			abin = abin + vib
			regs['ifId'] = {'IR':'101011'+self.rs+self.rd+abin,'NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, quando as informacoes serao passadas
		#para o registrador id/ex e o ir sera separado
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			#novamente o abin, ele sera usado para dar o sign_extend do valor imediato
			abin = '0'
			vib = bin(int(self.vi))
			vib = vib.replace('0b','')
			for i in range(0,31-len(vib)):
				abin = abin+'0'
			abin = abin + vib
			regs['idEx'] = {'A':self.rs,'B':self.rd,'IMM':abin,'IR':regs['ifId']['IR'],'NPC':regs['ifId']['NPC']}
		#terceiro clock, nessa parte sera a execucao, ou seja, o valor imediato e o valor do registrador
		#serao somados para obter a posicao da memoria que vamos salvar o valor
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			regs['exMem'] = {'Aluout':self.rs+'100000'+regs['idEx']['IMM'],'B':regs['idEx']['B'],'zero':'','IR':regs['idEx']['IR']}
		#no quarto clock, acessaremos vamos salvar o valor do registrador destino na posicao correta da memoria
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':'','LMD':mem[(int(registradores[self.rs])+int(self.vi))/4]}
			mem[(int(registradores[self.rs])+int(self.vi))/4] = registradores[self.rd]
		#o write back ocorrera aqui, mas nao tera funcao nenhuma nesse caso
		elif(self.c == 4):
			self.list.append('wb  ')
			print(string.join(self.list))
		self.c = self.c + 1
		return regs
		
class bne():
	#rComp1 = registrador de comparacao 1
	#rComp2 = registrador de comparacao 2
	#Label = label do branch
	def __init__(self,rComp1,rComp2,Label):
		self.c = 0
		self.rc1 = rComp1
		self.rc2 = rComp2
		self.lb = Label
		self.list =['bne:  ']
	#para sabermos de que tipo eh a instancia
	def tipo(self):
		return 'bne'
	#a funcao clock eh quem dira em que estado o comando bne esta no momento
	#com o auxilio da variavel self.c(contador de estados)
	def clock(self,regs,registradores,lcomandos):
		cont = 0
		#aqui estamos no primeiro clock, no if.
		if(self.c == 0):
			self.list.append('if  ')
			print(string.join(self.list))
			#estamos encontrando em que posicao o label esta no arquivo(no caso, no vetor de comandos)
			for i in range(0,len(lcomandos)-1):
				if(lcomandos[i][0] == self.lb+':'):
					#se encontrarmos o label, colocamos o pc dele em pclabel(
					#multiplicamos por 4, pois o indice do vetor nao eh igual do arquivo
					#entao nao poderiamos apenas transformar o indice do label no vetor em bin)
					pclabel = i * 4
					i = len(lcomandos)
			#transformamos em binario
			pclabelbin = bin(pclabel).replace('0b','')
			#completamos com 0 para ter 16 bits
			abin = '0'
			for i in range(0,15-len(pclabelbin)):
				abin = abin + '0'
			abin = abin + pclabelbin
			regs['ifId'] = {'IR':'000101'+self.rc1+self.rc2+abin,'NPC':regs['ifId']['NPC']+4}
		#aqui sera o segundo clock, id. Faremos muito parecido com o passado, para poder dividir
		#o ir. A unica diferenca eh que aqui fazemos o sign_extend no endereco do label
		elif(self.c == 1):
			self.list.append('id  ')
			print(string.join(self.list))
			for i in range(0,len(lcomandos)-1):
				if(lcomandos[i][0] == self.lb+':'):
					pclabel = i * 4
					i = len(lcomandos)
			pclabelbin = bin(pclabel).replace('0b','')
			abin = '0'
			for i in range(0,31-len(pclabelbin)):
				abin = abin + '0'
			abin = abin + pclabelbin
			regs['idEx'] = {'A':self.rc1,'B':self.rc2,'IMM':abin,'IR':regs['ifId']['IR'],'NPC':regs['ifId']['NPC']}
		#aqui temos o ex. Aqui atualizaremos o pc caso o branch tenha que ocorrer
		elif(self.c == 2):
			self.list.append('ex  ')
			print(string.join(self.list))
			for i in range(0,len(lcomandos)-1):
				if(lcomandos[i][0] == self.lb+':'):
					pclabel = i * 4
					i = len(lcomandos)
			#temos que fazer um shift de 2 no local em que o label esta
			pclabel = pclabel << 2
			pclabelbin = bin(pclabel).replace('0b','')
			abin = '0'
			for i in range(0,31-len(pclabelbin)):
				abin = abin + '0'
			abin = abin + pclabelbin
			#se os registradores tiverem valores diferentes, faremos o branch
			if(registradores[self.rc1] != registradores[self.rc2]):
				#mas nos precisamos do valor do label em relacao ao vetor
				#entao vamos desfazer o que fizemos
				pclabel = pclabel >> 2
				cont = (pclabel/4)
				#zero soh serve para o zero do ex/mem
				zero = 0
			else:
				zero = 1
			regs['exMem'] = {'Aluout':bin(regs['idEx']['NPC']).replace('0b','')+'100000'+abin,'B':'','zero':str(zero),'IR':regs['idEx']['IR']}
		#os proximos dois clocks sao inuteis para essa instrucao.
		elif(self.c == 3):
			self.list.append('me  ')
			print(string.join(self.list))
			regs['memWb'] = {'IR':regs['exMem']['IR'],'Aluout':regs['exMem']['Aluout'],'LMD':''}
		elif(self.c == 4):
			self.list.append('wb  ')
			print(string.join(self.list))
		self.c = self.c + 1
		return [regs,cont]

#a classe do pipeline eh a classe que vai executar realmente o codigo passado
class pipeline():
	#eh necessario passar um arquivo com o codigo que deve ser executado
	def __init__(self,arquivo,timer):
		self.arquivo = arquivo
		self.pipe = [] #uma lista com os comandos que estao em execucao
		#sao os registradores do pipeline(if/id,id/ex,ex/mem e mem/wb)
		self.regs = {'ifId':{'IR':'','NPC':0},'idEx':{'A':'','B':'','IMM':'','IR':'','NPC':0},'exMem':{'Aluout':'','B':'','zero':'','IR':''},'memWb':{'IR':'','addres':''}}
		#sao os registradores t e s da arquitetura mips em binario($t0,$t1,$t2...)(nao temos os de kernel nem os $a0,$a1... ou $v0,$v1...)
		self.registradores={'01000':11,'01001':12,'01010':0,'01011':14,'01100':2,'01101':16,'01110':1,'01111':19,'10000':20,'10001':21,'10010':22,'10011':23,'10100':24,'10101':25,'10110':26,'10111':27,'11000':28,'11001':29}
		#eh uma representacao da memoria, uma lista
		self.mem = []
		#nossa memoria tera 512 posicoes, onde mem[5] = 5, ou seja, cada posicao
		#tera o valor da sua posicao salvo
		for i in range(0,511):
			self.mem.append(int(i))
		#tempo que ele deixara a resposta na tela
		self.timer = timer
			
	#o clock do pipeline eh dar clock em todas as instancias que estao em execucao no momento
	#i sera uma instancia
	def clock(self,n):
		cont = 0
		for i in self.pipe:
			#caso nao seja bne, nao temos que nos preocupar com atualizacao do pc, por isso
			#nao precisamos mexer no cont
			if(i.tipo() != 'bne'):
				self.regs = i.clock(self.regs,self.registradores,self.mem)
			#se a instancia for do tipo bne, ela retornara o valor do novo pc(caso o branch ocorra)
			#e devemos retornar isso para a funcao main do pipeline para colocar o comando certo
			else:
				respaux = i.clock(self.regs,self.registradores,n)
				self.regs = respaux[0]
				if respaux[1] != 0:
					cont = respaux[1]
		return cont
			
	#aqui converteremos tres valores de registradores para seus valores binarios
	# um exemplo eh $t0 = 01000
	def converteRtoBin(self,val1,val2,val3):
		if val1 == '$t0':
			val1 = '01000'
		elif val1 == '$t1':
			val1 = '01001'
		elif val1 == '$t2':
			val1 = '01010'
		elif val1 == '$t3':
			val1 = '01011'
		elif val1 == '$t4':
			val1 = '01100'
		elif val1 == '$t5':
			val1 = '01101'
		elif val1 == '$t6':
			val1 = '01110'
		elif val1 == '$t7':
			val1 = '01111'
		elif val1 == '$t8':
			val1 = '11000'
		elif val1 == '$t9':
			val1 = '11001'
		elif val1 == '$s0':
			val1 = '10000'
		elif val1 == '$s1':
			val1 = '10001'
		elif val1 == '$s2':
			val1 = '10010'
		elif val1 == '$s3':
			val1 = '10011'
		elif val1 == '$s4':
			val1 = '10100'
		elif val1 == '$s5':
			val1 = '10101'
		elif val1 == '$s6':
			val1 = '10110'
		elif val1 == '$s7':
			val1 = '10111'
			
		if val2 == '$t0':
			val2 = '01000'
		elif val2 == '$t1':
			val2 = '01001'
		elif val2 == '$t2':
			val2 = '01010'
		elif val2 == '$t3':
			val2 = '01011'
		elif val2 == '$t4':
			val2 = '01100'
		elif val2 == '$t5':
			val2 = '01101'
		elif val2 == '$t6':
			val2 = '01110'
		elif val2 == '$t7':
			val2 = '01111'
		elif val2 == '$t8':
			val2 = '11000'
		elif val2 == '$t9':
			val2 = '11001'
		elif val2 == '$s0':
			val2 = '10000'
		elif val2 == '$s1':
			val2 = '10001'
		elif val2 == '$s2':
			val2 = '10010'
		elif val2 == '$s3':
			val2 = '10011'
		elif val2 == '$s4':
			val2 = '10100'
		elif val2 == '$s5':
			val2 = '10101'
		elif val2 == '$s6':
			val2 = '10110'
		elif val2 == '$s7':
			val2 = '10111'

		if val3 == '$t0':
			val3 = '01000'
		elif val3 == '$t1':
			val3 = '01001'
		elif val3 == '$t2':
			val3 = '01010'
		elif val3 == '$t3':
			val3 = '01011'
		elif val3 == '$t4':
			val3 = '01100'
		elif val3 == '$t5':
			val3 = '01101'
		elif val3 == '$t6':
			val3 = '01110'
		elif val3 == '$t7':
			val3 = '01111'
		elif val3 == '$t8':
			val3 = '11000'
		elif val3 == '$t9':
			val3 = '11001'
		elif val3 == '$s0':
			val3 = '10000'
		elif val3 == '$s1':
			val3 = '10001'
		elif val3 == '$s2':
			val3 = '10010'
		elif val3 == '$s3':
			val3 = '10011'
		elif val3 == '$s4':
			val3 = '10100'
		elif val3 == '$s5':
			val3 = '10101'
		elif val3 == '$s6':
			val3 = '10110'
		elif val3 == '$s7':
			val3 = '10111'
		return [val1,val2,val3]
	
	#essa funcao sera a que criara a instancia correta para o pipeline
	#ela eh que definira qual classe sera instanciada e colocada no pipe
	#para isso ela precisa do cont, para saber qual linha do codigo estamos
	#e da lista de comandos(variavel n) para poder acessar o proximo comando
	#que sera instanciado
	def set_instruction(self,cont,n):
		if(n[cont][0] == 'add'):
			#primeiro convertemos os valores dos registradores
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1],n[cont][1][2])
			#com os valores convertidos instanciamos uma nova classe
			a = add(valConv[0],valConv[1],valConv[2])
		elif(n[cont][0] == 'sub'):
			#primeiro convertemos os valores dos registradores
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1],n[cont][1][2])
			#com os valores convertidos instanciamos uma nova classe
			a = sub(valConv[0],valConv[1],valConv[2])
		elif(n[cont][0] == 'or'):
			#primeiro convertemos os valores dos registradores
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1],n[cont][1][2])
			#com os valores convertidos instanciamos uma nova classe
			a = func_or(valConv[0],valConv[1],valConv[2])
		elif(n[cont][0] == 'and'):
			#primeiro convertemos os valores dos registradores
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1],n[cont][1][2])
			#com os valores convertidos instanciamos uma nova classe
			a = func_and(valConv[0],valConv[1],valConv[2])
		elif(n[cont][0] == 'sw'):
			#aqui temos que retirar os parenteses que ficam no segundo registrador
			n[cont][1][1] = n[cont][1][1].split('(')
			n[cont][1][1][1] = n[cont][1][1][1].replace(')','')
			#para que assim possamos converter o valor deles para binario
			#nesse caso, o valor imediato tambem eh passado, mas nao eh convertido
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1][0],n[cont][1][1][1])
			a = sw(valConv[0],valConv[1],valConv[2])
		elif(n[cont][0] == 'lw'):
			#aqui temos que retirar os parenteses que ficam no segundo registrador
			n[cont][1][1] = n[cont][1][1].split('(')
			n[cont][1][1][1] = n[cont][1][1][1].replace(')','')
			#para que assim possamos converter o valor deles para binario
			#nesse caso, o valor imediato tambem eh passado, mas nao eh convertido
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1][0],n[cont][1][1][1])
			a = lw(valConv[0],valConv[1],valConv[2])
		elif(n[cont][0] == 'bne'):
			valConv = self.converteRtoBin(n[cont][1][0],n[cont][1][1],n[cont][1][2])
			a = bne(valConv[0],valConv[1],valConv[2])
		else:
			a = 'nada'
		return a
	#a funcao main eh a que fara a execucao do pipeline, aqui eh onde abrimos o arquivo com os comandos
	#e controlamos qual comando deve ser instanciado e qual comando deve sair do pipeline
	def main(self):
		#abrimos o arquivo e colocamos
		a = open(self.arquivo,'r')
		#arrumar o arquivo de valores
		n=[]
		for i in a:
			n.append(i.split(' '))
		for i in range(0,len(n)):
			if((':' in n[i][0]) == True):
				n[i][0] = n[i][0].replace('\n','')
			else:
				n[i][1] = n[i][1].replace('\n','')
				n[i][1] = n[i][1].split(',')
		#ate aqui, apenas abrimos o arquivo de valores, carregamos ele na memoria(variavel n)
		#e deixamos ele organizado de uma forma que facilite a compreensao de cada um dos parametros
		#a variavel cont, dira em qual comando nos estamos(eh como se fosse nosso pc)
		cont = 0
		#j controlara quem deve sair do pipeline, ou seja, as instrucoes que ja tiveram 5 clocks
		j = 0
		#uma forma de fazer repeticao infinita
		while True:
			#como eh um pipeline ele rodara a quantidade de comandos + 4
			#ou seja, tera exatamente essa quantidade de clocks
			if(cont < len(n)+4):
				#aqui eh onde instanciamos as classes no pipeline
				#se cont for maior ou igual a quantidade de comandos, nao devemos mais 
				#instanciar nenhuma classe, pois todos os comandos ja acabaram
				if(cont < len(n)):
					#caso tenha um label, a funcao set_instruction retornara 'nada'
					#se isso acontecer, temos que pegar o proximo comando para instanciar
					aux = self.set_instruction(cont,n)
					while aux == 'nada':
						cont = cont + 1
						aux = self.set_instruction(cont,n)
					#se estamos nas 5 primeiras instancias(ou seja, 5 primeiros comandos)
					#apenas devemos encaixar a instancia nova na lista pipe
					if(len(self.pipe) < 5):
						self.pipe.append(aux)
					#se estivermos apos essas 5 primeiras instancias, devemos retirar o
					#comando que ja teve 5 clocks e colocar no lugar dele uma nova instancia
					#do proximo comando que pegamos do arquivo j controla quem deve sair e
					#onde a proxima instancia devera entrar
					else:
						del self.pipe[j]
						self.pipe.insert(j,aux)
						if(j==4):
							j = 0
						else:
							j = j + 1
				#aqui mandamos o pipeline dar clock, ou seja, mandamos o clock para todas as
				#instancias do pipeline, cada instancia eh responsavel por printar
				#em que posicao do pipeline esta no momento(if, id, ex, mem ou wb)
				valoraux = self.clock(n)
				#caso tenha sido uma instrucao bne o valoraux recebera o valor do novo pc
				#devemos colocar isso no cont, pois ele eh como se fosse nosso pc
				if(valoraux != 0):
					cont = valoraux
				#ao final de cada interacao printamos todos os registradores do pipeline
				print('IF/ID  '+str(self.regs['ifId']))
				print('ID/EX  '+str(self.regs['idEx']))
				print('EX/MEM '+str(self.regs['exMem']))
				print('MEM/WB '+str(self.regs['memWb']))
			#quando o cont for maior que a quantidade maxima de clocks
			#nosso codigo deve parar
			else:
				print(self.mem)
				print(self.registradores)
				break
			#colocamos um time para que seja possivel visualizara cada interacao
			time.sleep(self.timer)
			#isso vai limpar a tela ao final de cada interacao
			os.system('cls')
			cont = cont + 1
	
			
			
			
			
			
			
			
			