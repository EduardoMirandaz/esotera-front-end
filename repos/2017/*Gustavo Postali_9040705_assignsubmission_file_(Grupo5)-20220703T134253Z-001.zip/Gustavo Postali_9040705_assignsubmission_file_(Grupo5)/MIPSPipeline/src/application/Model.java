package application;

//classe para as funções que não alteram diretamente os elementos da cena

public class Model {
	
	//função para definir a cor a serem pintados os barramentos de cada instrução,
	//a cor depende do indice da instrução na lista de instruções do programa;
	
	public String newColor(int index) {
		
		switch(index) {
			case 0:
				return "RED";
			case 1:
				return "YELLOW";
			case 2:
				return "GREEN";
			case 3:
				return "ORANGE";
			case 4:
				return "PINK";
			case 5:
				return "PURPLE";
			case 6:
				return "OLIVE";
			default:
				return null;
		}
	}
	
	
	//função que verifica se uma string é um número, usada para verificar a
	//validade de instruções do tipo I
	private boolean isNumeric(String s) {  
	    return s != null && s.matches("[-+]?\\d*\\.?\\d+");  
	}
	
	//função que verifica a validade de uma instrução a partir do vetor 
	//de argumentos da instrução;
	//verifica sea primeira palavra é uma instruçaõ entre "add, sub, and or, load,
	//stroe e bne;
	public boolean isValid(String[] tokens) {
		
		if(tokens.length != 4)
			return false;
		
		switch (tokens[0]) {
			case "add":
				for(int i=1;i<tokens.length;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				return true;
			case "sub":
				for(int i=1;i<tokens.length;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				return true;
			case "and":
				for(int i=1;i<tokens.length;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				return true;
			case "or":
				for(int i=1;i<tokens.length;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				return true;
			case "load":
				for(int i=1;i<tokens.length-1;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				if(!isNumeric(tokens[tokens.length-1])) {
					return false;
				}
				return true;
			case "store":
				for(int i=1;i<tokens.length-1;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				if(!isNumeric(tokens[tokens.length-1])){
					return false;
				}
				return true;
			case "bne":
				for(int i=1;i<tokens.length-1;i++) {
					if(tokens[i].equals("r1") || tokens[i].equals("r2") || tokens[i].equals("r3") || tokens[i].equals("r4")){
					}else {
						return false;
					}
				}
				if(!isNumeric(tokens[tokens.length-1])) {
					return false;
				}
				return true;
			default:
				return false;
		}
	}
}
