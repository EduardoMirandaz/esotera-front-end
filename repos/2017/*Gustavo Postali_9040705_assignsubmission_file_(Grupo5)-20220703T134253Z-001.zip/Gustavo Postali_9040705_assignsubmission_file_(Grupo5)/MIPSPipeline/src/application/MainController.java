package application;

import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.shape.Line;


//classe que controla todos os elementos da cena;

public class MainController {
	
	//função que divide a instrução a partir dos espaços e retorna um vetor com
	//seus componentes
	private String[] parseString(String s) {
		String delims = " ";
		String[] tokens = s.split(delims);
		return tokens;
	}

	
//----------------VARIÁVEIS PARA OS NÓS DA CENA----------------------------
	@FXML
	private Button addInstruction;
	@FXML
	private Label m1value;
	@FXML
	private Button m1Inc;
	@FXML
	private Label m2value;
	@FXML
	private Button m2Inc;
	@FXML
	private Label m3value;
	@FXML
	private Button m3Inc;
	@FXML
	private Label m4value;
	@FXML
	private Button m4Inc;
	@FXML
	private Button nextcc;
	@FXML
	private TextField instructionfield;
	@FXML
	private Label instructionif;
	@FXML
	private Label instructionid;
	@FXML
	private Label instructionexe;
	@FXML
	private Label instructionmem;
	@FXML
	private Label instructionwb;
	@FXML
	private Label pcvalue;
	@FXML
	private Label pcvalueadder;
	@FXML
	private Label pcvalueadder2;
	@FXML
	private Label immediateadder2;
	@FXML
	private Label r1value;
	@FXML
	private Label r2value;
	@FXML
	private Label r3value;
	@FXML
	private Label r4value;
	@FXML
	private Label alura;
	@FXML
	private Label alurb;
	@FXML 
	private Line pcadderoutline;
	@FXML 
	private Group fetchlines;
	@FXML
	private Group adder1outlines;
	@FXML
	private Line pcinline;
	@FXML
	private Group decodelines;
	@FXML
	private Group rbdecode;
	@FXML
	private Line tobar2016;
	@FXML
	private Line bar2016;
	@FXML
	private Group bar1511;
	@FXML
	private Group signalextend;
	@FXML
	private Line decodebranchline;
	@FXML
	private Line adder2out;
	@FXML
	private Line adder2pcin;
	@FXML
	private Group shiftedsignal;
	@FXML
	private Group extendedsignal;
	@FXML
	private Line aluabar;
	@FXML
	private Line rbexe;
	@FXML
	private Line rbmux2;
	@FXML
	private Line mux2out;
	@FXML
	private Group writedataexe;
	@FXML
	private Group aluoutexe;
	@FXML
	private Line mux31511;
	@FXML
	private Line mux32016;
	@FXML
	private Line mux3out;
	@FXML
	private Line extendedmux2;
	@FXML
	private Line aluoutmem;
	@FXML
	private Line mux4newpc;
	@FXML
	private Line writedatamem;
	@FXML
	private Line memoryaddress;
	@FXML
	private Line mux4zero;
	@FXML
	private Group mux4out;
	@FXML
	private Group aluzeroflag;
	@FXML
	private Line datamemout;
	@FXML
	private Line mux3outmem;
	@FXML
	private Group aluopresult;
	@FXML
	private Line memdatawb;
	@FXML
	private Group aluopresultwb;
	@FXML
	private Group mux5out;
	@FXML
	private Group wbregister;
//-------------------------------------------------------------------------
	
	
//------------------ATRIBUTOS AUXILIARES PARA A CLASSE---------------------- 
	private boolean start = true;	//flag que verifica se alguma instrução ja foi executada, usada para inicializar todas as variáveis
	private Model model = new Model();  //instancia da classe que ppossui métodos necessários e que não alteram a cena
	private String[] argsif = new String[4];	//argumentos da instrução no estágio de fetch
	private String[] argsid = new String[4];	//argumentos da instrução no estágio de decode
	private String[] argsexe = new String[4];	//argumentos da instrução no estágio de execute
	private String[] argsmem = new String[4];	//argumentos da instrução no estágio de memmory
	private String[] argswb = new String[4];	//argumentos da instrução no estágio de writeback
	private ArrayList<String> instructions = new ArrayList<String>(); //lista das intruções
	private int aluResult; //guarda o resultado da operação realizada na ula
	private int wbData; //guarda o resultado da operação realizada na ula para usar no estágio de writeback
	private String ifColor;	//armazena a cor da instrução na estágio de fetch 
	private String idColor;	//armazena a cor da instrução na estágio de decode
	private String exeColor;//armazena a cor da instrução na estágio de execute
	private String memColor;//armazena a cor da instrução na estágio de memory
	private String wbColor;////armazena a cor da instrução na estágio de writeback
//-------------------------------------------------------------------------------
	
	//inicializa as variaveis necessarias
	private void initialize() {
		
		instructionif.setText("");
		instructionid.setText("");
		instructionexe.setText("");
		instructionmem.setText("");
		instructionwb.setText("");
		
		ifColor = "BLACK";
		idColor = "BLACK";
		exeColor = "BLACK";
		memColor = "BLACK";
		wbColor = "BLACK";
		
		for (int i=0;i<4;i++) {
			argsif[i] = "0";
			argsid[i] = "0";
			argsexe[i] = "0";
			argsmem[i] = "0";
			argswb[i] = "0";
		}
	}

	
	//funções que aumentam o valor de cada posição na memoria de dados 
	//quando estes são clicados
	@FXML
	public void increaseM1Value(ActionEvent e) {
		m1value.setText(Integer.toString(Integer.parseInt(m1value.getText())+1));
	}
	@FXML
	public void increaseM2Value(ActionEvent e) {
		m2value.setText(Integer.toString(Integer.parseInt(m2value.getText())+1));
	}
	@FXML
	public void increaseM3Value(ActionEvent e) {
		m3value.setText(Integer.toString(Integer.parseInt(m3value.getText())+1));
	}
	@FXML
	public void increaseM4Value(ActionEvent e) {
		m4value.setText(Integer.toString(Integer.parseInt(m4value.getText())+1));
	}
	
	//adiciona uma instrução a lista se esta for uma instrução valida
	@FXML
	public void addInstruction(ActionEvent e) {
		String instruction = instructionfield.getText();
		String[] tokens = parseString(instruction);
		
		if(tokens[0].equals("NOP")) {
			instructions.add(instruction);
			instructionfield.setText("");
		}else if(!model.isValid(tokens)) {			
			instructionfield.setText("INVALID INSTRUCTION");
			return;
		}
		instructions.add(instruction);
		instructionfield.setText("");
	}
	
	//passa para o próximo ciclo de clock quando o botão é clicado
	@FXML
	public void nextClockCycle(ActionEvent e) {
		if(start) {
			initialize();
			start = false;
		}
		//FETCH
		//passa as instruções de um estágio de clock para o próximo
		instructionwb.setText(instructionmem.getText());
		instructionmem.setText(instructionexe.getText());
		instructionexe.setText(instructionid.getText());
		instructionid.setText(instructionif.getText());
		if(Integer.parseInt(pcvalue.getText())/4 < instructions.size()){
			instructionif.setText(instructions.get(Integer.parseInt(pcvalue.getText())/4));
		}else {
			instructionif.setText("NOP");
		}
		argswb = argsmem;
		wbColor = memColor;
		argsmem = argsexe;
		memColor = exeColor;
		argsexe = argsid;
		exeColor = idColor;
		argsid = argsif;
		idColor = ifColor;
		argsif = parseString(instructionif.getText());
		ifColor = model.newColor((Integer.parseInt(pcvalue.getText()))/4%7);
		pcvalueadder.setText(pcvalue.getText());

		//altera as cores dos barramentos
		for(Node n : fetchlines.getChildren()) {
			n.setStyle("-fx-stroke: " + ifColor);
		}
		for(Node n : adder1outlines.getChildren()) {
			n.setStyle("-fx-stroke: " + ifColor);
		}
		pcadderoutline.setStyle("-fx-stroke: " + "BLACK");
		if(argsif[0].equals("bne")) {
			pcadderoutline.setStyle("-fx-stroke: " + ifColor);
			pcvalueadder2.setText(Integer.toString(Integer.parseInt(pcvalue.getText())));
		}
		if(argsmem[0].equals("bne")) {
			if(aluResult == 0) {
				pcvalue.setText(Integer.toString(Integer.parseInt(pcvalueadder2.getText())+Integer.parseInt(immediateadder2.getText())));
				pcinline.setStyle("-fx-stroke: " + memColor);
			}else {
				pcvalue.setText(Integer.toString(Integer.parseInt(pcvalue.getText())+4));
				pcinline.setStyle("-fx-stroke: " + ifColor);
			}
		}else {
			pcvalue.setText(Integer.toString(Integer.parseInt(pcvalue.getText())+4));
			pcinline.setStyle("-fx-stroke: " + ifColor);
		}
		
		//DECODE
		//altera as cores dos barramentos
		if(argsid[0].equals("NOP")) {
			idColor = "BLACK";
			for(Node n : decodelines.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			for(Node n : rbdecode.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			tobar2016.setStyle("-fx-stroke: " + idColor);
			for(Node n : bar1511.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			bar2016.setStyle("-fx-stroke: " + idColor);
			for(Node n : signalextend.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			decodebranchline.setStyle("-fx-stroke: " + idColor);
			
		}
		for(Node n : decodelines.getChildren()) {
			n.setStyle("-fx-stroke: " + idColor);
		}
		if(argsid[0].equals("add") || argsid[0].equals("sub") || argsid[0].equals("and") || argsid[0].equals("or")) {
			for(Node n : rbdecode.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			tobar2016.setStyle("-fx-stroke: " + idColor);
			for(Node n : bar1511.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			for(Node n : signalextend.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			bar2016.setStyle("-fx-stroke: " + "BLACK");
			decodebranchline.setStyle("-fx-stroke: " + "BLACK");
		}else if(argsid[0].equals("load")) {
			tobar2016.setStyle("-fx-stroke: " + idColor);
			bar2016.setStyle("-fx-stroke: " + idColor);
			for(Node n : signalextend.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			for(Node n : bar1511.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : rbdecode.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			decodebranchline.setStyle("-fx-stroke: " + "BLACK");
		}else if (argsid[0].equals("store")){
			for(Node n : rbdecode.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}			
			tobar2016.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : bar1511.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			bar2016.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : signalextend.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			decodebranchline.setStyle("-fx-stroke: " + "BLACK");
		}
		else if (argsid[0].equals("bne")){
			for(Node n : rbdecode.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}			tobar2016.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : bar1511.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			bar2016.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : signalextend.getChildren()) {
				n.setStyle("-fx-stroke: " + idColor);
			}
			decodebranchline.setStyle("-fx-stroke: " + idColor);
		}
		
		
		//WB
		//altera as cores dos barramentos e valores dos registradores
		if(argswb[0].equals("NOP")||argswb[0].equals("store")||argswb[0].equals("bne")) {
			wbColor = "BLACK";
			memdatawb.setStyle("-fx-stroke: " + wbColor);
			for(Node n : aluopresultwb.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
			for(Node n : mux5out.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
			for(Node n : wbregister.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
		}else if(argswb[0].equals("add") || argswb[0].equals("sub") || argswb[0].equals("and") || argswb[0].equals("or")) {	
			if(argswb[1].equals("r1")) 
				r1value.setText(Integer.toString(wbData));
			else if(argswb[1].equals("r2")) 
				r2value.setText(Integer.toString(wbData));
			else if(argswb[1].equals("r3")) 
				r3value.setText(Integer.toString(wbData));
			else if(argswb[1].equals("r4")) 
				r4value.setText(Integer.toString(wbData));
			
			memdatawb.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : aluopresultwb.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
			for(Node n : mux5out.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
			for(Node n : wbregister.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
		} else if(argswb[0].equals("load")) {
			if(argswb[1].equals("r1")) {
				if(wbData%4 == 0) 
					r1value.setText(m1value.getText());
				else if(wbData%4 == 1) 
					r1value.setText(m2value.getText());
				else if(wbData%4 == 2) 
					r1value.setText(m3value.getText());
				else if(wbData%4 == 3) 
					r1value.setText(m4value.getText());
			}else if(argswb[1].equals("r2")) {
				if(wbData%4 == 0) 
					r2value.setText(m1value.getText());
				else if(wbData%4 == 1) 
					r2value.setText(m2value.getText());
				else if(wbData%4 == 2) 
					r2value.setText(m3value.getText());
				else if(wbData%4 == 3) 
					r2value.setText(m4value.getText());
			}else if(argswb[1].equals("r3")) {
				if(wbData%4 == 0) 
					r3value.setText(m1value.getText());
				else if(wbData%4 == 1) 
					r3value.setText(m2value.getText());
				else if(wbData%4 == 2) 
					r3value.setText(m3value.getText());
				else if(wbData%4 == 3)
					r3value.setText(m4value.getText());
			}else if(argswb[1].equals("r4")) {
				if(wbData%4 == 0) 
					r4value.setText(m1value.getText());
				else if(wbData%4 == 1) 
					r4value.setText(m2value.getText());
				else if(wbData%4 == 2) 
					r4value.setText(m3value.getText());
				else if(wbData%4 == 3) 
					r4value.setText(m4value.getText());
			}
			memdatawb.setStyle("-fx-stroke: " + wbColor);
			for(Node n : aluopresultwb.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : mux5out.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
			for(Node n : wbregister.getChildren()) {
				n.setStyle("-fx-stroke: " + wbColor);
			}
		}
		
		//MEM
		//altera as cores dos barramentos e os valores das posições de memória
		if(argsmem[0].equals("NOP")) {
			memColor = "BLACK";
			aluoutmem.setStyle("-fx-stroke: " + memColor);
			memoryaddress.setStyle("-fx-stroke: " + memColor);
			writedatamem.setStyle("-fx-stroke: " + memColor);
			for(Node n : aluopresult.getChildren()) {
				n.setStyle("-fx-stroke: " + memColor);
			}
			for(Node n : aluzeroflag.getChildren()) {
				n.setStyle("-fx-stroke: " + memColor);
			}
			mux3outmem.setStyle("-fx-stroke: " + memColor);
			datamemout.setStyle("-fx-stroke: " + memColor);
			mux4zero.setStyle("-fx-stroke: " + memColor);
			mux4newpc.setStyle("-fx-stroke: " + memColor);
			for(Node n : mux4out.getChildren()) {
				n.setStyle("-fx-stroke: " + memColor);
			}
		}else if(argsmem[0].equals("store")) {
			if(argsmem[1].equals("r1")) {
				if(aluResult%4 == 0) 
					m1value.setText(r1value.getText());
				else if(aluResult%4 == 1) 
					m2value.setText(r1value.getText());
				else if(aluResult%4 == 2) 
					m3value.setText(r1value.getText());
				else if(aluResult%4 == 3) 
					m4value.setText(r1value.getText());
			}else if(argsmem[1].equals("r2")) {
				if(aluResult%4 == 0) 
					m1value.setText(r2value.getText());
				else if(aluResult%4 == 1) 
					m2value.setText(r2value.getText());
				else if(aluResult%4 == 2) 
					m3value.setText(r2value.getText());
				else if(aluResult%4 == 3) 
					m4value.setText(r2value.getText());
			}else if(argsmem[1].equals("r3")) {
				if(aluResult%4 == 0) 
					m1value.setText(r3value.getText());
				else if(aluResult%4 == 1) 
					m2value.setText(r3value.getText());
				else if(aluResult%4 == 2) 
					m3value.setText(r3value.getText());
				else if(aluResult%4 == 3) 
					m4value.setText(r3value.getText());
			}else if(argsmem[1].equals("r4")) {
				if(aluResult%4 == 0) 
					m1value.setText(r4value.getText());
				else if(aluResult%4 == 1) 
					m2value.setText(r4value.getText());
				else if(aluResult%4 == 2) 
					m3value.setText(r4value.getText());
				else if(aluResult%4 == 3) 
					m4value.setText(r4value.getText());
			}
			aluoutmem.setStyle("-fx-stroke: " + memColor);
			memoryaddress.setStyle("-fx-stroke: " + memColor);
			writedatamem.setStyle("-fx-stroke: " + memColor);
			for(Node n : aluopresult.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : aluzeroflag.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			mux3outmem.setStyle("-fx-stroke: " + "BLACK");
			datamemout.setStyle("-fx-stroke: " + "BLACK");
			mux4zero.setStyle("-fx-stroke: " + "BLACK");
			mux4newpc.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : mux4out.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
		}else if(argsmem[0].equals("add") || argsmem[0].equals("sub") || argsmem[0].equals("and") || argsmem[0].equals("or")) {
			aluoutmem.setStyle("-fx-stroke: " + memColor);
			memoryaddress.setStyle("-fx-stroke: " + "BLACK");
			writedatamem.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : aluopresult.getChildren()) {
				n.setStyle("-fx-stroke: " + memColor);
			}
			for(Node n : aluzeroflag.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			mux3outmem.setStyle("-fx-stroke: " + memColor);
			datamemout.setStyle("-fx-stroke: " + "BLACK");
			mux4zero.setStyle("-fx-stroke: " + "BLACK");
			mux4newpc.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : mux4out.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
		}else if(argsmem[0].equals("load")) {
			aluoutmem.setStyle("-fx-stroke: " + memColor);
			memoryaddress.setStyle("-fx-stroke: " + memColor);
			writedatamem.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : aluopresult.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : aluzeroflag.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			mux3outmem.setStyle("-fx-stroke: " + memColor);
			datamemout.setStyle("-fx-stroke: " + memColor);
			mux4zero.setStyle("-fx-stroke: " + "BLACK");
			mux4newpc.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : mux4out.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
		}
		else if(argsmem[0].equals("bne")) {
			aluoutmem.setStyle("-fx-stroke: " + memColor);
			memoryaddress.setStyle("-fx-stroke: " + "BLACK");
			writedatamem.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : aluopresult.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : aluzeroflag.getChildren()) {
				n.setStyle("-fx-stroke: " + memColor);
			}
			mux3outmem.setStyle("-fx-stroke: " + "BLACK");
			datamemout.setStyle("-fx-stroke: " + "BLACK");
			mux4zero.setStyle("-fx-stroke: " + memColor);
			mux4newpc.setStyle("-fx-stroke: " + memColor);
			for(Node n : mux4out.getChildren()) {
				n.setStyle("-fx-stroke: " + memColor);
			}
		}
		wbData = aluResult;
		
		//EXE
		//altera as cores e realiza as operações da ula
		if(argsexe[0].equals("NOP")) {
			exeColor = "BLACK";
			adder2out.setStyle("-fx-stroke: " + exeColor);
			adder2pcin.setStyle("-fx-stroke: " + exeColor);
			for(Node n : shiftedsignal.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			for(Node n : extendedsignal.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			aluabar.setStyle("-fx-stroke: " + exeColor);
			rbexe.setStyle("-fx-stroke: " + exeColor);
			rbmux2.setStyle("-fx-stroke: " + exeColor);
			mux2out.setStyle("-fx-stroke: " + exeColor);
			for(Node n : writedataexe.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			for(Node n : aluoutexe.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			mux3out.setStyle("-fx-stroke: " + exeColor);
			mux32016.setStyle("-fx-stroke: " + exeColor);
			mux31511.setStyle("-fx-stroke: " + exeColor);
			extendedmux2.setStyle("-fx-stroke: " + exeColor);
		}else if(argsexe[0].equals("add") || argsexe[0].equals("sub") || argsexe[0].equals("and") || argsexe[0].equals("or")) {
			if(argsexe[2].equals("r1"))
				alura.setText(r1value.getText());
			else if(argsexe[2].equals("r2"))
				alura.setText(r2value.getText());
			else if(argsexe[2].equals("r3"))
				alura.setText(r3value.getText());
			else if(argsexe[2].equals("r4"))
				alura.setText(r4value.getText());
			if(argsexe[3].equals("r1"))
				alurb.setText(r1value.getText());
			else if(argsexe[3].equals("r2"))
				alurb.setText(r2value.getText());
			else if(argsexe[3].equals("r3"))
				alurb.setText(r3value.getText());
			else if(argsexe[3].equals("r4"))
				alurb.setText(r4value.getText());
			
			adder2out.setStyle("-fx-stroke: " + "BLACK");
			adder2pcin.setStyle("-fx-stroke: " + "BLACK");
			for(Node n : shiftedsignal.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : extendedsignal.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			aluabar.setStyle("-fx-stroke: " + exeColor);
			rbexe.setStyle("-fx-stroke: " + exeColor);
			rbmux2.setStyle("-fx-stroke: " + exeColor);
			mux2out.setStyle("-fx-stroke: " + exeColor);
			for(Node n : writedataexe.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : aluoutexe.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			mux3out.setStyle("-fx-stroke: " + exeColor);
			mux32016.setStyle("-fx-stroke: " + "BLACK");
			mux31511.setStyle("-fx-stroke: " + exeColor);
			extendedmux2.setStyle("-fx-stroke: " + "BLACK");
			
		} else if(argsexe[0].equals("load") || argsexe[0].equals("store")) {
			if(argsexe[2].equals("r1"))
				alura.setText(r1value.getText());
			else if(argsexe[2].equals("r2"))
				alura.setText(r2value.getText());
			else if(argsexe[2].equals("r3"))
				alura.setText(r3value.getText());
			else if(argsexe[2].equals("r4"))
				alura.setText(r4value.getText());
			alurb.setText(argsexe[3]);
			
			if(argsexe[0].equals("load")) {
				adder2out.setStyle("-fx-stroke: " + "BLACK");
				adder2pcin.setStyle("-fx-stroke: " + "BLACK");
				for(Node n : shiftedsignal.getChildren()) {
					n.setStyle("-fx-stroke: " + "BLACK");
				}
				for(Node n : extendedsignal.getChildren()) {
					n.setStyle("-fx-stroke: " + exeColor);
				}
				aluabar.setStyle("-fx-stroke: " + exeColor);
				rbexe.setStyle("-fx-stroke: " + "BLACK");
				rbmux2.setStyle("-fx-stroke: " + "BLACK");
				extendedmux2.setStyle("-fx-stroke: " + exeColor);
				mux2out.setStyle("-fx-stroke: " + exeColor);
				for(Node n : writedataexe.getChildren()) {
					n.setStyle("-fx-stroke: " + "BLACK");
				}
				for(Node n : aluoutexe.getChildren()) {
					n.setStyle("-fx-stroke: " + exeColor);
				}
				mux3out.setStyle("-fx-stroke: " + exeColor);
				mux32016.setStyle("-fx-stroke: " + exeColor);
				mux31511.setStyle("-fx-stroke: " + "BLACK");
			}else {
				adder2out.setStyle("-fx-stroke: " + "BLACK");
				adder2pcin.setStyle("-fx-stroke: " + "BLACK");
				for(Node n : shiftedsignal.getChildren()) {
					n.setStyle("-fx-stroke: " + "BLACK");
				}
				for(Node n : extendedsignal.getChildren()) {
					n.setStyle("-fx-stroke: " + exeColor);
				}
				aluabar.setStyle("-fx-stroke: " + exeColor);
				rbexe.setStyle("-fx-stroke: " + exeColor);
				rbmux2.setStyle("-fx-stroke: " + "BLACK");
				extendedmux2.setStyle("-fx-stroke: " + exeColor);
				mux2out.setStyle("-fx-stroke: " + exeColor);
				for(Node n : writedataexe.getChildren()) {
					n.setStyle("-fx-stroke: " + exeColor);
				}
				for(Node n : aluoutexe.getChildren()) {
					n.setStyle("-fx-stroke: " + exeColor);
				}
				mux3out.setStyle("-fx-stroke: " + "BLACK");
				mux32016.setStyle("-fx-stroke: " + "BLACK");
				mux31511.setStyle("-fx-stroke: " + "BLACK");
			}
			
		}else if(argsexe[0].equals("bne")) {
			if(argsexe[1].equals("r1"))
				alura.setText(r1value.getText());
			else if(argsexe[1].equals("r2"))
				alura.setText(r2value.getText());
			else if(argsexe[1].equals("r3"))
				alura.setText(r3value.getText());
			else if(argsexe[1].equals("r4"))
				alura.setText(r4value.getText());
			if(argsexe[2].equals("r1"))
				alurb.setText(r1value.getText());
			else if(argsexe[2].equals("r2"))
				alurb.setText(r2value.getText());
			else if(argsexe[2].equals("r3"))
				alurb.setText(r3value.getText());
			else if(argsexe[2].equals("r4"))
				alurb.setText(r4value.getText());
			immediateadder2.setText(argsexe[3]);
			
			adder2out.setStyle("-fx-stroke: " + exeColor);
			adder2pcin.setStyle("-fx-stroke: " + exeColor);
			for(Node n : shiftedsignal.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			for(Node n : extendedsignal.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			aluabar.setStyle("-fx-stroke: " + exeColor);
			rbexe.setStyle("-fx-stroke: " + exeColor);
			rbmux2.setStyle("-fx-stroke: " + exeColor);
			mux2out.setStyle("-fx-stroke: " + exeColor);
			for(Node n : writedataexe.getChildren()) {
				n.setStyle("-fx-stroke: " + "BLACK");
			}
			for(Node n : aluoutexe.getChildren()) {
				n.setStyle("-fx-stroke: " + exeColor);
			}
			mux3out.setStyle("-fx-stroke: " + "BLACK");
			mux32016.setStyle("-fx-stroke: " + "BLACK");
			mux31511.setStyle("-fx-stroke: " + "BLACK");
			extendedmux2.setStyle("-fx-stroke: " + "BLACK");
		}
		if (argsexe[0].equals("add") || argsexe[0].equals("load") || argsexe[0].equals("store"))
			aluResult = Integer.parseInt(alura.getText())+Integer.parseInt(alurb.getText());
		else if (argsexe[0].equals("sub"))
			aluResult = Integer.parseInt(alura.getText())-Integer.parseInt(alurb.getText());
		else if (argsexe[0].equals("and") || argsexe[0].equals("or") || argsexe[0].equals("bne"))
			aluResult = alura.getText().equals(alurb.getText()) ? 1 : 0;		
		
	}
	
}
	
