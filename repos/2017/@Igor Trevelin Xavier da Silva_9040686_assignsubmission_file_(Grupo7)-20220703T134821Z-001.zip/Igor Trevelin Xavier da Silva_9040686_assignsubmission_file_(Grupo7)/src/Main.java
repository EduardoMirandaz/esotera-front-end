public class Main {
	
	/* Main */
	public static void main(String args[]) {
		new Thread(new Simulador()).run();
	}
}