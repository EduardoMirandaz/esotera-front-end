Alunos:

Leonardo Cesar Cerqueira	8937483
Lucas Kassouf Crocomo		8937420
Sabrina Faceroli Tridico 	9066452

Para a execu��o desse simulador, � necess�rio ter instalado Python 3.6.

Como executar:
Neste diret�rio, execute o comando

python Interface.py ./tests/test.in

O simulador ser� executado. Para realizar a simula��o, basta clicar no �cone "Clock it!" quantas vezes for necess�rio (at� que a execu��o termine) e os registradores ser�o atualizados.
Lembrando que, nesse caso, o simulador ir� simular o c�digo situado no arquivo "test.in" da pasta tests. Para simular outro c�digo, apenas troque o conte�do deste arquivo ou referencie o novo arquivo (caminho para o arquivo) no comando.

EXTRA:
Vale lembrar, tamb�m, que este trabalho trata dependencias de dados e de controle, utilizando forwarding e stalls.