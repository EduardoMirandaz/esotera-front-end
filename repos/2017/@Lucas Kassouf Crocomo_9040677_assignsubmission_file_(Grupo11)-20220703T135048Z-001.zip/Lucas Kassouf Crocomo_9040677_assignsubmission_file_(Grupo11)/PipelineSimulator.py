"""
Alunos:

Leonardo Cesar Cerqueira    8937483
Lucas Kassouf Crocomo       8937420
Sabrina Faceroli Tridico    9066452
"""

from Instruction import *
import collections 

class PipelineSimulator(object): 
    operations = {'add' : '+', 'addi' : '+', 'sub' : '-', 'subi' : '-', 
                  'and' : '&', 'andi' : '&', 'or'  : '|', 'ori'  : '|'} 
                  
    def __init__(self,instrCollection):
        self.instrCount = 0
        self.cycles = 0
        self.hazardList = []
        self.__done = False
        self.branched = False
        self.stall = False
        
        self.pipeline = [None for x in range(0,5)]

        self.pipeline[0] = FetchStage(Nop, None, self)
        self.pipeline[1] = WriteStage(Nop, None, self)
        self.pipeline[2] = ReadStage(Nop, None, self)
        self.pipeline[3] = ExecStage(Nop, None, self)
        self.pipeline[4] = DataStage(Nop, None, self)

        self.simulationInfo = []
        
        self.registers = dict([("$r%s" % x, 0) for x in range(32)]) 
        
        self.instructionMemory = dict([(x*4, 0) for x in range(int(0xffc/4))])

        self.dataMemory = dict([(x*4, 0) for x in range(int(0x4000/4))])

        self.programCounter = 0x1000

        self.instrCollection = instrCollection
       
        y=0
        for instr in self.instrCollection:
           self.instructionMemory[0x1000 + y] = instr
           y += 4
    
    def step(self):
        self.cycles +=1
        cycleInfo = DebugInfo(self.cycles)

        self.pipeline[1] = WriteStage(self.pipeline[4].instr, self.pipeline[4], self)
        if self.stall :
            self.pipeline[4] = DataStage(Nop, None, self)
            self.stall = False
        else :
            self.pipeline[4] = DataStage(self.pipeline[3].instr, self.pipeline[3], self)
            self.pipeline[3] = ExecStage(self.pipeline[2].instr, self.pipeline[2], self)
            self.pipeline[2] = ReadStage(self.pipeline[0].instr, self.pipeline[0], self)
            self.pipeline[0] = FetchStage(None, None, self)
         
        for pi in self.pipeline:
                pi.advance()

        if (self.pipeline[0] is not None):
            cycleInfo.pipelineRegs['IF/ID']['IR'] = self.pipeline[0].ir[:] if self.pipeline[0].ir else "Nop"
            cycleInfo.pipelineRegs['IF/ID']['PC'] = self.pipeline[0].pc

        if (self.pipeline[2] is not None):
            cycleInfo.pipelineRegs['ID/EX']['IR'] = self.pipeline[2].ir[:] if self.pipeline[2].ir else "Nop"
            cycleInfo.pipelineRegs['ID/EX']['PC'] = self.pipeline[2].pc
            cycleInfo.pipelineRegs['ID/EX']['A'] = self.pipeline[2].a
            cycleInfo.pipelineRegs['ID/EX']['B'] = self.pipeline[2].b
            cycleInfo.pipelineRegs['ID/EX']['IMM'] = self.pipeline[2].imm

        if (self.pipeline[3] is not None):
            cycleInfo.pipelineRegs['EX/MEM']['IR'] = self.pipeline[3].ir[:] if self.pipeline[3].ir else "Nop"
            cycleInfo.pipelineRegs['EX/MEM']['COND'] = self.pipeline[3].cond
            cycleInfo.pipelineRegs['EX/MEM']['ALUOUT'] = self.pipeline[3].aluout
            cycleInfo.pipelineRegs['EX/MEM']['B'] = self.pipeline[3].b

        if (self.pipeline[4] is not None):
            cycleInfo.pipelineRegs['MEM/WB']['IR'] = self.pipeline[4].ir[:] if self.pipeline[4].ir else "Nop"
            cycleInfo.pipelineRegs['MEM/WB']['LMD'] = self.pipeline[4].lmd
            cycleInfo.pipelineRegs['MEM/WB']['ALUOUT'] = self.pipeline[4].aluout

        for key, value in self.registers.items():
            cycleInfo.mainRegs[key] = self.registers[key]

        if (self.pipeline[1].instr.controls['regWrite']) :
            self.hazardList.pop(0)
        
        self.simulationInfo.append(cycleInfo)

        self.checkDone()

        if self.stall or self.branched:
            self.programCounter -= 4 
            self.branched = False
    
    def checkDone(self):
        self.__done = True
        for pi in self.pipeline:
            if pi.instr is not Nop:
                self.__done = False
    
    def run(self):
        while not self.__done:
            self.step()
        return self.simulationInfo
    
    def getForwardVal(self, regName):
        """ Forward the proper value based on the given register name
            If the value is not ready, return "HELLO" 
        """
        if (self.pipeline[4] is not Nop 
                and self.pipeline[4].instr.result is not None
                and self.pipeline[4].instr.values['dest'] == regName) :
                    return self.pipeline[4].instr.result
        elif (self.pipeline[1] is not Nop
                and self.pipeline[1].instr.values['dest'] == regName ):
                    return self.pipeline[1].instr.result
        else:
            return "HELLO" 

class PipelineStage(object):
    def __init__(self, instruction, stage, simulator):
        self.instr = instruction
        self.previousStage = stage
        self.simulator = simulator
        self.ir = None
        self.pc = 0
        self.a = 0
        self.b = 0
        self.imm = 0
        self.aluout = 0
        self.cond = False
        self.lmd = 0
        
    def advance(self):
        pass
    
    def __repr__(self):
        return str(self) + ':\t' + str(self.instr)
    
class FetchStage(PipelineStage):
    def advance(self):
        if self.simulator.programCounter < (len(self.simulator.instrCollection) * 4 + 0x1000):
            self.simulator.instrCount += 1
            self.instr = self.simulator.instructionMemory[self.simulator.programCounter]
        else:
            self.instr = Nop
        self.simulator.programCounter += 4

        self.ir = str(self.instr)[:]
        self.pc = self.simulator.programCounter
         
    def __str__(self):
        return 'Fetch Stage\t'
    
class ReadStage(PipelineStage):
    def advance(self):
        immed = 0
        areg = 0
        breg = 0
        if(self.instr.controls['regRead']):
            self.instr.source1RegValue = self.simulator.registers[self.instr.values['s1']]
            areg = self.instr.source1RegValue

            if (self.instr.values['immed'] and
                 not( self.instr.values['op'] == 'bne' or self.instr.values['op'] == 'beq' 
                     or self.instr.values['op'] =='lw' or self.instr.values['op'] =='sw')): 
                if "0x" in self.instr.values['immed']:
                    self.instr.source2RegValue = int(self.instr.values['immed'],16)
                else :
                    self.instr.source2RegValue = int(self.instr.values['immed'])
                immed = self.instr.source2RegValue
                
            elif self.instr.values['s2']:
                self.instr.source2RegValue = self.simulator.registers[self.instr.values['s2']]
                breg = self.instr.source2RegValue
                    
        if self.instr.values['op'] == 'j':
            if "0x" in self.instr.values['target']:
                    targetval = int(self.instr.values['target'], 16)
            else :
                    targetval = int(self.instr.values['target'])
            self.simulator.programCounter = targetval
            self.simulator.pipeline[0] = FetchStage(Nop, self)

        if (self.previousStage is not None):
            self.ir = str(self.previousStage.ir)[:]
            self.pc = self.previousStage.pc
            self.imm = immed
            self.a = areg
            self.b = breg

    def __str__(self):
        return 'Read from Register'
    
class ExecStage(PipelineStage):
    def advance(self):
        ALUResult = 0
        if self.instr is not Nop and self.instr.controls['aluop']:
            #se temos um hazard em s1 ou s2, pegamos o valor de outras instruções no pipeline
            if self.instr.values['s1'] in self.simulator.hazardList :
                forwardVal = self.simulator.getForwardVal(self.instr.values['s1'])
                if forwardVal != "HELLO":
                    self.instr.source1RegValue = forwardVal
                else :
                    self.simulator.stall = True
                    return
            if self.instr.values['s2'] in self.simulator.hazardList :
                forwardVal = self.simulator.getForwardVal(self.instr.values['s2'])
                if forwardVal != "HELLO" :
                    self.instr.source2RegValue = forwardVal
                else :
                    self.simulator.stall = True
                    return
            #colocamos o registrador destino para a lista de hazards
            if self.instr.controls['regWrite'] :
                self.simulator.hazardList.append(self.instr.values['dest'])    

            if  self.instr.values['op'] == 'lw':
                self.instr.source1RegValue = self.instr.source1RegValue + int(self.instr.values['immed'])
                ALUResult = self.instr.source1RegValue
            elif  self.instr.values['op'] == 'sw':
                self.instr.source2RegValue = self.instr.source2RegValue + int(self.instr.values['immed'])
                ALUResult = self.instr.source2RegValue

            elif self.instr.values['op'] == 'jr':
                self.simulator.programCounter = self.instr.source1RegValue
                self.simulator.pipeline[0] = FetchStage(Nop, self)
                self.simulator.pipeline[2] = ReadStage(Nop, self)
            elif self.instr.values['op'] == 'bne':
                if self.instr.source1RegValue != self.instr.source2RegValue:
                    self.simulator.programCounter = self.simulator.programCounter + (int(self.instr.values['immed']) * 4) - 8
                    ALUResult = self.simulator.programCounter
                    self.simulator.pipeline[0] = FetchStage(Nop, None, self)
                    self.simulator.pipeline[2] = ReadStage(Nop, None, self)
                    self.simulator.branched = True
            elif self.instr.values['op'] == 'beq':
                if self.instr.source1RegValue == self.instr.source2RegValue:
                    self.simulator.programCounter = self.simulator.programCounter + (int(self.instr.values['immed']) * 4) - 8
                    ALUResult = self.simulator.programCounter
                    self.simulator.pipeline[0] = FetchStage(Nop, None, self)
                    self.simulator.pipeline[2] = ReadStage(Nop, None, self)
                    self.simulator.branched = True
            else :         
                if (self.instr.values['op'] == 'slt'):
                    val = 1 if self.instr.source1RegValue < self.instr.source2RegValue else 0
                    self.instr.result = val
                elif (self.instr.values['op'] == 'nor'):
                    self.instr.result = ~(self.instr.source1RegValue | self.instr.source2RegValue)
                else:
                    self.instr.result = eval("%d %s %d" % 
                                                        (self.instr.source1RegValue,
                                                        self.simulator.operations[self.instr.values['op']],
                                                        self.instr.source2RegValue))
                ALUResult = self.instr.result

        if (self.previousStage is not None):
            self.ir = str(self.previousStage.ir)[:]
            self.aluout = ALUResult
            self.cond = self.simulator.branched
            self.b = self.previousStage.b
                
    def __str__(self):
        return 'Execute Stage\t'
    
class DataStage(PipelineStage):
    def advance(self):
        if self.instr.controls['writeMem']:
            self.simulator.dataMemory[self.instr.source2RegValue] = self.instr.source1RegValue
        elif self.instr.controls['readMem']:
            self.instr.result = self.simulator.dataMemory[self.instr.source1RegValue]

        if (self.previousStage is not None):
            self.ir = str(self.previousStage.ir)[:]
            self.aluout = self.previousStage.aluout
            self.lmd = self.instr.result

    def __str__(self):
        return 'Main Memory'
    
class WriteStage(PipelineStage):
    def advance(self):
        if self.instr.controls['regWrite']:
            if self.instr.values['dest'] == '$r0':
                pass
            elif self.instr.values['dest']:
                self.simulator.registers[self.instr.values['dest']] = self.instr.result
                
    def __str__(self):
        return 'Write to Register'

class DebugInfo:
    def __init__(self, cycle):
        self.cycle = cycle
        
        self.mainRegs = {}

        self.pipelineRegs = {}
        self.pipelineRegs['IF/ID'] = {}
        self.pipelineRegs['IF/ID']['IR'] = ''
        self.pipelineRegs['IF/ID']['PC'] = 0

        self.pipelineRegs['ID/EX'] = {}
        self.pipelineRegs['ID/EX']['A'] = 0
        self.pipelineRegs['ID/EX']['B'] = 0
        self.pipelineRegs['ID/EX']['PC'] = 0
        self.pipelineRegs['ID/EX']['IR'] = ''
        self.pipelineRegs['ID/EX']['IMM'] = 0

        self.pipelineRegs['EX/MEM'] = {}
        self.pipelineRegs['EX/MEM']['IR'] = ''
        self.pipelineRegs['EX/MEM']['ALUOUT'] = 0
        self.pipelineRegs['EX/MEM']['COND'] = False
        self.pipelineRegs['EX/MEM']['B'] = 0

        self.pipelineRegs['MEM/WB'] = {}
        self.pipelineRegs['MEM/WB']['IR'] = ''
        self.pipelineRegs['MEM/WB']['ALUOUT'] = 0
        self.pipelineRegs['MEM/WB']['LMD'] = 0