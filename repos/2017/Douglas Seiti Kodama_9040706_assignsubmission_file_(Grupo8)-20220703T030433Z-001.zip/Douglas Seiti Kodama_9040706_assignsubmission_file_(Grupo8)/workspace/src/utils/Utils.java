/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

public class Utils {
    
    /**
     * Converte string binária para um número inteiro.
     * @param binNumber string de um número em binário.
     * @return valor em inteiro do número binário convertido.
     **/
    static public int btoi(String binNumber) {
        long l = Long.parseLong(binNumber, 2);
        int i = (int) l;
        return i;
    }
    
    /**
     * Converte um número inteiro para uma string binária.
     * @param number o número inteiro a ser convertido.
     * @return string binária do número convertido.
     **/
    static public String itob(int number) {
        return Integer.toBinaryString(number);
    }
    
    /**
     * Converte um número inteiro para uma string binária.
     * @param number o número a ser convertido.
     * @param nbits tamanho da string (em número de bits).
     * @return string binária do número convertido.
     **/
    static public String itob(int number, int nbits) {
        int i;
        String extension = "";
        String binNumber = Integer.toBinaryString(number);
        
        for (i = 0; i < nbits - binNumber.length(); ++i) { // Extensão de sinal para a String ter nbits caracteres
            extension += "0";
        }
        
        return extension + binNumber;
    }
    
}
