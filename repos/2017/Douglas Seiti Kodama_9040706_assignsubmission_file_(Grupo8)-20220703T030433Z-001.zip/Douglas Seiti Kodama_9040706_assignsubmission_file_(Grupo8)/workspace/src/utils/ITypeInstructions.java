/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa instruções do tipo I.
 */
public enum ITypeInstructions {
    bne("000101"), lw("100011"), sw("101011");
    
    final private String opcode;
    
    /**
     * Construtor da enum do tipo ITypeInstructions.
     * @param opcode string que representa o opcode da instrução.
     */
    private ITypeInstructions(String opcode) { this.opcode = opcode; }

    /**
     * Obtém o opcode da instrução.
     * @return o opcode da instrução.
     */
    public String opcode() { return this.opcode; }
}
