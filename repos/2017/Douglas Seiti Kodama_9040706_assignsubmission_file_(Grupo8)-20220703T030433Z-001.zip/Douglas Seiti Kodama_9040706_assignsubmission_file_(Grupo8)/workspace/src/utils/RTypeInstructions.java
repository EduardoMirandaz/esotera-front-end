/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa instruções do R, ou seja, as aritméticas.
 */
public enum RTypeInstructions {
    arithmetic("000000"), add("000000"), sub("000000"), or("000000"), and("000000");
    
    final private String opcode;
    
    /**
     * Construtor da enum do tipo RTypeInstructions
     * @param opcode string que representa o opcode da instrução, nesse caso, sempre é 000000.
     */
    private RTypeInstructions(String opcode) { this.opcode = opcode; }

    /**
     * Obtém o opcode da instrução. 
     * @return o opcode da instrução.
     */
    public String opcode() { return this.opcode; }
}
