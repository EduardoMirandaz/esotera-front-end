/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa o registrador intermediário IF/ID.
 */
public enum IfId {
    IR(0), PC(1), NPC(2);
    
    final private int regPos;
    
    /**
     * Construtor da enum do tipo IfId.
     * @param regPos índice de um dos registradores presentes em IF/ID.
     */
    private IfId(int regPos) { this.regPos = regPos; }
    
    /**
     * Obtém o índice de um dos registradores de IF/ID.
     * @return o índice de um dos registradores.
     */
    public int value() { return this.regPos; }
}
