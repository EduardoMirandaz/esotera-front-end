/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa o registrador intermediário EX/MEM.
 */
public enum ExMem {
    IR(16), ALUOutput(17), AddResult(18), B(19), Zero(20), Branch(21), MemRead(22), MemWrite(23), RegWrite(24), MemToReg(25);
    
    private final int regPos;
    
    /**
     * Construtor da enum do tipo ExMem.
     * @param regPos índice de um dos registradores presentes em EX/MEM.
     */
    private ExMem(int regPos) { this.regPos = regPos; }
    
    /**
     * Obtém o índice de um dos registradores de EX/MEM.
     * @return o índice de um dos registradores.
     */
    public int value() { return this.regPos; }
}
