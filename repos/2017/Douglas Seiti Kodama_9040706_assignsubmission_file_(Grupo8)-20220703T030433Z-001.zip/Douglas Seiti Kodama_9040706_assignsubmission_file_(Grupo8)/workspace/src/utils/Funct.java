/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa o campo de funct de uma instrução do tipo R. 
 */
public enum Funct {
    add("100000"), sub("100010"), and("100100"), or("100101");
    
    final private String code;
    
    /**
     * Construtor da enum do tipo Funct
     * @param code sequência de bits que representa a operação.
     */
    private Funct(String code) { 
        this.code = code;
    }

    /**
     * Obtém a sequência de bits que representa uma operação.
     * @return o código da operação.
     */
    public String code() { return this.code; }
}
