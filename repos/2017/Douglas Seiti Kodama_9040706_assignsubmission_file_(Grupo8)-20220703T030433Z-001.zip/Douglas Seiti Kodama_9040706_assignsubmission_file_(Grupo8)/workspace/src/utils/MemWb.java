/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa o registrador intermediário MEM/WB.
 */
public enum MemWb {
    IR(26), ALUOutput(27), LMD(28), RegWrite(29), MemToReg(30);
    
    private final int regPos;
    
    /**
     * Contrutor da enum do tipo MemWb.
     * @param regPos índice de um dos registradores presentes em MEM/WB.
     */
    private MemWb(int regPos) { this.regPos = regPos; }
    
    /**
     * Obtém o índice de um dos registrados de MEM/WB.
     * @return o indice de um dos registradores.
     */
    public int value() { return this.regPos; }
}
