/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package utils;

/**
 * Enum que representa o registrador intermediário ID/EX.
 */
public enum IdEx {
    IR(3), NPC(4), A(5), B(6), Imm(7), RegDst(8), ALUOp(9), ALUSrc(10), Branch(11), MemRead(12), MemWrite(13), RegWrite(14), MemToReg(15);
    
    private final int regPos;
    
    /**
     * Construtor da enum do tipo IdEx.
     * @param regPos índice de um dos registradores presentes em ID/EX.
     */
    private IdEx(int regPos) { this.regPos = regPos; }
    
    /**
     * Obtém o índice de um dos registradores de ID/EX.
     * @return o índice de um dos registradores.
     */
    public int value() { return this.regPos; }
}
