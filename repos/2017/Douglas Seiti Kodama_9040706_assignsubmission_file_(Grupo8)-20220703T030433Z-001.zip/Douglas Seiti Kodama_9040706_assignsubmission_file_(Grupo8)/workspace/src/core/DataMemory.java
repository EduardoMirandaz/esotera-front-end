/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;

import utils.Utils;

/**
 * Classe representativa de uma memória de dados.
 */
public class DataMemory extends Memory {
    /**
     * Construtor de um objeto do tipo DataMemory (memória de dados).
     * @param npos número de posições da memória de dados, sendo que cada posição equivale a um byte.
     * @param wordSize tamanho da palavra de dados em bytes.
     */
    public DataMemory(int npos, int wordSize) {
        super(npos/wordSize, wordSize);
        for (int i = 0; i < npos/wordSize; ++i) {
            positions[i] = Utils.itob(i);
        }
    }
}
