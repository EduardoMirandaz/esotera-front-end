/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;

/**
 * Classe representativa de uma unidade de extensão de sinal.
 */
public class SignalExtend {
    
    /**
     * Realiza a extensão de sinal para um valor com 32 bits.
     * @param binNumber valor em binário de um número qualquer.
     * @return o valor em binário do número de input, porém com 32 bits.
     */
    public String signalExtend(String binNumber) {
        int i, len;
        String extension = "";
        
        for (i = 0; i < 32 - binNumber.length(); ++i) {
            extension += "0";
        }
        
        return extension + binNumber;
    }
}
