/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;

/**
 * Classe representativa de uma memória.
 */
public class Memory {
    protected String[] positions;
    protected final int npos;
    protected final int wordSize;
    
    /**
     * Construtor de um objeto do tipo Memory (memória).
     * @param npos número de posições da memória de dados, sendo que cada posição equivale a um byte.
     * @param wordSize tamanho da palavra de dados em bytes.
     */
    public Memory(int npos, int wordSize) {
        this.npos = npos;
        this.wordSize = wordSize;
        positions = new String[this.npos];
    }
    
    /**
     * Obtém o conteúdo de uma palavra de dados a partir de uma posição da memória.
     * Note que cada posição na memória armazena uma palavra e, portanto,
     * abrange um número de bytes igual ao tamanho da palavra
     * (ex: a posição 0 abrange os bytes 0, 1, 2 e 3 se o tamanho da palavra for 4). 
     * @param pos a posição de memória da qual se deseja o conteúdo.
     * @return o conteúdo presente na posição de memória dada.
     */
    public String load(int pos) {
        if (pos >= 0 && pos < npos) {
            return positions[pos];
        }
        return "";
    }
    
    /**
     * Armazena uma palavra de dados binária em uma posição da memória.
     * Note que cada posição na memória armazena uma palavra e, portanto,
     * abrange um número de bytes igual ao tamanho da palavra
     * (ex: a posição 0 abrange os bytes 0, 1, 2 e 3 se o tamanho da palavra for 4). 
     * @param pos posição em que se deseja colocar a palavra de dados.
     * @param content palavra a ser colocado na posição dada. Deve ser uma cadeia binária do mesmo tamanho da palavra de dados.
     */ 
    public void store(int pos, String content) {
        if (pos >= 0 && pos < npos) {
            positions[pos] = content;
        }
    }
    
    /**
     * Imprime o conteúdo sequencial de algumas ou todas posições de memória.
     * @param lim o limite máximo de posições sequenciais de memória que se deseja imprimir, a partir da posição 0.
     */
    public void print(int lim) {
      if (lim <= positions.length && lim >= 0) {
        for (int i = 0; i < lim; ++i) {
            System.out.println("[" + i + "] = " + positions[i]);
        }
      }
    }
    
    /**
     * Obtém uma representação em string da memória.
     * @return a representação em string da memória.
     */
    @Override
    public String toString() {
        String ret = "";

        for (int i = 0; i < positions.length; ++i) {
            ret += ("[" + i + "] = " + positions[i] + "\n");
        }

        return ret;
    }
}
