/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;

import utils.Utils;

/**
 * Classes representativa do Banco de Registradores.
 */
public class RegisterBank extends Memory {
    
    /**
     * Construtor de um objeto do tipo RegisterBank (banco de registradores).
     * @param nreg número de registradores do banco de registradores.
     * @param wordSize tamanho da palavra de dados em bytes.
     */
    public RegisterBank(int nreg, int wordSize) {
        super(nreg, wordSize);
        for (int i = 0; i < nreg; ++i) {
            positions[i] = Utils.itob(i);
        }
    }
}
