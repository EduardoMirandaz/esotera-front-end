/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;

import utils.*;

/**
 * Classe representativa de uma unidade lógica aritmética.
 */
public class ALU {
    
    /**
     * Soma dois valores binários.
     * @param binNumber1 string de um número em binário.
     * @param binNumber2 string de um númro em binário.
     * @return soma de dois valores em binário.
     **/
    public String sum(String binNumber1, String binNumber2) {
        return Utils.itob(Utils.btoi(binNumber1) + Utils.btoi(binNumber2));
    }

    /**
     * Subtrai dois valores binários.
     * @param binNumber1 string de um número em binário.
     * @param binNumber2 string de um númro em binário.
     * @return subtração de dois valores em binário.
     **/
    public String sub(String binNumber1, String binNumber2) {
        return Utils.itob(Utils.btoi(binNumber1) - Utils.btoi(binNumber2));
    }

    /**
     * Faz um and com dois valores binários.
     * @param binNumber1 string de um número em binário.
     * @param binNumber2 string de um númro em binário.
     * @return and de dois valores em binário.
     **/
    public String and(String binNumber1, String binNumber2) {
        return Utils.itob(Utils.btoi(binNumber1) & Utils.btoi(binNumber2));
    }

    /**
     * Faz um or de dois valores binários.
     * @param binNumber1 string de um número em binário.
     * @param binNumber2 string de um númro em binário.
     * @return or de dois valores em binário.
     **/
    public String or(String binNumber1, String binNumber2) {
        return Utils.itob(Utils.btoi(binNumber1) | Utils.btoi(binNumber2));
    }
    
    /**
     * Executa uma instrução em pipeline do estágio de execução.
     * @param pipeRegisters o vetor de registradores do pipeline antes da execução da instrução.
     * @param newPipeRegisters o vetor de registradores do pipeline após a execução da instrução.
     **/
    public void executeInstruction(String[] pipeRegisters, String[] newPipeRegisters) {
        String A        = pipeRegisters[IdEx.A.value()];
        String B        = pipeRegisters[IdEx.B.value()];
        String Imm      = pipeRegisters[IdEx.Imm.value()];
        String ALUOp    = pipeRegisters[IdEx.ALUOp.value()];
        String ALUSrc   = pipeRegisters[IdEx.ALUSrc.value()];
        String ans = "";

        //Se tipo "R", i.e., o segundo operando vem do banco de registradores
        if (ALUSrc.equals("0")) {
            if (ALUOp.equals(Funct.add.code())) {
                ans = sum(A, B);
            } else if (ALUOp.equals(Funct.sub.code())) {
                ans = sub(A, B);
            } else if (ALUOp.equals(Funct.or.code())) {
                ans = or(A, B);
            } else if (ALUOp.equals(Funct.and.code())) {
                ans = and(A, B);
            }
        } else {    //load ou store (soma)
            ans = sum(A, Imm);
        }
        newPipeRegisters[ExMem.ALUOutput.value()] = ans;
        newPipeRegisters[ExMem.Zero.value()] = ans.equals("0") ? "1" : "0";
    }
}
