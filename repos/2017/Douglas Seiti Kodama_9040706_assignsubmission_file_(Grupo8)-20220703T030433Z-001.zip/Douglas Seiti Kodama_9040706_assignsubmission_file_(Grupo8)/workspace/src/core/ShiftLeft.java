/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;
import core.SignalExtend;
import core.ALU;
import utils.Utils;

/**
 * Classes representativa de uma unidade de Shift Left.
 */
public class ShiftLeft {
    
    /**
    * Realiza um shift de 2 para a esquerda em um dado número.
    * @param binNumber valor em binário de um número qualquer.
    * @return valor em binário do número após a operação de shift.
    */
    public String shiftLeft(String binNumber) {
        return Utils.itob(Utils.btoi(binNumber) << 2);
    }
}
