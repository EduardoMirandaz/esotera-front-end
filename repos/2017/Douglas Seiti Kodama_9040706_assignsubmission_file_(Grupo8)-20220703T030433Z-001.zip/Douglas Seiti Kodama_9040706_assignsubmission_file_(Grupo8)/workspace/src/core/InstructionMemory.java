/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package core;

import java.util.ArrayList;
import java.util.Arrays;

import utils.*;

/**
 * Classe representativa de uma memória de instruções.
 */
public class InstructionMemory extends Memory{
    /**
     * Construtor de um objeto do tipo InstructionMemory (memória de instruções).
     * @param npos número de posições da memória de dados, sendo que cada posição equivale a um byte.
     * @param wordSize tamanho da palavra de dados em bytes.
     */
    public InstructionMemory(int npos, int wordSize) {
        super(npos/wordSize, wordSize);
        for (int i = 0; i < npos/wordSize; ++i) {
            positions[i] = "00000000000000000000000000100000";  //nop (add $0, $0, $0)
        }
    }
    
    /**
     * Converte uma instrução textual MIPS do tipo R para sua representação binária equivalente.
     * @param instruction vetor de tokens que compõem a instrução
     * @return a instrução em sua representação binária.
     */
    public String convertRInstructionToBin(String[] instruction) {
        int i, j;
        String[] str = new String[] {"", "", ""};
        String bininstruction = RTypeInstructions.arithmetic.opcode();

        for (i = 1; i < instruction.length; ++i) {
            for (j = 0; j < instruction[i].length(); ++j) {
                if(Character.isDigit(instruction[i].charAt(j))) str[i-1] += instruction[i].charAt(j);
            }
        }

        bininstruction += Utils.itob(Integer.parseInt(str[1]) , 5); // Source Register A
        bininstruction += Utils.itob(Integer.parseInt(str[2]) , 5); // Source Register B
        bininstruction += Utils.itob(Integer.parseInt(str[0]) , 5); // Destiny Register D
        bininstruction += "00000"; // No Shift Operation

        for (Funct funct : Funct.values()) {
            if (instruction[0].equals(funct.name()))
                bininstruction += funct.code();
        }

        return bininstruction;
    }
    
    /**
     * Converte uma instrução textual MIPS do tipo I para sua representação binária equivalente.
     * @param instruction vetor de tokens que compõem a instrução
     * @return a instrução em sua representação binária.
     */
    public String convertIInstructionToBin(String[] instruction) {
        int i, j, count = 0;
        String[] str = new String[] {"", "", ""};
        String bininstruction = "";

        for (i = 1; i < instruction.length; ++i) {
            if (instruction[i].charAt(0) == '$') {
                for (j = 0; j < instruction[i].length(); ++j) {
                    if (Character.isDigit(instruction[i].charAt(j))) {
                        str[count] += instruction[i].charAt(j);
                        count++;
                    }
                }
            }
        }

        for (i = 0; i< instruction.length;i++) {
            if (instruction[i].matches("\\d+"))
                str[count] += instruction[i];
        }

        for (ITypeInstructions inst : ITypeInstructions.values()) {
            if (inst.name().equals(instruction[0]))
                bininstruction += inst.opcode();
        }

        bininstruction += Utils.itob(Integer.parseInt(str[1]), 5);
        bininstruction += Utils.itob(Integer.parseInt(str[0]), 5);
        bininstruction += Utils.itob(Integer.parseInt(str[2]), 16);

        return bininstruction;
    }
    
    /**
     * Converte uma instrução textual MIPS do tipo J para sua representação binária equivalente.
     * @param instruction vetor de tokens que compõem a instrução
     * @return a instrução em sua representação binária.
     */
    public String convertJInstructionToBin(String[] instruction) {
        String bininstruction = "";

        for (JTypeInstructions inst : JTypeInstructions.values()) {
            if (inst.name().equals(instruction[0]))
                bininstruction += inst.opcode();
        }

        bininstruction += Utils.itob(Integer.parseInt(instruction[1]) , 26);

        return bininstruction;
    }

    /**
     * Converte uma instrução textual MIPS para sua representação binária equivalente.
     * @param instruction a instrução textual a ser convertida.
     * @return a instrução em sua representação binária.
     */
    public String convertInstructionToBin(String instruction) {
        int i;
        String[] jType = new String[] {""};
        String[] args = instruction.split("[ (]");

        //Instruções do tipo I
        for (ITypeInstructions inst : ITypeInstructions.values()) {
            if (args[0].equals(inst.name()))
                return convertIInstructionToBin(args);
        }

        //Instruções do tipo J
        for (JTypeInstructions inst : JTypeInstructions.values()) {
            if (args[0].equals(inst.name()))
                return convertJInstructionToBin(args);
        }

        //Instruções do tipo R
        for (RTypeInstructions inst : RTypeInstructions.values()) {
            if (args[0].equals(inst.name()))
                return convertRInstructionToBin(args);
        }

        return "";
    }
    
    /**
     * Carrega um conjunto de instruções MIPS na memória de instruções.
     * @param as instruções a serem carregadas.
     */
    public void loadInstructions(String[] instructions) {
        for (int i = 0; i < instructions.length; ++i) {
            positions[i] = convertInstructionToBin(instructions[i]);
        }
    }

}
