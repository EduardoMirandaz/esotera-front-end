/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package simulator;

import core.*;
import utils.*;

import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.Arrays;

/**
 * Classe representativa de um simulador da arquitetura MIPS.
 */
public class Simulator {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    int iMemorySize;            //número de posições da memória de instruções
    int dMemorySize;            //número de posições da memória de dados
    int wordSize;               //tamanho da palavra de dados em bytes
    int nRegisters;             //número de registradores da arquitetura
    int pc;                     //o contador de programa da arquitetura
    InstructionMemory iMemory;  //memória de instruções
    DataMemory dMemory;         //memória de dados
    RegisterBank registerBank;  //banco de registradores
    ALU alu;                    //a unidade lógica aritmética
    SignalExtend signalExtend;  //a unidade de extensão de sinal
    ShiftLeft shiftLeft;        //a unidade de shift à esquerda
    String[] pipeRegisters;     //registradores intermediários do pipeline (valores de entrada)
    String[] newPipeRegisters;  //registradores intermediários do pipeline (valores de saída)
    
    /**
     * Construtor de um objeto do tipo Simulator (simulador).
     * @param addrBitsNo número de bits a serem usados para endereçar a memória de dados e de instruções.
     * @param wordSize tamanho da palavra de dados em bytes da arquitetura (ex: 4 bytes = 32 bits).
     * @nRegisters número de registradores do banco de registradores.
     */
    public Simulator(int addrBitsNo, int wordSize, int nRegisters) {
        this.iMemorySize = 2 << (addrBitsNo - 1);
        this.dMemorySize = 2 << (addrBitsNo - 1);
        this.wordSize = wordSize;
        this.nRegisters = nRegisters;
        this.pc = 0;
        this.iMemory = new InstructionMemory(this.iMemorySize, this.wordSize);
        this.dMemory = new DataMemory(this.iMemorySize, this.wordSize);
        this.registerBank = new RegisterBank(this.nRegisters, this.wordSize);
        this.alu = new ALU();
        this.signalExtend = new SignalExtend();
        this.shiftLeft = new ShiftLeft();
        this.pipeRegisters = new String[31];
        this.newPipeRegisters = new String[31];
        this.initializePipeRegisters(this.pipeRegisters);
        this.initializePipeRegisters(this.newPipeRegisters);
    }

    public void initializePipeRegisters(String[] pipeRegisters) {
        pipeRegisters[IfId.IR.value()] = "00000000000000000000000000100000";
        pipeRegisters[IfId.PC.value()] = "0";
        pipeRegisters[IfId.NPC.value()] = "0";
        pipeRegisters[IdEx.IR.value()] = "00000000000000000000000000100000";
        pipeRegisters[IdEx.NPC.value()] = "0";
        pipeRegisters[IdEx.A.value()] = "0";
        pipeRegisters[IdEx.B.value()] = "0";
        pipeRegisters[IdEx.Imm.value()] = "0";
        pipeRegisters[IdEx.RegDst.value()] = "1";
        pipeRegisters[IdEx.ALUOp.value()] = Funct.add.code();
        pipeRegisters[IdEx.ALUSrc.value()] = "0";
        pipeRegisters[IdEx.Branch.value()] = "0";
        pipeRegisters[IdEx.MemRead.value()] = "0";
        pipeRegisters[IdEx.MemWrite.value()] = "0";
        pipeRegisters[IdEx.RegWrite.value()] = "1";
        pipeRegisters[IdEx.MemToReg.value()] = "0";
        pipeRegisters[ExMem.IR.value()] = "00000000000000000000000000100000";
        pipeRegisters[ExMem.ALUOutput.value()] = "0";
        pipeRegisters[ExMem.AddResult.value()] = "0";
        pipeRegisters[ExMem.B.value()] = "0";
        pipeRegisters[ExMem.Zero.value()] = "1";
        pipeRegisters[ExMem.Branch.value()] = "0";
        pipeRegisters[ExMem.MemRead.value()] = "0";
        pipeRegisters[ExMem.MemWrite.value()] = "0";
        pipeRegisters[ExMem.RegWrite.value()] = "1";
        pipeRegisters[ExMem.MemToReg.value()] = "0";
        pipeRegisters[MemWb.IR.value()] = "00000000000000000000000000100000";
        pipeRegisters[MemWb.ALUOutput.value()] = "0";
        pipeRegisters[MemWb.LMD.value()] = "0";
        pipeRegisters[MemWb.RegWrite.value()] = "1";
        pipeRegisters[MemWb.MemToReg.value()] = "0";
    }
    
    /**
     * Busca a instrução na memória de instruções na posição apontada por pc (contador de programa).
     */
    public void fetchInstruction() {
        newPipeRegisters[IfId.PC.value()] = Utils.itob(pc);

        String opcode = pipeRegisters[ExMem.IR.value()].substring(0, 6);
        if (opcode.equals(ITypeInstructions.bne.opcode()) && pipeRegisters[ExMem.Zero.value()] == "0") {
            pc = Utils.btoi(pipeRegisters[ExMem.AddResult.value()]);

            newPipeRegisters[IfId.IR.value()] = "00000000000000000000000000100000";
            pipeRegisters[IfId.IR.value()] = "00000000000000000000000000100000";
            pipeRegisters[IdEx.IR.value()] = "00000000000000000000000000100000";
            pipeRegisters[IdEx.NPC.value()] = "0";
            pipeRegisters[IdEx.A.value()] = "0";
            pipeRegisters[IdEx.B.value()] = "0";
            pipeRegisters[IdEx.Imm.value()] = "0";
            pipeRegisters[IdEx.RegDst.value()] = "1";
            pipeRegisters[IdEx.ALUOp.value()] = Funct.add.code();
            pipeRegisters[IdEx.ALUSrc.value()] = "0";
            pipeRegisters[IdEx.Branch.value()] = "0";
            pipeRegisters[IdEx.MemRead.value()] = "0";
            pipeRegisters[IdEx.MemWrite.value()] = "0";
            pipeRegisters[IdEx.RegWrite.value()] = "1";
            pipeRegisters[IdEx.MemToReg.value()] = "0";
            pipeRegisters[ExMem.IR.value()] = "00000000000000000000000000100000";
            pipeRegisters[ExMem.ALUOutput.value()] = "0";
            pipeRegisters[ExMem.AddResult.value()] = "0";
            pipeRegisters[ExMem.B.value()] = "0";
            pipeRegisters[ExMem.Zero.value()] = "1";
            pipeRegisters[ExMem.Branch.value()] = "0";
            pipeRegisters[ExMem.MemRead.value()] = "0";
            pipeRegisters[ExMem.MemWrite.value()] = "0";
            pipeRegisters[ExMem.RegWrite.value()] = "1";
            pipeRegisters[ExMem.MemToReg.value()] = "0";
        } else {
            newPipeRegisters[IfId.IR.value()] = iMemory.load(pc/wordSize);
            pc += 4;
        }

        newPipeRegisters[IfId.NPC.value()] = Utils.itob(pc);
    }
    
    /**
     * Decodifica uma instrução binária do tipo I, gerando os sinais de controle necessários
     * e buscando os operandos no banco de registradores.
     * @param instruction a instrução a ser decodificada
     */
    public void decodeIInstruction(String instruction) {
        System.out.println("Decoding I instruction: " + instruction);
        String rs = instruction.substring(6, 11);
        String rt = instruction.substring(11, 16);
        String Imm = instruction.substring(16, 32);
        int op;

        newPipeRegisters[IdEx.IR.value()] = pipeRegisters[IfId.IR.value()];
        newPipeRegisters[IdEx.NPC.value()] = pipeRegisters[IfId.NPC.value()];
        newPipeRegisters[IdEx.A.value()] = registerBank.load(Utils.btoi(rs));
        newPipeRegisters[IdEx.B.value()] = registerBank.load(Utils.btoi(rt));

        if (instruction.substring(0,6).equals(ITypeInstructions.lw.opcode()))
            op = 0;
        else if (instruction.substring(0,6).equals(ITypeInstructions.sw.opcode()))
            op = 1;
        else
            op = 2;

        if (op == 0 || op == 1) {
            newPipeRegisters[IdEx.Imm.value()] = signalExtend.signalExtend(Imm);
            newPipeRegisters[IdEx.RegDst.value()] = "0";
            newPipeRegisters[IdEx.ALUOp.value()] = Funct.add.code();
            newPipeRegisters[IdEx.ALUSrc.value()] = "1";
            newPipeRegisters[IdEx.Branch.value()] = "0";

            if (op == 0) {
                newPipeRegisters[IdEx.MemRead.value()] = "1";
                newPipeRegisters[IdEx.MemWrite.value()] = "0";
                newPipeRegisters[IdEx.RegWrite.value()] = "1";
                newPipeRegisters[IdEx.MemToReg.value()] = "1";
            } else {
                newPipeRegisters[IdEx.MemRead.value()] = "0";
                newPipeRegisters[IdEx.MemWrite.value()] = "1";
                newPipeRegisters[IdEx.RegWrite.value()] = "0";
                newPipeRegisters[IdEx.MemToReg.value()] = "0";
            }
        } else {
            newPipeRegisters[IdEx.Imm.value()] = signalExtend.signalExtend(Imm);
            newPipeRegisters[IdEx.ALUOp.value()] = Funct.sub.code();

            newPipeRegisters[IdEx.RegDst.value()] = "0";
            newPipeRegisters[IdEx.ALUSrc.value()] = "0";
            newPipeRegisters[IdEx.Branch.value()] = "1";
            newPipeRegisters[IdEx.MemRead.value()] = "0";
            newPipeRegisters[IdEx.MemWrite.value()] = "0";
            newPipeRegisters[IdEx.RegWrite.value()] = "0";
            newPipeRegisters[IdEx.MemToReg.value()] = "0";
        }
    }
    
    /**
     * Decodifica uma instrução binária do tipo J, gerando os sinais de controle necessários
     * e buscando os operandos no banco de registradores.
     * @param instruction a instrução a ser decodificada
     */
    public void decodeJInstruction(String instruction) {
        String opcode = instruction.substring(0, 6);
        String offset = instruction.substring(6, 32);

        newPipeRegisters[IdEx.IR.value()] = pipeRegisters[IfId.IR.value()];
        newPipeRegisters[IdEx.NPC.value()] = pipeRegisters[IfId.NPC.value()];
        newPipeRegisters[IdEx.A.value()] = "0"; // nao importa
        newPipeRegisters[IdEx.B.value()] = "0"; // nao importa
        newPipeRegisters[IdEx.Imm.value()] = signalExtend.signalExtend(offset);
        newPipeRegisters[IdEx.RegDst.value()] = "0"; // nao importa
        newPipeRegisters[IdEx.ALUOp.value()] = "0"; // nao importa

        newPipeRegisters[IdEx.ALUSrc.value()] = "0"; //nao importa
        newPipeRegisters[IdEx.Branch.value()] = "1"; //é um jump entao é um desvio, eu acho (CONFIRMAR!!)
        newPipeRegisters[IdEx.MemRead.value()] = "0";
        newPipeRegisters[IdEx.MemWrite.value()] = "0";
        newPipeRegisters[IdEx.RegWrite.value()] = "0";
        newPipeRegisters[IdEx.MemToReg.value()] = "0"; //tanto faz pois regwrite é 0
    }
    
    /**
     * Decodifica uma instrução binária do tipo R, gerando os sinais de controle necessários
     * e buscando os operandos no banco de registradores.
     * @param instruction a instrução a ser decodificada
     */
    public void decodeRInstruction(String instruction){
        System.out.println("Decoding R instruction: " + instruction);
        String opcode = instruction.substring(0, 6);
        String rs = instruction.substring(6, 11);
        String rt = instruction.substring(11, 16);
        String rd = instruction.substring(16, 21);
        String funct = instruction.substring(26, 32);
        String operation = "";

        newPipeRegisters[IdEx.IR.value()] = pipeRegisters[IfId.IR.value()];
        newPipeRegisters[IdEx.NPC.value()] = pipeRegisters[IfId.NPC.value()];
        newPipeRegisters[IdEx.A.value()] = registerBank.load(Utils.btoi(rs));
        newPipeRegisters[IdEx.B.value()] = registerBank.load(Utils.btoi(rt));
        newPipeRegisters[IdEx.Imm.value()] = "0";
        newPipeRegisters[IdEx.RegDst.value()] = "1";

        for (Funct op : Funct.values()) {
            if (funct.equals(op.code()))
                newPipeRegisters[IdEx.ALUOp.value()] = op.code();
        }

        newPipeRegisters[IdEx.ALUSrc.value()] = "0";
        newPipeRegisters[IdEx.Branch.value()] = "0";
        newPipeRegisters[IdEx.MemRead.value()] = "0";
        newPipeRegisters[IdEx.MemWrite.value()] = "0";
        newPipeRegisters[IdEx.RegWrite.value()] = "1";
        newPipeRegisters[IdEx.MemToReg.value()] = "0";
    }
    
    /**
     * Decodifica a instrução binária no estágio de "decodification" do pipeline,
     * gerando os sinais de controle necessários e buscando os operandos no banco de registradores.
     */
    public void decodeInstruction() {
        String instruction = pipeRegisters[IfId.IR.value()];
        String opcode = instruction.substring(0, 6);

        //Instruções do tipo I
        for (ITypeInstructions inst : ITypeInstructions.values()) {
            if (opcode.equals(inst.opcode()))
                decodeIInstruction(instruction);
        }

        //Instruções do tipo J
        for (JTypeInstructions inst : JTypeInstructions.values()) {
            if (opcode.equals(inst.opcode()))
                decodeJInstruction(instruction);
        }

        //Instruções do tipo R
        if (opcode.equals(RTypeInstructions.arithmetic.opcode()))
            decodeRInstruction(instruction);
    }
    
    /**
     * Executa a instrução binária situada no estágio de "execution" do pipeline.
     */
    public void executeInstruction() {
        newPipeRegisters[ExMem.IR.value()] = pipeRegisters[IdEx.IR.value()];
        newPipeRegisters[ExMem.B.value()] = pipeRegisters[IdEx.B.value()];
        newPipeRegisters[ExMem.Zero.value()] = "0";
        newPipeRegisters[ExMem.Branch.value()] = pipeRegisters[IdEx.Branch.value()];
        newPipeRegisters[ExMem.MemRead.value()] = pipeRegisters[IdEx.MemRead.value()];
        newPipeRegisters[ExMem.MemWrite.value()] = pipeRegisters[IdEx.MemWrite.value()];
        newPipeRegisters[ExMem.RegWrite.value()] = pipeRegisters[IdEx.RegWrite.value()];
        newPipeRegisters[ExMem.MemToReg.value()] = pipeRegisters[IdEx.MemToReg.value()];

        alu.executeInstruction(pipeRegisters, newPipeRegisters);
        String npc = pipeRegisters[IdEx.NPC.value()];
        String imm = shiftLeft.shiftLeft(pipeRegisters[IdEx.Imm.value()]);
        newPipeRegisters[ExMem.AddResult.value()] = alu.sum(npc, imm);
        
        //se for branch, utilizar somador para fazer npc + Imm << 2
        /*String opcode = pipeRegisters[IdEx.IR.value()].substring(0, 6);
        if (opcode.equals(ITypeInstructions.bne.opcode())) {
            String npc = pipeRegisters[IdEx.NPC.value()];
            String imm = shiftLeft.shiftLeft(pipeRegisters[IdEx.Imm.value()]);
            newPipeRegisters[ExMem.AddResult.value()] = alu.sum(npc, imm);
        }*/
    }
    
    /**
     * Realiza o acesso à memória requisitado pela instrução no estágio de "memory access" do pipeline.
     */
    public void accessMemory() {
        newPipeRegisters[MemWb.IR.value()] = pipeRegisters[ExMem.IR.value()];
        newPipeRegisters[MemWb.ALUOutput.value()] = pipeRegisters[ExMem.ALUOutput.value()];
        newPipeRegisters[MemWb.LMD.value()] = "0";
        newPipeRegisters[MemWb.RegWrite.value()] = pipeRegisters[ExMem.RegWrite.value()];
        newPipeRegisters[MemWb.MemToReg.value()] = pipeRegisters[ExMem.MemToReg.value()];

        String instructionOpcode = pipeRegisters[ExMem.IR.value()].substring(0,6);
        int pos;
        if (instructionOpcode.equals(RTypeInstructions.arithmetic.opcode())) {
            newPipeRegisters[MemWb.ALUOutput.value()] = pipeRegisters[ExMem.ALUOutput.value()];
        } else if (instructionOpcode.equals(ITypeInstructions.lw.opcode())) {
            pos = Utils.btoi(pipeRegisters[ExMem.ALUOutput.value()]);
            newPipeRegisters[MemWb.LMD.value()] = dMemory.load(pos);
        } else if(instructionOpcode.equals(ITypeInstructions.sw.opcode())) {
            pos = Utils.btoi(pipeRegisters[ExMem.ALUOutput.value()]);
            dMemory.store(pos, pipeRegisters[ExMem.B.value()]);
        }
    }
    
    /**
     * Realiza a escrita no banco de registradores requisitada pela instrução no estágio de "write back" do pipeline.
     */
    public void writeBack() {
        String instructionOpcode = pipeRegisters[MemWb.IR.value()].substring(0, 6);

        if (instructionOpcode.equals(RTypeInstructions.arithmetic.opcode())) { //(add, sub, ...)
            int rd = Utils.btoi(pipeRegisters[MemWb.IR.value()].substring(16, 21)); //rd
            registerBank.store(rd, pipeRegisters[MemWb.ALUOutput.value()]);
        } else if (instructionOpcode.equals(ITypeInstructions.lw.opcode())) {
            int rt = Utils.btoi(pipeRegisters[MemWb.IR.value()].substring(11, 16)); //rt
            registerBank.store(rt, pipeRegisters[MemWb.LMD.value()]);
            System.out.println("Write Back. rt = " + rt);
        } /* else if (instructionOpcode.equals(ITypeInstructions.addi.opcode() || ...) {
            //Caso especifico para instrucoes aritmeticas do tipo I (com valor imediato)
            int rt = Utils.btoi(pipeRegisters[MemWb.IR.value()].substring(11, 15)); //rt
            registerBank.store(rt, pipeRegisters[MemWb.ALUOutput.value()]);
        } */
    }
    
    /**
     * Atualiza os valores contidos nos registrdores intermediários do pipeline.
     * Esse método deve ser chamado antes de se mudar o ciclo de clock da simulação.
     */
    public void updatePipeRegisters() {
         for (int i = 0; i < pipeRegisters.length; ++i) {
             pipeRegisters[i] = newPipeRegisters[i];
         }
    }
    
    /**
     * Carrega um conjunto de instruções textuais MIPS para a memória de instruções.
     * @param instructions o vetor de instruções textuais MIPS.
     */
    public void loadInstructions(String[] instructions) {
        iMemory.loadInstructions(instructions);
    }
    
    /**
     * Imprime o conteúdo dos registradores intermediários de pipeline.
     */
    public void showPipeRegisters() {
        System.out.println("Registradores Intermediários do Pipeline:");
        for (IfId i: IfId.values()) {
            System.out.println(ANSI_RED + "IF/ID." + ANSI_RESET + i.name() + " = " + pipeRegisters[i.value()]);
        }
        for (IdEx i: IdEx.values()) {
            System.out.println(ANSI_GREEN + "ID/EX." + ANSI_RESET + i.name() + " = " + pipeRegisters[i.value()]);
        }
        for (ExMem i: ExMem.values()) {
            System.out.println(ANSI_BLUE + "EX/MEM." + ANSI_RESET + i.name() + " = " + pipeRegisters[i.value()]);
        }
        for (MemWb i: MemWb.values()) {
            System.out.println(ANSI_YELLOW + "MEM/WB." + ANSI_RESET + i.name() + " = " + pipeRegisters[i.value()]);
        }
        System.out.println();
    }
    
    public void printDataMemory(int lim) { dMemory.print(lim); }
    
    public void printRegisterBank(int lim) { registerBank.print(lim); }

    public String[] getNewPipeRegisters() { return this.newPipeRegisters; }

    public RegisterBank getRegisterBank() { return this.registerBank; }

    public int getPC() { return this.pc; }

    public String[] getPipeRegisters() { return this.pipeRegisters; }

    public int getDataMemorySize() { return this.dMemorySize; }

    public DataMemory getDataMemory() { return this.dMemory; }

    public static void main(String[] args) {
        /*
            Ler uma ou mais instruções do usuário
            Jogar essas instruções na memória de instruções
            Executar as instruções na ordem em que foram dadas
                (1) Decodificá-las (identificando seu tipo e buscando os operandos)
                (2) Executá-la passando os dados para a ULA
                (3) Atualizar a memória de dados se necessário
                (4) Atualizar o banco de registradores
        */
        Simulator simulator = new Simulator(16, 4, 8);
        //String[] instructions = new String[] {"lw $1, 4($0)", "sw $2 8($0)", "add $1, $4, $3", "sub $5, $3, $4", "or $6, $3, $4", "add $1, $4, $3", "add $1, $4, $3", "add $1, $4, $3", "add $1, $4, $3"};
        String[] instructions = new String[] {"lw $1, 4($0)", "sw $2 8($0)", "add $1, $4, $3", "sub $5, $3, $4", "or $6, $3, $4", "add $1, $4, $3", "add $1, $4, $3", "add $1, $4, $3", "add $1, $4, $3"};

        simulator.loadInstructions(instructions);
        int i = 0;
        while (i < 10) {
            System.out.println("*** PC = " + simulator.getPC() + " ***");

            simulator.fetchInstruction();

            simulator.decodeInstruction();

            simulator.executeInstruction();

            simulator.accessMemory();

            simulator.writeBack();

            simulator.updatePipeRegisters();

            simulator.showPipeRegisters();

            simulator.printDataMemory(20);
            simulator.printRegisterBank(8);

            i++;
        }
    }
}
