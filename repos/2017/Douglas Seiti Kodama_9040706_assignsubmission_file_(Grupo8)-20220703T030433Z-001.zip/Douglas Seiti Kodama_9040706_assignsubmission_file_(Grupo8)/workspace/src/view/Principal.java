/*
 Douglas Seiti Kodama - 9277131
Filipe Mariano Freire da Silva - 9293161
Thauan Leandro Gonçalves - 9293543
Vitor Giovani Dellinocente - 9277875
 */
package view;

import core.*;
import utils.*;
import simulator.*;
import java.awt.Color;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author thauan
 */
public class Principal extends javax.swing.JFrame {

        //iteração atual do simulador
	private int iter;
        //fase
	private int phase;
        //cores usadas para pintar os elementos
	private final int[][] colors;
        //simulador rodando por baixo
	private Simulator simulator;
        //diz se as instruções já foram previamente carregadas
	private boolean instructionsLoaded;
        //shift para ajustar colorização após branch
        private int shift;
        //Vetor de Caixas de Texto dos registradores do Banco de Registradores
        private JTextField[] registers;
        
        /**
         * Renderizador customizado para pintar linhas específicas da tabela
         * de instruções, para deixar mais fácil a visualização das instruções.
         */
	public class MyRenderer extends DefaultTableCellRenderer  {

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean   isSelected, boolean hasFocus, int row, int column) {
			Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                        int mod = (row+4-shift)%4;
            
                        if (row >= phase && row < phase+4)
                            c.setBackground(new Color(colors[mod][0], colors[mod][1], colors[mod][2]));
                        else 
                            c.setBackground(table.getBackground());
                        
			return c;
		}
	}

	/**
	 * Construtor da interface gráfica. Inicializa o conteúdo das váriáveis
         * que serão utilizadas e dos elementos gráficos.
	 */
	public Principal() {

		initComponents();
		this.simulator = new Simulator (16, 4, 8);
		this.iter = 0;
		this.phase = 0;
                this.shift = 0;
		this.colors = new int[][]{{125, 190, 230}, {110, 215, 150}, {215, 170, 110}, {170, 160, 210}};
		this.registers = new JTextField[]{jTFr0, jTFr1, jTFr2, jTFr3, jTFr4, jTFr5, jTFr6, jTFr7};
		this.instructionsLoaded = false;
	}

        /**
         * Função referente à inicialização dos componentes da interface
         * gráfica. Todo o código dela foi gerado automaticamente pela IDE NetBeans.
         */
	@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTdados = new javax.swing.JTable();
        jBcarregar = new javax.swing.JButton();
        jBproxima = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTinstrucao = new javax.swing.JTable();
        jBgoto = new javax.swing.JButton();
        jTFgoto = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPmux1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTFpc = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPbr = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jTFbrr4 = new javax.swing.JTextField();
        jTFbrr1 = new javax.swing.JTextField();
        jTFbrr5 = new javax.swing.JTextField();
        jTFbrr2 = new javax.swing.JTextField();
        jTFbrr3 = new javax.swing.JTextField();
        jTFbrr0 = new javax.swing.JTextField();
        jPmux2 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPidid = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jTF1npc = new javax.swing.JTextField();
        jTF1pc = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jTFr0 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jTFr1 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jTFr2 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jTFr3 = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jTFr4 = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jTFr5 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jTFr6 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jTFr7 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jPmux3 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jPmux4 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jPmux5 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jPidexe = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jTF2rd = new javax.swing.JTextField();
        jTF2br = new javax.swing.JTextField();
        jTF2as = new javax.swing.JTextField();
        jTF2mw = new javax.swing.JTextField();
        jTF2mr = new javax.swing.JTextField();
        jTF2rw = new javax.swing.JTextField();
        jTF2npc = new javax.swing.JTextField();
        jTF2a = new javax.swing.JTextField();
        jTF2b = new javax.swing.JTextField();
        jTF2Imm = new javax.swing.JTextField();
        jTF2mtr = new javax.swing.JTextField();
        jPexemem = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jTF3br = new javax.swing.JTextField();
        jTF3mr = new javax.swing.JTextField();
        jTF3mw = new javax.swing.JTextField();
        jTF3rw = new javax.swing.JTextField();
        jTF3mtr = new javax.swing.JTextField();
        jTF3b = new javax.swing.JTextField();
        jTF3z = new javax.swing.JTextField();
        jPmeminstr = new javax.swing.JPanel();
        jPmemdados = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jTFmdr0 = new javax.swing.JTextField();
        jTFmdr2 = new javax.swing.JTextField();
        jTFmdr1 = new javax.swing.JTextField();
        jPmemwb = new javax.swing.JPanel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jTF4rw = new javax.swing.JTextField();
        jTF4mtr = new javax.swing.JTextField();
        jTF4lmd = new javax.swing.JTextField();
        jTFrw = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jTFrd = new javax.swing.JTextField();
        jLabel67 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jTFas = new javax.swing.JTextField();
        jLabel77 = new javax.swing.JLabel();
        jTFuo = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jTFmr = new javax.swing.JTextField();
        jTFmw = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPmux7 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jTFmtr = new javax.swing.JTextField();
        jLabel78 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jTF1ir = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jTF2ir = new javax.swing.JTextField();
        jLabel63 = new javax.swing.JLabel();
        jTF2ao = new javax.swing.JTextField();
        jLabel79 = new javax.swing.JLabel();
        jTF3ir = new javax.swing.JTextField();
        jLabel84 = new javax.swing.JLabel();
        jTF3ao = new javax.swing.JTextField();
        jLabel87 = new javax.swing.JLabel();
        jTF4ir = new javax.swing.JTextField();
        jLabel94 = new javax.swing.JLabel();
        jTF4ao = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Simulador");
        setPreferredSize(new java.awt.Dimension(1350, 800));
        setSize(new java.awt.Dimension(1200, 800));

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTdados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "End", "Dados"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTdados.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTdadosFocusGained(evt);
            }
        });
        jScrollPane1.setViewportView(jTdados);
        if (jTdados.getColumnModel().getColumnCount() > 0) {
            jTdados.getColumnModel().getColumn(0).setResizable(false);
            jTdados.getColumnModel().getColumn(1).setResizable(false);
        }

        jBcarregar.setText("Carregar");
        jBcarregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBcarregarActionPerformed(evt);
            }
        });

        jBproxima.setText("Próxima");
        jBproxima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBproximaActionPerformed(evt);
            }
        });

        jTinstrucao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "End", "Instrução"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTinstrucao.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTinstrucaoFocusGained(evt);
            }
        });
        jScrollPane2.setViewportView(jTinstrucao);
        if (jTinstrucao.getColumnModel().getColumnCount() > 0) {
            jTinstrucao.getColumnModel().getColumn(0).setResizable(false);
            jTinstrucao.getColumnModel().getColumn(1).setResizable(false);
        }

        jBgoto.setText("Vá para");
        jBgoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBgotoActionPerformed(evt);
            }
        });

        jTFgoto.setEditable(false);
        jTFgoto.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jBcarregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBproxima))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jBgoto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFgoto)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBcarregar)
                    .addComponent(jBproxima))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBgoto)
                    .addComponent(jTFgoto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(164, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPmux1.setBackground(new java.awt.Color(204, 204, 204));
        jPmux1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPmux1.setToolTipText("");

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel1.setText("Sign");

        jLabel23.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel23.setText("Extend");

        javax.swing.GroupLayout jPmux1Layout = new javax.swing.GroupLayout(jPmux1);
        jPmux1.setLayout(jPmux1Layout);
        jPmux1Layout.setHorizontalGroup(
            jPmux1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmux1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel23)
                .addContainerGap())
        );
        jPmux1Layout.setVerticalGroup(
            jPmux1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmux1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addContainerGap())
        );

        jTFpc.setEditable(false);
        jTFpc.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFpc.setText("0");
        jTFpc.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel2.setText("PC");

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel6.setText("ADD");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel11.setText("IF/ID");

        jPbr.setBackground(new java.awt.Color(204, 255, 204));
        jPbr.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel13.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel13.setText("Read reg A");

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel14.setText("Write reg");

        jLabel15.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel15.setText("Read reg B");

        jLabel16.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel16.setText("Read data A");

        jLabel17.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel17.setText("Write data");

        jLabel19.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel19.setText("Read data B");

        jTFbrr4.setEditable(false);
        jTFbrr4.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFbrr4.setText("0");
        jTFbrr4.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFbrr1.setEditable(false);
        jTFbrr1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFbrr1.setText("0");
        jTFbrr1.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFbrr5.setEditable(false);
        jTFbrr5.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFbrr5.setText("0");
        jTFbrr5.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFbrr2.setEditable(false);
        jTFbrr2.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFbrr2.setText("0");
        jTFbrr2.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFbrr3.setEditable(false);
        jTFbrr3.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFbrr3.setText("0");
        jTFbrr3.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFbrr0.setEditable(false);
        jTFbrr0.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFbrr0.setText("0");
        jTFbrr0.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPbrLayout = new javax.swing.GroupLayout(jPbr);
        jPbr.setLayout(jPbrLayout);
        jPbrLayout.setHorizontalGroup(
            jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPbrLayout.createSequentialGroup()
                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPbrLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPbrLayout.createSequentialGroup()
                                .addComponent(jTFbrr1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTFbrr5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPbrLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel13))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel19)))
                            .addGroup(jPbrLayout.createSequentialGroup()
                                .addComponent(jTFbrr0, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTFbrr4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPbrLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(jLabel14))))
                .addGap(0, 22, Short.MAX_VALUE))
            .addGroup(jPbrLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTFbrr3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFbrr2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPbrLayout.setVerticalGroup(
            jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPbrLayout.createSequentialGroup()
                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFbrr4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFbrr0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPbrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTFbrr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFbrr5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTFbrr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTFbrr3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPmux2.setBackground(new java.awt.Color(204, 204, 204));
        jPmux2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPmux2.setToolTipText("");

        jLabel22.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel22.setText("Mux 1");

        javax.swing.GroupLayout jPmux2Layout = new javax.swing.GroupLayout(jPmux2);
        jPmux2.setLayout(jPmux2Layout);
        jPmux2Layout.setHorizontalGroup(
            jPmux2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux2Layout.createSequentialGroup()
                .addComponent(jLabel22)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPmux2Layout.setVerticalGroup(
            jPmux2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux2Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addGap(26, 26, 26))
        );

        jPidid.setBackground(new java.awt.Color(204, 255, 255));
        jPidid.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel25.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel25.setText("NPC");

        jLabel26.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel26.setText("PC");

        jTF1npc.setEditable(false);
        jTF1npc.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF1npc.setText("0");
        jTF1npc.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF1pc.setEditable(false);
        jTF1pc.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF1pc.setText("0");
        jTF1pc.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPididLayout = new javax.swing.GroupLayout(jPidid);
        jPidid.setLayout(jPididLayout);
        jPididLayout.setHorizontalGroup(
            jPididLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPididLayout.createSequentialGroup()
                .addGroup(jPididLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPididLayout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPididLayout.createSequentialGroup()
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addGroup(jPididLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTF1npc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTF1pc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPididLayout.setVerticalGroup(
            jPididLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPididLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPididLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jTF1npc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPididLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel26)
                    .addComponent(jTF1pc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(353, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));
        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel12.setText("R0");

        jTFr0.setEditable(false);
        jTFr0.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel30.setText("R1");

        jTFr1.setEditable(false);
        jTFr1.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel31.setText("R2");

        jTFr2.setEditable(false);
        jTFr2.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel32.setText("R3");

        jTFr3.setEditable(false);
        jTFr3.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel33.setText("R4");

        jTFr4.setEditable(false);
        jTFr4.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel34.setText("R5");

        jTFr5.setEditable(false);
        jTFr5.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel35.setText("R6");

        jTFr6.setEditable(false);
        jTFr6.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel36.setText("R7");

        jTFr7.setEditable(false);
        jTFr7.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel37.setText("Registradores");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr0, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr4, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr5, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr6, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFr7, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel37))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel37)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTFr1, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jTFr0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFr2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFr3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFr4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFr5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFr6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFr7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel33)
                            .addComponent(jLabel12)
                            .addComponent(jLabel30)
                            .addComponent(jLabel32)
                            .addComponent(jLabel31)
                            .addComponent(jLabel35)
                            .addComponent(jLabel34)
                            .addComponent(jLabel36))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));
        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel18.setText("ADD");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel18)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPmux3.setBackground(new java.awt.Color(204, 204, 204));
        jPmux3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPmux3.setToolTipText("");

        jLabel39.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel39.setText("Shift");

        jLabel40.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel40.setText("Left 2");

        javax.swing.GroupLayout jPmux3Layout = new javax.swing.GroupLayout(jPmux3);
        jPmux3.setLayout(jPmux3Layout);
        jPmux3Layout.setHorizontalGroup(
            jPmux3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel40)
            .addComponent(jLabel39)
        );
        jPmux3Layout.setVerticalGroup(
            jPmux3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmux3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel39)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel40)
                .addContainerGap())
        );

        jPmux4.setBackground(new java.awt.Color(204, 204, 204));
        jPmux4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPmux4.setToolTipText("");

        jLabel41.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel41.setText("Mux 3");

        javax.swing.GroupLayout jPmux4Layout = new javax.swing.GroupLayout(jPmux4);
        jPmux4.setLayout(jPmux4Layout);
        jPmux4Layout.setHorizontalGroup(
            jPmux4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel41))
        );
        jPmux4Layout.setVerticalGroup(
            jPmux4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmux4Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));
        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel42.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel42.setText("ULA");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel42)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel42)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jPmux5.setBackground(new java.awt.Color(204, 204, 204));
        jPmux5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPmux5.setToolTipText("");

        jLabel43.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel43.setText("Mux 2");

        javax.swing.GroupLayout jPmux5Layout = new javax.swing.GroupLayout(jPmux5);
        jPmux5.setLayout(jPmux5Layout);
        jPmux5Layout.setHorizontalGroup(
            jPmux5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel43))
        );
        jPmux5Layout.setVerticalGroup(
            jPmux5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmux5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel43)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPidexe.setBackground(new java.awt.Color(204, 255, 255));
        jPidexe.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel62.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel62.setText("RD");

        jLabel64.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel64.setText("AS");

        jLabel66.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel66.setText("Br");

        jLabel68.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel68.setText("MW");

        jLabel69.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel69.setText("RW");

        jLabel70.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel70.setText("MTR");

        jLabel71.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel71.setText("NPC");

        jLabel72.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel72.setText("A");

        jLabel73.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel73.setText("B");

        jLabel74.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel74.setText("Imm");

        jLabel76.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel76.setText("MR");

        jTF2rd.setEditable(false);
        jTF2rd.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2rd.setText("1");
        jTF2rd.setAutoscrolls(false);
        jTF2rd.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2br.setEditable(false);
        jTF2br.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2br.setText("1");
        jTF2br.setAutoscrolls(false);
        jTF2br.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2as.setEditable(false);
        jTF2as.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2as.setText("1");
        jTF2as.setAutoscrolls(false);
        jTF2as.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2mw.setEditable(false);
        jTF2mw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2mw.setText("1");
        jTF2mw.setAutoscrolls(false);
        jTF2mw.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2mr.setEditable(false);
        jTF2mr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2mr.setText("1");
        jTF2mr.setAutoscrolls(false);
        jTF2mr.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2rw.setEditable(false);
        jTF2rw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2rw.setText("1");
        jTF2rw.setAutoscrolls(false);
        jTF2rw.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2npc.setEditable(false);
        jTF2npc.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2npc.setText("0");
        jTF2npc.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2a.setEditable(false);
        jTF2a.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2a.setText("0");
        jTF2a.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2b.setEditable(false);
        jTF2b.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2b.setText("0");
        jTF2b.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2Imm.setEditable(false);
        jTF2Imm.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2Imm.setText("0");
        jTF2Imm.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF2mtr.setEditable(false);
        jTF2mtr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2mtr.setText("1");
        jTF2mtr.setAutoscrolls(false);
        jTF2mtr.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPidexeLayout = new javax.swing.GroupLayout(jPidexe);
        jPidexe.setLayout(jPidexeLayout);
        jPidexeLayout.setHorizontalGroup(
            jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPidexeLayout.createSequentialGroup()
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addComponent(jLabel74)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTF2Imm, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel68)
                            .addComponent(jLabel64)
                            .addComponent(jLabel62)
                            .addComponent(jLabel69)
                            .addComponent(jLabel76)
                            .addComponent(jLabel66))
                        .addGap(16, 16, 16)
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF2rd, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2as, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2br, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2mr, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2rw, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2mw, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addComponent(jLabel70)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTF2mtr, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel71)
                            .addComponent(jLabel72)
                            .addComponent(jLabel73))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF2npc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2a, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF2b, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPidexeLayout.setVerticalGroup(
            jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPidexeLayout.createSequentialGroup()
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel62)
                    .addComponent(jTF2rd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF2as, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel64))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF2br, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel66))
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel68)
                            .addComponent(jTF2mw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel69)
                            .addComponent(jTF2rw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel70)
                            .addComponent(jTF2mtr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTF2mr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel76)))
                .addGap(62, 62, 62)
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addComponent(jLabel71)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel72)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel73))
                    .addGroup(jPidexeLayout.createSequentialGroup()
                        .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPidexeLayout.createSequentialGroup()
                                .addComponent(jTF2npc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25))
                            .addComponent(jTF2a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))
                    .addComponent(jTF2b, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPidexeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF2Imm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel74))
                .addContainerGap(79, Short.MAX_VALUE))
        );

        jPexemem.setBackground(new java.awt.Color(204, 255, 255));
        jPexemem.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel80.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel80.setText("Br");

        jLabel81.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel81.setText("MW");

        jLabel82.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel82.setText("RW");

        jLabel83.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel83.setText("MTR");

        jLabel85.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel85.setText("B");

        jLabel86.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel86.setText("Z");

        jLabel89.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel89.setText("MR");

        jTF3br.setEditable(false);
        jTF3br.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3br.setText("1");
        jTF3br.setAutoscrolls(false);
        jTF3br.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF3mr.setEditable(false);
        jTF3mr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3mr.setText("1");
        jTF3mr.setAutoscrolls(false);
        jTF3mr.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF3mw.setEditable(false);
        jTF3mw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3mw.setText("1");
        jTF3mw.setAutoscrolls(false);
        jTF3mw.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF3rw.setEditable(false);
        jTF3rw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3rw.setText("1");
        jTF3rw.setAutoscrolls(false);
        jTF3rw.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF3mtr.setEditable(false);
        jTF3mtr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3mtr.setText("1");
        jTF3mtr.setAutoscrolls(false);
        jTF3mtr.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF3b.setEditable(false);
        jTF3b.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3b.setText("0");
        jTF3b.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF3z.setEditable(false);
        jTF3z.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3z.setText("0");
        jTF3z.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPexememLayout = new javax.swing.GroupLayout(jPexemem);
        jPexemem.setLayout(jPexememLayout);
        jPexememLayout.setHorizontalGroup(
            jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPexememLayout.createSequentialGroup()
                .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPexememLayout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel85)
                            .addComponent(jLabel86))
                        .addGap(21, 21, 21)
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF3b, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF3z, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPexememLayout.createSequentialGroup()
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel83)
                            .addComponent(jLabel82))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF3mtr, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF3rw, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPexememLayout.createSequentialGroup()
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel89)
                            .addComponent(jLabel80)
                            .addComponent(jLabel81, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF3mw, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF3mr, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF3br, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPexememLayout.setVerticalGroup(
            jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPexememLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF3br, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel80))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF3mr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel89))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF3mw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel81))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPexememLayout.createSequentialGroup()
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel82)
                            .addComponent(jTF3rw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel83)
                            .addComponent(jTF3mtr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 145, Short.MAX_VALUE)
                        .addComponent(jLabel85))
                    .addComponent(jTF3b, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPexememLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF3z, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel86))
                .addContainerGap(109, Short.MAX_VALUE))
        );

        jPmeminstr.setBackground(new java.awt.Color(153, 153, 255));
        jPmeminstr.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPmeminstrLayout = new javax.swing.GroupLayout(jPmeminstr);
        jPmeminstr.setLayout(jPmeminstrLayout);
        jPmeminstrLayout.setHorizontalGroup(
            jPmeminstrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 76, Short.MAX_VALUE)
        );
        jPmeminstrLayout.setVerticalGroup(
            jPmeminstrLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        jPmemdados.setBackground(new java.awt.Color(204, 255, 204));
        jPmemdados.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel28.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel28.setText("Addr");

        jLabel46.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel46.setText("Read data");

        jLabel47.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel47.setText("Write data");

        jTFmdr0.setEditable(false);
        jTFmdr0.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFmdr0.setText("0");
        jTFmdr0.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFmdr2.setEditable(false);
        jTFmdr2.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFmdr2.setText("0");
        jTFmdr2.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFmdr1.setEditable(false);
        jTFmdr1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFmdr1.setText("0");
        jTFmdr1.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPmemdadosLayout = new javax.swing.GroupLayout(jPmemdados);
        jPmemdados.setLayout(jPmemdadosLayout);
        jPmemdadosLayout.setHorizontalGroup(
            jPmemdadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmemdadosLayout.createSequentialGroup()
                .addGroup(jPmemdadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28)
                    .addComponent(jLabel47)
                    .addComponent(jTFmdr0, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPmemdadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPmemdadosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addComponent(jTFmdr2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmemdadosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                        .addComponent(jLabel46)
                        .addContainerGap())))
            .addGroup(jPmemdadosLayout.createSequentialGroup()
                .addComponent(jTFmdr1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPmemdadosLayout.setVerticalGroup(
            jPmemdadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmemdadosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPmemdadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(jLabel46))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPmemdadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFmdr0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFmdr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel47)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTFmdr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPmemwb.setBackground(new java.awt.Color(204, 255, 255));
        jPmemwb.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel92.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel92.setText("RW");

        jLabel93.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel93.setText("MTR");

        jLabel95.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel95.setText("LMD");

        jTF4rw.setEditable(false);
        jTF4rw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF4rw.setText("1");
        jTF4rw.setAutoscrolls(false);
        jTF4rw.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF4mtr.setEditable(false);
        jTF4mtr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF4mtr.setText("1");
        jTF4mtr.setAutoscrolls(false);
        jTF4mtr.setPreferredSize(new java.awt.Dimension(50, 19));

        jTF4lmd.setEditable(false);
        jTF4lmd.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF4lmd.setText("1");
        jTF4lmd.setAutoscrolls(false);
        jTF4lmd.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPmemwbLayout = new javax.swing.GroupLayout(jPmemwb);
        jPmemwb.setLayout(jPmemwbLayout);
        jPmemwbLayout.setHorizontalGroup(
            jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmemwbLayout.createSequentialGroup()
                .addGroup(jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmemwbLayout.createSequentialGroup()
                        .addGroup(jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel92)
                            .addComponent(jLabel93))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF4rw, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF4mtr, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPmemwbLayout.createSequentialGroup()
                        .addComponent(jLabel95)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTF4lmd, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(46, 46, 46))
        );
        jPmemwbLayout.setVerticalGroup(
            jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPmemwbLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel92)
                    .addComponent(jTF4rw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel93)
                    .addComponent(jTF4mtr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPmemwbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel95)
                    .addComponent(jTF4lmd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(287, Short.MAX_VALUE))
        );

        jTFrw.setEditable(false);
        jTFrw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFrw.setText("1");
        jTFrw.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel20.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel20.setText("RW");

        jLabel21.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel21.setText("ID/EXE");

        jTFrd.setEditable(false);
        jTFrd.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFrd.setText("1");
        jTFrd.setAutoscrolls(false);
        jTFrd.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel67.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel67.setText("RD");

        jLabel75.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel75.setText("AS");

        jTFas.setEditable(false);
        jTFas.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFas.setText("1");
        jTFas.setAutoscrolls(false);
        jTFas.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel77.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel77.setText("UO");

        jTFuo.setEditable(false);
        jTFuo.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFuo.setText("1");
        jTFuo.setAutoscrolls(false);
        jTFuo.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel29.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel29.setText("EXE/MEM");

        jLabel44.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel44.setText("MR");

        jTFmr.setEditable(false);
        jTFmr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFmr.setText("1");
        jTFmr.setPreferredSize(new java.awt.Dimension(50, 19));

        jTFmw.setEditable(false);
        jTFmw.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFmw.setText("1");
        jTFmw.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel45.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel45.setText("MW");

        jLabel38.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel38.setText("MEM/WB");

        jPmux7.setBackground(new java.awt.Color(204, 204, 204));
        jPmux7.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPmux7.setToolTipText("");

        jLabel49.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel49.setText("Mux 4");

        javax.swing.GroupLayout jPmux7Layout = new javax.swing.GroupLayout(jPmux7);
        jPmux7.setLayout(jPmux7Layout);
        jPmux7Layout.setHorizontalGroup(
            jPmux7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux7Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel49))
        );
        jPmux7Layout.setVerticalGroup(
            jPmux7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPmux7Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jTFmtr.setEditable(false);
        jTFmtr.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTFmtr.setText("1");
        jTFmtr.setAutoscrolls(false);
        jTFmtr.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel78.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel78.setText("MTR");

        jLabel50.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel50.setText("Banco de Registradores");

        jLabel51.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel51.setText("Memória de Dados");

        jLabel52.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel52.setText("Memória de Instruções");

        jTF1ir.setEditable(false);
        jTF1ir.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF1ir.setText("0");
        jTF1ir.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel24.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel24.setText("IF/ID.IR");

        jLabel65.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel65.setText("ID/EXE.IR");

        jTF2ir.setEditable(false);
        jTF2ir.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2ir.setText("0");
        jTF2ir.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel63.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel63.setText("ID/EXE.ALUOp");

        jTF2ao.setEditable(false);
        jTF2ao.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF2ao.setText("1");
        jTF2ao.setAutoscrolls(false);
        jTF2ao.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel79.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel79.setText("EXE/MEM.IR");

        jTF3ir.setEditable(false);
        jTF3ir.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3ir.setText("0");
        jTF3ir.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel84.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel84.setText("EXE/MEM.ALUOutput");

        jTF3ao.setEditable(false);
        jTF3ao.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF3ao.setText("0");
        jTF3ao.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel87.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel87.setText("MEM/WB.IR");

        jTF4ir.setEditable(false);
        jTF4ir.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF4ir.setText("1");
        jTF4ir.setAutoscrolls(false);
        jTF4ir.setPreferredSize(new java.awt.Dimension(50, 19));

        jLabel94.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        jLabel94.setText("MEM/WB.ALUOutput");

        jTF4ao.setEditable(false);
        jTF4ao.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jTF4ao.setText("1");
        jTF4ao.setAutoscrolls(false);
        jTF4ao.setPreferredSize(new java.awt.Dimension(50, 19));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(222, 222, 222)
                        .addComponent(jLabel11))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPmux2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel52))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTFpc, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel2))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jPmeminstr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(4, 4, 4)
                        .addComponent(jPidid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPbr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addComponent(jPmux1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel50))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(87, 87, 87)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel20)
                                    .addComponent(jTFrw, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(jTF1ir, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF2ao, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel63)
                            .addComponent(jLabel65)
                            .addComponent(jTF2ir, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jPidexe, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jPmux3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jPmux5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jTFrd, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel67)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTFas, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel75))
                                        .addComponent(jPmux4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(jLabel77))
                                    .addComponent(jTFuo, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel79)
                            .addComponent(jTF3ao, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel84)
                            .addComponent(jTF3ir, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel29)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jPexemem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPmemdados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel51))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(71, 71, 71)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTFmr, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel44)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(65, 65, 65)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTFmw, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel45)))))
                            .addComponent(jLabel87)
                            .addComponent(jTF4ir, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel38)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jPmemwb, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTFmtr, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel78)
                                    .addComponent(jPmux7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jLabel94)
                    .addComponent(jTF4ao, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel21)
                            .addComponent(jLabel29))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(93, 93, 93)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(12, 12, 12)
                                                .addComponent(jLabel2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTFpc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jPmux2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jPmeminstr, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel52)
                                        .addGap(93, 93, 93))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTFrw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jPbr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel50)
                                        .addGap(18, 18, 18)))
                                .addComponent(jPmux1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel65))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTF1ir, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTF2ir, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(44, 44, 44)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jPmux3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(39, 39, 39)
                                                .addComponent(jPmux5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel75)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTFas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(100, 100, 100))
                                                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel77)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTFuo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(18, 18, 18)
                                        .addComponent(jPmux4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel67)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTFrd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(83, 83, 83)
                                        .addComponent(jLabel45)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTFmw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jPmemdados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(4, 4, 4)
                                        .addComponent(jLabel51)
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel44)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTFmr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jPidexe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jPidid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jPexemem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel79)
                                    .addComponent(jLabel87))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTF3ir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTF4ir, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel63)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF2ao, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel84)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF3ao, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel94)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF4ao, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPmemwb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(147, 147, 147)
                                .addComponent(jPmux7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel78)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTFmtr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(202, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(143, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        
        /**
         * Função responsável por inicializar o simulador,
         * preencher a memória de instrução e de dados na
         * interface gráfica.
         * @param evt Evento detectado no botão de "Carregar".
         */
	private void jBcarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBcarregarActionPerformed
		String filename = "./samples/instructions1.txt";
		BufferedReader br = null;
		FileReader fr = null;
		ArrayList<String> temp = new ArrayList<String>();
		String[] instructions;
                JFileChooser chooser;
                FileNameExtensionFilter filter;
                int returnVal = 0;
                
                //Não deixa carregar nada novo, se já foi carregado previamente
		if (instructionsLoaded == false) {
                        //abre um FileChooser para escolher qual o arquivo das instruções
                        chooser = new JFileChooser();
                        filter = new FileNameExtensionFilter("text", "txt");
                        chooser.setCurrentDirectory(new File("./samples"));
                        chooser.setFileFilter(filter);
                        returnVal = chooser.showOpenDialog(this);
                        
                        if (returnVal == JFileChooser.APPROVE_OPTION) {
                            filename = chooser.getSelectedFile().getAbsolutePath();
                        }
                        
                        //Permite escrever na caixa de texto de "Vá para"
                        jTFgoto.setEditable(true);

			try {
				fr = new FileReader(filename);
				br = new BufferedReader(fr);
                                
                                //Coloca os valores na tabela da memória de dados
				for (int i = 0; i < simulator.getDataMemorySize()/4; i++) {
					jTdados.setValueAt( (""+Utils.btoi(simulator.getDataMemory().load(i))), i, 1);
				}

				String sCurrentLine;
				int end = 0;
				DefaultTableModel model = (DefaultTableModel) jTinstrucao.getModel();
                                
                                //Lê instruções a serem executadas
				while ((sCurrentLine = br.readLine()) != null) {
					model.addRow(new Object[]{end*4, sCurrentLine});
					end = end + 1;
					temp.add(sCurrentLine);
				}
                                
                                //Carrega as instruções no carregador
				instructions = new String[end];
				for (int i = 0; i < end; i++)
					instructions[i] = temp.get(i);

				simulator.loadInstructions(instructions);

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		this.instructionsLoaded = true;

	}//GEN-LAST:event_jBcarregarActionPerformed
        
        /**
         * Função responsável por inicializar alguns parâmentros da tabela
         * referente à memória de dados.
         * @param evt Evento detectado "Focus Gained" na tabela de memória de dados.
         */
	private void jTdadosFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTdadosFocusGained
		jTdados.getColumnModel().getColumn(0).setPreferredWidth(20);
		jTdados.getColumnModel().getColumn(1).setPreferredWidth(110);
	}//GEN-LAST:event_jTdadosFocusGained
        
        /**
         * Função responsável por realizar um clock no simulador, executando
         * os estágios nas instruções e fazer as atualizações correspondentes na
         * interface gráfica.
         * @param evt Evento detectado no botão "Próxima"
         */
	private void jBproximaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBproximaActionPerformed
		int ncols = jTinstrucao.getColumnCount();
		Color[] c = new Color[4];
		int indexes[] = new int[]{iter%4,(iter-1)%4, (iter-2)%4, (iter-3)%4};
		int ind, inst, na;
                DefaultTableModel model = (DefaultTableModel)jTdados.getModel();
                String opcode;

		if (this.instructionsLoaded == true) {

			if(simulator.getPipeRegisters()[IfId.IR.value()].substring(0, 6).equals(ITypeInstructions.bne.opcode()))
				inst = 0;
			else if(simulator.getPipeRegisters()[IfId.IR.value()].substring(0, 6).equals(ITypeInstructions.lw.opcode()))
				inst = 1;
			else if(simulator.getPipeRegisters()[IfId.IR.value()].substring(0, 6).equals(ITypeInstructions.sw.opcode()))
				inst = 2;
			else
				inst = 3;
			
			na = Utils.btoi(simulator.getPipeRegisters()[IfId.IR.value()].substring(6, 11));
			jTFbrr0.setText(""+na);
			jTFbrr4.setText(""+Utils.btoi(simulator.getRegisterBank().load(na)));
			na = Utils.btoi(simulator.getPipeRegisters()[IfId.IR.value()].substring(11, 16));
			jTFbrr1.setText(""+na);
			jTFbrr5.setText(""+Utils.btoi(simulator.getRegisterBank().load(na)));

			jTFrw.setText(simulator.getPipeRegisters()[MemWb.RegWrite.value()]);

			if(simulator.getPipeRegisters()[IdEx.ALUOp.value()].equals(Funct.add.code())) 
				jTFuo.setText("add");
			else if(simulator.getPipeRegisters()[IdEx.ALUOp.value()].equals(Funct.sub.code())) 
				jTFuo.setText("sub");
			else if(simulator.getPipeRegisters()[IdEx.ALUOp.value()].equals(Funct.and.code())) 
				jTFuo.setText("and");
			else
				jTFuo.setText("or");

			if(inst == 3)
				jTFrd.setText("0");
			else
				jTFrd.setText("1");

			if(simulator.getPipeRegisters()[MemWb.RegWrite.value()].equals("1")) {
				na = Utils.btoi(simulator.getPipeRegisters()[MemWb.IR.value()].substring(16, 21));
				jTFbrr2.setText(""+na);
				if(simulator.getPipeRegisters()[MemWb.MemToReg.value()].equals("0"))
					jTFbrr3.setText(""+Utils.btoi(simulator.getPipeRegisters()[MemWb.ALUOutput.value()]));
				else
					jTFbrr3.setText(""+Utils.btoi(simulator.getPipeRegisters()[MemWb.LMD.value()]));
			}
			else {
				jTFbrr2.setText("8");
				jTFbrr3.setText("0");
			}

			jTFas.setText(simulator.getPipeRegisters()[IdEx.ALUSrc.value()]);

			na = Utils.btoi(simulator.getPipeRegisters()[ExMem.ALUOutput.value()]);
                        if (na >= 0 && na < simulator.getDataMemorySize()/4)
                            jTdados.setRowSelectionInterval(na, na);
			
			//if(simulator.getPipeRegisters()[ExMem.MemWrite.value()])
			jTFmw.setText(simulator.getPipeRegisters()[ExMem.MemWrite.value()]);
			jTFmr.setText(simulator.getPipeRegisters()[ExMem.MemRead.value()]);
			
			jTFmdr0.setText(""+na);
                        if (na >= 0 && na < simulator.getDataMemorySize()/4)
                            jTFmdr2.setText(""+Utils.btoi(simulator.getDataMemory().load(na)));
			jTFmdr1.setText(""+Utils.btoi(simulator.getPipeRegisters()[ExMem.B.value()]));

			jTFmtr.setText(simulator.getPipeRegisters()[MemWb.MemToReg.value()]);

			//Atualiza valor dos registradores do banco de registradores
			for (int i = 0; i < 8; i++)
				registers[i].setText(""+Utils.btoi(simulator.getRegisterBank().load(i)));

			//Atualiza valor do pc
			jTFpc.setText(Integer.toString(simulator.getPC()));

			//Atualiza valor dos registradores em IF/ID
			jTF1ir.setText(simulator.getPipeRegisters()[IfId.IR.value()]);
			jTF1npc.setText(""+Utils.btoi(simulator.getPipeRegisters()[IfId.NPC.value()]));
			jTF1pc.setText(""+Utils.btoi(simulator.getPipeRegisters()[IfId.PC.value()]));

			//Atualiza valor dos registradores em ID/EXE
			jTF2rd.setText(simulator.getPipeRegisters()[IdEx.RegDst.value()]);
			jTF2ao.setText(simulator.getPipeRegisters()[IdEx.ALUOp.value()]);
			jTF2as.setText(simulator.getPipeRegisters()[IdEx.ALUSrc.value()]);
			jTF2br.setText(simulator.getPipeRegisters()[IdEx.Branch.value()]);
			jTF2mr.setText(simulator.getPipeRegisters()[IdEx.MemRead.value()]);
			jTF2mw.setText(simulator.getPipeRegisters()[IdEx.MemWrite.value()]);
			jTF2rw.setText(simulator.getPipeRegisters()[IdEx.RegWrite.value()]);
			jTF2mtr.setText(simulator.getPipeRegisters()[IdEx.MemToReg.value()]);
			jTF2ir.setText(simulator.getPipeRegisters()[IdEx.IR.value()]);
			jTF2npc.setText(""+Utils.btoi(simulator.getPipeRegisters()[IdEx.NPC.value()]));
			jTF2a.setText(""+Utils.btoi(simulator.getPipeRegisters()[IdEx.A.value()]));
			jTF2b.setText(""+Utils.btoi(simulator.getPipeRegisters()[IdEx.B.value()]));
			jTF2Imm.setText(""+Utils.btoi(simulator.getPipeRegisters()[IdEx.Imm.value()]));

			//Atualiza valor dos registradores em EXE/MEM
			jTF3br.setText(simulator.getPipeRegisters()[ExMem.Branch.value()]);
			jTF3mr.setText(simulator.getPipeRegisters()[ExMem.MemRead.value()]);
			jTF3mw.setText(simulator.getPipeRegisters()[ExMem.MemWrite.value()]);
			jTF3rw.setText(simulator.getPipeRegisters()[ExMem.RegWrite.value()]);
			jTF3mtr.setText(simulator.getPipeRegisters()[ExMem.MemToReg.value()]);
			jTF3ir.setText(simulator.getPipeRegisters()[ExMem.IR.value()]);
			jTF3ao.setText(""+Utils.btoi(simulator.getPipeRegisters()[ExMem.ALUOutput.value()]));
			jTF3b.setText(""+Utils.btoi(simulator.getPipeRegisters()[ExMem.B.value()]));
			jTF3z.setText(simulator.getPipeRegisters()[ExMem.Zero.value()]);

			//Atualiza valor dos registradores em MEM/WB
			jTF4rw.setText(simulator.getPipeRegisters()[MemWb.RegWrite.value()]);
			jTF4mtr.setText(simulator.getPipeRegisters()[MemWb.MemToReg.value()]);
			jTF4ir.setText(simulator.getPipeRegisters()[MemWb.IR.value()]);
			jTF4ao.setText(""+Utils.btoi(simulator.getPipeRegisters()[MemWb.ALUOutput.value()]));
			jTF4lmd.setText(simulator.getPipeRegisters()[MemWb.LMD.value()]);

			//Atualiza memoria de dados
			for (int i = 0; i < simulator.getDataMemorySize()/4; i++) {
                            model.setValueAt(""+Utils.btoi(simulator.getDataMemory().load(i)), i, 1);
                        }
                        
                        //Atualiza (muda cores) a memoria  de instrucoes
                        opcode = simulator.getPipeRegisters()[ExMem.IR.value()].substring(0, 6);
                        
                        //Branch ira ocorrer
                        if (opcode.equals(ITypeInstructions.bne.opcode()) && simulator.getPipeRegisters()[ExMem.Zero.value()] == "0") {
                            phase = Utils.btoi(simulator.getPipeRegisters()[ExMem.AddResult.value()])/4;
                            shift = phase%4;
                            iter = -1;
                        }
                        //Branch nao ira ocorrer
                        else {
                            if (iter >= 4)
                                    phase++;               
                        }
                        
                        //Especifica o novo rendereizador para as células da tabela
                        for (int i = 0; i < ncols; i++) {
				jTinstrucao.getColumnModel().getColumn(i).setCellRenderer(new MyRenderer());
			}
                        
                        //Pinta os registradores entre os estágios e as memórias.
			for (int i = 0; i < 4; i++) {
                                //Se forem indices inválidos (após branch, ou logo no início antes de o pipeline estar cheio) pinta de ciano
				if (indexes[i] < 0) {
					c[i] = Color.cyan;
				}
                                //Se forem índices válidos, pinta com as cores respectivas.
				else {
					ind = indexes[i];
					c[i] = new Color (colors[ind][0], colors[ind][1], colors[ind][2]);
				}
			}
                        
                        //colorindo memoria de instrucao e registradores ID/IF
			jPmeminstr.setBackground(c[0]);
			jPidid.setBackground(c[0]);

			//colorindo banco de registradores e registradores IF/EXe
			jPbr.setBackground(c[1]);
			jPidexe.setBackground(c[1]);

                        //Pinta registradores EX/MEM
			jPexemem.setBackground(c[2]);
                        
                         //pinta registradores MEM/WB e memória de dados
			jPmemdados.setBackground(c[3]);
			jPmemwb.setBackground(c[3]);
                        
                        //Manda "repintar" a tabela
			jTinstrucao.repaint();

                        //Executa etapas (manda mais um clock)
                        simulator.fetchInstruction();
			simulator.decodeInstruction();
			simulator.executeInstruction();
			simulator.accessMemory();
			simulator.writeBack();
			simulator.updatePipeRegisters();
                        
                        this.iter++;
		}
	}//GEN-LAST:event_jBproximaActionPerformed
        /**
         * Função responśavel por inicializar o conteúdo, na interface gráfica,
         * na tabela referente à memória de instrução.
         * @param evt Evento "Focus Gained" detectado na tabela de instrução.
         */
	private void jTinstrucaoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTinstrucaoFocusGained
		jTinstrucao.getColumnModel().getColumn(0).setPreferredWidth(20);
		jTinstrucao.getColumnModel().getColumn(1).setPreferredWidth(110);
		jTdados.getColumnModel().getColumn(0).setPreferredWidth(20);
		jTdados.getColumnModel().getColumn(1).setPreferredWidth(110);

		DefaultTableModel model = (DefaultTableModel) jTdados.getModel();

		int i;
		for(i = 0; i < simulator.getDataMemorySize(); i+=4) {
			model.addRow(new Object[]{i, ""});
		}
	}//GEN-LAST:event_jTinstrucaoFocusGained
        
        /**
         * Função responsável pelo botão de "Vá para" na interface gráfica,
         * que deixa uma certa linha em foco na tabela da memória de dados.
         * @param evt Evento detectado no botão "Vá para"
         */
	private void jBgotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBgotoActionPerformed
		if(this.instructionsLoaded == true) {
			int line = Integer.parseInt(jTFgoto.getText());
			if (line < jTdados.getRowCount())
				jTdados.scrollRectToVisible(jTdados.getCellRect(line, 0, true));
		}
	}//GEN-LAST:event_jBgotoActionPerformed

	/**
         * Main.
	 * @param args Argumentos da linha de comando.
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
		/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
		 * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		//</editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Principal().setVisible(true);
			}
		});

	}
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBcarregar;
    private javax.swing.JButton jBgoto;
    private javax.swing.JButton jBproxima;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPbr;
    private javax.swing.JPanel jPexemem;
    private javax.swing.JPanel jPidexe;
    private javax.swing.JPanel jPidid;
    private javax.swing.JPanel jPmemdados;
    private javax.swing.JPanel jPmeminstr;
    private javax.swing.JPanel jPmemwb;
    private javax.swing.JPanel jPmux1;
    private javax.swing.JPanel jPmux2;
    private javax.swing.JPanel jPmux3;
    private javax.swing.JPanel jPmux4;
    private javax.swing.JPanel jPmux5;
    private javax.swing.JPanel jPmux7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTF1ir;
    private javax.swing.JTextField jTF1npc;
    private javax.swing.JTextField jTF1pc;
    private javax.swing.JTextField jTF2Imm;
    private javax.swing.JTextField jTF2a;
    private javax.swing.JTextField jTF2ao;
    private javax.swing.JTextField jTF2as;
    private javax.swing.JTextField jTF2b;
    private javax.swing.JTextField jTF2br;
    private javax.swing.JTextField jTF2ir;
    private javax.swing.JTextField jTF2mr;
    private javax.swing.JTextField jTF2mtr;
    private javax.swing.JTextField jTF2mw;
    private javax.swing.JTextField jTF2npc;
    private javax.swing.JTextField jTF2rd;
    private javax.swing.JTextField jTF2rw;
    private javax.swing.JTextField jTF3ao;
    private javax.swing.JTextField jTF3b;
    private javax.swing.JTextField jTF3br;
    private javax.swing.JTextField jTF3ir;
    private javax.swing.JTextField jTF3mr;
    private javax.swing.JTextField jTF3mtr;
    private javax.swing.JTextField jTF3mw;
    private javax.swing.JTextField jTF3rw;
    private javax.swing.JTextField jTF3z;
    private javax.swing.JTextField jTF4ao;
    private javax.swing.JTextField jTF4ir;
    private javax.swing.JTextField jTF4lmd;
    private javax.swing.JTextField jTF4mtr;
    private javax.swing.JTextField jTF4rw;
    private javax.swing.JTextField jTFas;
    private javax.swing.JTextField jTFbrr0;
    private javax.swing.JTextField jTFbrr1;
    private javax.swing.JTextField jTFbrr2;
    private javax.swing.JTextField jTFbrr3;
    private javax.swing.JTextField jTFbrr4;
    private javax.swing.JTextField jTFbrr5;
    private javax.swing.JTextField jTFgoto;
    private javax.swing.JTextField jTFmdr0;
    private javax.swing.JTextField jTFmdr1;
    private javax.swing.JTextField jTFmdr2;
    private javax.swing.JTextField jTFmr;
    private javax.swing.JTextField jTFmtr;
    private javax.swing.JTextField jTFmw;
    private javax.swing.JTextField jTFpc;
    private javax.swing.JTextField jTFr0;
    private javax.swing.JTextField jTFr1;
    private javax.swing.JTextField jTFr2;
    private javax.swing.JTextField jTFr3;
    private javax.swing.JTextField jTFr4;
    private javax.swing.JTextField jTFr5;
    private javax.swing.JTextField jTFr6;
    private javax.swing.JTextField jTFr7;
    private javax.swing.JTextField jTFrd;
    private javax.swing.JTextField jTFrw;
    private javax.swing.JTextField jTFuo;
    private javax.swing.JTable jTdados;
    private javax.swing.JTable jTinstrucao;
    // End of variables declaration//GEN-END:variables
}
