package scoreboarding;

import java.io.FileNotFoundException;
import java.util.Scanner;
import view.ScoreboardingInterface;

public class ArqCompTrab1 {
    
    //Funcao principal
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        //Cria um objeto scoreboarding, e imprime seu estado inicial e de seus componentes
        Scoreboarding scoreboarding = new Scoreboarding();
        System.out.println("\nScoreboarding:\n");
        //scoreboarding.next();
        scoreboarding.printScoreboarding();

        //Inicializa interface grafica
        ScoreboardingInterface telaInicial = new ScoreboardingInterface(scoreboarding);
        telaInicial.setVisible(true);
        
        //Dados para testes/uso em terminal
//        System.out.println("Press \"ENTER\" to continue...");
//        Scanner scanner = new Scanner(System.in);
//        while (!scanner.nextLine().equals("e")) {
//            scoreboarding.next();
//            scoreboarding.printScoreboarding();
//
//            System.out.println("Memory:");
//            scoreboarding.printMemory();
//
//            System.out.println("\nRegisters:");
//            scoreboarding.printRegisters();
//        }
        
        //Dados para testar e imprimir estado das coisas utilizadas(ex: registradores, unidades funcionais, etc.)
//        scoreboarding.solveAll();
//        scoreboarding.printScoreboarding();
//
//        //inicializar uma memoria
//        Memory memory = new Memory();
//        memory.readMemory("./Memory.txt");
//
//        System.out.println("Memory:");
//        memory.printMemory();
//
//        //inicializar registradores que podem ser inicializados
//        Register.initializeRegisters();
//        Register.readRegisters("./RegistersInit.txt");
//
//        //inicializar codigo assembly se possivel e registradores restantes com valor 0
//        ArrayList<AssemblyInstruction> assemblyCode = AssemblyCode.readAssembly("./AssemblyCode.txt");
//
//        System.out.println("\nAssembly Instructions:");
//        for (AssemblyInstruction ai : assemblyCode) {
//            ai.printInstruction();
//        }
//
//        System.out.println("\nRegisters:");
//        Register.printRegisters();
//
//        //inicializar unidades funcionais que podem ser inicializadas
//        FunctionalUnit.initializeFunctionalUnits();
//        FunctionalUnit.readFunctionalUnits("./FunctionalUnits.txt");
//
//        System.out.println("\nFunctionalUnitis:");
//        FunctionalUnit.printFunctionalUnits();
    }
}
