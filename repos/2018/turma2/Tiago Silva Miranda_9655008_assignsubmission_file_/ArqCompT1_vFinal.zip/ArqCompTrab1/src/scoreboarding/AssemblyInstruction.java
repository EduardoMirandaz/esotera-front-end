package scoreboarding;

import java.util.ArrayList;

//Classe que representa uma instrucao a ser processada no scoreboarding
public class AssemblyInstruction {
//por enquanto soh aceita instrucoes basicas (mudar aqui e no assemblyCode, etc.
//se necessario para aceitar/tratar outras se necessario)

    private String name; //nome da instrucao (ex: ADD.D)
    private Character type; //tipo da instrucao (ex: tipo R, I, L/S -> Load/Store)
    private ArrayList<Register> instructionRegisters; //registradores (ex: F6, R2, ...) (valor1, valor2, valor3)
    private ArrayList<Float> instructionValues; //valores (ex: 24, 32, ...) (valor1, valor2, valor3)
    //private int number; //valor de instrucoes que contem valor (ex: tipo I -> valor imediato, tipo S/L -> "posicao da memoria")
    private Float instructionRes; //resultado da instrucao apos executar

    //Construtor
    public AssemblyInstruction() {
        name = null;
        type = 0;
        instructionRegisters = new ArrayList<>();
        instructionValues = new ArrayList<>();
        instructionRes = null;
    }

    //Construtor com parametros
    public AssemblyInstruction(String name, Character type, ArrayList<Register> instructionRegisters, ArrayList<Float> instructionValues, Float instructionRes) {
        this.name = name;
        this.type = type;
        this.instructionRegisters = instructionRegisters;
        this.instructionValues = instructionValues;
        this.instructionRes = instructionRes;
    }

    //Funcao que determina o tipo da instrucao, e altera o tipo de dados para refletir isso
    public void findInstructionType() {
        //Instrucoes do tipo D tem o dado tipo double
        //Do contrario, tem o tipo Int (no fim das contas todos os valores sao tratados como float)
        switch (name) {
            //Instrucao tipo Load
            case "LW.D":
//                name = name.substring(0, name.length() - 2);
                setRegistersInt(false);
            case "LW":
                type = 'L';
                break;
            //Instrucoes tipo Store
            case "SW.D":
//                name = name.substring(0, name.length() - 2);
                setRegistersInt(false);
            case "SW":
                type = 'S';
                break;
            //Instrucoes com valor imediato
            case "ADDI.D":
//                name = name.substring(0, name.length() - 2);
                setRegistersInt(false);
            case "ADDI":
                type = 'I';
                break;
            //Instrucoes com operandos em registradores
            case "ADD.D":
            case "SUB.D":
            case "DIV.D":
            case "MULT.D":
//                name = name.substring(0, name.length() - 2);
                setRegistersInt(false);
            case "ADD":
            case "SUB":
            case "DIV":
            case "MULT":
                type = 'R';
                break;
            default:
                System.out.println("Instruction Not Found - " + name);
                System.exit(0);
                break;
        }
    }

    //Funcao que define o tipo de dados no banco de registradores
    public void setRegistersInt(boolean isRegistersInt) {
        for (Register r : instructionRegisters) {
            r.setIsRegisterInt(isRegistersInt);
        }
    }

    //Funcao para impressao da instrucao
    public void printInstruction() {
        switch (type) { //Cada instrucao sera impressa de acordo com a estrutura de seus operandos
            case 'L':
            case 'S':
                System.out.println(name + "[" + type + "]: "
                        + instructionRegisters.get(0).getName() + " "
                        + instructionValues.get(0) + " "
                        + instructionRegisters.get(1).getName() + "");
                break;
            case 'I':
                System.out.println(name + "[" + type + "]: "
                        + instructionRegisters.get(0).getName() + " "
                        + instructionRegisters.get(1).getName() + " "
                        + instructionValues.get(0) + "");
                break;
            case 'R':
                System.out.println(name + "[" + type + "]: "
                        + instructionRegisters.get(0).getName() + " "
                        + instructionRegisters.get(1).getName() + " "
                        + instructionRegisters.get(2).getName() + "");
                break;
        }
    }

    //Funcao para impressao da instrucao, com dados inteiros
    public void printInstructionWithIsInt() {
        switch (type) {
            case 'L':
            case 'S':
                System.out.println(name + "[" + type + "]: "
                        + instructionRegisters.get(0).getName() + "[" + instructionRegisters.get(0).isIsRegisterInt() + "] "
                        + instructionValues.get(0) + " "
                        + instructionRegisters.get(1).getName() + "[" + instructionRegisters.get(1).isIsRegisterInt() + "]");
                break;
            case 'I':
                System.out.println(name + "[" + type + "]: "
                        + instructionRegisters.get(0).getName() + "[" + instructionRegisters.get(0).isIsRegisterInt() + "] "
                        + instructionRegisters.get(1).getName() + "[" + instructionRegisters.get(1).isIsRegisterInt() + "] "
                        + instructionValues.get(0) + "");
                break;
            case 'R':
                System.out.println(name + "[" + type + "]: "
                        + instructionRegisters.get(0).getName() + "[" + instructionRegisters.get(0).isIsRegisterInt() + "] "
                        + instructionRegisters.get(1).getName() + "[" + instructionRegisters.get(1).isIsRegisterInt() + "] "
                        + instructionRegisters.get(2).getName() + "[" + instructionRegisters.get(2).isIsRegisterInt() + "]");
                break;
        }
    }

    //Funcao para definicao dos dados no banco de registradores, de acordo com os operandos
    public void setRegistersValues() {
        switch (type) {
            case 'R':
                instructionRegisters.get(2).setValue(Register.findRegisterByName(
                        instructionRegisters.get(2).getName()).getValue()); //Lendo r2
            case 'S':
                instructionRegisters.get(0).setValue(Register.findRegisterByName(
                        instructionRegisters.get(0).getName()).getValue()); //Lendo r0
            case 'L':
            case 'I':
                instructionRegisters.get(1).setValue(Register.findRegisterByName(
                        instructionRegisters.get(1).getName()).getValue()); //Lendo r1
                break;
        }
    }

    //Funcao que executa a instrucao
    public void executeInstruction() {
        switch (type) {
            case 'L':
            case 'S':
                instructionRes = instructionRegisters.get(1).getValue() + instructionValues.get(0); //executando calculo do endereco para load/store
                break;
            case 'I':
                switch (name) {
                    case "ADDI.D":
                    case "ADDI":
                        instructionRes = instructionRegisters.get(1).getValue() + instructionValues.get(0);  //executando add com valor imediato - r1 + IM
                        break;
                }
            case 'R':
                switch (name) {
                    case "ADD.D":
                    case "ADD":
                        instructionRes = instructionRegisters.get(1).getValue() + instructionRegisters.get(2).getValue(); //executando adicao com valores dos registradores - r1 + r2
                        break;
                    case "SUB.D":
                    case "SUB":
                        instructionRes = instructionRegisters.get(1).getValue() - instructionRegisters.get(2).getValue(); //executando subtracao com valores dos registradores - r1 - r2
                        break;
                    case "DIV.D":
                        instructionRes = (float) (int) (instructionRegisters.get(1).getValue() / instructionRegisters.get(2).getValue()); //executando divisao real com valores dos registradores - r1/r2
                        break;
                    case "DIV":
                        instructionRes = instructionRegisters.get(1).getValue() / instructionRegisters.get(2).getValue(); //executando divisao inteira com valores dos registradores - r1/r2
                        break;
                    case "MULT.D":
                    case "MULT":
                        instructionRes = instructionRegisters.get(1).getValue() * instructionRegisters.get(2).getValue(); //executando multiplicacao com valores dos registradores - r1*r2
                        break;
                }
                break;
        }
    }

    //Funcao que escreve o resultado da instrucao
    public void writeBackInstruction(Memory memory) {
        Register regAux = Register.findRegisterByName(instructionRegisters.get(0).getName()); //obtendo referencia para r0
        switch (type) {
            //Load/Store - escreve o resultado na memoria
            case 'L':
                regAux.setValue(memory.getValueByPosition(instructionRes.intValue())); //escrevendo no r0 o conteudo da memoria no endereco obtido pela funcao executeInstruction()
                break;
            case 'S':
                memory.setValueByPosition(instructionRes.intValue(), instructionRegisters.get(0).getValue()); //escrevendo o conteudo de r0 na memoria na posicao obtida em executeInstructio()
                break;
            //Outras instrucoes - escreve o resultado no banco de registradores(r0)
            case 'I':
            case 'R':
                regAux.setValue(instructionRes); //r0 = resultado da instrucao
                break;
        }
    }

    /* Getters e Setters para os atributos da classe */
    public Float getInstructionRes() {
        return instructionRes;
    }

    public void setInstructionRes(Float instructionRes) {
        this.instructionRes = instructionRes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Character getType() {
        return type;
    }

    public void setType(Character type) {
        this.type = type;
    }

    public ArrayList<Register> getInstructionRegisters() {
        return instructionRegisters;
    }

    public void setInstructionRegisters(ArrayList<Register> instructionRegisters) {
        this.instructionRegisters = instructionRegisters;
    }

    public ArrayList<Float> getInstructionValues() {
        return instructionValues;
    }

    public void setInstructionValues(ArrayList<Float> instructionValues) {
        this.instructionValues = instructionValues;
    }

}
