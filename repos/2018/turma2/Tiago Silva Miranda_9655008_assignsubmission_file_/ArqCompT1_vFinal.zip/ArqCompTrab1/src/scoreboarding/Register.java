package scoreboarding;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Classe que simula um registrador, com seu nome, valor guardado e status
public class Register implements Comparable<Register> {

    public static ArrayList<Register> registers; //registradores

    private String name; //nome do registrador
    private Float value; //valor do registrador
    private Boolean isRegisterInt; //se a instrucao trata de registradores inteiros ou double

    private String status; //status do registrador (nome da unidade funcional que ira escrever nele, '0' caso nenhuma)

    //Construtor
    public Register() {
        name = null;
        value = null;
        isRegisterInt = true;
        status = "";
    }

    //Construtor com parametros
    public Register(String name, Float value, Boolean isRegisterInt, String status) {
        this.name = name;
        this.value = value;
        this.isRegisterInt = isRegisterInt;
        this.status = status;
    }

    //Funcao de inicializacao do banco de registradores
    public static void initializeRegisters() {
        registers = new ArrayList<>();
    }

    //Funcao que le o arquivo que inicializa o banco de registradores
    public static void readRegisters(String path) throws FileNotFoundException { //le um "arquivo de registradores"
        File registersFile = new File(path);
        Scanner scanner = new Scanner(registersFile/*"F2 10 F6 23"*/);

        scanner.useDelimiter("\\n|\\s|\\r"); //delimitador pro scanner

        while (scanner.hasNext()) { //ler cada uma das entradas/instrucoes
            Register newRegister = new Register();
            String name = readName(scanner);

            if (name.equals("null")) {
                return;
            }
            newRegister.setName(name);
            newRegister.setValue(readValue(scanner));
            newRegister.setIsRegisterInt(false);
            newRegister.setStatus("0");

            //apos criacao do registrador, incluimos no banco
            Register.registers.add(newRegister);
        }
    }

    //Funcao auxiliar - le uma string de um arquivo a partir da posicao dada
    //pelo scanner
    public static String readName(Scanner scanner) {
        String name = scannerGetNext(scanner);

        return name;
    }

    //Funcao auxiliar - le um valor Float de um arquivo a partir da posicao
    //dada pelo scanner
    public static Float readValue(Scanner scanner) {
        Float newValue = Float.valueOf(scannerGetNext(scanner));

        return newValue;
    }

    //Funcao auxiliar - retorna a proxima string valida a partir da posicao
    //dada pelo scanner
    public static String scannerGetNext(Scanner scanner) {
        String stringAux = "";
        do {
            if (scanner.hasNext()) {
                stringAux = scanner.next();
            } else {
                stringAux = "null";
            }
        } while (stringAux.equals(""));
        return stringAux;
    }

    //Imprime o banco de registradores com seus respectivos valores
    public static void printRegisters() {
        for (Register r : registers) {
            System.out.println(r.getName() + " : " + r.getValue());
        }
    }

    //Retorna um objeto registrador a partir de seu nome
    public static Register findRegisterByName(String registerName) {
        for (Register r : registers) {
            if (r.name.equals(registerName)) {
                return r;
            }
        }
        return null;
    }

    /* Getters e Setters para os atributos da classe */
    public Boolean isIsRegisterInt() {
        return isRegisterInt;
    }

    public void setIsRegisterInt(Boolean isRegisterInt) {
        this.isRegisterInt = isRegisterInt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getValue() {
        return value;
    }

    public void setValue(Float value) {
        this.value = value;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int compareTo(Register register) { //Funcao para comparacao do nome de dois registradores
        return name.compareTo(register.name);
    }
}
