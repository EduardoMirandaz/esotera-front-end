package scoreboarding;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Definicao de funcoes de leitura do conjunto de instrucoes a partir de um arquivo de entrada
public class AssemblyCode {

    //private AssemblyInstruction[] assemblyCode; //codigo em assembly com as instrucoes
    //Funcao de leitura para o arquivo que contem o programa a ser executado
    public static ArrayList<AssemblyInstruction> readAssembly(String path) throws FileNotFoundException { //"le um arquivo em assembly" e retorna o codigo
        File assemblyFile = new File(path);
        Scanner scanner = new Scanner(assemblyFile/*LW.D F6, 30(R3)"*/);

        scanner.useDelimiter(",|\\n|\\s|\\(|\\)|\\r"); //delimitador pro scanner

        ArrayList<AssemblyInstruction> assemblyCode = new ArrayList<>(); //codigo em assembly

        String stringAux;
        AssemblyInstruction assemblyInstruction = null;
        while (scanner.hasNext()) { //ler cada uma das entradas/instrucoes
            stringAux = scanner.next();
            if (!stringAux.equals("")) {
                //instrucao
                assemblyInstruction = new AssemblyInstruction();
                assemblyInstruction.setName(stringAux);
                assemblyInstruction.findInstructionType();

                //ler registradores e/ou valores imediatos
                switch (assemblyInstruction.getType()) {
                    //Load/Store - operandos(r0, offset, r1)
                    case 'L':
                    case 'S':
                        readRegister(assemblyInstruction, scanner); //Lendo r0
                        readImmediate(assemblyInstruction, scanner); //Lendo offset
                        readRegister(assemblyInstruction, scanner); //Lendo r1
                        break;
                    //Instrucao com valor imediato
                    case 'I':
                        readRegister(assemblyInstruction, scanner); //Lendo r0
                        readRegister(assemblyInstruction, scanner); //Lendo r1
                        readImmediate(assemblyInstruction, scanner); //Lendo valor
                        break;
                    //Instrucao tipo R (com 3 registradores)
                    case 'R':
                        readRegister(assemblyInstruction, scanner); //Lendo r0
                        readRegister(assemblyInstruction, scanner); //Lendo r1
                        readRegister(assemblyInstruction, scanner); //Lendo r2
                        break;
                }
                //System.out.println(stringAux + "\n");

                assemblyCode.add(assemblyInstruction);
            }
        }

        return assemblyCode;
    }

    //Funcao que le o nome de um operando da instrucao, criando-o se ja nao existe
    //no banco de registradores
    public static void readRegister(AssemblyInstruction assemblyInstruction, Scanner scanner) {
        String registerI = scannerGetNext(scanner);
        Register newRegister = Register.findRegisterByName(registerI);

        if (newRegister == null) {
            newRegister = new Register(registerI, 0f, false, "0");
            Register.registers.add(newRegister);
        }

        //depois de definido o registrador, adiciona-o como um operando da instrucao
        assemblyInstruction.getInstructionRegisters().add(newRegister);
    }

    //Funcao que le um operando como valor imediato
    public static void readImmediate(AssemblyInstruction assemblyInstruction, Scanner scanner) {
        Float newImmediate = Float.valueOf(scannerGetNext(scanner));

        assemblyInstruction.getInstructionValues().add(newImmediate);
    }

    //Funcao auxiliar - retorna a proxima string valida a partir da posicao
    //dada pelo scanner
    public static String scannerGetNext(Scanner scanner) {
        String stringAux = "";
        do {
            if (scanner.hasNext()) {
                stringAux = scanner.next();
            } else {
                stringAux = "null";
            }
        } while (stringAux.equals(""));
        return stringAux;
    }
}
