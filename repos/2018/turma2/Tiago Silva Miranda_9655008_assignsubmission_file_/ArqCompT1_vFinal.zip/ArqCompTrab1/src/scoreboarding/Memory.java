package scoreboarding;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Classe que simula a estrutura de uma memoria RAM
public class Memory {

    private ArrayList<Integer> position; //posicao da memoria
    private ArrayList<Float> value; //valor da posicao da memoria

    //Construtor
    public Memory() {
        position = new ArrayList<>();
        value = new ArrayList<>();
    }

    //Construtor com parametros
    public Memory(ArrayList<Integer> position, ArrayList<Float> value) {
        this.position = position;
        this.value = value;
    }

    //Le um arquivo de inicializacao e cria a estrutura da memoria
    public void readMemory(String path) throws FileNotFoundException { //le um "arquivo de memoria"
        File memoryFile = new File(path);
        Scanner scanner = new Scanner(memoryFile/*10 20 32 50"*/);

        scanner.useDelimiter("\\n|\\s|\\r"); //delimitador pro scanner

        while (scanner.hasNext()) { //ler cada uma das entradas/instrucoes
            //le a posicao de memoria e seu valor correspondente
            readValue(position, scanner);
            readValue(value, scanner);
        }
    }

    //Funcao que le um valor de um arquivo e armazena na lista "list"
    public static void readValue(ArrayList list, Scanner scanner) {
        String stringAux = scannerGetNext(scanner);
        if (stringAux.equals("null")) {
            return;
        }

        Float newValue = Float.valueOf(stringAux);

        list.add(newValue);
    }

    //Retorna o proximo item de um arquivo como uma string
    public static String scannerGetNext(Scanner scanner) {
        String stringAux = "";
        do {
            if (scanner.hasNext()) {
                stringAux = scanner.next();
            } else {
                stringAux = "null";
            }
        } while (stringAux.equals(""));
        return stringAux;
    }

    //Imprime a posicao de memoria e seu valor correspondente
    public void printMemory() {
        for (int i = 0; i < position.size(); i++) {
            System.out.println(position.get(i) + " : " + value.get(i));
        }
    }

    //Funcao que retorna o valor gravado no endereco "pos" da memoria
    public Float getValueByPosition(int pos) {
        //Percorre a lista ate a posicao pos
        for (int i = 0; i < position.size(); i++) {
            String sAux = String.valueOf(position.get(i)); //por algum motivo o ArrayList<Integer>
            sAux = sAux.substring(0, sAux.length() - 2); //retorna um Float (ex: 1.0) que da erro 
            int posAux = Integer.parseInt(sAux); //ao tentar ser convertido para int/Integer

            if (posAux == pos) {
                return value.get(i);
            }
        }

        System.out.println("Posicao nao encontrada!");
        return 0f;
    }

    //Funcao que grava um valor "val" no endereco "pos" da memoria
    public void setValueByPosition(int pos, float val) {
        for (int i = 0; i < position.size(); i++) {
            String sAux = String.valueOf(position.get(i)); //por algum motivo o ArrayList<Integer>
            sAux = sAux.substring(0, sAux.length() - 2); //retorna um Float (ex: 1.0) que da erro 
            int posAux = Integer.parseInt(sAux); //ao tentar ser convertido para int/Integer

            if (posAux == pos) {
                value.set(i, val);
                return;
            }
        }

        System.out.println("Posicao nao encontrada!");
    }

    /* Getters e Setters para os atributos da classe */
    public ArrayList<Integer> getPosition() {
        return position;
    }

    public void setPosition(ArrayList<Integer> position) {
        this.position = position;
    }

    public ArrayList<Float> getValue() {
        return value;
    }

    public void setValue(ArrayList<Float> value) {
        this.value = value;
    }
}
