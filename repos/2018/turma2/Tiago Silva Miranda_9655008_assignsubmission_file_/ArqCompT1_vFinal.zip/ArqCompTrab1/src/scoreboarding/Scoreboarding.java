package scoreboarding;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

//Classe que executa as instrucoes de acordo com o algoritmo de scoreboarding
public class Scoreboarding {

    private ArrayList<AssemblyInstruction> assemblyCode; //codigo em assembly com as instrucoes
    private ArrayList<Integer[]> instructionsStatus; // status das instrucoes 
    private ArrayList<Integer> currentInstructionsStatus; // em qual passo as instrucoes estao

    private int currentClock; //ciclo de clock atual

    private Memory memory;

    //Construtor
    public Scoreboarding() throws FileNotFoundException { //inicializar scoreboarding
        //inicializar uma memoria
        memory = new Memory();
        memory.readMemory("./Memory.txt");

        //Imprimindo o estado inicial da memoria
        System.out.println("Memory:");
        memory.printMemory();

        //inicializar registradores que podem ser inicializados
        Register.initializeRegisters();
        Register.readRegisters("./RegistersInit.txt");

        //inicializar codigo assembly se possivel e registradores restantes com valor 0
        assemblyCode = AssemblyCode.readAssembly("./AssemblyCode.txt");
        instructionsStatus = new ArrayList<>();
        currentInstructionsStatus = new ArrayList<>();

        //Imprimindo codigo a ser executado
        System.out.println("\nAssembly Instructions:");
        for (int i = 0; i < assemblyCode.size(); i++) {
//        for (AssemblyInstruction ai : assemblyCode) {
            assemblyCode.get(i).printInstruction();

            currentInstructionsStatus.add(0);
            instructionsStatus.add(new Integer[4]); //inicializar clocks
            for (int j = 0; j < instructionsStatus.get(i).length; j++) {
                instructionsStatus.get(i)[j] = null;
            }
        }

        Collections.sort(Register.registers); //ordenar registradores por "ordem alfabetica" para facilitar visualizacao
        System.out.println("\nRegisters:"); //Imprimindo estado inicial do banco de registradores
        Register.printRegisters();

        //inicializar unidades funcionais que podem ser inicializadas
        FunctionalUnit.initializeFunctionalUnits();
        FunctionalUnit.readFunctionalUnits("./FunctionalUnits.txt");

        //Imprimindo unidades funcionais
        System.out.println("\nFunctionalUnitis:");
        FunctionalUnit.printFunctionalUnits();

        currentClock = 1;
    }

    //Construtor com parametros
    public Scoreboarding(ArrayList<AssemblyInstruction> assemblyCode, ArrayList<Integer[]> instructionsStatus, ArrayList<Integer> currentInstructionsStatus, int currentClock, Memory memory) {
        this.assemblyCode = assemblyCode;
        this.instructionsStatus = instructionsStatus;
        this.currentInstructionsStatus = currentInstructionsStatus;
        this.currentClock = currentClock;
        this.memory = memory;
    }

    //Avanca um ciclo de clock
    public void next() {
//        Boolean bAux = true; //para soh despachar uma/a primeira instrucao por ciclo no maximo
        Boolean[] vAux = new Boolean[currentInstructionsStatus.size()]; //vetor utilizado para nao realizar mais de um passo
        for (int i = 0; i < currentInstructionsStatus.size(); i++) { //(Issue, ReadOp, ExecComplete, WriteRes) no mesmo ciclo de clock
            vAux[i] = false;
        }

        //tentar despachar uma instrucao (Issue)
        for (int i = 0; i < currentInstructionsStatus.size(); i++) {
            if (currentInstructionsStatus.get(i) == 0) {
                vAux[i] = checkIssue(i);
                break;
            }
        }

        //tentar realizar os outros passos (ReadOp, ExecComplete, WriteRes)
        for (int i = currentInstructionsStatus.size() - 1; i >= 0; i--) {
            if (!vAux[i] && currentInstructionsStatus.get(i) == 1) {
                vAux[i] = checkReadOp(i);
            } else if (!vAux[i] && currentInstructionsStatus.get(i) == 2) {
                vAux[i] = checkExecComplete(i);
            } else if (!vAux[i] && currentInstructionsStatus.get(i) == 3) {
                vAux[i] = checkWriteRes(i);
            }
        }

        currentClock++; //incrementar o clock
    }

    //Funcao para execucao do estagio Issue
    //checa se a instrucao i pode ser executada, e iniciando sua execucao quando possivel
    //Retorna true caso a instrucao foi colocada para executar
    public Boolean checkIssue(Integer i) {
        AssemblyInstruction ai = assemblyCode.get(i);
        Register regAux;
        for (FunctionalUnit fu : FunctionalUnit.functionalUnits) { //Iterando sobre as unidades funcionais
            for (String s : fu.getInstructionsUse()) {
                if (s.equals(ai.getName()) && !fu.getIsBusy()) {  //Caso em que a unidade atual pode processar a instrucao, e nao esta ocupada
                    if (!(ai.getType() == 'S')
                            && !Register.findRegisterByName(ai.getInstructionRegisters().get(0).getName()).getStatus().equals("0")) {  //Caso em que nao eh um Store, e r0 nao tem status 0 - nao faz nada
                        continue;
                    } else { //Caso contrario, definimos status de r0 como o nome da unidade funcional que escrevera nele
                        Register.findRegisterByName(ai.getInstructionRegisters().get(0).getName()).setStatus(fu.getName());
                    }

                    fu.setIsBusy(true); //Alterando o estado da unidade para ocupada
                    fu.setOp(ai.getName()); //Definindo a operacao sendo executada

                    switch (ai.getType()) { //Definindo os dados da unidade funcional
                        case 'L': //Caso Load/Store - Fi = r0 / Fj = offset / Fk = r1
                        case 'S':
                            fu.setFi(ai.getInstructionRegisters().get(0).getName());
                            fu.setFj(ai.getInstructionValues().get(0).toString());
                            fu.setFk(ai.getInstructionRegisters().get(1).getName());

                            regAux = Register.findRegisterByName(fu.getFk());
                            fu.setQk(regAux.getStatus()); //Qk = status de r1

                            if (!fu.getQk().equals("0")) { //Se r1 precisar esperar valor, Rk = false
                                fu.setRk(false);
                            }
                            break;
                        case 'I': //Caso tipo I: Fi = r0 / Fj = r1 / Fk = IMM
                            fu.setFi(ai.getInstructionRegisters().get(0).getName());
                            fu.setFj(ai.getInstructionRegisters().get(1).getName());
                            fu.setFk(ai.getInstructionValues().get(0).toString());

                            regAux = Register.findRegisterByName(fu.getFj());
                            fu.setQj(regAux.getStatus()); //Qj = status de r1

                            if (!fu.getQj().equals("0")) { //Se r1 precisar esperar valor, Rj = false
                                fu.setRj(false);
                            }
                            break;
                        case 'R': //Caso tipo R: Fi = r0 / Fj = r1 / Fk = r2
                            fu.setFi(ai.getInstructionRegisters().get(0).getName());
                            fu.setFj(ai.getInstructionRegisters().get(1).getName());
                            fu.setFk(ai.getInstructionRegisters().get(2).getName());

                            regAux = Register.findRegisterByName(fu.getFj());
                            fu.setQj(regAux.getStatus()); //Qj = status r1
                            regAux = Register.findRegisterByName(fu.getFk());
                            fu.setQk(regAux.getStatus()); //Qk = status r2

                            if (!fu.getQj().equals("0")) { //Se r1 precisar esperar valor, Rj = false
                                fu.setRj(false);
                            }
                            if (!fu.getQk().equals("0")) { //Se r2 precisar esperar valor, Rk = false
                                fu.setRk(false);
                            }
                            break;
                    }

                    fu.setInstructionNumber(i); //unidade funcional mantem o indice da instrucao que executa
                    instructionsStatus.get(i)[0] = currentClock; //salva o clock de conclusao
                    currentInstructionsStatus.set(i, 1); // proximo estado - readOp
                    return true;
                }
            }
        }
        return false;
    }

    //Funcao para execucao do estagio readOp
    //Checa se a instrucao esta numa unidade funcional, e tenta ler seus operandos
    //Retorna true se o estagio foi completo
    public Boolean checkReadOp(Integer i) {
        AssemblyInstruction ai = assemblyCode.get(i);
        for (FunctionalUnit fu : FunctionalUnit.functionalUnits) {
            if (Objects.equals(fu.getInstructionNumber(), i)) { //Se a instrucao i esta rodando na unidade funcional atual
                if (fu.getIsBusy() && fu.getRj() && fu.getRk()) { //Se a unidade esta ocupada, e os valores estao prontos para serem lidos
                    fu.setQj("0"); //Le os valores e seta as flags correspondentes
                    fu.setQk("0");
                    fu.setRj(false);
                    fu.setRk(false);

                    ai.setRegistersValues();

                    instructionsStatus.get(i)[1] = currentClock; //salva o clock de conclusao
                    currentInstructionsStatus.set(i, 2); //proximo estado - execComplete

                    return true;
                }
            }
        }
        return false;
    }

    //Funcao para execucao do estagio ExecComplete
    //Retorna true caso a execucao da instrucao foi finalizada
    public Boolean checkExecComplete(Integer i) {
        AssemblyInstruction ai = assemblyCode.get(i);
        for (FunctionalUnit fu : FunctionalUnit.functionalUnits) {
            if (Objects.equals(fu.getInstructionNumber(), i)) { //Encontrando a unidade funcional que esta processando a instrucao i
                for (int j = 0; j < fu.getInstructionsUse().size(); j++) {
                    //Simulando o delay de cada instrucao:
                    //Quando a diferenca entre o clock inicial e o clock atual se torna maior ou
                    //igual o tempo de execucao da instrucao, eh feita a execucao
                    if (fu.getInstructionsUse().get(j).equals(ai.getName()) && fu.getIsBusy()
                            && (currentClock - instructionsStatus.get(i)[1]) >= fu.getInstructionsTime().get(j)) {
                        ai.executeInstruction();

                        instructionsStatus.get(i)[2] = currentClock; //salva o clock de conclusao
                        currentInstructionsStatus.set(i, 3); //proximo estado - writeRes

                        return true;
                    }
                }
            }
        }
        return false;
    }

    //Funcao para execucao do estagio ExecComplete
    //Retorna true caso a execucao da instrucao foi finalizada
    public Boolean checkWriteRes(Integer i) {
        AssemblyInstruction ai = assemblyCode.get(i);
        for (FunctionalUnit fu : FunctionalUnit.functionalUnits) {
            if (Objects.equals(fu.getInstructionNumber(), i) && fu.getIsBusy()) { //Encontrando a unidade funcional que esta processando a instrucao i
                for (FunctionalUnit fu2 : FunctionalUnit.functionalUnits) {
                    if (!fu.equals(fu2)) {  //checando unidades diferentes da que executa i
                        if ((fu.getFi().equals(fu2.getFj()) && fu2.getRj())
                                || (fu.getFi().equals(fu2.getFk()) && fu2.getRk())) {
                            //caso em que uma unidade esta utilizando como um de seus operandos o registrador que queremos escrever: nao fazaer nada esse ciclo
                            return false;
                        }
                    }
                }

                Register regAux = Register.findRegisterByName(fu.getFi());
                if (!regAux.getStatus().equals("0")) {
                    for (FunctionalUnit fu2 : FunctionalUnit.functionalUnits) {
                        if (!fu.equals(fu2)) {
                            //alterando os status das outras unidades funcionais para refletir a
                            //escrita, e possibilitar a leitura do operando
                            if (regAux.getStatus().equals(fu2.getQj()) && !fu2.getRj()) {
                                fu2.setQj("0");
                                fu2.setRj(true);
                            }

                            if (regAux.getStatus().equals(fu2.getQk()) && !fu2.getRk()) {
                                fu2.setQk("0");
                                fu2.setRk(true);
                            }
                        }
                    }
                    regAux.setStatus("0");
                }

                fu.resetFunctionalUnit(); //liberando a unidade funcional para uso futuro

                ai.getInstructionRes(); //escrevendo o resultado no lugar correto

                ai.writeBackInstruction(memory);

                instructionsStatus.get(i)[3] = currentClock; //salva o clock de conclusao
                currentInstructionsStatus.set(i, 4); // ultimo estado

                return true;
            }
        }
        return false;
    }

    //Funcao que avanca o clock automaticamente ate a conclusao de todas as instrucoes
    public void solveAll() {
        Boolean boolAux = true;
        while (boolAux) {
            next();

            boolAux = false;
            for (Integer i : currentInstructionsStatus) {
                if (i != 4) {
                    boolAux = true;
                }
            }
        }
    }

    //Funcao de impressao do Scoreboarding e todos os seus componentes
    //com o estado atualizado
    public void printScoreboarding() {
        System.out.println("Current Clock: " + (currentClock - 1));
        System.out.println("Instruction Status\nIs\tRo\tEc\tWr");
        for (int i = 0; i < assemblyCode.size(); i++) {
            for (Integer f : instructionsStatus.get(i)) {
                System.out.print(f + "\t");
            }
            System.out.println();
        }
        System.out.println();

        System.out.println("Functional Unit Status\nBusy\tOp\tFi\tFj\tFk\tQj\tQk\tRj\tRk");
        for (FunctionalUnit fu : FunctionalUnit.functionalUnits) {
            System.out.println(fu.getIsBusy() + "\t" + fu.getOp() + "\t"
                    + fu.getFi() + "\t" + fu.getFj() + "\t" + fu.getFk() + "\t"
                    + fu.getQj() + "\t" + fu.getQk() + "\t"
                    + fu.getRj() + "\t" + fu.getRk() + "\t");
        }
        System.out.println();

        System.out.println("Register Result Status");
        for (Register r : Register.registers) {
            System.out.println(" " + r.getName() + " : " + r.getStatus());
        }
        System.out.println();
    }

    //Imprime o conteudo da memoria
    public void printMemory() {
        memory.printMemory();
    }

    //Imprime o conteudo do banco de registradores
    public void printRegisters() {
        Register.printRegisters();
    }

    /* Getters e Setters para os atributos da classe */
    public ArrayList<Integer> getCurrentInstructionsStatus() {
        return currentInstructionsStatus;
    }

    public void setCurrentInstructionsStatus(ArrayList<Integer> currentInstructionsStatus) {
        this.currentInstructionsStatus = currentInstructionsStatus;
    }

    public ArrayList<Integer[]> getInstructionsStatus() {
        return instructionsStatus;
    }

    public void setInstructionsStatus(ArrayList<Integer[]> instructionsStatus) {
        this.instructionsStatus = instructionsStatus;
    }

    public ArrayList<AssemblyInstruction> getAssemblyCode() {
        return assemblyCode;
    }

    public void setAssemblyCode(ArrayList<AssemblyInstruction> assemblyCode) {
        this.assemblyCode = assemblyCode;
    }

    public int getCurrentClock() {
        return currentClock;
    }

    public void setCurrentClock(int currentClock) {
        this.currentClock = currentClock;
    }

    public Memory getMemory() {
        return memory;
    }

    public void setMemory(Memory memory) {
        this.memory = memory;
    }
}
