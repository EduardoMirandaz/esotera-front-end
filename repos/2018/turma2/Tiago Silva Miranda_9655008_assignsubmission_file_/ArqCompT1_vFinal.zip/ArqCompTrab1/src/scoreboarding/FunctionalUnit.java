package scoreboarding;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Classe que representa uma unidade funcional para a implementacao do Scoreboarding
public class FunctionalUnit {

    public static ArrayList<FunctionalUnit> functionalUnits; //unidades funcionais

    private String name; //nome da unidade funcional
    private ArrayList<String> instructionsUse; //instrucoes que essa unidade funcional pode computar
    private ArrayList<Float> instructionsTime; //quantidade de clocks que as instrucoes levam para executar
    private Integer instructionNumber; //numero da instrucao que esta executando

    private Boolean isBusy; //dados da unidade funcional
    private String op;
    private String fi;
    private String fj;
    private String fk;
    private String qj;
    private String qk;
    private Boolean rj;
    private Boolean rk;

    //Construtor
    public FunctionalUnit() {
        name = null;
        instructionsUse = new ArrayList<>();
        instructionsTime = new ArrayList<>();
        instructionNumber = -1;
        isBusy = false;
        op = null;
        fi = null;
        fj = null;
        fk = null;
        qj = null;
        qk = null;
        rj = true;
        rk = true;
    }

    //Funcao que limpa o conteudo da unidade funcional
    public void resetFunctionalUnit() {
        instructionNumber = -1;
        isBusy = false;
        op = null;
        fi = null;
        fj = null;
        fk = null;
        qj = null;
        qk = null;
        rj = true;
        rk = true;
    }

    //Construtor com parametros
    public FunctionalUnit(String name, ArrayList<String> instructionsUse, ArrayList<Float> instructionsTime, Integer instructionNumber, Boolean isBusy, String op, String fi, String fj, String fk, String qj, String qk, Boolean rj, Boolean rk) {
        this.name = name;
        this.instructionsUse = instructionsUse;
        this.instructionsTime = instructionsTime;
        this.instructionNumber = instructionNumber;
        this.isBusy = isBusy;
        this.op = op;
        this.fi = fi;
        this.fj = fj;
        this.fk = fk;
        this.qj = qj;
        this.qk = qk;
        this.rj = rj;
        this.rk = rk;
    }

    //inicializa a lista de unidades funcionais
    public static void initializeFunctionalUnits() {
        functionalUnits = new ArrayList<>();
    }

    //Funcao que le o arquivo de definicao de unidades funcionais, com suas respectivas
    //instrucoes aceitas e tempos de clock
    public static void readFunctionalUnits(String path) throws FileNotFoundException { //le um "arquivo de unidades funcionais"
        File functionalUnitsFile = new File(path);
        Scanner scanner = new Scanner(functionalUnitsFile/*"ADD1 ADD.D ADD SUB.D SUB END"*/);

        scanner.useDelimiter("\\n|\\s|\\r"); //delimitador pro scanner

        while (scanner.hasNext()) { //ler cada uma das entradas/instrucoes
            FunctionalUnit newFunctionalUnit = new FunctionalUnit();
            String name = readString(scanner);

            if (name.equals("null")) {
                return;
            }
            newFunctionalUnit.setName(name);

            String stringAux = readString(scanner);
            while (!stringAux.equals("END")) {
                newFunctionalUnit.getInstructionsUse().add(stringAux); //inicializa o tipo de instrucao que essa unidade vai processar
                newFunctionalUnit.getInstructionsTime().add(readValue(scanner)); //inicializa o tempo de clock que a instrucao precisa para terminar

                stringAux = readString(scanner);
            }

            FunctionalUnit.functionalUnits.add(newFunctionalUnit);
        }
    }

    //Funcao auxiliar - le uma string de um arquivo a partir da posicao dada
    //pelo scanner
    public static String readString(Scanner scanner) {
        String name = scannerGetNext(scanner);

        return name;
    }

    //Funcao auxiliar - le um valor Float de um arquivo a partir da posicao
    //dada pelo scanner
    public static Float readValue(Scanner scanner) {
        Float newValue = Float.valueOf(scannerGetNext(scanner));

        return newValue;
    }

    //Funcao auxiliar - retorna a proxima string valida a partir da posicao
    //dada pelo scanner
    public static String scannerGetNext(Scanner scanner) {
        String stringAux = "";
        do {
            if (scanner.hasNext()) {
                stringAux = scanner.next();
            } else {
                stringAux = "null";
            }
        } while (stringAux.equals(""));
        return stringAux;
    }

    //Funcao que imprime as unidades funcionais e suas respectivas instrucoes
    //com tempos de clock
    public static void printFunctionalUnits() {
        for (FunctionalUnit fu : functionalUnits) {
            System.out.print(fu.getName() + " :");
            for (int i = 0; i < fu.getInstructionsUse().size(); i++) {
                System.out.print(" " + fu.getInstructionsUse().get(i) + " " + fu.getInstructionsTime().get(i));
            }
            System.out.println();
        }
    }

    //Funcao que retorna um objeto unidade funcional a partir de seu nome
    public static FunctionalUnit findFunctionalUnitByName(String functionalUnitName) {
        for (FunctionalUnit fu : functionalUnits) {
            if (fu.name.equals(functionalUnitName)) {
                return fu;
            }
        }
        return null;
    }

    /* Getters e Setters para os atributos da classe */
    public Integer getInstructionNumber() {
        return instructionNumber;
    }

    public void setInstructionNumber(Integer instructionNumber) {
        this.instructionNumber = instructionNumber;
    }

    public ArrayList<Float> getInstructionsTime() {
        return instructionsTime;
    }

    public void setInstructionsTime(ArrayList<Float> instructionsTime) {
        this.instructionsTime = instructionsTime;
    }

    public ArrayList<String> getInstructionsUse() {
        return instructionsUse;
    }

    public void setInstructionsUse(ArrayList<String> instructionsUse) {
        this.instructionsUse = instructionsUse;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getIsBusy() {
        return isBusy;
    }

    public void setIsBusy(Boolean isBusy) {
        this.isBusy = isBusy;
    }

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    public String getFi() {
        return fi;
    }

    public void setFi(String fi) {
        this.fi = fi;
    }

    public String getFj() {
        return fj;
    }

    public void setFj(String fj) {
        this.fj = fj;
    }

    public String getFk() {
        return fk;
    }

    public void setFk(String fk) {
        this.fk = fk;
    }

    public String getQj() {
        return qj;
    }

    public void setQj(String qj) {
        this.qj = qj;
    }

    public String getQk() {
        return qk;
    }

    public void setQk(String qk) {
        this.qk = qk;
    }

    public Boolean getRj() {
        return rj;
    }

    public void setRj(Boolean rj) {
        this.rj = rj;
    }

    public Boolean getRk() {
        return rk;
    }

    public void setRk(Boolean rk) {
        this.rk = rk;
    }
}
