﻿Trabalho 1 - Arquitetura de computadores
Simulador - Scoreboarding

Integrantes do grupo 	Nº USP
Bruno Waldvogel 	9847690
Eduardo Siqueira 	9278299
Tiago Silva Miranda 	9778992 

OBS: É importante ressaltar que o projeto foi desenvolvido com o uso da IDE Netbeans versão 8.1, jdk 1.7 em sistema operacional Windows 10 com java 1.8. Apesar de terem sido realizados testes do programa, pedimos desculpa caso ocorra qualquer problema, inclusive os que podem ocorrer devido a utilização de outros SOs e versões de java. Qualquer problema favor contatar os membros do grupo para possível correção e/ou explicação caso necessário.

Instruções de uso:

Para executar o programa, apenas execute o arquivo .jar incluído, com os arquivos:

  - AssemblyCode.txt
    
  - FunctionalUnits.txt
    
  - Memory.txt
    
  - RegistersInit.txt

presentes no mesmo diretório do .jar.


  
  Utilização Básica:
    - Botão "Next": Avança o ciclo de clock
        Caso já tenha terminado a execução, continua avançando apenas um ciclo.
    - Botão "Run All": Avança todos os ciclos até o fim do código
        Caso já tenha terminado a execução, avança apenas um ciclo.
    - Botão "Reset": Recomeça a simulação
        OBS: Após iniciar a simulação, dados salvos nos arquivos "<arquivo>.txt" podem ser alterados sem impacto na simulação. Esses mesmos arquivos não receberão atualizações decorrentes da simulação, ou seja, eles mantêm seus valores iniciais.
        OBS 2: Caso os arquivos "<arquivo>.txt" sejam alterados e o botão "Reset" seja pressionado, a simulação iniciará com os os novos dados inseridos, sem a necessidade de reabrir o programa.

- AssemblyCode.txt: contém o código em Assembly que será executado.

  Cada linha deve ser da forma:
    
    <INSTRUCAO> <OPERANDO>,  <OPERANDO>, <OPERANDO>

  ou para Load/Store:
    
    <INSTRUCAO> <REGISTRADOR>, <VALOR IMEDIATO>(<REGISTRADOR>)
  Instruções aceitas:
	LW, LW.D, SW, SW.D,
	ADD, ADD.D, ADDI, ADDI.D, SUB, SUB.D, 
	MULT, MULT.D, DIV, DIV.D
  
Exemplo:

    LW.D F6, 34(R2)

    LW.D F2, 45(R3)
    
MULT.D F0, F2, F4

    SUB.D F8, F6, F2

    DIV.D F10, F0, F6

    ADD.D F6, F8, F2

  Criar novas instruções:
    Para criar/inserir novas intruções aritméticas básicas de tipos já existentes (tipo I, R e L ou S), como um "shift", um "XOR", um "MULTADD" (multiplica e soma), basta acessar o código AssemblyInstruction.java e alterar/adicionar nas funções "findInstructionType()" e "executeInstruction()". Caso seja necessária a inserção de operações mais complexas como uma operação de branch (ex: BNE, BEQ, etc.), ou tipos diferentes (ex: tipo J, etc.) provavelmente será necessário alterar mais coisas nos códigos "AssemblyInstruction.java" e "Scoreboarding.java", entre outros. 


- FunctionalUnits.txt: contém a definição das unidades funcionais, com o nome, as instruções que ela aceita e os tempos de clock respectivos
.
  Cada linha deve ser da forma:
    
    <NOME DA UNIDADE> <INSTRUÇÃO1> <TEMPO DE EXECUÇÃO1> <INSTRUÇÃO2> <TEMPO DE EXECUÇÃO2> ... END

  Exemplo:

    LOAD1 LW.D 1 LW 1 SW.D 5 SW 5 END

    ADD1 ADDI.D 2 ADDI 2 ADD.D 2 ADD 2 SUB.D 2 SUB 2 END

    MULT1 MULT.D 10 MULT 10 END
MULT2 MULT.D 10 MULT 10 END

    DIV1 DIV.D 40 DIV 40 END



- 
Memory.txt: contém os endereços que serão utilizados, e seus respectivos conteúdos. É necessário definir todos os endereços que serão acessados.

  Cada linha deve ser da forma:
    
    <ENDERECO> <CONTEÚDO>

  Exemplo:

    1 10
    
32 50
    
34 100

    50 20




- RegistersInit.txt: contém os nomes dos registradores e seus respectivos conteúdos. Não é necessário definir todos os registradores que serão acessados, 
apenas aqueles que terão um valor inicial diferente de 0.
  
Cada linha deve ser da forma:
    
    <NOME DO REGISTRADOR> <CONTEÚDO>

  Exemplo:

    F6 10
  
  F2 2
  
  F0 5



