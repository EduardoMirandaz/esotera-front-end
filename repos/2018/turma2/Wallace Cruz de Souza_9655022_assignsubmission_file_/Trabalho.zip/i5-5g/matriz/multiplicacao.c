#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define TAM 2000

void print_matrix(long int **matrix, long int nrows, long int ncols){

  for(long int i = 0; i < nrows; i++){
    for(long int j = 0; j < ncols; j++)
      printf("%ld ", matrix[i][j]);

    printf("\n");
  }
}

void free_matrix(long int **matrix, long int nrows){

    for(long int i = 0;  i < nrows; i++)
      free(matrix[i]);

    free(matrix);
}

long int main(long int argc, char const *argv[]) {
  long int **matrix1,  **matrix2, **result;

  //Alocando memória para as matrixes
  matrix1 = (long int **) malloc(sizeof(long int *) * TAM);
  matrix2 = (long int **) malloc(sizeof(long int *) * TAM);
  result = (long int **) malloc(sizeof(long int *) * TAM);

  for(long int i = 0; i < TAM; i++){
    matrix1[i] = (long int *) malloc(sizeof(long int) * TAM);
    matrix2[i] = (long int *) malloc(sizeof(long int) * TAM);
    result[i] = (long int *) calloc(TAM, sizeof(long int)); //iniciando a matriz de resultado com zero
  }

  //preenchendo matrix1 e matrix2
  for(long int i = 0; i < TAM; i++)
    for(long int j = 0; j < TAM; j++ ){
      matrix1[i][j] = i + j;
      matrix2[i][j] = 2 * (i + j);
    }

  for(long int i = 0; i < TAM; i++)
    for(long int j = 0; j < TAM; j++)
      for(long int k = 0; k < TAM; k++)
        result[i][j] += matrix1[i][k] * matrix2[k][j];


  // print_matrix(result, TAM, TAM);


  free_matrix(matrix1, TAM);
  free_matrix(matrix2, TAM);
  free_matrix(result, TAM);

  return 0;
}
