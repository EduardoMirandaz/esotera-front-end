Os slides finalizados estão no arquivo pdf. O arquivo PowerPoint foi oferecido apenas como fonte caso deseje modificá-lo (há alguns erros de formatação quando aberto no OpenOffice por exemplo).

Integrantes descritos na monografia. Foi difícil achar outras 2 pessoas porque somos de outra turma :(
