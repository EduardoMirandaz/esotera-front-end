var _yt_player={};(function(g){var window=this;var ba,da,ia,ma,na,oa,qa,pa,ra,xa,caa,daa,Ga,eaa,faa,gaa,Na,haa,Ua,iaa,$a,Xa,jaa,Ya,kaa,laa,gb,kb,nb,ob,tb,wb,xb,uaa,Ab,Fb,Ib,Mb,Ob,Pb,Sb,Tb,$b,bc,ac,dc,fc,gc,waa,hc,lc,yaa,mc,zaa,pc,qc,tc,uc,wc,vc,Dc,Bc,Fc,Gc,Hc,Aaa,Daa,Eaa,Oc,Faa,Nc,od,sd,td,zd,Hd,Id,Jaa,cd,Naa,Oaa,Vd,Rd,$d,ae,ce,ge,be,he,ie,je,ke,le,me,ne,oe,pe,qe,re,se,te,we,xe,ue,ye,ze,Ae,Be,Ce,De,Ie,Ge,Je,Ke,Paa,Le,Me,He,Ne,Pe,Oe,Re,Se,Qe,Te,Ue,Qaa,$e,Saa,cf,df,ef,gf,lf,Taa,hf,of,vf,uf,Vaa,kf,yf,zf,Af,Bf,Df,Waa,Ef,Ff,Xaa,Kf,Mf,Nf,Qf,Sf,Tf,Uf,
Wf,Xf,$f,cg,Zf,ag,Of,Vf,Zaa,fg,dg,eg,hg,Yaa,gg,lg,mg,$aa,aba,bba,cba,dba,pg,rg,tg,ug,Ag,Bg,Cg,Dg,Eg,Fg,Hg,Jg,Kg,Mg,hba,Og,Pg,Rg,Sg,iba,Zg,$g,ah,bh,eh,fh,gh,lh,qh,rh,vh,oh,jba,Eh,Hh,Jh,Kh,Lh,kba,lba,Mh,Oh,Nh,Ph,Qh,nba,pba,qba,sba,Sh,Th,Uh,Vh,uba,$h,ai,bi,vba,ci,di,ei,fi,gi,hi,ii,wba,ji,oi,pi,qi,ti,ri,zba,si,ui,vi,xi,wi,yi,Aba,zi,Bi,Ci,Bba,Fi,Hi,Ki,Mi,Oi,Li,Qi,Pi,Cba,Ri,Si,Ti,Ui,Wi,Xi,Yi,Zi,$i,Eba,Fba,aj,bj,cj,dj,ej,fj,gj,hj,ij,jj,Vi,lj,mj,oj,pj,qj,Jba,sj,nj,tj,uj,vj,wj,Kba,xj,yj,zj,Bj,Lba,Mba,Dj,Nba,
Ej,Fj,Ij,Jj,Kj,Mj,Oj,Pj,Qj,Rj,Sj,Lj,Nj,Pba,Tj,Uj,Qba,Vj,Wj,Xj,Yj,Zj,ak,bk,ck,dk,fk,ek,Rba,Sba,ik,jk,Vba,lk,Uba,Wba,mk,Xba,Yba,kk,nk,ok,Zba,$ba,pk,rk,aca,bca,cca,tk,uk,dca,vk,eca,wk,fca,xk,yk,zk,gca,Ak,Bk,Ck,hca,Dk,Ek,Fk,Gk,ica,Ik,Hk,jca,Kk,Jk,Nk,Mk,kca,oca,nca,Pk,pca,qca,rca,tca,sca,Qk,uca,Rk,Tk,vca,wca,Uk,Vk,Wk,yca,Xk,zca,Yk,$k,al,bl,dl,Bca,el,Aca,Cca,fl,Dca,Eca,Fca,hl,jl,kl,ll,il,ol,pl,ml,ql,rl,Hca,sl,tl,vl,Ica,wl,xl,Jca,zl,yl,Al,Kca,Bl,Cl,Mca,Nca,Gl,Hl,Il,Dl,Jl,Kl,Oca,Lca,Pca,Rca,Qca,Sca,Tca,Nl,
Ll,Uca,Wca,Xca,Pl,Ql,Rl,Tl,bda,Yca,Xl,Yl,Zl,$l,am,cda,bm,cm,dm,dda,fm,gm,hm,eda,fda,gda,hda,ida,jm,lm,km,mm,nm,om,lda,mda,pm,tm,sm,ym,zm,Bm,pda,Em,Gm,Fm,nda,Jm,Mm,rda,sda,tda,Om,Nm,Qm,Rm,uda,xda,Um,Sm,vda,wda,Wm,yda,Vm,Bda,Ada,Xm,Zm,$m,bn,cn,en,Fda,gn,Gda,hn,jn,ln,mn,nn,pn,qn,Hda,un,Ida,Kda,Dn,En,Gn,Hn,On,Pn,Qn,Rn,Sn,Lda,Un,Vn,Oda,Nda,Pda,ho,io,jo,ko,Qda,no,oo,po,qo,so,to,uo,vo,xo,yo,zo,Ao,Sda,Bo,Co,Do,Eo,Fo,Go,Io,Ko,Lo,Mo,Zda,Xda,Yda,bea,$da,aea,cea,dea,No,Po,eea,Qo,fea,Ro,To,Vo,Wo,Xo,So,Uo,$o,Zo,
ap,bp,hea,fp,gp,ip,jea,jp,kea,lea,tp,vp,yp,zp,Ap,mea,oea,Cp,pea,Dp,Ep,qea,Ip,rea,sea,Gp,Mp,Op,Pp,Qp,Sp,Tp,Lp,Up,Wp,tea,Zp,Yp,aq,bq,cq,eq,dq,vea,hq,iq,jq,kq,qq,sq,vq,xq,yq,xea,yea,Nq,Oq,Qq,Sq,Tq,Wq,Uq,Yq,Xq,Zq,Bea,nr,mr,or,Cea,Gea,Hea,yr,wr,Br,Er,Dr,Cr,Gr,Iea,Lr,Nr,Oo,Rr,Xr,Wr,Jea,cs,ds,fs,gs,hs,ls,us,ts,vs,ws,xs,ys,zs,As,Ds,Es,Fs,Hs,Ks,Ls,Ts,Rs,Us,Ss,Vs,Ws,Ys,Zs,$s,ct,gt,ht,Tea,kt,lt,mt,it,pt,qt,rt,ut,vt,xt,Vea,At,Bt,Dt,Gt,Ht,Wea,It,Jt,Kt,Lt,Mt,Nt,Ot,Pt,Qt,Rt,St,Tt,Ut,Vt,Xea,Xt,Wt,Yt,Zt,$t,au,bu,
Yea,eu,bfa,ru,fu,qu,cfa,vu,wu,xu,yu,zu,Au,Cu,Du,Eu,Fu,Hu,Iu,Ju,Ku,Lu,Mu,Nu,Ou,Pu,Qu,Ru,Tu,Su,Uu,Vu,ffa,Xu,$u,gfa,Wu,dv,ev,bv,Zu,fv,gv,av,cv,hv,iv,efa,jv,kv,lv,mv,nv,tv,vv,lfa,pv,wv,yv,Bv,xv,uv,Cv,mfa,Dv,Ev,ov,qv,rv,Av,zv,Gv,Hv,Jv,Iv,nfa,Kv,Lv,Mv,ofa,Ov,Nv,Pv,Qv,Rv,Sv,Tv,Uv,Vv,Wv,Xv,Yv,Zv,$v,pfa,qfa,bw,dw,gw,hw,jw,fw,rfa,kw,lw,mw,nw,sfa,tfa,ow,ufa,qw,pw,tw,vw,ww,xw,yw,Aw,vfa,Bw,Cw,Dw,Ew,Gw,Hw,Fw,Iw,Jw,wfa,Kw,Lw,Mw,Nw,Ow,xfa,yfa,Cfa,Dfa,zfa,Afa,Bfa,Pw,Qw,Efa,Sw,Uw,Ffa,Vw,Xw,Yw,Gfa,Hfa,Zw,ax,Lfa,Kfa,
Jfa,bx,Ifa,Mfa,dx,cx,gx,Pfa,Qfa,hx,ix,Rfa,jx,kx,Sfa,lx,mx,Tfa,Ufa,nx,ex,Nfa,Vfa,qx,Wfa,rx,sx,tx,ux,Xfa,Yfa,vx,xx,wx,yx,Zfa,Ax,Bx,Cx,Dx,Fx,zx,Gx,T,Hx,Ix,Jx,Kx,Lx,Nx,aga,Ox,Px,iy,jy,fy,ey,qy,ty,Vx,Ux,dy,gga,hga,iga,vy,yy,zy,Ay,By,wy,Cy,Dy,jga,Fy,Ey,Gy,kga,Ky,lga,mga,Jy,Iy,Hy,Ly,nga,Ny,oga,qga,pga,Py,rga,Qy,sga,Sy,Ry,tga,uga,Ty,wga,Uy,vga,Vy,Wy,Xy,xga,Yy,az,dz,fz,hz,iz,kz,vz,nz,wz,zga,xz,yz,Bz,Jz,Fz,Nz,Oz,Pz,Ez,Sz,Iz,Fga,Cz,Hz,Lz,Mz,Dz,zz,Tz,Az,Gga,Gz,Vz,Iga,aA,Pga,bA,dA,Rga,Qga,gA,iA,jA,hA,kA,mA,fA,
Sga,pA,tA,vA,wA,eA,Tga,Kga,Lga,Mga,Vga,Jga,Wga,Xga,Yga,Zga,$ga,aha,cha,dha,BA,nA,eha,DA,EA,FA,GA,HA,IA,cA,Zz,xA,yA,$z,JA,KA,MA,OA,PA,QA,fha,RA,TA,VA,LA,XA,YA,$A,aB,bB,cB,dB,eB,fB,hha,gB,hB,jB,kB,lB,mB,nB,tB,xB,AB,zB,BB,CB,jha,DB,yB,EB,FB,kha,HB,GB,JB,KB,LB,MB,NB,QB,RB,PB,OB,SB,TB,UB,XB,ZB,mha,eC,fC,gC,hC,nha,oha,cC,iC,kC,lC,nC,mC,pC,qC,rC,sC,tC,uC,vC,wC,xC,oC,yC,pha,qha,zC,rha,sha,tha,AC,uha,vha,wha,xha,yha,BC,CC,GC,FC,IC,DC,JC,KC,LC,EC,MC,HC,NC,OC,PC,UC,SC,TC,VC,XC,QC,WC,RC,YC,ZC,Aha,$C,aD,bD,dD,
eD,cD,gD,hD,fD,jD,Bha,iD,kD,lD,Cha,mD,nD,oD,Eha,rD,Fha,sD,uD,vD,tD,wD,xD,Dha,qD,pD,AD,zD,BD,CD,ED,DD,HD,ID,JD,LD,MD,GD,ND,OD,FD,PD,QD,RD,SD,KD,TD,UD,VD,Hha,Iha,YD,XD,Jha,WD,ZD,Kha,dE,Lha,fE,gE,hE,eE,$D,Mha,aE,bE,Nha,cE,Oha,Pha,iE,jE,Qha,kE,Rha,oE,lE,nE,mE,Sha,Tha,qE,Uha,pE,rE,sE,tE,uE,Vha,vE,wE,Yha,Xha,Wha,xE,zE,AE,BE,EE,FE,HE,IE,LE,JE,ME,aia,$ha,NE,cia,bia,dia,TE,SE,UE,OE,QE,RE,VE,GE,Zha,WE,yE,XE,PE,YE,DE,eia,fia,ZE,$E,aF,gia,bF,cF,hia,dF,eF,fF,gF,iia,jia,hF,iF,kF,kia,mia,lF,nia,mF,nF,jF,pia,oF,
pF,qF,qia,ria,rF,sia,sF,tF,uF,wF,zF,uia,tia,xF,BF,yF,via,wia,AF,xia,yia,CF,GF,HF,DF,EF,JF,FF,KF,MF,NF,zia,PF,RF,TF,SF,UF,VF,QF,OF,Aia,YF,Cia,$F,bG,cG,dG,gG,aG,hG,eG,XF,Eia,Fia,fG,iG,WF,ZF,Dia,Gia,Hia,Bia,jG,kG,mG,nG,lG,oG,pG,qG,sG,tG,uG,rG,vG,xG,yG,JG,Jia,AG,KG,MG,PG,NG,Kia,QG,WG,UG,wG,GG,cH,aH,Mia,XG,CG,iH,jH,gH,mH,lH,qH,rH,VG,dH,sH,Iia,BG,nH,zH,Nia,hH,yH,Oia,BH,oH,CH,Pia,AH,EH,DH,xH,FH,YG,uH,wH,HH,IH,$G,HG,kH,KH,JH,GH,IG,MH,RG,Qia,zG,NH,vH,OH,pH,RH,SH,LH,ZG,yI,Ria,DI,Sia,Tia,EI,FI,HI,II,JI,KI,LI,
MI,NI,X,OI,PI,QI,RI,Uia,Wia,Via,SI,TI,UI,VI,WI,XI,YI,ZI,$I,Xia,aJ,bJ,cJ,Yia,dJ,eJ,fJ,gJ,hJ,Y,iJ,jJ,Zia,mJ,nJ,oJ,pJ,rJ,tJ,$ia,sJ,uJ,vJ,wJ,xJ,yJ,zJ,AJ,BJ,CJ,DJ,cja,EJ,FJ,GJ,dja,HJ,IJ,JJ,eja,fja,KJ,LJ,MJ,gja,NJ,OJ,PJ,QJ,RJ,SJ,TJ,hja,UJ,VJ,WJ,XJ,YJ,ZJ,$J,aK,cK,dK,bK,eK,fK,lja,ija,gK,jja,iK,jK,kK,lK,nK,oK,mK,pK,qK,uK,vK,mja,nja,wK,AK,zK,xK,yK,BK,oja,CK,pja,DK,EK,FK,HK,qja,JK,IK,KK,MK,NK,rja,OK,UK,YK,ZK,sja,QK,TK,VK,SK,XK,WK,bL,$K,aL,cL,RK,PK,dL,eL,fL,hL,tja,iL,jL,gL,kL,lL,uja,mL,nL,oL,pL,qL,rL,sL,tL,uL,
vL,wL,xL,yL,zL,AL,BL,CL,DL,EL,FL,GL,HL,IL,JL,KL,LL,ML,NL,OL,vja,PL,wja,xja,yja,Aja,zja,QL,Bja,RL,SL,TL,UL,VL,WL,XL,YL,ZL,aM,bM,eM,cM,dM,fM,gM,Cja,Eja,lM,iM,kM,jM,Dja,mM,nM,Fja,qM,oM,pM,rM,sM,tM,uM,wM,xM,Gja,yM,Hja,zM,Ija,Jja,AM,Lja,Kja,CM,DM,FM,BM,EM,GM,HM,Nja,Oja,IM,Pja,KM,MM,NM,OM,Qja,Rja,Sja,PM,Uja,Tja,QM,UM,RM,TM,SM,XM,YM,vM,WM,aN,bN,hM,cN,dN,iN,jN,kN,wN,xN,Vja,yN,zN,AN,BN,CN,DN,FN,GN,HN,IN,JN,KN,LN,ON,PN,QN,Zja,Wja,Yja,Xja,RN,SN,$ja,TN,UN,aka,bka,cka,dka,VN,eka,fka,WN,XN,YN,ZN,$N,gka,hka,ika,
cO,jka,kka,lka,mka,dO,bO,eO,fO,gO,nka,oka,qka,pka,iO,jO,kO,ska,lO,mO,nO,oO,pO,qO,tka,rO,uka,sO,tO,uO,vO,xO,yO,zO,AO,BO,CO,DO,EO,vka,wka,FO,xka,yka,GO,zka,HO,IO,JO,Aka,KO,LO,MO,Bka,Cka,Eka,Fka,PO,QO,NO,Dka,OO,Gka,RO,SO,Hka,TO,VO,UO,WO,XO,YO,ZO,$O,bP,Jka,cP,dP,eP,fP,gP,iP,kP,lP,mP,nP,oP,pP,qP,rP,sP,uP,wP,Mka,xP,yP,BP,CP,at,AP,GP,JP,KP,QP,OP,VP,WP,XP,TP,YP,aQ,ZP,hQ,iQ,jQ,kQ,cQ,oQ,nQ,gQ,mQ,eQ,lQ,pQ,fQ,Oka,zQ,AQ,yQ,DQ,EQ,FQ,IQ,PQ,QQ,RQ,TQ,Qka,UQ,YQ,VQ,aR,bR,cR,SQ,eR,WQ,fR,dR,ZQ,iR,hR,jR,Rka,mR,lR,nR,kR,
Ska,Tka,pR,sR,qR,tR,rR,uR,xR,wR,yR,zR,Vka,AR,BR,CR,FR,ER,HR,IR,JR,KR,LR,MR,NR,OR,QR,Xka,Wka,TR,WR,VR,XR,zI,ZR,bla,YR,AI,XQ,cS,dS,eS,fS,gS,hS,$ka,ala,lS,kS,SR,qS,RR,sS,tS,uS,rS,xS,lI,XH,yS,AS,jS,iS,DS,bS,ES,$M,CI,FS,dla,GS,ela,HS,$Q,oS,oR,gR,KS,MS,LS,NS,aS,PS,CS,BS,QS,jI,ZM,Xs,RS,nS,SS,US,VS,mI,XS,JS,YS,WS,$S,Zka,zS,wS,vS,aa,fa,aT,Haa,Rc,Ca,baa;ba=function(a){return function(){return aa[a].apply(this,arguments)}};
g.ca=function(a,b){return aa[a]=b};
da=function(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}}};
g.q=function(a){var b="undefined"!=typeof window.Symbol&&window.Symbol.iterator&&a[window.Symbol.iterator];return b?b.call(a):{next:da(a)}};
g.ea=function(a){if(!(a instanceof Array)){a=g.q(a);for(var b,c=[];!(b=a.next()).done;)c.push(b.value);a=c}return a};
g.r=function(a,b){a.prototype=fa(b.prototype);a.prototype.constructor=a;if(ha)ha(a,b);else for(var c in b)if("prototype"!=c)if(Object.defineProperties){var d=Object.getOwnPropertyDescriptor(b,c);d&&Object.defineProperty(a,c,d)}else a[c]=b[c];a.Aa=b.prototype};
ia=function(a,b,c){a instanceof String&&(a=String(a));for(var d=a.length,e=0;e<d;e++){var f=a[e];if(b.call(c,f,e,a))return{ev:e,tA:f}}return{ev:-1,tA:void 0}};
ma=function(a,b){if(b){for(var c=ka,d=a.split("."),e=0;e<d.length-1;e++){var f=d[e];f in c||(c[f]={});c=c[f]}d=d[d.length-1];e=c[d];f=b(e);f!=e&&null!=f&&la(c,d,{configurable:!0,writable:!0,value:f})}};
na=function(a,b,c){if(null==a)throw new TypeError("The 'this' value for String.prototype."+c+" must not be null or undefined");if(b instanceof RegExp)throw new TypeError("First argument to String.prototype."+c+" must not be a regular expression");return a+""};
oa=function(){oa=function(){};
ka.Symbol||(ka.Symbol=aaa)};
qa=function(){oa();var a=ka.Symbol.iterator;a||(a=ka.Symbol.iterator=ka.Symbol("iterator"));"function"!=typeof Array.prototype[a]&&la(Array.prototype,a,{configurable:!0,writable:!0,value:function(){return pa(da(this))}});
qa=function(){}};
pa=function(a){qa();a={next:a};a[ka.Symbol.iterator]=function(){return this};
return a};
ra=function(a,b){return Object.prototype.hasOwnProperty.call(a,b)};
g.t=function(a){return void 0!==a};
g.v=function(a){return"string"==typeof a};
g.sa=function(a){return"boolean"==typeof a};
g.ta=function(a){return"number"==typeof a};
g.ua=function(a,b,c){a=a.split(".");c=c||g.w;a[0]in c||"undefined"==typeof c.execScript||c.execScript("var "+a[0]);for(var d;a.length&&(d=a.shift());)!a.length&&g.t(b)?c[d]=b:c[d]&&c[d]!==Object.prototype[d]?c=c[d]:c=c[d]={}};
g.y=function(a,b){for(var c=a.split("."),d=b||g.w,e=0;e<c.length;e++)if(d=d[c[e]],null==d)return null;return d};
g.va=function(){};
g.wa=function(a){a.Ic=void 0;a.getInstance=function(){return a.Ic?a.Ic:a.Ic=new a}};
xa=function(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;var c=Object.prototype.toString.call(a);if("[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==b&&"undefined"==typeof a.call)return"object";return b};
g.ya=function(a){return"array"==xa(a)};
g.za=function(a){var b=xa(a);return"array"==b||"object"==b&&"number"==typeof a.length};
g.Aa=function(a){return"function"==xa(a)};
g.Ba=function(a){var b=typeof a;return"object"==b&&null!=a||"function"==b};
g.Da=function(a){return a[Ca]||(a[Ca]=++baa)};
caa=function(a,b,c){return a.call.apply(a.bind,arguments)};
daa=function(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var c=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(c,d);return a.apply(b,c)}}return function(){return a.apply(b,arguments)}};
g.z=function(a,b,c){Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?g.z=caa:g.z=daa;return g.z.apply(null,arguments)};
g.Ea=function(a,b){var c=Array.prototype.slice.call(arguments,1);return function(){var b=c.slice();b.push.apply(b,arguments);return a.apply(this,b)}};
g.Fa=function(a,b){for(var c in b)a[c]=b[c]};
g.A=function(a,b){function c(){}
c.prototype=b.prototype;a.Aa=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.TQ=function(a,c,f){for(var d=Array(arguments.length-2),e=2;e<arguments.length;e++)d[e-2]=arguments[e];return b.prototype[c].apply(a,d)}};
Ga=function(a){if(Error.captureStackTrace)Error.captureStackTrace(this,Ga);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))};
eaa=function(){};
g.Ha=function(a){return a[a.length-1]};
faa=function(a,b){for(var c=g.v(a)?a.split(""):a,d=a.length-1;0<=d;--d)d in c&&b.call(void 0,c[d],d,a)};
g.Ja=function(a,b,c){b=g.Ia(a,b,c);return 0>b?null:g.v(a)?a.charAt(b):a[b]};
g.Ia=function(a,b,c){for(var d=a.length,e=g.v(a)?a.split(""):a,f=0;f<d;f++)if(f in e&&b.call(c,e[f],f,a))return f;return-1};
gaa=function(a,b){var c=g.Ka(a,b,void 0);return 0>c?null:g.v(a)?a.charAt(c):a[c]};
g.Ka=function(a,b,c){for(var d=g.v(a)?a.split(""):a,e=a.length-1;0<=e;e--)if(e in d&&b.call(c,d[e],e,a))return e;return-1};
g.Ma=function(a,b){return 0<=(0,g.La)(a,b)};
Na=function(a){if(!g.ya(a))for(var b=a.length-1;0<=b;b--)delete a[b];a.length=0};
g.Oa=function(a,b){g.Ma(a,b)||a.push(b)};
g.Qa=function(a,b){var c=(0,g.La)(a,b),d;(d=0<=c)&&g.Pa(a,c);return d};
g.Pa=function(a,b){return 1==Array.prototype.splice.call(a,b,1).length};
g.Ra=function(a,b){var c=g.Ia(a,b,void 0);0<=c&&g.Pa(a,c)};
haa=function(a,b){var c=0;faa(a,function(d,e){b.call(void 0,d,e,a)&&g.Pa(a,e)&&c++})};
g.Sa=function(a){return Array.prototype.concat.apply([],arguments)};
g.Ta=function(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]};
Ua=function(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(g.za(d)){var e=a.length||0,f=d.length||0;a.length=e+f;for(var k=0;k<f;k++)a[e+k]=d[k]}else a.push(d)}};
g.Wa=function(a,b,c,d){Array.prototype.splice.apply(a,g.Va(arguments,1))};
g.Va=function(a,b,c){return 2>=arguments.length?Array.prototype.slice.call(a,b):Array.prototype.slice.call(a,b,c)};
iaa=function(a){for(var b={},c=0,d=0;d<a.length;){var e=a[d++];var f=e;f=g.Ba(f)?"o"+g.Da(f):(typeof f).charAt(0)+f;Object.prototype.hasOwnProperty.call(b,f)||(b[f]=!0,a[c++]=e)}a.length=c};
g.Za=function(a,b,c){return Xa(a,c||Ya,!1,b)};
$a=function(a,b){return Xa(a,b,!0,void 0,void 0)};
Xa=function(a,b,c,d,e){for(var f=0,k=a.length,l;f<k;){var m=f+k>>1,n;c?n=b.call(e,a[m],m,a):n=b(d,a[m]);0<n?f=m+1:(k=m,l=!n)}return l?f:~f};
g.bb=function(a,b){a.sort(b||Ya)};
jaa=function(a,b){var c=Ya;g.bb(a,function(a,e){return c(b(a),b(e))})};
g.cb=function(a,b){if(!g.za(a)||!g.za(b)||a.length!=b.length)return!1;for(var c=a.length,d=kaa,e=0;e<c;e++)if(!d(a[e],b[e]))return!1;return!0};
Ya=function(a,b){return a>b?1:a<b?-1:0};
kaa=function(a,b){return a===b};
g.db=function(a,b,c){c=g.Za(a,b,c);0>c&&g.Wa(a,-(c+1),0,b)};
g.eb=function(a,b,c){var d={};(0,g.C)(a,function(e,f){d[b.call(c,e,f,a)]=e});
return d};
laa=function(a){for(var b=[],c=0;c<a;c++)b[c]="";return b};
g.fb=function(a,b){return 0==a.lastIndexOf(b,0)};
gb=function(a,b){var c=a.length-b.length;return 0<=c&&a.indexOf(b,c)==c};
g.ib=function(a){return/^[\s\xa0]*$/.test(a)};
g.jb=function(a){return(0,window.encodeURIComponent)(String(a))};
kb=function(a){return(0,window.decodeURIComponent)(a.replace(/\+/g," "))};
g.lb=function(a){if(!maa.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(naa,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(oaa,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(paa,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(qaa,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(raa,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(saa,"&#0;"));return a};
nb=function(a,b){a.length>b&&(a=a.substring(0,b-3)+"...");return a};
ob=function(a,b){return-1!=a.toLowerCase().indexOf(b.toLowerCase())};
g.pb=function(a,b){var c=g.t(void 0)?a.toFixed(void 0):String(a),d=c.indexOf(".");-1==d&&(d=c.length);return taa("0",Math.max(0,b-d))+c};
g.qb=function(a){return null==a?"":String(a)};
g.rb=function(){return Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^(0,g.D)()).toString(36)};
g.ub=function(a,b){for(var c=0,d=sb(String(a)).split("."),e=sb(String(b)).split("."),f=Math.max(d.length,e.length),k=0;0==c&&k<f;k++){var l=d[k]||"",m=e[k]||"";do{l=/(\d*)(\D*)(.*)/.exec(l)||["","","",""];m=/(\d*)(\D*)(.*)/.exec(m)||["","","",""];if(0==l[0].length&&0==m[0].length)break;c=tb(0==l[1].length?0:(0,window.parseInt)(l[1],10),0==m[1].length?0:(0,window.parseInt)(m[1],10))||tb(0==l[2].length,0==m[2].length)||tb(l[2],m[2]);l=l[3];m=m[3]}while(0==c)}return c};
tb=function(a,b){return a<b?-1:a>b?1:0};
g.vb=function(a){for(var b=0,c=0;c<a.length;++c)b=31*b+a.charCodeAt(c)>>>0;return b};
wb=function(a){var b=Number(a);return 0==b&&g.ib(a)?window.NaN:b};
xb=function(a){return String(a).replace(/\-([a-z])/g,function(a,c){return c.toUpperCase()})};
g.yb=function(a){return String(a).replace(/([A-Z])/g,"-$1").toLowerCase()};
uaa=function(a){var b=g.v(void 0)?"undefined".replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g,"\\$1").replace(/\x08/g,"\\x08"):"\\s";return a.replace(new RegExp("(^"+(b?"|["+b+"]+":"")+")([a-z])","g"),function(a,b,e){return b+e.toUpperCase()})};
Ab=function(a){return-1!=g.zb.indexOf(a)};
g.Bb=function(a,b,c){for(var d in a)b.call(c,a[d],d,a)};
g.Db=function(a,b,c){var d={},e;for(e in a)b.call(c,a[e],e,a)&&(d[e]=a[e]);return d};
g.Eb=function(a,b){var c={},d;for(d in a)c[d]=b.call(void 0,a[d],d,a);return c};
Fb=function(a,b){for(var c in a)if(b.call(void 0,a[c],c,a))return!0;return!1};
g.Gb=function(a,b){for(var c in a)if(!b.call(void 0,a[c],c,a))return!1;return!0};
g.Hb=function(a){var b=0,c;for(c in a)b++;return b};
Ib=function(a){for(var b in a)return a[b]};
g.Jb=function(a){var b=[],c=0,d;for(d in a)b[c++]=a[d];return b};
g.Kb=function(a){var b=[],c=0,d;for(d in a)b[c++]=d;return b};
g.Lb=function(a,b){var c=g.za(b),d=c?b:arguments;for(c=c?0:1;c<d.length;c++){if(null==a)return;a=a[d[c]]}return a};
Mb=function(a,b){return null!==a&&b in a};
g.Nb=function(a,b){for(var c in a)if(a[c]==b)return!0;return!1};
Ob=function(a,b,c){for(var d in a)if(b.call(c,a[d],d,a))return d};
Pb=function(a,b){var c=Ob(a,b,void 0);return c&&a[c]};
g.Qb=function(a){for(var b in a)return!1;return!0};
g.Rb=function(a){for(var b in a)delete a[b]};
Sb=function(a,b){b in a&&delete a[b]};
Tb=function(a,b,c){return null!==a&&b in a?a[b]:c};
g.Vb=function(a,b){for(var c in a)if(!(c in b)||a[c]!==b[c])return!1;for(c in b)if(!(c in a))return!1;return!0};
g.Wb=function(a){var b={},c;for(c in a)b[c]=a[c];return b};
g.Xb=function(a){var b=xa(a);if("object"==b||"array"==b){if(g.Aa(a.clone))return a.clone();b="array"==b?[]:{};for(var c in a)b[c]=g.Xb(a[c]);return b}return a};
g.Zb=function(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var f=0;f<Yb.length;f++)c=Yb[f],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}};
$b=function(){return Ab("Firefox")||Ab("FxiOS")};
bc=function(){return Ab("Safari")&&!(ac()||Ab("Coast")||Ab("Opera")||Ab("Edge")||$b()||Ab("Silk")||Ab("Android"))};
ac=function(){return(Ab("Chrome")||Ab("CriOS"))&&!Ab("Edge")};
g.cc=function(){return Ab("Android")&&!(ac()||$b()||Ab("Opera")||Ab("Silk"))};
dc=function(){return Ab("iPhone")&&!Ab("iPod")&&!Ab("iPad")};
g.ec=function(){return dc()||Ab("iPad")||Ab("iPod")};
fc=function(a){fc[" "](a);return a};
gc=function(a,b){try{return fc(a[b]),!0}catch(c){}return!1};
waa=function(a,b){var c=vaa;return Object.prototype.hasOwnProperty.call(c,a)?c[a]:c[a]=b(a)};
hc=function(){var a=g.w.document;return a?a.documentMode:void 0};
g.jc=function(a){return waa(a,function(){return 0<=g.ub(ic,a)})};
g.kc=function(a){return Number(xaa)>=a};
lc=function(a){return function(){return a}};
yaa=function(a){var b=b||0;return function(){return a.apply(this,Array.prototype.slice.call(arguments,0,b))}};
mc=function(a){var b=!1,c;return function(){b||(c=a(),b=!0);return c}};
zaa=function(a){var b=a;return function(){if(b){var a=b;b=null;a()}}};
pc=function(a,b){this.g=a===nc&&b||"";this.l=oc};
qc=function(a){return a instanceof pc&&a.constructor===pc&&a.l===oc?a.g:"type_error:Const"};
g.rc=function(a){return new pc(nc,a)};
tc=function(){this.l="";this.o=sc};
uc=function(a){if(a instanceof tc&&a.constructor===tc&&a.o===sc)return a.l;xa(a);return"type_error:TrustedResourceUrl"};
wc=function(a){return vc(qc(a))};
vc=function(a){var b=new tc;b.l=a;return b};
g.yc=function(){this.l="";this.o=xc};
g.zc=function(a){if(a instanceof g.yc&&a.constructor===g.yc&&a.o===xc)return a.l;xa(a);return"type_error:SafeUrl"};
g.Cc=function(a){if(a instanceof g.yc)return a;a="object"==typeof a&&a.vf?a.qe():String(a);Ac.test(a)||(a="about:invalid#zClosurez");return Bc(a)};
Dc=function(a){if(a instanceof g.yc)return a;a="object"==typeof a&&a.vf?a.qe():String(a);Ac.test(a)||(a="about:invalid#zClosurez");return Bc(a)};
Bc=function(a){var b=new g.yc;b.l=a;return b};
Fc=function(){this.g="";this.l=Ec};
Gc=function(a){var b=new Fc;b.g=a;return b};
Hc=function(a){return a instanceof g.yc?'url("'+g.zc(a).replace(/</g,"%3c").replace(/[\\"]/g,"\\$&")+'")':a instanceof pc?qc(a):Aaa(String(a))};
Aaa=function(a){var b=a.replace(Ic,"$1").replace(Ic,"$1").replace(Jc,"url");if(Baa.test(b)){if(Caa.test(a))return"zClosurez";for(var c=b=!0,d=0;d<a.length;d++){var e=a.charAt(d);"'"==e&&c?b=!b:'"'==e&&b&&(c=!c)}if(!b||!c||!Daa(a))return"zClosurez"}else return"zClosurez";return Eaa(a)};
Daa=function(a){for(var b=!0,c=/^[-_a-zA-Z0-9]$/,d=0;d<a.length;d++){var e=a.charAt(d);if("]"==e){if(b)return!1;b=!0}else if("["==e){if(!b)return!1;b=!1}else if(!b&&!c.test(e))return!1}return b};
Eaa=function(a){return a.replace(Jc,function(a,c,d,e){var b="";d=d.replace(/^(['"])(.*)\1$/,function(a,c,d){b=c;return d});
a=g.Cc(d).qe();return c+b+a+b+e})};
g.Lc=function(){this.l="";this.A=Kc;this.o=null};
g.Mc=function(a){if(a instanceof g.Lc&&a.constructor===g.Lc&&a.A===Kc)return a.l;xa(a);return"type_error:SafeHtml"};
Oc=function(a){if(a instanceof g.Lc)return a;var b="object"==typeof a,c=null;b&&a.cp&&(c=a.g());a=g.lb(b&&a.vf?a.qe():String(a));return Nc(a,c)};
Faa=function(a){function b(a){g.ya(a)?(0,g.C)(a,b):(a=Oc(a),d+=g.Mc(a),a=a.g(),0==c?c=a:0!=a&&c!=a&&(c=null))}
var c=0,d="";(0,g.C)(arguments,b);return Nc(d,c)};
Nc=function(a,b){var c=new g.Lc;c.l=a;c.o=b;return c};
g.Pc=function(a,b){if(Gaa())for(;a.lastChild;)a.removeChild(a.lastChild);a.innerHTML=b};
g.Qc=function(a,b){var c=b instanceof g.yc?b:Dc(b);a.href=g.zc(c)};
g.Sc=function(a,b){a.src=uc(b);if(null===Rc)b:{var c=g.w.document;if((c=c.querySelector&&c.querySelector("script[nonce]"))&&(c=c.nonce||c.getAttribute("nonce"))&&Haa.test(c)){Rc=c;break b}Rc=""}c=Rc;c&&a.setAttribute("nonce",c)};
g.Tc=function(a,b){qc(a);qc(a);return Nc(b,null)};
g.Uc=function(a,b,c){return Math.min(Math.max(a,b),c)};
g.Vc=function(a,b){var c=a%b;return 0>c*b?c+b:c};
g.Wc=function(a,b,c){return a+c*(b-a)};
g.Xc=function(a){return a*Math.PI/180};
g.Yc=function(a,b){this.x=g.t(a)?a:0;this.y=g.t(b)?b:0};
g.Zc=function(a,b){return a==b?!0:a&&b?a.x==b.x&&a.y==b.y:!1};
g.$c=function(a,b){return new g.Yc(a.x-b.x,a.y-b.y)};
g.ad=function(a,b){this.width=a;this.height=b};
g.bd=function(a,b){return a==b?!0:a&&b?a.width==b.width&&a.height==b.height:!1};
g.fd=function(a){return a?new cd(g.dd(a)):ed||(ed=new cd)};
g.gd=function(a){return g.v(a)?window.document.getElementById(a):a};
g.id=function(a,b){var c=b||window.document;return c.querySelectorAll&&c.querySelector?c.querySelectorAll("."+a):g.hd(window.document,"*",a,b)};
g.jd=function(a,b){var c=b||window.document;if(c.getElementsByClassName)c=c.getElementsByClassName(a)[0];else{c=window.document;var d=b||c;c=d.querySelectorAll&&d.querySelector&&a?d.querySelector(a?"."+a:""):g.hd(c,"*",a,b)[0]||null}return c||null};
g.hd=function(a,b,c,d){a=d||a;b=b&&"*"!=b?String(b).toUpperCase():"";if(a.querySelectorAll&&a.querySelector&&(b||c))return a.querySelectorAll(b+(c?"."+c:""));if(c&&a.getElementsByClassName){a=a.getElementsByClassName(c);if(b){d={};for(var e=0,f=0,k;k=a[f];f++)b==k.nodeName&&(d[e++]=k);d.length=e;return d}return a}a=a.getElementsByTagName(b||"*");if(c){d={};for(f=e=0;k=a[f];f++)b=k.className,"function"==typeof b.split&&g.Ma(b.split(/\s+/),c)&&(d[e++]=k);d.length=e;return d}return a};
g.ld=function(a,b){g.Bb(b,function(b,d){b&&"object"==typeof b&&b.vf&&(b=b.qe());"style"==d?a.style.cssText=b:"class"==d?a.className=b:"for"==d?a.htmlFor=b:kd.hasOwnProperty(d)?a.setAttribute(kd[d],b):g.fb(d,"aria-")||g.fb(d,"data-")?a.setAttribute(d,b):a[d]=b})};
g.nd=function(a){a=a.document;a=g.md(a)?a.documentElement:a.body;return new g.ad(a.clientWidth,a.clientHeight)};
g.qd=function(a){var b=od(a);a=a.parentWindow||a.defaultView;return g.pd&&g.jc("10")&&a.pageYOffset!=b.scrollTop?new g.Yc(b.scrollLeft,b.scrollTop):new g.Yc(a.pageXOffset||b.scrollLeft,a.pageYOffset||b.scrollTop)};
od=function(a){return a.scrollingElement?a.scrollingElement:!g.rd&&g.md(a)?a.documentElement:a.body||a.documentElement};
sd=function(a){return a?a.parentWindow||a.defaultView:window};
g.ud=function(a,b,c){var d=arguments,e=window.document,f=String(d[0]),k=d[1];if(!Iaa&&k&&(k.name||k.type)){f=["<",f];k.name&&f.push(' name="',g.lb(k.name),'"');if(k.type){f.push(' type="',g.lb(k.type),'"');var l={};g.Zb(l,k);delete l.type;k=l}f.push(">");f=f.join("")}f=e.createElement(f);k&&(g.v(k)?f.className=k:g.ya(k)?f.className=k.join(" "):g.ld(f,k));2<d.length&&td(e,f,d,2);return f};
td=function(a,b,c,d){function e(c){c&&b.appendChild(g.v(c)?a.createTextNode(c):c)}
for(;d<c.length;d++){var f=c[d];!g.za(f)||g.Ba(f)&&0<f.nodeType?e(f):(0,g.C)(Jaa(f)?g.Ta(f):f,e)}};
g.vd=function(a){return window.document.createElement(String(a))};
g.wd=function(a){return window.document.createTextNode(String(a))};
g.md=function(a){return"CSS1Compat"==a.compatMode};
g.xd=function(a,b){a.appendChild(b)};
g.yd=function(a){for(var b;b=a.firstChild;)a.removeChild(b)};
zd=function(a,b,c){a.insertBefore(b,a.childNodes[c]||null)};
g.Ad=function(a){return a&&a.parentNode?a.parentNode.removeChild(a):null};
g.Cd=function(a){return Kaa&&void 0!=a.children?a.children:(0,g.Bd)(a.childNodes,function(a){return 1==a.nodeType})};
g.Dd=function(a){if(g.t(a.firstElementChild))a=a.firstElementChild;else for(a=a.firstChild;a&&1!=a.nodeType;)a=a.nextSibling;return a};
g.Ed=function(a){var b;if(Laa&&!(g.pd&&g.jc("9")&&!g.jc("10")&&g.w.SVGElement&&a instanceof g.w.SVGElement)&&(b=a.parentElement))return b;b=a.parentNode;return g.Ba(b)&&1==b.nodeType?b:null};
g.Fd=function(a,b){if(!a||!b)return!1;if(a.contains&&1==b.nodeType)return a==b||a.contains(b);if("undefined"!=typeof a.compareDocumentPosition)return a==b||!!(a.compareDocumentPosition(b)&16);for(;b&&a!=b;)b=b.parentNode;return b==a};
g.dd=function(a){return 9==a.nodeType?a:a.ownerDocument||a.document};
g.Gd=function(a,b){if("textContent"in a)a.textContent=b;else if(3==a.nodeType)a.data=String(b);else if(a.firstChild&&3==a.firstChild.nodeType){for(;a.lastChild!=a.firstChild;)a.removeChild(a.lastChild);a.firstChild.data=String(b)}else{g.yd(a);var c=g.dd(a);a.appendChild(c.createTextNode(String(b)))}};
g.Jd=function(a){var b;if((b="A"==a.tagName||"INPUT"==a.tagName||"TEXTAREA"==a.tagName||"SELECT"==a.tagName||"BUTTON"==a.tagName?!a.disabled&&(!Hd(a)||Id(a)):Hd(a)&&Id(a))&&g.pd){var c;!g.Aa(a.getBoundingClientRect)||g.pd&&null==a.parentElement?c={height:a.offsetHeight,width:a.offsetWidth}:c=a.getBoundingClientRect();a=null!=c&&0<c.height&&0<c.width}else a=b;return a};
Hd=function(a){return g.pd&&!g.jc("9")?(a=a.getAttributeNode("tabindex"),null!=a&&a.specified):a.hasAttribute("tabindex")};
Id=function(a){a=a.tabIndex;return g.ta(a)&&0<=a&&32768>a};
Jaa=function(a){if(a&&"number"==typeof a.length){if(g.Ba(a))return"function"==typeof a.item||"string"==typeof a.item;if(g.Aa(a))return"function"==typeof a.item}return!1};
g.Ld=function(a,b,c,d){if(!b&&!c)return null;var e=b?String(b).toUpperCase():null;return g.Kd(a,function(a){return(!e||a.nodeName==e)&&(!c||g.v(a.className)&&g.Ma(a.className.split(/\s+/),c))},!0,d)};
g.Md=function(a,b){return g.Ld(a,null,b,void 0)};
g.Kd=function(a,b,c,d){a&&!c&&(a=a.parentNode);for(c=0;a&&(null==d||c<=d);){if(b(a))return a;a=a.parentNode;c++}return null};
cd=function(a){this.g=a||g.w.document||window.document};
g.Nd=function(a){a=a.g;return a.parentWindow||a.defaultView};
g.Od=function(a){Maa();return vc(a)};
g.Pd=function(a){for(var b=[],c=0,d=0;d<a.length;d++){var e=a.charCodeAt(d);255<e&&(b[c++]=e&255,e>>=8);b[c++]=e}return b};
g.Qd=function(a){if(8192>=a.length)return String.fromCharCode.apply(null,a);for(var b="",c=0;c<a.length;c+=8192){var d=g.Va(a,c,c+8192);b+=String.fromCharCode.apply(null,d)}return b};
Naa=function(a){return(0,g.E)(a,function(a){a=a.toString(16);return 1<a.length?a:"0"+a}).join("")};
g.Ud=function(a,b){g.za(a);Rd();for(var c=b?Sd:Td,d=[],e=0;e<a.length;e+=3){var f=a[e],k=e+1<a.length,l=k?a[e+1]:0,m=e+2<a.length,n=m?a[e+2]:0,p=f>>2;f=(f&3)<<4|l>>4;l=(l&15)<<2|n>>6;n&=63;m||(n=64,k||(l=64));d.push(c[p],c[f],c[l],c[n])}return d.join("")};
Oaa=function(a){var b=[];Vd(a,function(a){b.push(a)});
return b};
g.Wd=function(a){var b=a.length,c=0;"="===a[b-2]?c=2:"="===a[b-1]&&(c=1);var d=new window.Uint8Array(Math.ceil(3*b/4)-c),e=0;Vd(a,function(a){d[e++]=a});
return d.subarray(0,e)};
Vd=function(a,b){function c(b){for(;d<a.length;){var c=a.charAt(d++),e=Xd[c];if(null!=e)return e;if(!g.ib(c))throw Error("Unknown base64 encoding at char: "+c);}return b}
Rd();for(var d=0;;){var e=c(-1),f=c(0),k=c(64),l=c(64);if(64===l&&-1===e)break;b(e<<2|f>>4);64!=k&&(b(f<<4&240|k>>2),64!=l&&b(k<<6&192|l))}};
Rd=function(){if(!Td){Td={};Xd={};Sd={};for(var a=0;65>a;a++)Td[a]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(a),Xd[Td[a]]=a,Sd[a]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.".charAt(a),62<=a&&(Xd["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.".charAt(a)]=a)}};
$d=function(a){var b=0>a;a=Math.abs(a);var c=a>>>0;a=Math.floor((a-c)/4294967296);a>>>=0;b&&(a=~a>>>0,c=(~c>>>0)+1,4294967295<c&&(c=0,a++,4294967295<a&&(a=0)));Yd=c;Zd=a};
ae=function(a){var b=0>a?1:0;a=b?-a:a;if(0===a)Zd=0<1/a?0:2147483648,Yd=0;else if((0,window.isNaN)(a))Zd=2147483647,Yd=4294967295;else if(1.7976931348623157E308<a)Zd=(b<<31|2146435072)>>>0,Yd=0;else if(2.2250738585072014E-308>a)a/=Math.pow(2,-1074),Zd=(b<<31|a/4294967296)>>>0,Yd=a>>>0;else{var c=Math.floor(Math.log(a)/Math.LN2);1024==c&&(c=1023);a*=Math.pow(2,-c);Zd=(b<<31|c+1023<<20|1048576*a&1048575)>>>0;Yd=4503599627370496*a>>>0}};
ce=function(a,b,c){this.l=null;this.C=this.F=this.g=this.o=this.A=0;this.B=!1;a&&be(this,a,b,c)};
ge=function(a,b,c){if(fe.length){var d=fe.pop();a&&be(d,a,b,c);return d}return new ce(a,b,c)};
be=function(a,b,c,d){b=b.constructor===window.Uint8Array?b:b.constructor===window.ArrayBuffer?new window.Uint8Array(b):b.constructor===Array?new window.Uint8Array(b):b.constructor===String?g.Wd(b):new window.Uint8Array(0);a.l=b;a.A=g.t(c)?c:0;a.o=g.t(d)?a.A+d:a.l.length;a.g=a.A};
he=function(a){var b=a.l;var c=b[a.g+0];var d=c&127;if(128>c)return a.g+=1,d;c=b[a.g+1];d|=(c&127)<<7;if(128>c)return a.g+=2,d;c=b[a.g+2];d|=(c&127)<<14;if(128>c)return a.g+=3,d;c=b[a.g+3];d|=(c&127)<<21;if(128>c)return a.g+=4,d;c=b[a.g+4];d|=(c&15)<<28;if(128>c)return a.g+=5,d>>>0;a.g+=5;128<=b[a.g++]&&128<=b[a.g++]&&128<=b[a.g++]&&128<=b[a.g++]&&a.g++;return d};
ie=function(a){this.g=ge(a,void 0,void 0);this.B=this.g.g;this.l=this.o=-1;this.A=!1};
je=function(a){var b=a.g;(b=b.g==b.o)||(b=a.A)||(b=a.g,b=b.B||0>b.g||b.g>b.o);if(b)return!1;a.B=a.g.g;b=he(a.g);var c=b&7;if(0!=c&&5!=c&&1!=c&&2!=c&&3!=c&&4!=c)return a.A=!0,!1;a.o=b>>>3;a.l=c;return!0};
ke=function(a){switch(a.l){case 0:if(0!=a.l)ke(a);else{for(a=a.g;a.l[a.g]&128;)a.g++;a.g++}break;case 1:1!=a.l?ke(a):(a=a.g,a.g+=8);break;case 2:if(2!=a.l)ke(a);else{var b=he(a.g);a=a.g;a.g+=b}break;case 5:5!=a.l?ke(a):(a=a.g,a.g+=4);break;case 3:b=a.o;do{if(!je(a)){a.A=!0;break}if(4==a.l){a.o!=b&&(a.A=!0);break}ke(a)}while(1)}};
le=function(a){a=a.g;a:{for(var b,c=0,d,e=0;4>e;e++)if(b=a.l[a.g++],c|=(b&127)<<7*e,128>b){a.F=c>>>0;a.C=0;break a}b=a.l[a.g++];c|=(b&127)<<28;d=0|(b&127)>>4;if(128>b)a.F=c>>>0,a.C=d>>>0;else{for(e=0;5>e;e++)if(b=a.l[a.g++],d|=(b&127)<<7*e+3,128>b){a.F=c>>>0;a.C=d>>>0;break a}a.B=!0}}b=a.F;c=a.C;if(a=c&2147483648)b=~b+1>>>0,c=~c>>>0,0==b&&(c=c+1>>>0);b=4294967296*c+b;return a?-b:b};
me=function(a){var b=he(a.g);a=a.g;var c=a.l,d=a.g;b=d+b;for(var e=[],f="";d<b;){var k=c[d++];if(128>k)e.push(k);else if(192>k)continue;else if(224>k){var l=c[d++];e.push((k&31)<<6|l&63)}else if(240>k){l=c[d++];var m=c[d++];e.push((k&15)<<12|(l&63)<<6|m&63)}else if(248>k){l=c[d++];m=c[d++];var n=c[d++];k=(k&7)<<18|(l&63)<<12|(m&63)<<6|n&63;k-=65536;e.push((k>>10&1023)+55296,(k&1023)+56320)}8192<=e.length&&(f+=String.fromCharCode.apply(null,e),e.length=0)}f+=g.Qd(e);a.g=d;return f};
ne=function(a){var b=he(a.g);a=a.g;if(0>b||a.g+b>a.l.length)a.B=!0,b=new window.Uint8Array(0);else{var c=a.l.subarray(a.g,a.g+b);a.g+=b;b=c}return b};
oe=function(){this.g=[]};
pe=function(a){for(var b=Yd,c=Zd;0<c||127<b;)a.g.push(b&127|128),b=(b>>>7|c<<25)>>>0,c>>>=7;a.g.push(b)};
qe=function(a,b){for(;127<b;)a.g.push(b&127|128),b>>>=7;a.g.push(b)};
re=function(a,b){if(0<=b)qe(a,b);else{for(var c=0;9>c;c++)a.g.push(b&127|128),b>>=7;a.g.push(1)}};
se=function(a,b){a.g.push(b>>>0&255);a.g.push(b>>>8&255);a.g.push(b>>>16&255);a.g.push(b>>>24&255)};
te=function(){this.o=[];this.l=0;this.g=new oe};
we=function(a,b){ue(a,b,2);var c=a.g.end();a.o.push(c);a.l+=c.length;c.push(a.l);return c};
xe=function(a,b){var c=b.pop();for(c=a.l+a.g.length()-c;127<c;)b.push(c&127|128),c>>>=7,a.l++;b.push(c);a.l++};
ue=function(a,b,c){qe(a.g,8*b+c)};
ye=function(a,b,c){null!=c&&(ue(a,b,1),a=a.g,b=c>>>0,c=Math.floor((c-b)/4294967296)>>>0,Yd=b,Zd=c,se(a,Yd),se(a,Zd))};
ze=function(a,b,c){null!=c&&(ue(a,b,0),a.g.g.push(c?1:0))};
Ae=function(a,b,c){if(null!=c){b=we(a,b);for(var d=a.g,e=0;e<c.length;e++){var f=c.charCodeAt(e);if(128>f)d.g.push(f);else if(2048>f)d.g.push(f>>6|192),d.g.push(f&63|128);else if(65536>f)if(55296<=f&&56319>=f&&e+1<c.length){var k=c.charCodeAt(e+1);56320<=k&&57343>=k&&(f=1024*(f-55296)+k-56320+65536,d.g.push(f>>18|240),d.g.push(f>>12&63|128),d.g.push(f>>6&63|128),d.g.push(f&63|128),e++)}else d.g.push(f>>12|224),d.g.push(f>>6&63|128),d.g.push(f&63|128)}xe(a,b)}};
Be=function(a,b,c,d){null!=c&&(b=we(a,b),d(c,a),xe(a,b))};
Ce=function(a,b,c,d){if(null!=c)for(var e=0;e<c.length;e++){var f=we(a,b);d(c[e],a);xe(a,f)}};
De=function(){};
Ie=function(a,b,c,d){a.g=null;b||(b=[]);a.F=void 0;a.A=-1;a.l=b;a:{if(b=a.l.length){--b;var e=a.l[b];if(!(null===e||"object"!=typeof e||g.ya(e)||Ee&&e instanceof window.Uint8Array)){a.B=b-a.A;a.o=e;break a}}a.B=Number.MAX_VALUE}a.C={};if(c)for(b=0;b<c.length;b++)e=c[b],e<a.B?(e+=a.A,a.l[e]=a.l[e]||Fe):(Ge(a),a.o[e]=a.o[e]||Fe);if(d&&d.length)for(b=0;b<d.length;b++)He(a,d[b])};
Ge=function(a){var b=a.B+a.A;a.l[b]||(a.o=a.l[b]={})};
Je=function(a,b){if(b<a.B){var c=b+a.A,d=a.l[c];return d===Fe?a.l[c]=[]:d}if(a.o)return d=a.o[b],d===Fe?a.o[b]=[]:d};
Ke=function(a,b){if(b<a.B){var c=b+a.A,d=a.l[c];return d===Fe?a.l[c]=[]:d}d=a.o[b];return d===Fe?a.o[b]=[]:d};
Paa=function(a){if(null==a||a instanceof window.Uint8Array)return a;if(g.v(a))return g.Wd(a);xa(a);return null};
Le=function(a,b,c){b<a.B?a.l[b+a.A]=c:(Ge(a),a.o[b]=c)};
Me=function(a,b,c,d){(c=He(a,c))&&c!==b&&void 0!==d&&(a.g&&c in a.g&&(a.g[c]=void 0),Le(a,c,void 0));Le(a,b,d)};
He=function(a,b){for(var c,d,e=0;e<b.length;e++){var f=b[e],k=Je(a,f);null!=k&&(c=f,d=k,Le(a,f,void 0))}return c?(Le(a,c,d),c):0};
Ne=function(a,b,c){a.g||(a.g={});if(!a.g[c]){var d=Je(a,c);d&&(a.g[c]=new b(d))}return a.g[c]};
Pe=function(a,b,c){Oe(a,b,c);b=a.g[c];b==Fe&&(b=a.g[c]=[]);return b};
Oe=function(a,b,c){a.g||(a.g={});if(!a.g[c]){for(var d=Ke(a,c),e=[],f=0;f<d.length;f++)e[f]=new b(d[f]);a.g[c]=e}};
Re=function(a,b,c){a.g||(a.g={});c=c||[];for(var d=[],e=0;e<c.length;e++)d[e]=Qe(c[e]);a.g[b]=c;Le(a,b,d)};
Se=function(a){if(a.g)for(var b in a.g){var c=a.g[b];if(g.ya(c))for(var d=0;d<c.length;d++)c[d]&&Qe(c[d]);else c&&Qe(c)}};
Qe=function(a){Se(a);return a.l};
Te=function(a){if(g.ya(a)){for(var b=Array(a.length),c=0;c<a.length;c++){var d=a[c];null!=d&&(b[c]="object"==typeof d?Te(d):d)}return b}if(Ee&&a instanceof window.Uint8Array)return new window.Uint8Array(a);b={};for(c in a)d=a[c],null!=d&&(b[c]="object"==typeof d?Te(d):d);return b};
Ue=function(a){for(var b=[],c=a=sd(a.ownerDocument);c!=a.top;c=c.parent)if(c.frameElement)b.push(c.frameElement);else break;return b};
Qaa=function(a){var b=g.y("window.location.href");null==a&&(a='Unknown Error of type "null/undefined"');if(g.v(a))return{message:a,name:"Unknown error",lineNumber:"Not available",fileName:b,stack:"Not available"};var c=!1;try{var d=a.lineNumber||a.line||"Not available"}catch(f){d="Not available",c=!0}try{var e=a.fileName||a.filename||a.sourceURL||g.w.$googDebugFname||b}catch(f){e="Not available",c=!0}return!c&&a.lineNumber&&a.fileName&&a.stack&&a.message&&a.name?a:(b=a.message,null==b&&(a.constructor&&
a.constructor instanceof Function?(a.constructor.name?b=a.constructor.name:(b=a.constructor,Ve[b]?b=Ve[b]:(b=String(b),Ve[b]||(c=/function\s+([^\(]+)/m.exec(b),Ve[b]=c?c[1]:"[Anonymous]"),b=Ve[b])),b='Unknown Error of type "'+b+'"'):b="Unknown Error of unknown type"),{message:b,name:a.name||"UnknownError",lineNumber:d,fileName:e,stack:a.stack||"Not available"})};
g.G=function(){this.Fc=this.Fc;this.sc=this.sc};
g.I=function(a,b){g.We(a,g.Ea(g.Xe,b))};
g.We=function(a,b){a.Fc?g.t(void 0)?b.call(void 0):b():(a.sc||(a.sc=[]),a.sc.push(g.t(void 0)?(0,g.z)(b,void 0):b))};
g.Xe=function(a){a&&"function"==typeof a.dispose&&a.dispose()};
g.Ye=function(a){for(var b=0,c=arguments.length;b<c;++b){var d=arguments[b];g.za(d)?g.Ye.apply(null,d):g.Xe(d)}};
g.Ze=function(a,b){this.type=a;this.currentTarget=this.target=b;this.defaultPrevented=this.oh=!1;this.kz=!0};
$e=function(a,b){g.Ze.call(this,a?a.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=0;this.key="";this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.g=null;a&&this.init(a,b)};
g.bf=function(a){return!(!a||!a[g.af])};
Saa=function(a,b,c,d,e){this.listener=a;this.g=null;this.src=b;this.type=c;this.capture=!!d;this.Sl=e;this.key=++Raa;this.si=this.jl=!1};
cf=function(a){a.si=!0;a.listener=null;a.g=null;a.src=null;a.Sl=null};
df=function(a){this.src=a;this.listeners={};this.g=0};
ef=function(a,b){var c=b.type;if(!(c in a.listeners))return!1;var d=g.Qa(a.listeners[c],b);d&&(cf(b),0==a.listeners[c].length&&(delete a.listeners[c],a.g--));return d};
g.ff=function(a){var b=0,c;for(c in a.listeners){for(var d=a.listeners[c],e=0;e<d.length;e++)++b,cf(d[e]);delete a.listeners[c];a.g--}};
gf=function(a,b,c,d){for(var e=0;e<a.length;++e){var f=a[e];if(!f.si&&f.listener==b&&f.capture==!!c&&f.Sl==d)return e}return-1};
g.jf=function(a,b,c,d,e){if(d&&d.once)return hf(a,b,c,d,e);if(g.ya(b)){for(var f=0;f<b.length;f++)g.jf(a,b[f],c,d,e);return null}c=kf(c);return g.bf(a)?a.fa(b,c,g.Ba(d)?!!d.capture:!!d,e):lf(a,b,c,!1,d,e)};
lf=function(a,b,c,d,e,f){if(!b)throw Error("Invalid event type");var k=g.Ba(e)?!!e.capture:!!e,l=g.mf(a);l||(a[nf]=l=new df(a));c=l.add(b,c,d,k,f);if(c.g)return c;d=Taa();c.g=d;d.src=a;d.listener=c;if(a.addEventListener)Uaa||(e=k),void 0===e&&(e=!1),a.addEventListener(b.toString(),d,e);else if(a.attachEvent)a.attachEvent(of(b.toString()),d);else if(a.addListener&&a.removeListener)a.addListener(d);else throw Error("addEventListener and attachEvent are unavailable.");pf++;return c};
Taa=function(){var a=Vaa,b=qf?function(c){return a.call(b.src,b.listener,c)}:function(c){c=a.call(b.src,b.listener,c);
if(!c)return c};
return b};
hf=function(a,b,c,d,e){if(g.ya(b)){for(var f=0;f<b.length;f++)hf(a,b[f],c,d,e);return null}c=kf(c);return g.bf(a)?a.km(b,c,g.Ba(d)?!!d.capture:!!d,e):lf(a,b,c,!0,d,e)};
g.rf=function(a,b,c,d,e){if(g.ya(b))for(var f=0;f<b.length;f++)g.rf(a,b[f],c,d,e);else d=g.Ba(d)?!!d.capture:!!d,c=kf(c),g.bf(a)?a.Pa(b,c,d,e):a&&(a=g.mf(a))&&(b=a.fj(b,c,d,e))&&g.sf(b)};
g.sf=function(a){if(g.ta(a)||!a||a.si)return!1;var b=a.src;if(g.bf(b))return ef(b.oe,a);var c=a.type,d=a.g;b.removeEventListener?b.removeEventListener(c,d,a.capture):b.detachEvent?b.detachEvent(of(c),d):b.addListener&&b.removeListener&&b.removeListener(d);pf--;(c=g.mf(b))?(ef(c,a),0==c.g&&(c.src=null,b[nf]=null)):cf(a);return!0};
of=function(a){return a in tf?tf[a]:tf[a]="on"+a};
vf=function(a,b,c,d){var e=!0;if(a=g.mf(a))if(b=a.listeners[b.toString()])for(b=b.concat(),a=0;a<b.length;a++){var f=b[a];f&&f.capture==c&&!f.si&&(f=uf(f,d),e=e&&!1!==f)}return e};
uf=function(a,b){var c=a.listener,d=a.Sl||a.src;a.jl&&g.sf(a);return c.call(d,b)};
Vaa=function(a,b){if(a.si)return!0;if(!qf){var c=b||g.y("window.event"),d=new $e(c,this),e=!0;if(!(0>c.keyCode||void 0!=c.returnValue)){a:{var f=!1;if(0==c.keyCode)try{c.keyCode=-1;break a}catch(m){f=!0}if(f||void 0==c.returnValue)c.returnValue=!0}c=[];for(f=d.currentTarget;f;f=f.parentNode)c.push(f);f=a.type;for(var k=c.length-1;!d.oh&&0<=k;k--){d.currentTarget=c[k];var l=vf(c[k],f,!0,d);e=e&&l}for(k=0;!d.oh&&k<c.length;k++)d.currentTarget=c[k],l=vf(c[k],f,!1,d),e=e&&l}return e}return uf(a,new $e(b,
this))};
g.mf=function(a){a=a[nf];return a instanceof df?a:null};
kf=function(a){if(g.Aa(a))return a;a[wf]||(a[wf]=function(b){return a.handleEvent(b)});
return a[wf]};
g.xf=function(){g.G.call(this);this.oe=new df(this);this.ba=this;this.J=null};
yf=function(a,b,c,d){b=a.oe.listeners[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,f=0;f<b.length;++f){var k=b[f];if(k&&!k.si&&k.capture==c){var l=k.listener,m=k.Sl||k.src;k.jl&&ef(a.oe,k);e=!1!==l.call(m,d)&&e}}return e&&0!=d.kz};
zf=function(a,b){this.o=a;this.A=b;this.l=0;this.g=null};
Af=function(a,b){a.A(b);100>a.l&&(a.l++,b.next=a.g,a.g=b)};
Bf=function(a){g.w.setTimeout(function(){throw a;},0)};
Df=function(a,b){var c=a;b&&(c=(0,g.z)(a,b));!g.Aa(g.w.setImmediate)||g.w.Window&&g.w.Window.prototype&&!Ab("Edge")&&g.w.Window.prototype.setImmediate==g.w.setImmediate?(Cf||(Cf=Waa()),Cf(c)):g.w.setImmediate(c)};
Waa=function(){var a=g.w.MessageChannel;"undefined"===typeof a&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!Ab("Presto")&&(a=function(){var a=window.document.createElement("IFRAME");a.style.display="none";a.src="";window.document.documentElement.appendChild(a);var b=a.contentWindow;a=b.document;a.open();a.write("");a.close();var c="callImmediate"+Math.random(),d="file:"==b.location.protocol?"*":b.location.protocol+"//"+b.location.host;a=(0,g.z)(function(a){if(("*"==
d||a.origin==d)&&a.data==c)this.port1.onmessage()},this);
b.addEventListener("message",a,!1);this.port1={};this.port2={postMessage:function(){b.postMessage(c,d)}}});
if("undefined"!==typeof a&&!Ab("Trident")&&!Ab("MSIE")){var b=new a,c={},d=c;b.port1.onmessage=function(){if(g.t(c.next)){c=c.next;var a=c.zt;c.zt=null;a()}};
return function(a){d.next={zt:a};d=d.next;b.port2.postMessage(0)}}return"undefined"!==typeof window.document&&"onreadystatechange"in window.document.createElement("SCRIPT")?function(a){var b=window.document.createElement("SCRIPT");
b.onreadystatechange=function(){b.onreadystatechange=null;b.parentNode.removeChild(b);b=null;a();a=null};
window.document.documentElement.appendChild(b)}:function(a){g.w.setTimeout(a,0)}};
Ef=function(){this.l=this.g=null};
Ff=function(){this.next=this.scope=this.mf=null};
g.Jf=function(a,b){Gf||Xaa();Hf||(Gf(),Hf=!0);If.add(a,b)};
Xaa=function(){if(g.w.Promise&&g.w.Promise.resolve){var a=g.w.Promise.resolve(void 0);Gf=function(){a.then(Kf)}}else Gf=function(){Df(Kf)}};
Kf=function(){for(var a;a=If.remove();){try{a.mf.call(a.scope)}catch(b){Bf(b)}Af(Lf,a)}Hf=!1};
Mf=function(a){a.prototype.$goog_Thenable=!0};
Nf=function(a){if(!a)return!1;try{return!!a.$goog_Thenable}catch(b){return!1}};
g.Pf=function(a,b){this.g=0;this.F=void 0;this.A=this.l=this.o=null;this.B=this.C=!1;if(a!=g.va)try{var c=this;a.call(b,function(a){Of(c,2,a)},function(a){Of(c,3,a)})}catch(d){Of(this,3,d)}};
Qf=function(){this.next=this.context=this.onRejected=this.o=this.g=null;this.l=!1};
Sf=function(a,b,c){var d=Rf.get();d.o=a;d.onRejected=b;d.context=c;return d};
Tf=function(a){if(a instanceof g.Pf)return a;var b=new g.Pf(g.va);Of(b,2,a);return b};
Uf=function(a){return new g.Pf(function(b,c){c(a)})};
Wf=function(a,b,c){Vf(a,b,c,null)||g.Jf(g.Ea(b,a))};
Xf=function(a){return new g.Pf(function(b,c){a.length||b(void 0);for(var d=0,e;d<a.length;d++)e=a[d],Wf(e,b,c)})};
g.Yf=function(a){return new g.Pf(function(b,c){var d=a.length,e=[];if(d)for(var f=function(a,c){d--;e[a]=c;0==d&&b(e)},k=function(a){c(a)},l=0,m;l<a.length;l++)m=a[l],Wf(m,g.Ea(f,l),k);
else b(e)})};
$f=function(a,b){var c=Sf(b,b,void 0);c.l=!0;Zf(a,c);return a};
g.bg=function(a,b){return ag(a,null,b,void 0)};
cg=function(a,b){if(0==a.g)if(a.o){var c=a.o;if(c.l){for(var d=0,e=null,f=null,k=c.l;k&&(k.l||(d++,k.g==a&&(e=k),!(e&&1<d)));k=k.next)e||(f=k);e&&(0==c.g&&1==d?cg(c,b):(f?(d=f,d.next==c.A&&(c.A=d),d.next=d.next.next):dg(c),eg(c,e,3,b)))}a.o=null}else Of(a,3,b)};
Zf=function(a,b){a.l||2!=a.g&&3!=a.g||fg(a);a.A?a.A.next=b:a.l=b;a.A=b};
ag=function(a,b,c,d){var e=Sf(null,null,null);e.g=new g.Pf(function(a,k){e.o=b?function(c){try{var e=b.call(d,c);a(e)}catch(n){k(n)}}:a;
e.onRejected=c?function(b){try{var e=c.call(d,b);!g.t(e)&&b instanceof gg?k(b):a(e)}catch(n){k(n)}}:k});
e.g.o=a;Zf(a,e);return e.g};
Of=function(a,b,c){0==a.g&&(a===c&&(b=3,c=new TypeError("Promise cannot resolve to itself")),a.g=1,Vf(c,a.H,a.J,a)||(a.F=c,a.g=b,a.o=null,fg(a),3!=b||c instanceof gg||Yaa(a,c)))};
Vf=function(a,b,c,d){if(a instanceof g.Pf)return Zf(a,Sf(b||g.va,c||null,d)),!0;if(Nf(a))return a.then(b,c,d),!0;if(g.Ba(a))try{var e=a.then;if(g.Aa(e))return Zaa(a,e,b,c,d),!0}catch(f){return c.call(d,f),!0}return!1};
Zaa=function(a,b,c,d,e){function f(a){l||(l=!0,d.call(e,a))}
function k(a){l||(l=!0,c.call(e,a))}
var l=!1;try{b.call(a,k,f)}catch(m){f(m)}};
fg=function(a){a.C||(a.C=!0,g.Jf(a.G,a))};
dg=function(a){var b=null;a.l&&(b=a.l,a.l=b.next,b.next=null);a.l||(a.A=null);return b};
eg=function(a,b,c,d){if(3==c&&b.onRejected&&!b.l)for(;a&&a.B;a=a.o)a.B=!1;if(b.g)b.g.o=null,hg(b,c,d);else try{b.l?b.o.call(b.context):hg(b,c,d)}catch(e){ig.call(null,e)}Af(Rf,b)};
hg=function(a,b,c){2==b?a.o.call(a.context,c):a.onRejected&&a.onRejected.call(a.context,c)};
Yaa=function(a,b){a.B=!0;g.Jf(function(){a.B&&ig.call(null,b)})};
gg=function(a){Ga.call(this,a)};
g.jg=function(a,b){g.xf.call(this);this.Uc=a||1;this.zk=b||g.w;this.xt=(0,g.z)(this.yc,this);this.Av=(0,g.D)()};
g.kg=function(a,b,c){if(g.Aa(a))c&&(a=(0,g.z)(a,c));else if(a&&"function"==typeof a.handleEvent)a=(0,g.z)(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<Number(b)?-1:g.w.setTimeout(a,b||0)};
lg=function(a,b){var c=null;return g.bg(new g.Pf(function(d,e){c=g.kg(function(){d(b)},a);
-1==c&&e(Error("Failed to schedule timer."))}),function(a){g.w.clearTimeout(c);
throw a;})};
mg=function(){return Math.round((0,g.D)()/1E3)};
$aa=function(a){var b=window.performance&&window.performance.timing&&window.performance.timing.domLoading&&0<window.performance.timing.domLoading?Math.round(window.performance.timing.domLoading/1E3):null;return null!=b?b:null!=a?a:mg()};
aba=function(){this.l=-1};
bba=function(a){return/^\s*$/.test(a)?!1:/^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g,"@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g,"]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g,""))};
cba=function(a){try{return g.w.JSON.parse(a)}catch(d){var b=d}a=String(a);if(bba(a))try{var c=eval("("+a+")");b&&og("Invalid JSON: "+a,b);return c}catch(d){}throw Error("Invalid JSON string: "+a);};
g.qg=function(a){var b=[];pg(new dba,a,b);return b.join("")};
dba=function(){};
pg=function(a,b,c){if(null==b)c.push("null");else{if("object"==typeof b){if(g.ya(b)){var d=b;b=d.length;c.push("[");for(var e="",f=0;f<b;f++)c.push(e),pg(a,d[f],c),e=",";c.push("]");return}if(b instanceof String||b instanceof Number||b instanceof Boolean)b=b.valueOf();else{c.push("{");e="";for(d in b)Object.prototype.hasOwnProperty.call(b,d)&&(f=b[d],"function"!=typeof f&&(c.push(e),rg(d,c),c.push(":"),pg(a,f,c),e=","));c.push("}");return}}switch(typeof b){case "string":rg(b,c);break;case "number":c.push((0,window.isFinite)(b)&&
!(0,window.isNaN)(b)?String(b):"null");break;case "boolean":c.push(String(b));break;case "function":c.push("null");break;default:throw Error("Unknown type: "+typeof b);}}};
rg=function(a,b){b.push('"',a.replace(eba,function(a){var b=sg[a];b||(b="\\u"+(a.charCodeAt(0)|65536).toString(16).substr(1),sg[a]=b);return b}),'"')};
tg=function(a){this.g=a||{cookie:""}};
ug=function(a){a=(a.g.cookie||"").split(";");for(var b=[],c=[],d,e,f=0;f<a.length;f++)e=sb(a[f]),d=e.indexOf("="),-1==d?(b.push(""),c.push(e)):(b.push(e.substring(0,d)),c.push(e.substring(d+1)));return{keys:b,values:c}};
g.vg=function(a,b,c,d,e,f,k){var l="";a&&(l+=a+":");c&&(l+="//",b&&(l+=b+"@"),l+=c,d&&(l+=":"+d));e&&(l+=e);f&&(l+="?"+f);k&&(l+="#"+k);return l};
g.wg=function(a){return a.match(fba)};
g.xg=function(a){return a?(0,window.decodeURI)(a):a};
g.yg=function(a){return g.xg(g.wg(a)[3]||null)};
g.zg=function(a){return Number(g.wg(a)[4]||null)||null};
Ag=function(a,b){if(a)for(var c=a.split("&"),d=0;d<c.length;d++){var e=c[d].indexOf("="),f=null;if(0<=e){var k=c[d].substring(0,e);f=c[d].substring(e+1)}else k=c[d];b(k,f?kb(f):"")}};
Bg=function(a){var b=a.indexOf("#");0>b&&(b=a.length);var c=a.indexOf("?");if(0>c||c>b){c=b;var d=""}else d=a.substring(c+1,b);return[a.substr(0,c),d,a.substr(b)]};
Cg=function(a,b){return b?a?a+"&"+b:b:a};
Dg=function(a,b){if(!b)return a;var c=Bg(a);c[1]=Cg(c[1],b);return c[0]+(c[1]?"?"+c[1]:"")+c[2]};
Eg=function(a,b,c){if(g.ya(b))for(var d=0;d<b.length;d++)Eg(a,String(b[d]),c);else null!=b&&c.push(a+(""===b?"":"="+g.jb(b)))};
Fg=function(a,b){for(var c=[],d=b||0;d<a.length;d+=2)Eg(a[d],a[d+1],c);return c.join("&")};
g.Gg=function(a){var b=[],c;for(c in a)Eg(c,a[c],b);return b.join("&")};
Hg=function(a,b){var c=2==arguments.length?Fg(arguments[1],0):Fg(arguments,1);return Dg(a,c)};
g.Ig=function(a,b){var c=g.Gg(b);return Dg(a,c)};
Jg=function(a,b,c){c=null!=c?"="+g.jb(c):"";return Dg(a,b+c)};
Kg=function(a,b,c,d){for(var e=c.length;0<=(b=a.indexOf(c,b))&&b<d;){var f=a.charCodeAt(b-1);if(38==f||63==f)if(f=a.charCodeAt(b+e),!f||61==f||38==f||35==f)return b;b+=e+1}return-1};
Mg=function(a,b){var c=a.search(Lg),d=Kg(a,0,b,c);if(0>d)return null;var e=a.indexOf("&",d);if(0>e||e>c)e=c;d+=b.length+1;return kb(a.substr(d,e-d))};
g.Ng=function(a,b){for(var c=a.search(Lg),d=0,e,f=[];0<=(e=Kg(a,d,b,c));)f.push(a.substring(d,e)),d=Math.min(a.indexOf("&",e)+1||c,c);f.push(a.substr(d));return f.join("").replace(gba,"$1")};
hba=function(a,b){var c=Bg(a),d=c[1],e=[];d&&(0,g.C)(d.split("&"),function(a){var c=a.indexOf("=");b.hasOwnProperty(0<=c?a.substr(0,c):a)||e.push(a)});
c[1]=Cg(e.join("&"),g.Gg(b));return c[0]+(c[1]?"?"+c[1]:"")+c[2]};
Og=function(){this.g={};return this};
Pg=function(a,b){a.g.eb=Tb(a.g,"eb",0)|b};
g.Qg=function(a,b,c,d){this.top=a;this.right=b;this.bottom=c;this.left=d};
Rg=function(a,b){return a==b?!0:a&&b?a.top==b.top&&a.right==b.right&&a.bottom==b.bottom&&a.left==b.left:!1};
Sg=function(a,b,c){b instanceof g.Yc?(a.left+=b.x,a.right+=b.x,a.top+=b.y,a.bottom+=b.y):(a.left+=b,a.right+=b,g.ta(c)&&(a.top+=c,a.bottom+=c));return a};
g.Tg=function(a,b,c,d){this.left=a;this.top=b;this.width=c;this.height=d};
g.Ug=function(a){return new g.Qg(a.top,a.left+a.width,a.top+a.height,a.left)};
g.Vg=function(a,b){return a==b?!0:a&&b?a.left==b.left&&a.width==b.width&&a.top==b.top&&a.height==b.height:!1};
g.Wg=function(a,b){var c=Math.max(a.left,b.left),d=Math.min(a.left+a.width,b.left+b.width);if(c<=d){var e=Math.max(a.top,b.top),f=Math.min(a.top+a.height,b.top+b.height);if(e<=f)return a.left=c,a.top=e,a.width=d-c,a.height=f-e,!0}return!1};
g.Xg=function(a){return new g.ad(a.width,a.height)};
g.Yg=function(a){return new g.Yc(a.left,a.top)};
iba=function(){this.g={};this.l=0};
Zg=function(a,b){this.B=a;this.o=!0;this.g=b};
$g=function(a,b){Zg.call(this,String(a),b);this.A=a;this.g=!!b};
ah=function(a,b){Zg.call(this,a,b)};
bh=function(a){if(a.match(/^-?[0-9]+\.-?[0-9]+\.-?[0-9]+\.-?[0-9]+$/)){a=a.split(".");var b=Number(a[0]),c=Number(a[1]);return new ah("",new g.Tg(c,b,Number(a[3])-c,Number(a[2])-b))}return new ah("",new g.Tg(0,0,0,0))};
eh=function(){ch||(ch=new iba);return ch};
fh=function(a,b){a.g[b.B]=b};
g.hh=function(a,b,c){if(g.v(b))(b=gh(a,b))&&(a.style[b]=c);else for(var d in b){c=a;var e=b[d],f=gh(c,d);f&&(c.style[f]=e)}};
gh=function(a,b){var c=ih[b];if(!c){var d=xb(b);c=d;void 0===a.style[d]&&(d=(g.rd?"Webkit":g.jh?"Moz":g.pd?"ms":g.kh?"O":null)+uaa(d),void 0!==a.style[d]&&(c=d));ih[b]=c}return c};
lh=function(a,b){var c=a.style[xb(b)];return"undefined"!==typeof c?c:a.style[gh(a,b)]||""};
g.mh=function(a,b){var c=g.dd(a);return c.defaultView&&c.defaultView.getComputedStyle&&(c=c.defaultView.getComputedStyle(a,null))?c[b]||c.getPropertyValue(b)||"":""};
g.nh=function(a,b){return g.mh(a,b)||(a.currentStyle?a.currentStyle[b]:null)||a.style&&a.style[b]};
g.ph=function(a,b,c){if(b instanceof g.Yc){var d=b.x;b=b.y}else d=b,b=c;a.style.left=oh(d,!1);a.style.top=oh(b,!1)};
qh=function(a){return new g.Yc(a.offsetLeft,a.offsetTop)};
rh=function(a){try{var b=a.getBoundingClientRect()}catch(c){return{left:0,top:0,right:0,bottom:0}}g.pd&&a.ownerDocument.body&&(a=a.ownerDocument,b.left-=a.documentElement.clientLeft+a.body.clientLeft,b.top-=a.documentElement.clientTop+a.body.clientTop);return b};
g.sh=function(a){if(g.pd&&!g.kc(8))return a.offsetParent;var b=g.dd(a),c=g.nh(a,"position"),d="fixed"==c||"absolute"==c;for(a=a.parentNode;a&&a!=b;a=a.parentNode)if(11==a.nodeType&&a.host&&(a=a.host),c=g.nh(a,"position"),d=d&&"static"==c&&a!=b.documentElement&&a!=b.body,!d&&(a.scrollWidth>a.clientWidth||a.scrollHeight>a.clientHeight||"fixed"==c||"absolute"==c||"relative"==c))return a;return null};
g.uh=function(a){for(var b=new g.Qg(0,window.Infinity,window.Infinity,0),c=g.fd(a),d=c.g.body,e=c.g.documentElement,f=od(c.g);a=g.sh(a);)if(!(g.pd&&0==a.clientWidth||g.rd&&0==a.clientHeight&&a==d)&&a!=d&&a!=e&&"visible"!=g.nh(a,"overflow")){var k=g.th(a),l=new g.Yc(a.clientLeft,a.clientTop);k.x+=l.x;k.y+=l.y;b.top=Math.max(b.top,k.y);b.right=Math.min(b.right,k.x+a.clientWidth);b.bottom=Math.min(b.bottom,k.y+a.clientHeight);b.left=Math.max(b.left,k.x)}d=f.scrollLeft;f=f.scrollTop;b.left=Math.max(b.left,
d);b.top=Math.max(b.top,f);c=g.nd(g.Nd(c)||window);b.right=Math.min(b.right,d+c.width);b.bottom=Math.min(b.bottom,f+c.height);return 0<=b.top&&0<=b.left&&b.bottom>b.top&&b.right>b.left?b:null};
g.th=function(a){var b=g.dd(a),c=new g.Yc(0,0);var d=b?g.dd(b):window.document;d=!g.pd||g.kc(9)||g.md(g.fd(d).g)?d.documentElement:d.body;if(a==d)return c;a=rh(a);b=g.qd(g.fd(b).g);c.x=a.left+b.x;c.y=a.top+b.y;return c};
g.wh=function(a,b){var c=new g.Yc(0,0),d=sd(g.dd(a));if(!gc(d,"parent"))return c;var e=a;do{var f=d==b?g.th(e):vh(e);c.x+=f.x;c.y+=f.y}while(d&&d!=b&&d!=d.parent&&(e=d.frameElement)&&(d=d.parent));return c};
g.yh=function(a,b){var c=g.xh(a),d=g.xh(b);return new g.Yc(c.x-d.x,c.y-d.y)};
vh=function(a){a=rh(a);return new g.Yc(a.left,a.top)};
g.xh=function(a){if(1==a.nodeType)return vh(a);a=a.changedTouches?a.changedTouches[0]:a;return new g.Yc(a.clientX,a.clientY)};
g.Ah=function(a,b,c){if(b instanceof g.ad)c=b.height,b=b.width;else if(void 0==c)throw Error("missing height argument");g.zh(a,b);a.style.height=oh(c,!0)};
oh=function(a,b){"number"==typeof a&&(a=(b?Math.round(a):a)+"px");return a};
g.zh=function(a,b){a.style.width=oh(b,!0)};
g.Bh=function(a){var b=jba;if("none"!=g.nh(a,"display"))return b(a);var c=a.style,d=c.display,e=c.visibility,f=c.position;c.visibility="hidden";c.position="absolute";c.display="inline";a=b(a);c.display=d;c.position=f;c.visibility=e;return a};
jba=function(a){var b=a.offsetWidth,c=a.offsetHeight,d=g.rd&&!b&&!c;return g.t(b)&&!d||!a.getBoundingClientRect?new g.ad(b,c):(a=rh(a),new g.ad(a.right-a.left,a.bottom-a.top))};
g.Ch=function(a,b){a.style.display=b?"":"none"};
g.Dh=function(a,b,c,d){if(/^\d+px?$/.test(b))return(0,window.parseInt)(b,10);var e=a.style[c],f=a.runtimeStyle[c];a.runtimeStyle[c]=a.currentStyle[c];a.style[c]=b;b=a.style[d];a.style[c]=e;a.runtimeStyle[c]=f;return+b};
Eh=function(a,b){var c=a.currentStyle?a.currentStyle[b]:null;return c?g.Dh(a,c,"left","pixelLeft"):0};
g.Fh=function(a){if(g.pd){var b=Eh(a,"paddingLeft"),c=Eh(a,"paddingRight"),d=Eh(a,"paddingTop");a=Eh(a,"paddingBottom");return new g.Qg(d,c,a,b)}b=g.mh(a,"paddingLeft");c=g.mh(a,"paddingRight");d=g.mh(a,"paddingTop");a=g.mh(a,"paddingBottom");return new g.Qg((0,window.parseFloat)(d),(0,window.parseFloat)(c),(0,window.parseFloat)(a),(0,window.parseFloat)(b))};
Hh=function(a,b){if("none"==(a.currentStyle?a.currentStyle[b+"Style"]:null))return 0;var c=a.currentStyle?a.currentStyle[b+"Width"]:null;return c in Gh?Gh[c]:g.Dh(a,c,"left","pixelLeft")};
g.Ih=function(a){if(g.pd&&!g.kc(9)){var b=Hh(a,"borderLeft"),c=Hh(a,"borderRight"),d=Hh(a,"borderTop");a=Hh(a,"borderBottom");return new g.Qg(d,c,a,b)}b=g.mh(a,"borderLeftWidth");c=g.mh(a,"borderRightWidth");d=g.mh(a,"borderTopWidth");a=g.mh(a,"borderBottomWidth");return new g.Qg((0,window.parseFloat)(d),(0,window.parseFloat)(c),(0,window.parseFloat)(a),(0,window.parseFloat)(b))};
Jh=function(a){var b=new g.Tg(-Number.MAX_VALUE/2,-Number.MAX_VALUE/2,Number.MAX_VALUE,Number.MAX_VALUE),c=new g.Tg(0,0,0,0);if(!a||0==a.length)return c;for(var d=0;d<a.length;d++)if(!g.Wg(b,a[d]))return c;return b};
Kh=function(a,b){var c=a.getBoundingClientRect(),d=g.wh(a,b);return new g.Tg(Math.round(d.x),Math.round(d.y),Math.round(c.right-c.left),Math.round(c.bottom-c.top))};
Lh=function(a,b,c){if(b&&c){a:{var d=Math.max(b.left,c.left);var e=Math.min(b.left+b.width,c.left+c.width);if(d<=e){var f=Math.max(b.top,c.top),k=Math.min(b.top+b.height,c.top+c.height);if(f<=k){d=new g.Tg(d,f,e-d,k-f);break a}}d=null}e=d?d.height*d.width:0;f=d?b.height*b.width:0;d=d&&f?Math.round(e/f*100):0;fh(a,new Zg("vp",d));d&&0<d?(e=g.Ug(b),f=g.Ug(c),e=e.top>=f.top&&e.top<f.bottom):e=!1;fh(a,new $g(512,e));d&&0<d?(e=g.Ug(b),f=g.Ug(c),e=e.bottom<=f.bottom&&e.bottom>f.top):e=!1;fh(a,new $g(1024,
e));d&&0<d?(e=g.Ug(b),f=g.Ug(c),e=e.left>=f.left&&e.left<f.right):e=!1;fh(a,new $g(2048,e));d&&0<d?(b=g.Ug(b),c=g.Ug(c),c=b.right<=c.right&&b.right>c.left):c=!1;fh(a,new $g(4096,c))}};
kba=function(a,b){var c=0;g.Lb(sd(),"ima","video","client","tagged")&&(c=1);var d=null;a&&(d=a());if(d){var e=d;d=eh();d.g={};var f=new $g(32,!0);f.o=!1;fh(d,f);f=sd().document;f=f.visibilityState||f.webkitVisibilityState||f.mozVisibilityState||f.msVisibilityState||"";fh(d,new $g(64,"hidden"!=f.toLowerCase().substring(f.length-6)?!0:!1));try{var k=sd().top;try{var l=!!k.location.href||""===k.location.href}catch(u){l=!1}if(l){var m=Ue(e);var n=m&&0!=m.length?"1":"0"}else n="2"}catch(u){n="2"}fh(d,
new $g(256,"2"==n));fh(d,new $g(128,"1"==n));m=l=sd().top;"2"==n&&(m=sd());k=Kh(e,m);fh(d,new ah("er",k));try{var p=m.document&&!m.document.body?null:g.nd(m||window)}catch(u){p=null}p?(m=g.qd(g.fd(m.document).g),fh(d,new $g(16384,!!m)),p=m?new g.Tg(m.x,m.y,p.width,p.height):null):p=null;fh(d,new ah("vi",p));if(p&&"1"==n){n=Ue(e);e=[];for(m=0;m<n.length;m++)(f=Kh(n[m],l))&&e.push(f);e.push(p);p=Jh(e)}Lh(d,k,p);d.l&&(n=mg()-d.l,fh(d,new Zg("ts",n)));d.l=mg()}else d=eh(),d.g={},d.l=mg(),fh(d,new $g(32,
!1));this.o=d;this.g=new Og;this.g.set("ve",4);c&&Pg(this.g,1);g.Lb(sd(),"ima","video","client","crossdomainTag")&&Pg(this.g,4);g.Lb(sd(),"ima","video","client","sdkTag")&&Pg(this.g,8);g.Lb(sd(),"ima","video","client","jsTag")&&Pg(this.g,2);b&&Tb(b,"fullscreen",!1)&&Pg(this.g,16);this.l=d=null;if(c&&(c=g.Lb(sd(),"ima","video","client"),c.getEData)){this.l=c.getEData();if(c=g.Lb(sd(),"ima","video","client","getLastSnapshotFromTop"))if(n=c())this.l.extendWithDataFromTopIframe(n.tagstamp,n.playstamp,
n.lactstamp),c=this.o,d=n.er,n=n.vi,d&&n&&(d=bh(d).getValue(),n=bh(n).getValue(),e=null,Tb(c.g,"er",null)&&(e=Tb(c.g,"er",null).getValue(),e.top+=d.top,e.left+=d.left,fh(c,new ah("er",e))),Tb(c.g,"vi",null)&&(p=Tb(c.g,"vi",null).getValue(),p.top+=d.top,p.left+=d.left,l=[],l.push(p),l.push(d),l.push(n),d=Jh(l),Lh(c,e,d),fh(c,new ah("vi",n))));a:{if(this.l){if(this.l.getTagLoadTimestamp){d=this.l.getTagLoadTimestamp();break a}if(this.l.getTimeSinceTagLoadSeconds){d=this.l.getTimeSinceTagLoadSeconds();
break a}}d=null}}this.g.set("td",mg()-$aa(d))};
lba=function(a,b){try{var c=new kba(a,b),d=[],e=Number(c.g.get("eb"));c.g.remove("eb");var f,k=c.g,l=[],m;for(m in k.g)l.push(m+k.g[m]);(f=l.join("_"))&&d.push(f);if(c.l){var n=c.l.serialize();n&&d.push(n)}var p,u=c.o;f=e;k=[];f||(f=0);for(var x in u.g){var B=u.g[x];if(B instanceof $g)B.getValue()&&(f|=B.A);else{var F,H=u.g[x];(F=H.o?H.l():"")&&k.push(x+F)}}k.push("eb"+String(f));(p=k.join("_"))&&d.push(p);c.g.set("eb",e);return d.join("_")}catch(Q){return"tle;"+nb(Q.name,12)+";"+nb(Q.message,40)}};
Mh=function(a,b,c,d){if(d)c=a+("&"+b+"="+c);else{var e="&"+b+"=",f=a.indexOf(e);0>f?c=a+e+c:(f+=e.length,e=a.indexOf("&",f),c=0<=e?a.substring(0,f)+c+a.substring(e):a.substring(0,f)+c)}return 2E3<c.length?g.t(void 0)?Mh(a,b,void 0,d):a:c};
Oh=function(){return!Nh()&&(Ab("iPod")||Ab("iPhone")||Ab("Android")||Ab("IEMobile"))};
Nh=function(){return Ab("iPad")||Ab("Android")&&!Ab("Mobile")||Ab("Silk")};
Ph=function(a){try{return!!a&&null!=a.location.href&&gc(a,"foo")}catch(b){return!1}};
Qh=function(a,b){if(a)for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b.call(void 0,a[c],c,a)};
nba=function(){var a=[];Qh(mba,function(b){a.push(b)});
return a};
pba=function(a){return(a=oba.exec(a))&&a[0]||""};
qba=function(){var a=Rh;if(!a)return"";var b=/.*[&#?]google_debug(=[^&]*)?(&.*)?$/;try{var c=b.exec((0,window.decodeURIComponent)(a));if(c)return c[1]&&1<c[1].length?c[1].substring(1):"true"}catch(d){}return""};
sba=function(){var a=g.vd("IFRAME").sandbox,b=a&&a.supports;if(!b)return{};var c={};(0,g.C)(rba(),function(d){b.call(a,d)&&(c[d]=!0)});
return c};
Sh=function(a){return a?a.passive&&tba()?a:a.capture||!1:!1};
Th=function(a,b,c,d){a.addEventListener&&a.addEventListener(b,c,Sh(d))};
Uh=function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,Sh(void 0))};
Vh=function(a,b){var c=!1,d=!1;d=void 0===d?!1:d;c=void 0===c?!1:c;a.google_image_requests||(a.google_image_requests=[]);var e=a.document.createElement("img");if(c){var f=function(){c&&g.Qa(a.google_image_requests,e);Uh(e,"load",f);Uh(e,"error",f)};
Th(e,"load",f);Th(e,"error",f)}d&&(e.referrerPolicy="no-referrer");e.src=b;a.google_image_requests.push(e)};
uba=function(){var a=Wh;a=void 0===a?g.w:a;var b=a.context||a.AMP_CONTEXT_DATA;if(!b)try{b=a.parent.context||a.parent.AMP_CONTEXT_DATA}catch(c){}try{if(b&&b.pageViewId&&b.canonicalUrl)return b}catch(c){}return null};
$h=function(){if(Xh&&!Ph(Yh)){var a="."+Zh.domain;try{for(;2<a.split(".").length&&!Ph(Yh);)Zh.domain=a=a.substr(a.indexOf(".")+1),Yh=window.parent}catch(b){}Ph(Yh)||(Yh=window)}return Yh};
ai=function(a,b,c){a&&null!==b&&b!=b.top&&(b=b.top);try{return(void 0===c?0:c)?(new g.ad(b.innerWidth,b.innerHeight)).round():g.nd(b||window).round()}catch(d){return new g.ad(-12245933,-12245933)}};
bi=function(a,b,c){try{a&&(b=b.top);var d=ai(a,b,void 0===c?!1:c),e=g.qd(g.fd(b.document).g);if(-12245933==d.width){var f=d.width;var k=new g.Qg(f,f,f,f)}else k=new g.Qg(e.y,e.x+d.width,e.y+d.height,e.x);return k}catch(l){return new g.Qg(-12245933,-12245933,-12245933,-12245933)}};
vba=function(a){var b={};(0,g.C)(a,function(a){var c=a.event,e=b[c];b.hasOwnProperty(c)?null===e||a.g(e)||(b[c]=null):b[c]=a});
haa(a,function(a){return null===b[a.event]})};
ci=function(){this.g=0;this.o=!1;this.A=-1;this.Tg=!1;this.l=0};
di=function(a){this.o=a;this.l=null;this.g=!1};
ei=function(){this.g={};this.o=!0;this.l={}};
fi=function(a,b,c){a.g[b]||(a.g[b]=new di(c));return a.g[b]};
gi=function(a,b,c){(a=a.g[b])&&null===a.l&&g.Nb(a.o,c)&&(a.l=c)};
hi=function(a,b){if(Mb(a.l,b))return a.l[b];var c=a.g[b];if(c)return c.getValue()};
ii=function(a){var b={},c=g.Db(a.g,function(a){return a.g});
g.Bb(c,function(c,e){var d=void 0!==a.l[e]?String(a.l[e]):c.g&&null!==c.l?String(c.l):"";0<d.length&&(b[e]=d)},a);
return b};
wba=function(a){a=ii(a);var b=[];g.Bb(a,function(a,d){d in Object.prototype||"undefined"!=typeof a&&b.push([d,":",a].join(""))});
return b};
ji=function(){return(0,g.D)()-xba};
oi=function(a){var b=0<=ki?ji()-ki:-1,c=li?ji()-mi:-1,d=0<=ni?ji()-ni:-1;if(79463068==a)return 500;if(947190542==a)return 100;if(79463069==a)return 200;a=[2E3,4E3];var e=[250,500,1E3];var f=b;-1!=c&&c<b&&(f=c);for(b=0;b<a.length;++b)if(f<a[b]){var k=e[b];break}void 0===k&&(k=e[a.length]);return-1!=d&&1500<d&&4E3>d?500:k};
pi=function(a,b){this.l=(void 0===a?0:a)||0;this.g=(void 0===b?"":b)||""};
qi=function(a,b,c){c=void 0===c?{}:c;this.error=a;this.context=b.context;this.line=b.line||-1;this.msg=b.message||"";this.file=b.file||"";this.id=b.id||"jserror";this.meta=c};
ti=function(a){a=a||ri();for(var b=new si(g.w.location.href,g.w,!1),c=null,d=a.length-1,e=d;0<=e;--e){var f=a[e];!c&&yba.test(f.url)&&(c=f);if(f.url&&!f.rp){b=f;break}}e=null;f=a.length&&a[d].url;0!=b.depth&&f&&(e=a[d]);return new zba(b,e,c)};
ri=function(){var a=g.w,b=[],c=null;do{var d=a;if(Ph(d)){var e=d.location.href;c=d.document&&d.document.referrer||null}else e=c,c=null;b.push(new si(e||"",d));try{a=d.parent}catch(f){a=null}}while(a&&d!=a);d=0;for(a=b.length-1;d<=a;++d)b[d].depth=a-d;d=g.w;if(d.location&&d.location.ancestorOrigins&&d.location.ancestorOrigins.length==b.length-1)for(a=1;a<b.length;++a)e=b[a],e.url||(e.url=d.location.ancestorOrigins[a-1]||"",e.rp=!0);return b};
zba=function(a,b,c){this.g=a;this.l=b;this.o=c};
si=function(a,b,c){this.url=a;this.fc=b;this.rp=!!c;this.depth=g.ta(void 0)?void 0:null};
ui=function(){this.o="&";this.A=g.t(void 0)?void 0:"trn";this.B=!1;this.l={};this.C=0;this.g=[]};
vi=function(a,b){var c={};c[a]=b;return[c]};
xi=function(a,b,c,d,e){var f=[];Qh(a,function(a,l){var k=wi(a,b,c,d,e);k&&f.push(l+"="+k)});
return f.join(b)};
wi=function(a,b,c,d,e){if(null==a)return"";b=b||"&";c=c||",$";"string"==typeof c&&(c=c.split(""));if(a instanceof Array){if(d=d||0,d<c.length){for(var f=[],k=0;k<a.length;k++)f.push(wi(a[k],b,c,d+1,e));return f.join(c[d])}}else if("object"==typeof a)return e=e||0,2>e?(0,window.encodeURIComponent)(xi(a,b,c,d,e+1)):"...";return(0,window.encodeURIComponent)(String(a))};
yi=function(a,b,c,d){a.g.push(b);a.l[b]=vi(c,d)};
Aba=function(a){if(!a.A)return 4E3;var b=1,c;for(c in a.l)b=c.length>b?c.length:b;return 4E3-a.A.length-b-a.o.length-1};
zi=function(a,b,c,d){if(Math.random()<(d||a.g))try{if(c instanceof ui)var e=c;else e=new ui,Qh(c,function(a,b){var c=e,d=c.C++,f=vi(b,a);c.g.push(d);c.l[d]=f});
var f=e.Ib(a.A,a.l,a.o+b+"&","");f&&Vh(g.w,f)}catch(k){}};
g.Ai=function(a,b){this.start=a<b?a:b;this.end=a<b?b:a};
Bi=function(){var a=g.w.performance;return a&&a.now&&a.timing?Math.floor(a.now()+a.timing.navigationStart):(0,g.D)()};
Ci=function(){var a=void 0===a?g.w:a;return(a=a.performance)&&a.now?a.now():null};
Bba=function(a,b,c){this.label=a;this.type=b;this.value=c;this.duration=0;this.uniqueId=this.label+"_"+this.type+"_"+Math.random();this.slotId=void 0};
Fi=function(){var a=Di;this.events=[];this.l=a||g.w;var b=null;a&&(a.google_js_reporting_queue=a.google_js_reporting_queue||[],this.events=a.google_js_reporting_queue,b=a.google_measure_js_timing);this.g=Ei()||(null!=b?b:1>Math.random())};
Hi=function(a){a&&Gi&&Ei()&&(Gi.clearMarks("goog_"+a.uniqueId+"_start"),Gi.clearMarks("goog_"+a.uniqueId+"_end"))};
Ki=function(){var a=Ii;this.o=Ji;this.B="jserror";this.A=!0;this.l=null;this.C=this.g;this.Fa=void 0===a?null:a};
Mi=function(a,b,c,d,e){try{if(a.Fa&&a.Fa.g){var f=a.Fa.start(b.toString(),3);var k=c();a.Fa.end(f)}else k=c()}catch(m){c=a.A;try{Hi(f);var l=Li(m);c=(e||a.C).call(a,b,l,void 0,d)}catch(n){a.g(217,n)}if(!c)throw m;}return k};
Oi=function(a,b,c){var d=Ni;return function(e){for(var f=[],k=0;k<arguments.length;++k)f[k-0]=arguments[k];return Mi(d,a,function(){return b.apply(void 0,f)},c,void 0)}};
Li=function(a){return new Pi(Qi(a),a.fileName,a.lineNumber)};
Qi=function(a){var b=a.toString();a.name&&-1==b.indexOf(a.name)&&(b+=": "+a.name);a.message&&-1==b.indexOf(a.message)&&(b+=": "+a.message);if(a.stack){a=a.stack;var c=b;try{-1==a.indexOf(c)&&(a=c+"\n"+a);for(var d;a!=d;)d=a,a=a.replace(/((https?:\/..*\/)[^\/:]*:\d+(?:.|\n)*)\2/,"$1");b=a.replace(/\n */g,"\n")}catch(e){b=c}}return b};
Pi=function(a,b,c){qi.call(this,Error(a),{message:a,file:void 0===b?"":b,line:void 0===c?-1:c})};
Cba=function(a){Ni.l=function(b){(0,g.C)(a,function(a){a(b)})}};
Ri=function(a,b){return Mi(Ni,a,b,void 0,Dba)};
Si=function(a,b){return Oi(a,b,void 0)};
Ti=function(a,b){Ni.g(a,b,void 0,void 0)};
Ui=function(a,b,c,d){c=Oi(d,c,void 0);Th(a,b,c,{capture:!1});return c};
Wi=function(a){var b=Vi.getInstance().l;b&&(b.l&&(a[4]=b.l),b.g&&(a[12]=b.g))};
Xi=function(a){var b=[];g.Bb(a,function(a,d){var c=(0,window.encodeURIComponent)(d),f=a;g.v(f)&&(f=(0,window.encodeURIComponent)(f));b.push(c+"="+f)});
b.push("24="+(0,g.D)());return b.join("\n")};
Yi=function(a){return{visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[a.visibilityState||a.webkitVisibilityState||a.mozVisibilityState||""]||0};
Zi=function(a,b,c,d){if(!a)return{value:d,done:!1};d=b(d,a);var e=c(d,a);return!e&&gc(a,"parentElement")?Zi(g.Ed(a),b,c,d):{done:e,value:d}};
$i=function(a,b,c,d){if(!a)return d;d=Zi(a,b,c,d);if(!d.done)try{var e=g.dd(a),f=e&&sd(e);return $i(f&&f.frameElement,b,c,d.value)}catch(k){}return d.value};
Eba=function(a){var b=!g.pd||g.jc(8);return $i(a,function(a,d){var c=gc(d,"style")&&d.style&&lh(d,"visibility");return{hidden:"hidden"===c,visible:b&&"visible"===c}},function(a){return a.hidden||a.visible},{hidden:!1,
visible:!1}).hidden};
Fba=function(a){return $i(a,function(a,c){return!(!gc(c,"style")||!c.style||"none"!==lh(c,"display"))},function(a){return a},!1)?!0:Eba(a)};
aj=function(a){return new g.Qg(a.top,a.right,a.bottom,a.left)};
bj=function(a){return null!=a&&0<=a&&1>=a};
cj=function(a){if(!a)return null;a=a.split("-");return 4==a.length?new g.Qg(wb(a[0]),wb(a[3]),wb(a[2]),wb(a[1])):null};
dj=function(a,b,c){this.time=a;this.volume=null;this.l=b;this.g=null;this.o=c};
ej=function(a,b,c,d,e,f,k,l,m){this.C=a;this.G=b;this.g=c;this.A=d;this.B=e;this.l=f;this.F=k;this.H=l;this.o=m};
fj=function(){this.L=!1;this.l=!Ph(Wh.top);this.J=Nh()||Oh();var a=ri();this.domain=0<a.length&&null!=a[a.length-1]&&null!=a[a.length-1].url?g.yg(a[a.length-1].url)||"":"";this.A=this.H=this.g=null;this.B=new g.Qg(0,0,0,0);this.o=!1;this.G=this.C=null;this.F=0};
gj=function(a,b){a.H=b.screen?new g.ad(b.screen.width,b.screen.height):null};
hj=function(a,b){a.g=a.o&&a.l?a.C?a.C:new g.Qg(0,0,0,0):bi(!0,b,a.J)};
ij=function(a,b){var c=a.g?new g.ad(a.g.se(),a.g.getHeight()):new g.ad(0,0);var d=b;d=void 0===d?Wh:d;null!==d&&d!=d.top&&(d=d.top);var e=0,f=0;try{var k=d.document,l=k.body,m=k.documentElement;if("CSS1Compat"==k.compatMode&&m.scrollHeight)e=m.scrollHeight!=c.height?m.scrollHeight:m.offsetHeight,f=m.scrollWidth!=c.width?m.scrollWidth:m.offsetWidth;else{var n=m.scrollHeight,p=m.scrollWidth,u=m.offsetHeight,x=m.offsetWidth;m.clientHeight!=u&&(n=l.scrollHeight,p=l.scrollWidth,u=l.offsetHeight,x=l.offsetWidth);
n>c.height?n>u?(e=n,f=p):(e=u,f=x):n<u?(e=n,f=p):(e=u,f=x)}var B=new g.ad(f,e)}catch(F){B=new g.ad(-12245933,-12245933)}a.A=B};
jj=function(){if(0<fj.getInstance().F)return!0;var a=Yi(Zh);return 1===a||0===a};
Vi=function(){this.o=void 0;this.B=0;this.l=new pi(0,"");this.g=0;this.bb="ns";this.A=-1;this.Sa=new ei;fi(this.Sa,"nio_mode",kj).g=!0;fi(this.Sa,"mv",Gba).g=!0;fi(this.Sa,"omid",kj);fi(this.Sa,"osd",kj).g=!0;fi(this.Sa,"epoh",kj).g=!0;fi(this.Sa,"epph",kj).g=!0;fi(this.Sa,"me",kj).g=!0;fi(this.Sa,"umt",kj).g=!0;fi(this.Sa,"gmpd",kj).g=!0;fi(this.Sa,"sel",kj).g=!0;fi(this.Sa,"mce",kj).g=!0;fi(this.Sa,"oflw",kj).g=!0;fi(this.Sa,"inapp",Hba).g=!0;fi(this.Sa,"phel",kj).g=!0;fi(this.Sa,"phell",kj).g=
!0;fi(this.Sa,"oseid",Iba).g=!0};
lj=function(a){this.o=a;this.l=0;this.g=null};
mj=function(a,b,c){this.fc=a;this.Z=void 0===c?"na":c;this.o=[];this.J=!1;this.g=new dj(-1,!0,this);this.l=this;this.F=this.A=b;this.L=this.O=this.C=!1;this.T="uk";this.R=!1};
oj=function(a,b){a.L||(a.L=!0,a.T=b,a.F=0,a.qn(),a.l==a&&(a.A=0,nj(a)))};
pj=function(a,b){g.Ma(a.o,b)||(a.o.push(b),b.Og(a.l),b.fg(a.g),b.Jf()&&(a.C=!0))};
qj=function(a,b){g.Qa(a.o,b);a.C&&b.Jf()&&Jba(a)};
Jba=function(a){a.C=a.o.length?(0,g.rj)(a.o,function(a){return a.Jf()}):!1};
sj=function(a){var b=g.Ta(a.o);(0,g.C)(b,function(b){b.fg(a.g)})};
nj=function(a){var b=g.Ta(a.o);(0,g.C)(b,function(b){b.Og(a.l)});
a.l!=a||sj(a)};
tj=function(a,b){var c;if(!(c=a.O)){c=a.g;var d=a.C;c=!(b&&(void 0===d||!d||c.volume==b.volume)&&c.l==b.l&&Rg(c.g,b.g))}a.g=b;c&&sj(a)};
uj=function(a,b,c,d){this.element=a;this.A=this.g=b;this.Sa=c;this.G=d;this.F=!1;this.l=new ej(b.g,this.element,new g.Qg(0,0,0,0),null,this.ej(),0,0,ji(),0)};
vj=function(a){this.B=!1;this.g=a};
wj=function(a,b,c){this.l=void 0===c?0:c;this.Tb=a;this.g=null==b?"":b};
Kba=function(a,b){return new wj(a.Tb,a.g,a.l+b)};
xj=function(a,b){return a.l<b.l?!0:a.l>b.l?!1:a.Tb<b.Tb?!0:a.Tb>b.Tb?!1:typeof a.g<typeof b.g?!0:typeof a.g>typeof b.g?!1:a.g<b.g};
yj=function(){this.o=0;this.g=[];this.l=!1};
zj=function(a){var b=new yj;var c=void 0===c?0:c;var d=void 0===d?!0:d;Qh(a,function(a,f){d&&void 0===a||b.add(f,a,c)});
return b};
Bj=function(a){var b=Lba;a.l&&(g.bb(a.g,function(a,b){return xj(b,a)?1:xj(a,b)?-1:0}),a.l=!1);
return Aj(a.g,function(a,d){var c=b(d);return""+a+(""!=a&&""!=c?"&":"")+c},"")};
Lba=function(a){var b=a.Tb;a=a.g;return""===a?b:g.sa(a)?a?b:"":g.ya(a)?0===a.length?b:b+"="+a.join():b+"="+(g.Ma(["mtos","tos","p"],b)?a:(0,window.encodeURIComponent)(a))};
Mba=function(a){var b=[],c=[];g.Bb(a,function(a,e){if(!(e in Object.prototype)&&"undefined"!=typeof a){g.ya(a)&&(a=a.join(","));var d=[e,"=",a].join("");switch(e){case "adk":case "r":case "tt":case "error":case "mtos":case "tos":case "p":case "bs":case "aio":case "nio":case "iem":b.unshift(d);break;case "req":case "url":case "referrer":case "iframe_loc":c.push(d);break;default:b.push(d)}}});
return b.concat(c)};
Dj=function(){if(Cj&&"unreleased"!==Cj)return Cj};
Nba=function(a){var b=void 0===b?4E3:b;a=a.toString();if(!/&v=[^&]+/.test(a)){var c=Dj();a=c?a+"&v="+(0,window.encodeURIComponent)(c):a}a=a.substring(0,b);b=$h()||Wh;Vh(b,a)};
Ej=function(a){for(var b=0,c=a,d=0;a&&a!=a.parent;)a=a.parent,d++,Ph(a)&&(c=a,b=d);return{fc:c,level:b}};
Fj=function(a){var b=a!==a.top,c=a.top===Ej(a).fc;if(b&&c&&null!=a.top.mraid)return{Lq:a.top.mraid,Er:3};a=a.mraid;return null!=a?b?c?{Lq:a,Er:2}:{Lq:a,Er:1}:{Lq:a,Er:0}:null};
Ij=function(a){Gj.e=-1;Gj.i=6;Gj.n=7;Gj.t=8;if(!Hj){var b=[];Qh(Gj,function(a,c){b[a+1]=c});
var c=b.join(""),d=a&&a[c];Hj=d&&function(b,c){return d.call(a,b,c)}}return Hj};
Jj=function(){this.l=this.o=this.A=this.g=0};
Kj=function(a){this.l=a=void 0===a?Oba:a;this.g=(0,g.E)(this.l,function(){return new Jj})};
Mj=function(a,b){return Lj(a,function(a){return a.g},void 0===b?!0:b)};
Oj=function(a,b){return Nj(a,b,function(a){return a.g})};
Pj=function(a){return Lj(a,function(a){return a.o},!0)};
Qj=function(a,b){return Nj(a,b,function(a){return a.o})};
Rj=function(a,b){return Nj(a,b,function(a){return a.l})};
Sj=function(a){(0,g.C)(a.g,function(a){a.l=0})};
Lj=function(a,b,c){a=(0,g.E)(a.g,function(a){return b(a)});
return c?a:Pba(a)};
Nj=function(a,b,c){var d=g.Ka(a.l,function(a){return b<=a});
return-1==d?0:c(a.g[d])};
Pba=function(a){return(0,g.E)(a,function(a,c,d){return 0<c?d[c]-d[c-1]:d[c]})};
Tj=function(){this.g=new Kj;this.Z=new Jj;this.O=this.F=-1;this.da=1E3;this.ba=new Kj([1,.9,.8,.7,.6,.5,.4,.3,.2,.1,0])};
Uj=function(a){try{var b=g.Ed(a);if(b)return b}catch(c){}return null};
Qba=function(a){var b=[];for(a=Uj(a);a;)b.push(a),a=Uj(a);return b};
Vj=function(a){return"fixed"===g.mh(a,"position").toLowerCase()};
Wj=function(a,b){var c=Math.max(a.top,b.top),d=Math.max(a.left,b.left);return new g.Qg(c,Math.max(d,Math.min(a.right,b.right)),Math.max(c,Math.min(a.bottom,b.bottom)),d)};
Xj=function(a){try{return aj(a.getBoundingClientRect())}catch(b){return new g.Qg(0,0,0,0)}};
Yj=function(){return 1==hi(Vi.getInstance().Sa,"oflw")};
Zj=function(a){if(!Yj()||Vj(a))return Xj(a);var b=Qba(a),c=g.Ia(b,Vj);b=(0,g.Bd)(-1===c?b:b.slice(0,c),function(a){var b=g.mh(a,"overflowX").toLowerCase();a=g.mh(a,"overflowY").toLowerCase();return!("visible"===b&&"visible"===a)});
b=(0,g.E)(b,function(a){return Xj(a)});
a=Xj(a);return Aj(b,Wj,a)};
ak=function(a){if(!Yj())return Zj(a);var b=Zj(a);try{var c=g.dd(a),d=c&&sd(c),e=d&&d.frameElement;if(!e)return b;var f=ak(e),k=Sg(b,f.left,f.top);return Wj(k,f)}catch(l){return b}};
bk=function(a,b,c,d){uj.call(this,a,b,c,d);this.o=new g.Qg(0,0,0,0)};
ck=function(a,b,c,d){return 4==Vi.getInstance().g?!1:0>=a.se()||0>=a.getHeight()?!0:c&&d?Ri(208,function(){return Rba(a,b,c)}):!1};
dk=function(a,b){return a.left<=b.right&&b.left<=a.right&&a.top<=b.bottom&&b.top<=a.bottom?new g.Qg(Math.max(a.top,b.top),Math.min(a.right,b.right),Math.min(a.bottom,b.bottom),Math.max(a.left,b.left)):new g.Qg(0,0,0,0)};
fk=function(a,b){var c=ek(a),d=ek(b);return 0===d?0:c/d};
ek=function(a){return Math.max(a.getHeight()*a.se(),0)};
Rba=function(a,b,c){if(!a||!b)return!1;b=Sg(a.clone(),-b.left,-b.top);a=(b.left+b.right)/2;b=(b.top+b.bottom)/2;var d=$h();Ph(d.top)&&d.top&&d.top.document&&(d=d.top);d=Ij(d&&d.document);if(!d)return!1;a=d(a,b);if(!a)return!1;b=(b=(b=g.dd(c))&&b.defaultView&&b.defaultView.frameElement)&&Sba(b,a);d=a===c;a=!d&&a&&g.Kd(a,function(a){return a===c});
return!(b||d||a)};
Sba=function(a,b){if(!a||!b)return!1;for(var c=0;null!==a&&100>c++;){if(a===b)return!0;try{if(a=g.Ed(a)||a){var d=g.dd(a),e=d&&sd(d),f=e&&e.frameElement;f&&(a=f)}}catch(k){break}}return!1};
ik=function(a,b,c){g.G.call(this);this.position=gk.clone();this.ke=0;this.Cp=this.Ll();this.zp=-2;this.aN=(0,g.D)();this.Yz=-1;this.Bj=b;this.Fh=-1!=b;this.Gx=null;this.opacity=-1;this.gz=c;this.jA=this.Dp=g.va;this.Hg=this.element=a;this.rA=this.Uh=!1;this.uo=1;this.Eh={Kq:null,Jq:null};this.Gz=!0;this.Nh=!1;Vi.getInstance().B++;this.yv=0;this.dc=this.Fo();this.Uz=-1;this.Hn=new g.Qg(0,0,0,0);a=this.Sa=new ei;fi(a,"od",Tba);fi(a,"opac",kj).g=!0;fi(a,"ud",kj);fi(a,"mkm",kj).g=!0;fi(a,"gcm",kj).g=
!0;fi(a,"cm",kj).g=!0;fi(a,"sela",kj).g=!0;fi(a,"sbeos",kj).g=!0;fi(a,"neh",kj);fi(a,"mwt",kj).g=!0;a=null!=Fj($h());if(b=this.element&&this.element.getAttribute)b=this.element,b=/-[a-z]/.test("googleAvInapp")?!1:g.hk&&b.dataset?"googleAvInapp"in b.dataset:b.hasAttribute?b.hasAttribute("data-"+g.yb("googleAvInapp")):!!b.getAttribute("data-"+g.yb("googleAvInapp"));(b||a)&&gi(Vi.getInstance().Sa,"inapp",1);1==this.gz?gi(this.Sa,"od",1):gi(this.Sa,"od",0)};
jk=function(a,b){if(b!=a.Nh){a.Nh=b;var c=fj.getInstance();b?c.F++:0<c.F&&c.F--}};
Vba=function(a,b,c){if(a.Fh){var d=Ij(Wh&&Wh.document);d&&(c||kk(a,Wh,!0),d=Uba(a,d),a.uh(a.position,d,b,c,!0,!0))}};
lk=function(a,b,c){if(c(b))return b;for(;;){var d=Math.floor((a+b)/2);if(d==a||d==b)return a;c(d)?a=d:b=d}};
Uba=function(a,b){var c=g.qd(window.document),d=a.uo,e=Math.floor(a.position.left-c.x)+1,f=Math.floor(a.position.top-c.y)+1,k=Math.floor(a.position.right-c.x)-d,l=Math.floor(a.position.bottom-c.y)-d;c=(l-f)*(k-e);if(f>l||e>k)return 0;d=!!b(e,f);var m=!!b(k,l);if(d&&m)return 1;var n=!!b(k,f),p=!!b(e,l);if(d)l=lk(f,l,function(a){return!!b(e,a)}),k=lk(e,k,function(a){return!!b(a,f)});
else if(n)l=lk(f,l,function(a){return!!b(k,a)}),e=lk(k,e,function(a){return!!b(a,f)});
else if(p)f=lk(l,f,function(a){return!!b(e,a)}),k=lk(e,k,function(a){return!!b(a,l)});
else if(m)f=lk(l,f,function(a){return!!b(k,a)}),e=lk(k,e,function(a){return!!b(a,l)});
else{var u=Math.floor((e+k)/2),x=Math.floor((f+l)/2);if(!b(u,x))return 0;f=lk(x,f,function(a){return!!b(u,a)});
l=lk(x,l,function(a){return!!b(u,a)});
e=lk(u,e,function(a){return!!b(a,x)});
k=lk(u,k,function(a){return!!b(a,x)})}return(l-f)*(k-e)/c};
Wba=function(a,b,c,d,e){a.Fh&&(d||kk(a,Wh,e),a.uh(a.position,c,b,d,!1,!0))};
mk=function(a,b,c){if(a.Fh){var d=a.dc.l,e=c?a.dc.g:a.yv;a.Hn&&!Rg(a.Hn,new g.Qg(0,0,0,0))&&(e=Sg(a.Hn.clone(),a.position.left,a.position.top));a.uh(a.position,e,b,c,!0,!0,{},void 0,d)}};
Xba=function(a,b){var c=b.create(a.Hg,a.Sa,a);null!=c&&c.Nv();c&&(a.bb=c)};
Yba=function(a,b,c){if(a.Fh&&a.bb){var d=$h(),e=fj.getInstance();kk(a,d,e.l);a.bb.Ni();d=a.bb.l;e=d.C.g;var f=!(!d.B&&!e);if(null!=d.A&&e){var k=d.g;a.Gx=new g.Yc(k.left-e.left,k.top-e.top)}a.uh(a.position,d.l,b,c,!0,f,void 0,void 0,d.o)}};
kk=function(a,b,c,d){if(d)a.position=d;else{b=c?b:b.top;try{var e=new g.Qg(0,0,0,0),f=new g.Yc(0,0);if(a.Hg){var k=1==a.gz;!c&&k&&Fba(a.Hg)||(e=ak(a.Hg));f=g.wh(a.Hg,b)}if(Yj())a.position=e;else{var l=e.se(),m=e.getHeight();c=f;var n=c.x,p=c.y;a.position=new g.Qg(Math.round(p),Math.round(n+l),Math.round(p+m),Math.round(n))}}catch(u){a.position=gk.clone()}}Yj()?(l=a.Hg.getBoundingClientRect(),a.ke=(l.right-l.left)*(l.bottom-l.top)):a.ke=(a.position.bottom-a.position.top)*(a.position.right-a.position.left)};
nk=function(a,b){var c=Math.pow(10,b);return Math.floor(a*c)/c};
ok=function(a){a.bb&&a.bb.Gp()};
Zba=function(a){Ri(151,function(){var b=uba().observeIntersection(function(c){try{if(!c||!c.length||0>=c.length)var d=null;else{for(var e=c[0],f=1;f<c.length;f++)c[f].time>e.time&&(e=c[f]);d=e}if(c=d){var k=c.intersectionRect.width*c.intersectionRect.height/(c.boundingClientRect.width*c.boundingClientRect.height),l=aj(c.boundingClientRect),m=aj(c.intersectionRect);var n=k*ek(l)/(Wh.screen.height*Wh.screen.width);a.dc.g=g.Uc(k,0,1);a.yv=a.dc.g;a.dc.l=g.Uc(n,0,1);kk(a,Wh,!0,l);var p=dk(l,m);a.Hn=0>=
a.ke||p.top>=p.bottom||p.left>=p.right?new g.Qg(0,0,0,0):Sg(p,-l.left,-l.top)}}catch(u){try{b(),Ti("osd_adblock::aioc",u)}catch(x){}}})})};
$ba=function(a,b){var c=Vi.getInstance().bb;if(b=void 0===b?g.va:b)a.jA=b;switch(c){case "aio":Zba(a)}};
pk=function(){};
rk=function(a){if(a instanceof pk)return a;if("function"==typeof a.ff)return a.ff(!1);if(g.za(a)){var b=0,c=new pk;c.next=function(){for(;;){if(b>=a.length)throw qk;if(b in a)return a[b++];b++}};
return c}throw Error("Not implemented");};
g.sk=function(a,b,c){if(g.za(a))try{(0,g.C)(a,b,c)}catch(d){if(d!==qk)throw d;}else{a=rk(a);try{for(;;)b.call(c,a.next(),void 0,a)}catch(d){if(d!==qk)throw d;}}};
aca=function(a){if(g.za(a))return g.Ta(a);a=rk(a);var b=[];g.sk(a,function(a){b.push(a)});
return b};
bca=function(){this.A=this.g=this.o=this.l=this.B=0};
cca=function(a){var b={};var c=(0,g.D)()-a.B;b=(b.ptlt=c,b);(c=a.l)&&(b.pnk=c);(c=a.o)&&(b.pnc=c);(c=a.A)&&(b.pnmm=c);(a=a.g)&&(b.pns=a);return b};
tk=function(){ci.call(this);this.fullscreen=!1;this.volume=void 0;this.paused=!1;this.B=-1};
uk=function(a){return bj(a.volume)&&.1<=a.volume};
dca=function(){var a={};this.l=(a.vs=[1,0],a.vw=[0,1],a.am=[2,2],a.a=[4,4],a.f=[8,8],a.bm=[16,16],a.b=[32,32],a.avw=[0,64],a.cm=[128,128],a.pv=[256,256],a.gdr=[0,512],a.p=[0,1024],a.r=[0,2048],a.m=[0,4096],a.um=[0,8192],a.ef=[0,16384],a.s=[0,32768],a.pmx=[0,16777216],a);this.g={};for(var b in this.l)0<this.l[b][1]&&(this.g[b]=0);this.o=0};
vk=function(a,b){var c=a.l[b],d=c[1];a.o+=c[0];0<d&&0==a.g[b]&&(a.g[b]=1)};
eca=function(a){return wk(a,g.Kb(a.l))};
wk=function(a,b){var c=0,d;for(d in a.g)g.Ma(b,d)&&1==a.g[d]&&(c+=a.l[d][1],a.g[d]=2);return c};
fca=function(a){var b=0,c;for(c in a.g){var d=a.g[c];if(1==d||2==d)b+=a.l[c][1]}return b};
xk=function(){this.g=this.l=0};
yk=function(){Tj.call(this);this.o=new Jj;this.R=this.H=this.L=0;this.G=-1;this.ha=new Jj;this.B=new Jj;this.l=new Kj;this.C=this.A=-1;this.J=new Jj;this.da=2E3;this.T=new xk;this.X=new xk;this.Y=new xk};
zk=function(a,b,c){var d=a.R;li||c||-1==a.G||(d+=b-a.G);return d};
gca=function(){this.g=!1};
Ak=function(a,b){this.g=!1;this.A=a;this.F=b;this.l=0};
Bk=function(a,b){if(a.o(b)){var c=a.F.report(a.A,b);a.l|=c;return 0==c}return!1};
Ck=function(a,b,c,d,e,f){e=void 0===e?null:e;f=void 0===f?[]:f;ik.call(this,b,c,d);this.Y=0;this.o={};this.gc=new dca;this.vA={};this.jc="";this.qg=null;this.Oa=!1;this.l=[];this.Ej=e;this.F=f;this.A=void 0;this.B=-1;this.ga=this.H=void 0;this.X=!1;this.J=this.L=0;this.R=-1;this.ba=this.wa=!1;this.Fi=this.Ta=0;this.ka=!1;this.Ia=this.Ja=-1;this.T=this.G=this.g=0;this.ob=this.ab=-1;this.nb=0;this.Va=new Kj;this.Z=this.oa=this.Ya=0;this.sa=-1;this.pa=0;this.Ca=!1;this.da=null;this.wc=0;this.ha=g.va;
this.O=[this.Ll()];this.rA=!0;this.uo=2;b=fj.getInstance();kk(this,a,b.l);this.wh={};this.wh.pause="p";this.wh.resume="r";this.wh.skip="s";this.wh.mute="m";this.wh.unmute="um";this.wh.exitfullscreen="ef";this.C=null};
hca=function(a,b,c){a.wc=1;a.o={};a.o.firstquartile=!1;a.o.midpoint=!1;a.o.thirdquartile=!1;a.o.complete=!1;a.o.pause=!1;a.o.skip=!1;a.o.viewable_impression=!1;a.Y=0;c||(a.xd().G=b)};
Dk=function(a){0!=a.wc&&(a.wc=3)};
Ek=function(a){return g.t(a)?Number(a)?nk(a,3):0:a};
Fk=function(a,b){var c;null!=b&&b<a.O.length?c=b:c=a.O.length-1;return a.O[c]};
Gk=function(a){var b=!!hi(Vi.getInstance().Sa,"umt");return a.H||!b&&!a.ga?0:1};
ica=function(a,b){(0,g.rj)(a.F,function(a){return a.A==b.A})||a.F.push(b)};
Ik=function(a,b,c){return 15E3<=b?!0:a.wa?(void 0===c?0:c)?!0:Hk(a.B)?b>=a.B/2:Hk(a.R)?b>=a.R:!1:!1};
Hk=function(a){return 1==hi(Vi.getInstance().Sa,"gmpd")?0<a:-1!=a};
jca=function(a){var b={},c=fj.getInstance();b.insideIframe=c.l;b.unmeasurable=a.Uh;b.position=a.position;b.exposure=a.dc.g;b.documentSize=c.A;b.viewportSize=new g.ad(c.g.se(),c.g.getHeight());null!=a.C&&(b.presenceData=a.C);b.screenShare=a.dc.l;return b};
Kk=function(a,b){Jk(a.l,b,function(){return{nN:0,Wl:void 0}});
a.l[b]={viewableArea:nk(a.dc.g,2),instantaneousState:a.gc.o}};
Jk=function(a,b,c){for(var d=a.length;d<b+1;)a.push(c()),d++};
Nk=function(a,b,c){var d=a.vA[b];if(null!=d)return d;d=kca(a,b);var e=Ob(Lk,function(a){return a==b});
c=Mk(a,d,d,c,lca[Lk[e]]);"fully_viewable_audible_half_duration_impression"==b&&(c.std="csm",c.ic=wk(a.gc,["gdr"]));return c};
Mk=function(a,b,c,d,e){if(a.Uh)return{"if":0};var f=a.position.clone();f.round();var k=(0,g.E)(a.l,function(a){return 100*a.nN|0}),l=fj.getInstance(),m=Vi.getInstance(),n=a.xd(),p={};
p["if"]=l.l?1:void 0;p.sdk=a.A?a.A:void 0;p.t=a.aN;p.p=[f.top,f.left,f.bottom,f.right];p.tos=Mj(n.g,!1);p.mtos=Pj(n.g);p.mcvt=n.Z.o;p.ps=void 0;p.pt=k;f=zk(n,ji(),2==a.wc);p.vht=f;p.mut=n.ha.o;p.a=Ek(a.dc.volume);p.mv=Ek(n.C);p.fs=a.Nh?1:0;p.ft=n.J.g;p.at=n.B.g;p.as=.1<=n.A?1:0;p.atos=Mj(n.l);p.ssb=Mj(n.ba,!1);p.amtos=Pj(n.l);p.uac=a.Ta;p.vpt=n.o.g;"nio"==m.bb&&(p.nio=1,p.avms="nio");p.gmm="4";p.gdr=Ik(a,n.o.g,!0)?1:0;a.rA&&(p.efpf=a.uo);0<a.pa&&(p.nnut=a.pa);p.tcm=Gk(a);p.nmt=a.oa;p.bt=a.Z;p.pst=
a.sa;p.vpaid=a.H;p.dur=a.B;p.vmtime=a.L;p.is=a.gc.o;1<=a.l.length&&(p.i0=a.l[0].Wl);2<=a.l.length&&(p.i1=a.l[1].Wl);3<=a.l.length&&(p.i2=a.l[2].Wl);4<=a.l.length&&(p.i3=a.l[3].Wl);p.cs=fca(a.gc);b&&(p.ic=eca(a.gc),p.dvpt=n.o.l,p.dvs=Rj(n.g,.5),p.dfvs=Rj(n.g,1),p.davs=Rj(n.l,.5),p.dafvs=Rj(n.l,1),c&&(n.o.l=0,Sj(n.g),Sj(n.l)),a.Vg()&&(p.dtos=n.L,p.dav=n.H,p.dtoss=a.Y+1,c&&(n.L=0,n.H=0,a.Y++)),p.dat=n.B.l,p.dft=n.J.l,c&&(n.B.l=0,n.J.l=0));l.A&&(p.ps=[l.A.width,l.A.height]);l.g&&(p.bs=[l.g.se(),l.g.getHeight()]);
l.H&&(p.scs=[l.H.width,l.H.height]);p.dom=l.domain;a.Fi&&(p.vds=a.Fi);if(0<a.F.length||a.Ej)b=g.Ta(a.F),a.Ej&&b.push(a.Ej),p.pings=(0,g.E)(b,function(a){return a.toString()});
b=(0,g.E)((0,g.Bd)(a.F,function(a){return a.B()}),function(a){return a.getId()});
iaa(b);p.ces=b;a.g&&(p.vmer=a.g);a.G&&(p.vmmk=a.G);a.T&&(p.vmiec=a.T);p.avms=a.bb?a.bb.lg():Vi.getInstance().bb;a.bb&&g.Zb(p,a.bb.qf());"exc"==m.bb&&(p.femt=a.ab,p.femvt=a.ob,p.emc=a.nb,p.emb=Mj(a.Va,!1),p.emuc=a.Ya,p.avms="exc");d?(p.c=nk(a.dc.g,2),p.ss=nk(a.dc.l,2)):p.tth=ji()-Ok;p.mc=nk(n.O,2);p.nc=nk(n.F,2);p.mv=Ek(n.C);p.nv=Ek(n.A);p.lte=nk(a.zp,2);d=Fk(a,e);Pj(n.g);p.qmtos=Pj(d.g);p.qnc=nk(d.F,2);p.qmv=Ek(d.C);p.qnv=Ek(d.A);p.qas=.1<=d.A?1:0;p.qi=a.jc;null!==a.da&&(p.nvat=a.da?1:0);p.avms||
(p.avms="geo");p.psm=n.T.g;p.psv=n.T.getValue();p.psfv=n.X.getValue();p.psa=n.Y.getValue();m=wba(m.Sa);m.length&&(p.veid=m);a.C&&g.Zb(p,cca(a.C));return p};
kca=function(a,b){if(g.Ma(mca,b))return!0;var c=a.o[b];return g.t(c)?(a.o[b]=!0,!c):!1};
oca=function(){this.g={};var a=sd();Pk(this,a,window.document);var b=nca();try{if("1"==b){for(var c=a.parent;c!=a.top;c=c.parent)Pk(this,c,c.document);Pk(this,a.top,a.top.document)}}catch(d){}};
nca=function(){var a=window.document.documentElement;try{if(!Ph(sd().top))return"2";var b=[],c=sd(a.ownerDocument);for(a=c;a!=c.top;a=a.parent)if(a.frameElement)b.push(a.frameElement);else break;return b&&0!=b.length?"1":"0"}catch(d){return"2"}};
Pk=function(a,b,c){Ui(c,"mousedown",function(){return pca(a)},301);
Ui(b,"scroll",function(){return qca(a)},302);
Ui(c,"touchmove",function(){return rca(a)},303);
Ui(c,"mousemove",function(){return sca(a)},304);
Ui(c,"keydown",function(){return tca(a)},305)};
pca=function(a){g.Bb(a.g,function(a){1E5<a.o||++a.o})};
qca=function(a){g.Bb(a.g,function(a){1E5<a.g||++a.g})};
rca=function(a){g.Bb(a.g,function(a){1E5<a.g||++a.g})};
tca=function(a){g.Bb(a.g,function(a){1E5<a.l||++a.l})};
sca=function(a){g.Bb(a.g,function(a){1E5<a.A||++a.A})};
Qk=function(){this.g=[];this.l=[]};
uca=function(a,b){return null!=b&&(0,g.rj)(a.g,function(a){return a.element===b})};
Rk=function(a,b){return g.Ja(a.g,function(a){return a.jc==b})};
Tk=function(){var a=Sk;return 0==a.g.length?a.l:0==a.l.length?a.g:g.Sa(a.l,a.g)};
vca=function(a,b){var c=Sk,d=(0,g.Bd)(a,(void 0===b?0:b)?function(a){return!Rk(c,a.jc)}:function(a){return!uca(c,a.element)});
c.g.push.apply(c.g,g.ea(d))};
wca=function(a){var b=Sk,c=[];(0,g.C)(a,function(a){(0,g.rj)(b.g,function(b){return b.element===a.element&&b.jc===a.jc})||(b.g.push(a),c.push(a))})};
Uk=function(){this.g=this.l=null};
Vk=function(a,b){function c(c,e){a.g=null;b(c,e)}
if(null==a.l)return!1;a.g=g.Ja(a.l,function(a){return null!=a&&a.rh()&&a.init(c)});
return null!=a.g};
Wk=function(a,b,c,d){uj.call(this,a,b,c,d);this.C=this.B=this.o=null};
yca=function(a){if(!a.element)return!1;var b=a.element;a.o=new a.g.fc.IntersectionObserver(function(b){return Xk(a,b)},xca);
a.o.observe(b);1===hi(Vi.getInstance().Sa,"nio_mode")&&Xk(a,a.o&&a.o.takeRecords?a.o.takeRecords():[]);return!0};
Xk=function(a,b){try{if(b.length){a.B||(a.B=ji());var c=zca(b),d=aj(c.boundingClientRect),e=Sg(aj(c.intersectionRect),-d.left,-d.top),f=ji(),k=c.boundingClientRect.width*c.boundingClientRect.height,l=c.intersectionRect.width*c.intersectionRect.height;var m=k?l/k:0;k=0;var n=c.intersectionRect.width*c.intersectionRect.height,p=a.g.g.g;p&&(k=(p.bottom-p.top)*(p.right-p.left));var u=c.intersectionRect.width*c.intersectionRect.height,x=window.screen.height*window.screen.width;a.l=new ej(a.g.g,a.element,
d,e,a.ej(),m,k?n/k:0,f,u&&x?u/x:0)}}catch(B){a.Gp(),Ti(299,B)}};
zca=function(a){return Aj(a,function(a,c){return a.time>c.time?a:c},a[0])};
Yk=function(a){a=void 0===a?Wh:a;vj.call(this,new mj(a,2))};
g.Zk=function(a,b,c){g.G.call(this);this.o=null!=c?(0,g.z)(a,c):a;this.Uc=b;this.l=(0,g.z)(this.AC,this);this.g=[]};
$k=function(a){a.Fa=g.kg(a.l,a.Uc);a.o.apply(null,a.g)};
al=function(){this.done=!1;this.g={MB:0,it:0,sr:0,fu:0,gp:-1};this.J=this.A=this.F=this.B=this.G=null;this.L=!1;this.l=null;this.O=0;this.o=new lj(this)};
bl=function(){var a=Vi.getInstance().bb;return"nio"==a||"aio"==a};
dl=function(){var a=cl;a.L||(a.L=!0,a.G||bl()||(a.B=new g.Zk(Si(137,function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];return a.C.apply(a,g.ea(c))}),100),a.G=Ui(Wh,"scroll",function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];
null!==a.B&&a.B.mj.apply(a.B,g.ea(c))},138)),a.F||bl()||(a.A=new g.Zk(Si(140,function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];
return a.C.apply(a,g.ea(c))}),100),a.F=Ui(Wh,"resize",function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];
null!==a.A&&a.A.mj.apply(a.A,g.ea(c))},141)),Aca(a,function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];
return a.H.apply(a,g.ea(c))}),a.H())};
Bca=function(){var a=Uk.getInstance();null!=a.g&&a.g.g||fj.getInstance().update(Wh)};
el=function(a,b,c,d){if(!a.done&&(a.o.cancel(),0!=b.length)){a.l=null;var e=fj.getInstance();Bca();try{var f=ji(),k=Vi.getInstance();k.A=f;if(null!=Uk.getInstance().g)for(d=0;d<b.length;d++)Yba(b[d],f,c);else switch(k.bb){case "exc":for(d=0;d<b.length;d++)mk(b[d],f,c);break;case "nis":for(e=0;e<b.length;e++)g.t(d)?b[e].Bn(d):b[e].Gv(f);break;case "gsv":for(e=0;e<b.length;e++)g.t(d)?b[e].Ru(d):b[e].Fv(f);break;case "aio":case "nio":for(d=0;d<b.length;d++)mk(b[d],f,c);break;case "iem":for(d=0;d<b.length;d++)Vba(b[d],
f,c);break;case "geo":if(e.G)for(d=0;d<b.length;d++)Wba(b[d],f,e.G,c,e.l)}for(d=0;d<b.length;d++);a.g.sr+=ji()-f;++a.g.fu}finally{c?(0,g.C)(b,function(a){a.dc.g=0}):a.o.schedule()}}};
Aca=function(a,b){var c;Zh.visibilityState?c="visibilitychange":Zh.mozVisibilityState?c="mozvisibilitychange":Zh.webkitVisibilityState&&(c="webkitvisibilitychange");c&&(a.J=a.J||Ui(Zh,c,b,142))};
Cca=function(){var a=cl;if(void 0===b){Vi.getInstance();var b=[];b.push(a.T)}b=g.q(b);for(var c=b.next();!c.done;c=b.next())if(c.value.call(a,Wh))return!0;return!1};
fl=function(a,b){var c=a.O;li&&(c+=b-mi);return c};
Dca=function(a){var b=cl;a=void 0===a?function(){return{}}:a;
Ni.B="av-js";Ji.g=.01;Cba([function(c){var d=Vi.getInstance(),e={};e=(e.bin=d.g,e.type="error",e);d=ii(d.Sa);if(!b.l){var f=Wh.document,k=0<=ki?ji()-ki:-1,l=ji();-1==b.g.gp&&(k=l);var m=fj.getInstance(),n=ii(Vi.getInstance().Sa),p=Tk();try{if(0<p.length){var u=m.g;u&&(n.bs=[u.se(),u.getHeight()]);var x=m.A;x&&(n.ps=[x.width,x.height]);Wh.screen&&(n.ss=[Wh.screen.width,Wh.screen.height])}else n.url=(0,window.encodeURIComponent)(Wh.location.href.substring(0,512)),f.referrer&&(n.referrer=(0,window.encodeURIComponent)(f.referrer.substring(0,
512)));n.tt=k;n.pt=ki;switch(Vi.getInstance().bb){case "iem":n.iem=1;break;case "aio":n.aio=1;break;case "nio":n.nio=1}void 0!==Wh.google_osd_load_pub_page_exp&&(n.olpp=Wh.google_osd_load_pub_page_exp);n.deb=[1,b.g.MB,b.g.it,b.g.sr,b.g.fu,b.g.gp,0,b.o.l].join("-");n.tvt=fl(b,l);if(null!==Wh&&Wh!=Wh.top){0<p.length&&(n.iframe_loc=(0,window.encodeURIComponent)(Wh.location.href.substring(0,512)));var B=m.B;n.is=[B.se(),B.getHeight()]}}catch(F){n.error=1}b.l=n}g.Zb(c,e,d,g.Wb(b.l),a());if(u=Dj())x={},
g.Zb(c,(x.v=(0,window.encodeURIComponent)(u),x))}])};
Eca=function(){var a=g.zb;return a?(0,g.rj)("AppleTV;GoogleTV;HbbTV;NetCast.TV;Opera TV;POV_TV;SMART-TV;SmartTV;TV Store;OMI/".split(";"),function(b){return ob(a,b)})?!0:ob(a,"Presto")&&ob(a,"Linux")&&!ob(a,"X11")&&!ob(a,"Android")&&!ob(a,"Mobi"):!1};
Fca=function(){var a=gl||Wh;if(!a)return"";var b=[];if(!a.location.href)return"";b.push("url="+(0,window.encodeURIComponent)(a.location.href.substring(0,512)));a.document&&a.document.referrer&&b.push("referrer="+(0,window.encodeURIComponent)(a.document.referrer.substring(0,512)));return b.join("&")};
hl=function(a){return function(b){return!g.t(b[a])&&g.t(0)?0:b[a]}};
jl=function(){var a=[0,2,4];return function(b){b=b.tos;if(g.ya(b)){for(var c=Array(b.length),d=0;d<b.length;d++)c[d]=0<d?c[d-1]+b[d]:b[d];return g.t(a)?il(c,a):c}}};
kl=function(a,b){return function(c){c=c[a];if(g.ya(c))return il(c,b)}};
ll=function(a){var b=Gca;return function(c){return b(c)?c[a]:void 0}};
il=function(a,b){return(0,g.Bd)(a,function(a,d){return g.Ma(b,d)})};
ol=function(a,b){var c={sv:"682",cb:"j"};c.nas=Sk.g.length;c.msg=a;if(g.t(b)){var d=ml(b);d&&(c.e=nl[d])}return c};
pl=function(a){return g.fb(a,"custom_metric_viewable")};
ml=function(a){var b=pl(a)?"custom_metric_viewable":a.toLowerCase();return Ob(Lk,function(a){return a==b})};
ql=function(a,b){Ak.call(this,a,b)};
rl=function(){this.l=this.A=this.C=this.B=this.o=this.g=""};
Hca=function(){};
sl=function(a,b,c,d,e){var f={};if(g.t(a))if(null!=b)for(var k in b){var l=b[k];k in Object.prototype||null!=l&&(g.Aa(l)?f[k]=l(a):f[k]=a[l])}else g.Zb(f,a);g.t(c)&&g.Zb(f,c);a=Bj(zj(f));0<a.length&&g.t(d)&&g.t(e)&&(e=e(a),a+="&"+d+"="+e);return a};
tl=function(){};
vl=function(a){a=Ica(a);vj.call(this,a.length?a[a.length-1]:new mj(Wh,0));this.o=a;this.A=g.va;this.l=null};
Ica=function(a){if(!a.length)return[];a=(0,g.Bd)(a,function(a){return null!=a&&a.rh()});
for(var b=1;b<a.length;b++)pj(a[b-1],a[b]);return a};
wl=function(){mj.call(this,Wh,1,"osd");this.Y=[];this.G=this.B=this.H=0;this.O=!0};
xl=function(a){var b=0;a=a.fc;try{if(a&&a.Goog_AdSense_getAdAdapterInstance)return a}catch(c){}for(;a&&5>b;){try{if(a.google_osd_static_frame)return a.google_osd_static_frame}catch(c){}try{if(a.aswift_0&&a.aswift_0.google_osd_static_frame)return a.aswift_0.google_osd_static_frame}catch(c){}b++;a=a!=a.parent?a.parent:null}return null};
Jca=function(a){var b={};Wi(b);b[0]="goog_request_monitoring";b[6]=4;b[16]=!1;try{var c=Xi(b);a.postMessage(c,"*")}catch(d){}};
zl=function(a){++a.G;if(2==a.H)yl(a);else{if(10<a.G){if(20<a.G){oj(a,"no");return}11==a.G&&(a.fc.clearInterval(a.B),a.B=a.fc.setInterval(Si(197,function(){return zl(a)}),500))}if(a.fc.postMessage)if(Vi.getInstance().l.ld()){var b=xl(a);
b&&Jca(b)}else oj(a,"ib");else oj(a,"c")}};
yl=function(a){a.fc.clearInterval(a.B);a.B=0};
Al=function(a,b){var c=xl(a),d=!c;d&&(c=a.fc.parent);if(c&&c.postMessage)try{c.postMessage(b,"*"),d&&a.fc.postMessage(b,"*")}catch(e){}};
Kca=function(a,b){(0,g.C)(a.Y,function(a){a(b)})};
Bl=function(){this.B=this.L=!1;this.l=null;this.o=new tl;this.g=null;var a={};this.J=(a.start=this.dD,a.firstquartile=this.YC,a.midpoint=this.aD,a.thirdquartile=this.eD,a.complete=this.WC,a.pause=this.gr,a.resume=this.jz,a.skip=this.cD,a.viewable_impression=this.cg,a.mute=this.Di,a.unmute=this.Di,a.fullscreen=this.ZC,a.exitfullscreen=this.XC,a.fully_viewable_audible_half_duration_impression=this.cg,a.measurable_impression=this.cg,a.abandon=this.gr,a.engagedview=this.cg,a.impression=this.cg,a.creativeview=
this.cg,a.progress=this.Di,a.custom_metric_viewable=this.cg,a.bufferstart=this.gr,a.bufferfinish=this.jz,a);a={};this.O=(a.overlay_resize=this.bD,a.abandon=this.Zo,a.close=this.Zo,a.collapse=this.Zo,a.overlay_unmeasurable_impression=function(a){return Nk(a,"overlay_unmeasurable_impression",jj())},a.overlay_viewable_immediate_impression=function(a){return Nk(a,"overlay_viewable_immediate_impression",jj())},a.overlay_unviewable_impression=function(a){return Nk(a,"overlay_unviewable_impression",jj())},
a.overlay_viewable_end_of_session_impression=function(a){return Nk(a,"overlay_viewable_end_of_session_impression",jj())},a);
Vi.getInstance().g=3;Lca(this);this.A=!1};
Cl=function(a,b,c,d){b=a.cn(null,d,!0,b);b.A=c;b.Dp=function(b){a.Yo(b)};
vca([b],a.A);return b};
Mca=function(){var a=[],b=fj.getInstance(),c=Vi.getInstance();hi(c.Sa,"osd")&&b.o&&b.l&&"exc"!=c.bb&&(b.o=!1,a.push(wl.getInstance()));return[new vl(a)]};
Nca=function(a){if(!a.L){a.L=!0;try{var b=ji(),c=Vi.getInstance(),d=fj.getInstance();ki=b;gl=Ej(Wh).fc;d.update(Wh);ij(d,Wh);gj(d,Wh);if("nis"!=c.bb&&"gsv"!=c.bb)if(Wh.document.body&&Wh.document.body.getBoundingClientRect){cl.g.it=0;cl.g.gp=ji()-b;"ns"==c.bb&&(c.bb="geo");var e=Mca(),f=Uk.getInstance();f.l=e;if(Vk(f,function(){d.o=!1;Dl()}))cl.done||(dl(),pj(f.g.g,a));
else if(d.l&&"exc"!=c.bb){var k=!!hi(c.Sa,"osd");if(d.o&&d.l&&!k){var l=wl.getInstance();l.initialize();pj(l,a)}else Dl()}else dl()}else El=!0}catch(m){throw Sk.reset(),m;}}};
Gl=function(a){cl.o.cancel();Fl=a;cl.done=!0};
Hl=function(a){var b=Vi.getInstance();if(null==a.l)switch(b.bb){case "nis":a.l="n";break;case "gsv":a.l="m";break;default:a.l="h"}return a.l};
Il=function(a,b,c){if(null==a.g)return b.Fi|=4,!1;a=a.g.report(c,b);b.Fi|=a;return 0==a};
Dl=function(){var a=[new Yk(Wh)],b=Uk.getInstance();b.l=a;Vk(b,function(){Gl("i")})?cl.done||dl():Cca()?dl():Gl("i")};
Jl=function(a,b,c){if(!b.Oa){var d=Nk(b,"start",jj());a=a.o.g(d).g;var e={};e.r=c;e.v="682v";Ag(a,function(a,b){return e[a]="mtos"==a||"tos"==a?b:(0,window.encodeURIComponent)(b)});
c=Fca();Ag(c,function(a,b){return e[a]=(0,window.encodeURIComponent)(b)});
e.id="lidarvf";c="//pagead2.googlesyndication.com/pagead/gen_204?"+Bj(zj(e));Nba(c);b.Oa=!0}};
Kl=function(a,b,c,d){el(cl,[a],!jj(),d);Kk(a,c);4!=c&&Jk(a.O,c,a.Ll);return Nk(a,b,jj())};
Oca=function(a,b,c){if(0==b.wc){"i"!=Fl&&(cl.done=!1);var d=Uk.getInstance();null!=d.g&&Xba(b,d.g);$ba(b,function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];return a.VC.apply(a,g.ea(c))});
d=g.t(c)?c.opt_nativeTime:void 0;ni=d=g.ta(d)?d:ji();b.Fh=!0;var e=jj();hca(b,d,e);el(cl,[b],!e,c)}};
Lca=function(a){Dca(function(){var b=Ll();null!=a.l&&(b.sdk=a.l);b.avms=Vi.getInstance().bb;return b})};
Pca=function(a,b){if(g.v(b)){if(1==a)var c=Sk.g;else if(2==a)c=Sk.l;else return;var d=g.Ia(c,function(c){return c.re()!=a?!1:c.jc==b});
0<=d&&(ok(c[d]),g.Pa(c,d))}};
Rca=function(a,b,c,d){if(a.A)var e=Rk(Sk,b);else e=g.Ja(Sk.g,function(a){return a.element===c}),null!==e&&e.jc!==b&&(a.Wi(e),e=null);
e||(e=Qca(a,c,b),e.A=Hl(a),d&&(e.qg=d));return e};
Qca=function(a,b,c){b=a.cn(b,ji(),!1,c);b.Dp=(0,g.z)(a.Yo,a);0==Sk.l.length&&(Vi.getInstance().o=79463069);wca([b]);dl();return b};
Sca=function(a,b){b.G=0;for(var c in Ml)null==a[c]&&(b.G|=Ml[c]);Nl(a,"currentTime");Nl(a,"duration")};
Tca=function(a){(0,g.C)(Sk.g,function(b){3==b.wc&&a.Wi(b)})};
Nl=function(a,b){var c=a[b];g.t(c)&&0<c&&(a[b]=Math.floor(1E3*c))};
Ll=function(){var a=fj.getInstance(),b={};return b.sv="682",b["if"]=a.l?"1":"0",b.nas=String(Sk.g.length),b};
Uca=function(){this.g=void 0;this.l=!1;this.o=0;this.A=-1;this.B="tos"};
Wca=function(a){try{var b=a.split(",");return b.length>g.Kb(Vca).length?null:Aj(b,function(a,b){var c=b.toLowerCase().split("=");if(2!=c.length||!g.t(Ol[c[0]])||!Ol[c[0]](c[1]))throw Error("Entry ("+c[0]+", "+c[1]+") is invalid.");a[c[0]]=c[1];return a},{})}catch(c){return null}};
Xca=function(a,b){if(void 0==a.g)return 0;switch(a.B){case "mtos":return a.l?Qj(b.l,a.g):Qj(b.g,a.g);case "tos":return a.l?Oj(b.l,a.g):Oj(b.g,a.g)}return 0};
Pl=function(a,b,c,d){Ak.call(this,b,d);this.Ga=a;this.C=c};
Ql=function(a){Ak.call(this,"fully_viewable_audible_half_duration_impression",a)};
Rl=function(a){return!a||"function"!==typeof a||0>String(Function.prototype.toString).indexOf("[native code]")?!1:0<=String(a).indexOf("[native code]")&&!0||!1};
Tl=function(a){return!!(1<<a&Sl)};
bda=function(){try{Yca()}catch(d){}var a="a=1&b="+Sl+"&",b=[],c=99;(0,g.C)(Zca,function(a,c){var d=!1;try{d=a(Wh)}catch(k){}b[c/32>>>0]|=d<<c%32});
(0,g.C)(b,function(b,e){a+=String.fromCharCode(c+e)+"="+(b>>>0).toString(16)+"&"});
c=105;(0,g.C)($ca,function(b){var d="false";try{d=b(Wh)}catch(f){}a+=String.fromCharCode(c++)+"="+d+"&"});
(0,g.C)(ada,function(b){var d="";try{var f=b(Wh);d=g.Ud(g.Pd(f),!0)}catch(k){}a+=String.fromCharCode(c++)+"="+d+"&"});
return a.slice(0,-1)};
Yca=function(){if(!Ul){var a=function(){Vl=!0;Wh.document.removeEventListener("webdriver-evaluate",a,!0)};
Wh.document.addEventListener("webdriver-evaluate",a,!0);var b=function(){Wl=!0;Wh.document.removeEventListener("webdriver-evaluate-response",b,!0)};
Wh.document.addEventListener("webdriver-evaluate-response",b,!0);Ul=!0}};
Xl=function(){this.l=64;this.g=Array(4);this.B=Array(this.l);this.A=this.o=0;this.reset()};
Yl=function(a,b,c){c||(c=0);var d=Array(16);if(g.v(b))for(var e=0;16>e;++e)d[e]=b.charCodeAt(c++)|b.charCodeAt(c++)<<8|b.charCodeAt(c++)<<16|b.charCodeAt(c++)<<24;else for(e=0;16>e;++e)d[e]=b[c++]|b[c++]<<8|b[c++]<<16|b[c++]<<24;b=a.g[0];c=a.g[1];e=a.g[2];var f=a.g[3];var k=b+(f^c&(e^f))+d[0]+3614090360&4294967295;b=c+(k<<7&4294967295|k>>>25);k=f+(e^b&(c^e))+d[1]+3905402710&4294967295;f=b+(k<<12&4294967295|k>>>20);k=e+(c^f&(b^c))+d[2]+606105819&4294967295;e=f+(k<<17&4294967295|k>>>15);k=c+(b^e&(f^
b))+d[3]+3250441966&4294967295;c=e+(k<<22&4294967295|k>>>10);k=b+(f^c&(e^f))+d[4]+4118548399&4294967295;b=c+(k<<7&4294967295|k>>>25);k=f+(e^b&(c^e))+d[5]+1200080426&4294967295;f=b+(k<<12&4294967295|k>>>20);k=e+(c^f&(b^c))+d[6]+2821735955&4294967295;e=f+(k<<17&4294967295|k>>>15);k=c+(b^e&(f^b))+d[7]+4249261313&4294967295;c=e+(k<<22&4294967295|k>>>10);k=b+(f^c&(e^f))+d[8]+1770035416&4294967295;b=c+(k<<7&4294967295|k>>>25);k=f+(e^b&(c^e))+d[9]+2336552879&4294967295;f=b+(k<<12&4294967295|k>>>20);k=e+
(c^f&(b^c))+d[10]+4294925233&4294967295;e=f+(k<<17&4294967295|k>>>15);k=c+(b^e&(f^b))+d[11]+2304563134&4294967295;c=e+(k<<22&4294967295|k>>>10);k=b+(f^c&(e^f))+d[12]+1804603682&4294967295;b=c+(k<<7&4294967295|k>>>25);k=f+(e^b&(c^e))+d[13]+4254626195&4294967295;f=b+(k<<12&4294967295|k>>>20);k=e+(c^f&(b^c))+d[14]+2792965006&4294967295;e=f+(k<<17&4294967295|k>>>15);k=c+(b^e&(f^b))+d[15]+1236535329&4294967295;c=e+(k<<22&4294967295|k>>>10);k=b+(e^f&(c^e))+d[1]+4129170786&4294967295;b=c+(k<<5&4294967295|
k>>>27);k=f+(c^e&(b^c))+d[6]+3225465664&4294967295;f=b+(k<<9&4294967295|k>>>23);k=e+(b^c&(f^b))+d[11]+643717713&4294967295;e=f+(k<<14&4294967295|k>>>18);k=c+(f^b&(e^f))+d[0]+3921069994&4294967295;c=e+(k<<20&4294967295|k>>>12);k=b+(e^f&(c^e))+d[5]+3593408605&4294967295;b=c+(k<<5&4294967295|k>>>27);k=f+(c^e&(b^c))+d[10]+38016083&4294967295;f=b+(k<<9&4294967295|k>>>23);k=e+(b^c&(f^b))+d[15]+3634488961&4294967295;e=f+(k<<14&4294967295|k>>>18);k=c+(f^b&(e^f))+d[4]+3889429448&4294967295;c=e+(k<<20&4294967295|
k>>>12);k=b+(e^f&(c^e))+d[9]+568446438&4294967295;b=c+(k<<5&4294967295|k>>>27);k=f+(c^e&(b^c))+d[14]+3275163606&4294967295;f=b+(k<<9&4294967295|k>>>23);k=e+(b^c&(f^b))+d[3]+4107603335&4294967295;e=f+(k<<14&4294967295|k>>>18);k=c+(f^b&(e^f))+d[8]+1163531501&4294967295;c=e+(k<<20&4294967295|k>>>12);k=b+(e^f&(c^e))+d[13]+2850285829&4294967295;b=c+(k<<5&4294967295|k>>>27);k=f+(c^e&(b^c))+d[2]+4243563512&4294967295;f=b+(k<<9&4294967295|k>>>23);k=e+(b^c&(f^b))+d[7]+1735328473&4294967295;e=f+(k<<14&4294967295|
k>>>18);k=c+(f^b&(e^f))+d[12]+2368359562&4294967295;c=e+(k<<20&4294967295|k>>>12);k=b+(c^e^f)+d[5]+4294588738&4294967295;b=c+(k<<4&4294967295|k>>>28);k=f+(b^c^e)+d[8]+2272392833&4294967295;f=b+(k<<11&4294967295|k>>>21);k=e+(f^b^c)+d[11]+1839030562&4294967295;e=f+(k<<16&4294967295|k>>>16);k=c+(e^f^b)+d[14]+4259657740&4294967295;c=e+(k<<23&4294967295|k>>>9);k=b+(c^e^f)+d[1]+2763975236&4294967295;b=c+(k<<4&4294967295|k>>>28);k=f+(b^c^e)+d[4]+1272893353&4294967295;f=b+(k<<11&4294967295|k>>>21);k=e+(f^
b^c)+d[7]+4139469664&4294967295;e=f+(k<<16&4294967295|k>>>16);k=c+(e^f^b)+d[10]+3200236656&4294967295;c=e+(k<<23&4294967295|k>>>9);k=b+(c^e^f)+d[13]+681279174&4294967295;b=c+(k<<4&4294967295|k>>>28);k=f+(b^c^e)+d[0]+3936430074&4294967295;f=b+(k<<11&4294967295|k>>>21);k=e+(f^b^c)+d[3]+3572445317&4294967295;e=f+(k<<16&4294967295|k>>>16);k=c+(e^f^b)+d[6]+76029189&4294967295;c=e+(k<<23&4294967295|k>>>9);k=b+(c^e^f)+d[9]+3654602809&4294967295;b=c+(k<<4&4294967295|k>>>28);k=f+(b^c^e)+d[12]+3873151461&4294967295;
f=b+(k<<11&4294967295|k>>>21);k=e+(f^b^c)+d[15]+530742520&4294967295;e=f+(k<<16&4294967295|k>>>16);k=c+(e^f^b)+d[2]+3299628645&4294967295;c=e+(k<<23&4294967295|k>>>9);k=b+(e^(c|~f))+d[0]+4096336452&4294967295;b=c+(k<<6&4294967295|k>>>26);k=f+(c^(b|~e))+d[7]+1126891415&4294967295;f=b+(k<<10&4294967295|k>>>22);k=e+(b^(f|~c))+d[14]+2878612391&4294967295;e=f+(k<<15&4294967295|k>>>17);k=c+(f^(e|~b))+d[5]+4237533241&4294967295;c=e+(k<<21&4294967295|k>>>11);k=b+(e^(c|~f))+d[12]+1700485571&4294967295;b=c+
(k<<6&4294967295|k>>>26);k=f+(c^(b|~e))+d[3]+2399980690&4294967295;f=b+(k<<10&4294967295|k>>>22);k=e+(b^(f|~c))+d[10]+4293915773&4294967295;e=f+(k<<15&4294967295|k>>>17);k=c+(f^(e|~b))+d[1]+2240044497&4294967295;c=e+(k<<21&4294967295|k>>>11);k=b+(e^(c|~f))+d[8]+1873313359&4294967295;b=c+(k<<6&4294967295|k>>>26);k=f+(c^(b|~e))+d[15]+4264355552&4294967295;f=b+(k<<10&4294967295|k>>>22);k=e+(b^(f|~c))+d[6]+2734768916&4294967295;e=f+(k<<15&4294967295|k>>>17);k=c+(f^(e|~b))+d[13]+1309151649&4294967295;
c=e+(k<<21&4294967295|k>>>11);k=b+(e^(c|~f))+d[4]+4149444226&4294967295;b=c+(k<<6&4294967295|k>>>26);k=f+(c^(b|~e))+d[11]+3174756917&4294967295;f=b+(k<<10&4294967295|k>>>22);k=e+(b^(f|~c))+d[2]+718787259&4294967295;e=f+(k<<15&4294967295|k>>>17);k=c+(f^(e|~b))+d[9]+3951481745&4294967295;a.g[0]=a.g[0]+b&4294967295;a.g[1]=a.g[1]+(e+(k<<21&4294967295|k>>>11))&4294967295;a.g[2]=a.g[2]+e&4294967295;a.g[3]=a.g[3]+f&4294967295};
Zl=function(){this.l=null};
$l=function(a){return function(b){var c=new Xl;c.update(b+a);return Naa(c.digest()).slice(-8)}};
am=function(a,b){this.l=a;this.o=b};
cda=function(a){var b=pl(a)?"custom_metric_viewable":a;a=Ob(Lk,function(a){return a==b});
return nl[a]};
bm=function(a,b,c){am.call(this,a,b);this.A=c};
cm=function(a,b){this.g=a;this.depth=b};
dm=function(a){function b(a,b){return null==a?b:a}
a=a||ri();var c=Math.max(a.length-1,0),d=ti(a);a=d.g;var e=d.l,f=d.o,k=[];f&&k.push(new cm([f.url,f.rp?2:0],b(f.depth,1)));e&&e!=f&&k.push(new cm([e.url,2],0));a.url&&a!=f&&k.push(new cm([a.url,0],b(a.depth,c)));d=(0,g.E)(k,function(a,b){return k.slice(0,k.length-b)});
!a.url||(f||e)&&a!=f||(e=pba(a.url))&&d.push([new cm([e,1],b(a.depth,c))]);d.push([]);return(0,g.E)(d,function(a){return dda(c,a)})};
dda=function(a,b){(0,g.em)(b,function(a){return 0<=a.depth});
var c=Aj(b,function(a,b){return Math.max(a,b.depth)},-1),d=laa(c+2);
d[0]=a;(0,g.C)(b,function(a){return d[a.depth+1]=a.g});
return d};
fm=function(){var a=dm();return(0,g.E)(a,function(a){return wi(a)})};
gm=function(){Bl.call(this);this.G=void 0;this.H=null;this.C=!1;this.F={};this.o=new Zl};
hm=function(){var a=gm.getInstance(),b="h"==Hl(a)||"b"==Hl(a),c="exc"!=Vi.getInstance().bb;b&&c&&(a.C=!0,a.H=new oca)};
eda=function(a,b,c){c=c.opt_configurable_tracking_events;if(null!=a.g&&g.ya(c)){var d=a.g;vba(c);(0,g.C)(c,function(a){var c=(0,g.E)(a.VQ,function(a){var b=Wca(a);if(null==b)a=null;else if(a=new Uca,null!=b.visible&&(a.g=b.visible/100),null!=b.audible&&(a.l=1==b.audible),null!=b.time){var c="mtos"==b.timetype?"mtos":"tos",d=gb(b.time,"%")?"%":"ms";b=(0,window.parseInt)(b.time,10);"%"==d&&(b/=100);"ms"==d?(a.o=b,a.A=-1):(a.o=-1,a.A=b);a.B=void 0===c?"tos":c}return a});
(0,g.rj)(c,function(a){return null==a})||ica(b,new Pl(a.id,a.event,c,d))})}};
fda=function(a,b,c){var d=Rk(Sk,b);d||(d=c.opt_nativeTime||-1,d=Cl(a,b,Hl(a),d),c.opt_osdId&&(d.qg=c.opt_osdId));return d};
gda=function(a,b,c){var d=Rk(Sk,b);d||(d=Cl(a,b,"n",c.opt_nativeTime||-1),d.Ca=fj.getInstance().L);return d};
hda=function(a,b){var c=Rk(Sk,b);c||(c=Cl(a,b,"h",-1));return c};
ida=function(a){var b=Vi.getInstance();switch(Hl(a)){case "b":return"ytads.bulleit.triggerExternalActivityEvent";case "n":return"ima.bridge.triggerExternalActivityEvent";case "h":if("exc"==b.bb)return"ima.bridge.triggerExternalActivityEvent";case "m":case "ml":return"ima.common.triggerExternalActivityEvent"}return null};
jm=function(a,b,c,d){c=void 0===c?{}:c;var e={};g.Zb(e,{opt_adElement:void 0,opt_fullscreen:void 0},c);if(e.opt_bounds)return a.o.g(ol("ol",d));if(g.t(d))if(c=ml(d),g.t(c))if(El)b=ol("ue",d);else if(b=a.Ol(b,e))if(a.A&&3==b.wc)b="stopped";else{b:{Nca(a);"i"==Fl&&(b.Uh=!0,a.wr(b));c=e.opt_fullscreen;g.t(c)&&jk(b,!!c);ob(g.zb,"CrKey")||ob(g.zb,"PlayStation")||ob(g.zb,"Roku")||Eca()||ob(g.zb,"Xbox")?c=!1:(c=Vi.getInstance().bb,c=Wh&&Fj(Wh)||"nis"===c||"gsv"===c?!1:0===Yi(Zh));var f=c;if(f){switch(b.re()){case 1:Jl(a,
b,"pv");break;case 2:a.mr(b)}Gl("pv")}c=d.toLowerCase();!f&&g.Ma(jda,c)&&Oca(a,b,e);0!=b.wc&&g.Ma(kda,c)&&!b.Uh&&!a.B&&b.Ej&&(f=b.Ej,f.g||(f.g=Bk(f,b)));(f=b.wh[c])&&vk(b.gc,f);switch(b.re()){case 1:var k=pl(c)?a.J.custom_metric_viewable:a.J[c];break;case 2:k=a.O[c]}if(k&&(d=k.call(a,b,e,d),g.t(d))){e=ol(void 0,c);g.Zb(e,d);d=e;break b}d=void 0}3==b.wc&&(a.A?ok(b):a.Wi(b));b=d}else b=ol("nf",d);else b=void 0;else El?b=ol("ue"):(b=a.Ol(b,e))?(d=ol(),g.Zb(d,Mk(b,!0,!1,!1)),b=d):b=ol("nf");return g.v(b)?
a.A&&"stopped"===b?im:a.o.g(void 0):a.o.g(b)};
lm=function(a,b){var c;if(b.qg&&km(a)){var d=a.F[b.qg];d?c=function(a,b){d.o(a,b)}:null!==d&&Ti("lidar::missingPlayerCallback",Error())}else c=g.y("ima.common.triggerViewabilityMeasurementUpdate");
if(g.Aa(c)){var e=jca(b);e.nativeVolume=a.G;c(b.jc,e)}};
km=function(a){return"exc"==Vi.getInstance().bb||"h"!=Hl(a)&&Hl(a),!1};
mm=function(a){var b={};return b.viewability=a.g,b.googleViewability=a.o,b.moatInit=a.B,b.moatViewability=a.C,b.integralAdsViewability=a.A,b.doubleVerifyViewability=a.l,b};
nm=function(a,b,c){c=void 0===c?{}:c;a=jm(gm.getInstance(),b,c,a);return mm(a)};
om=function(a){if(!a)return"";a=a.split("#")[0].split("?")[0];a=a.toLowerCase();0==a.indexOf("//")&&(a=window.location.protocol+a);/^[\w\-]*:\/\//.test(a)||(a=window.location.href);var b=a.substring(a.indexOf("://")+3),c=b.indexOf("/");-1!=c&&(b=b.substring(0,c));a=a.substring(0,a.indexOf("://"));if("http"!==a&&"https"!==a&&"chrome-extension"!==a&&"file"!==a&&"android-app"!==a&&"chrome-search"!==a&&"app"!==a)throw Error("Invalid URI scheme in origin: "+a);c="";var d=b.indexOf(":");if(-1!=d){var e=
b.substring(d+1);b=b.substring(0,d);if("http"===a&&"80"!==e||"https"===a&&"443"!==e)c=":"+e}return a+"://"+b+c};
lda=function(){function a(){e[0]=1732584193;e[1]=4023233417;e[2]=2562383102;e[3]=271733878;e[4]=3285377520;p=n=0}
function b(a){for(var b=k,c=0;64>c;c+=4)b[c/4]=a[c]<<24|a[c+1]<<16|a[c+2]<<8|a[c+3];for(c=16;80>c;c++)a=b[c-3]^b[c-8]^b[c-14]^b[c-16],b[c]=(a<<1|a>>>31)&4294967295;a=e[0];var d=e[1],f=e[2],l=e[3],m=e[4];for(c=0;80>c;c++){if(40>c)if(20>c){var n=l^d&(f^l);var p=1518500249}else n=d^f^l,p=1859775393;else 60>c?(n=d&f|l&(d|f),p=2400959708):(n=d^f^l,p=3395469782);n=((a<<5|a>>>27)&4294967295)+n+m+p+b[c]&4294967295;m=l;l=f;f=(d<<30|d>>>2)&4294967295;d=a;a=n}e[0]=e[0]+a&4294967295;e[1]=e[1]+d&4294967295;e[2]=
e[2]+f&4294967295;e[3]=e[3]+l&4294967295;e[4]=e[4]+m&4294967295}
function c(a,c){if("string"===typeof a){a=(0,window.unescape)((0,window.encodeURIComponent)(a));for(var d=[],e=0,k=a.length;e<k;++e)d.push(a.charCodeAt(e));a=d}c||(c=a.length);d=0;if(0==n)for(;d+64<c;)b(a.slice(d,d+64)),d+=64,p+=64;for(;d<c;)if(f[n++]=a[d++],p++,64==n)for(n=0,b(f);d+64<c;)b(a.slice(d,d+64)),d+=64,p+=64}
function d(){var a=[],d=8*p;56>n?c(l,56-n):c(l,64-(n-56));for(var k=63;56<=k;k--)f[k]=d&255,d>>>=8;b(f);for(k=d=0;5>k;k++)for(var m=24;0<=m;m-=8)a[d++]=e[k]>>m&255;return a}
for(var e=[],f=[],k=[],l=[128],m=1;64>m;++m)l[m]=0;var n,p;a();return{reset:a,update:c,digest:d,aC:function(){for(var a=d(),b="",c=0;c<a.length;c++)b+="0123456789ABCDEF".charAt(Math.floor(a[c]/16))+"0123456789ABCDEF".charAt(a[c]%16);return b}}};
mda=function(a,b,c){var d=[],e=[];if(1==(g.ya(c)?2:1))return e=[b,a],(0,g.C)(d,function(a){e.push(a)}),pm(e.join(" "));
var f=[],k=[];(0,g.C)(c,function(a){k.push(a.key);f.push(a.value)});
c=Math.floor((new Date).getTime()/1E3);e=0==f.length?[c,b,a]:[f.join(":"),c,b,a];(0,g.C)(d,function(a){e.push(a)});
a=pm(e.join(" "));a=[c,a];0==k.length||a.push(k.join(""));return a.join("_")};
pm=function(a){var b=lda();b.update(a);return b.aC().toLowerCase()};
g.qm=function(){var a=[],b=om(String(g.w.location.href)),c=g.w.__OVERRIDE_SID;null==c&&(c=(new tg(window.document)).get("SID"));if(c&&(b=(c=0==b.indexOf("https:")||0==b.indexOf("chrome-extension:"))?g.w.__SAPISID:g.w.__APISID,null==b&&(b=(new tg(window.document)).get(c?"SAPISID":"APISID")),b)){c=c?"SAPISIDHASH":"APISIDHASH";var d=String(g.w.location.href);return d&&b&&c?[c,mda(om(d),b,a||null)].join(" "):null}return null};
g.rm=function(a,b){this.l={};this.g=[];this.wg=this.Ba=0;var c=arguments.length;if(1<c){if(c%2)throw Error("Uneven number of arguments");for(var d=0;d<c;d+=2)this.set(arguments[d],arguments[d+1])}else if(a)if(a instanceof g.rm)for(c=a.Hd(),d=0;d<c.length;d++)this.set(c[d],a.get(c[d]));else for(d in a)this.set(d,a[d])};
tm=function(a){if(a.Ba!=a.g.length){for(var b=0,c=0;b<a.g.length;){var d=a.g[b];sm(a.l,d)&&(a.g[c++]=d);b++}a.g.length=c}if(a.Ba!=a.g.length){var e={};for(c=b=0;b<a.g.length;)d=a.g[b],sm(e,d)||(a.g[c++]=d,e[d]=1),b++;a.g.length=c}};
sm=function(a,b){return Object.prototype.hasOwnProperty.call(a,b)};
g.um=function(a,b){this.g=this.G=this.A="";this.B=null;this.C=this.l="";this.F=!1;var c;a instanceof g.um?(this.F=g.t(b)?b:a.F,g.vm(this,a.A),this.G=a.G,g.wm(this,a.g),g.xm(this,a.B),this.l=a.l,ym(this,a.o.clone()),this.C=a.C):a&&(c=g.wg(String(a)))?(this.F=!!b,g.vm(this,c[1]||"",!0),this.G=zm(c[2]||""),g.wm(this,c[3]||"",!0),g.xm(this,c[4]),this.l=zm(c[5]||"",!0),ym(this,c[6]||"",!0),this.C=zm(c[7]||"")):(this.F=!!b,this.o=new g.Am(null,this.F))};
g.vm=function(a,b,c){a.A=c?zm(b,!0):b;a.A&&(a.A=a.A.replace(/:$/,""))};
g.wm=function(a,b,c){a.g=c?zm(b,!0):b;return a};
g.xm=function(a,b){if(b){b=Number(b);if((0,window.isNaN)(b)||0>b)throw Error("Bad port number "+b);a.B=b}else a.B=null;return a};
ym=function(a,b,c){b instanceof g.Am?(a.o=b,nda(a.o,a.F)):(c||(b=Bm(b,oda)),a.o=new g.Am(b,a.F))};
g.Cm=function(a,b,c){a.o.set(b,c);return a};
g.Dm=function(a){return a instanceof g.um?a.clone():new g.um(a,void 0)};
zm=function(a,b){return a?b?(0,window.decodeURI)(a.replace(/%25/g,"%2525")):(0,window.decodeURIComponent)(a):""};
Bm=function(a,b,c){return g.v(a)?(a=(0,window.encodeURI)(a).replace(b,pda),c&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null};
pda=function(a){a=a.charCodeAt(0);return"%"+(a>>4&15).toString(16)+(a&15).toString(16)};
g.Am=function(a,b){this.Ba=this.g=null;this.l=a||null;this.o=!!b};
Em=function(a){a.g||(a.g=new g.rm,a.Ba=0,a.l&&Ag(a.l,function(b,c){a.add(kb(b),c)}))};
Gm=function(a,b){Em(a);b=Fm(a,b);return sm(a.g.l,b)};
g.Hm=function(a,b,c){a.remove(b);0<c.length&&(a.l=null,a.g.set(Fm(a,b),g.Ta(c)),a.Ba=a.Ba+c.length)};
Fm=function(a,b){var c=String(b);a.o&&(c=c.toLowerCase());return c};
nda=function(a,b){b&&!a.o&&(Em(a),a.l=null,a.g.forEach(function(a,b){var c=b.toLowerCase();b!=c&&(this.remove(b),g.Hm(this,c,a))},a));
a.o=b};
g.Im=function(a){g.G.call(this);this.l=a;this.g={}};
Jm=function(a,b,c,d,e,f){if(g.ya(c))for(var k=0;k<c.length;k++)Jm(a,b,c[k],d,e,f);else{b=hf(b,c,d||a.handleEvent,e,f||a.l||a);if(!b)return a;a.g[b.key]=b}return a};
g.Km=function(a){g.Bb(a.g,function(a,c){this.g.hasOwnProperty(c)&&g.sf(a)},a);
a.g={}};
g.Lm=function(a,b){return a.replace(qda,function(a,d){try{var c=Tb(b,d);if(null==c)return a;c=c.toString();if(""==c||!g.ib(g.qb(c)))return(0,window.encodeURIComponent)(c).replace(/%2C/g,",")}catch(f){}return a})};
Mm=function(a){g.Ze.call(this,a)};
rda=function(a){this.g=a};
sda=function(){var a=Nm();a:{if(Mb(a.g,"disableExperiments")&&(a=a.g.disableExperiments,g.sa(a)))break a;a=!1}return a};
tda=function(a){if(Mb(a.g,"forceExperimentIds")){a=a.g.forceExperimentIds;var b=[],c=0;g.ya(a)&&(0,g.C)(a,function(a){g.ta(a)&&(b[c++]=a)});
return b}return null};
Om=function(){this.A=!1;this.l=!0;this.o=null;try{dm(void 0)}catch(a){}};
Nm=function(){var a=Pm;if(null==a.o){var b={};var c=(new g.um(sd().location.href)).o;if(Gm(c,"tcnfp"))try{b=JSON.parse(c.get("tcnfp"))}catch(d){}a.o=new rda(b)}return a.o};
Qm=function(a,b,c){this.Ga=a;this.g=g.Uc(b||0,0,1);this.l=null!=c?c:!0};
Rm=function(a){this.Ga=a;this.l=new g.rm;this.g=null};
uda=function(a){var b=Math.random(),c=0,d=a.l.uc();(0,g.C)(d,function(a){c+=a.g},a);
var e=1<c?c:1;a.g=null;for(var f=0,k=0;k<d.length;++k)if(f+=d[k].g,f/e>=b){a.g=d[k];break}};
xda=function(){this.l=null!=g.w.G_testRunner;this.g=new g.rm;Pm.g()||(Sm(this,"GvnExternalLayer",31061774,.01),Sm(this,"GvnExternalLayer",31061775,.01),Sm(this,"GvnExternalLayer",41351088,.01),Sm(this,"GvnExternalLayer",41351089,.01),Sm(this,"GvnExternalLayer",420706008,.05),Sm(this,"GvnExternalLayer",420706009,.05),Sm(this,"GvnExternalLayer",41351073,.01),Sm(this,"GvnExternalLayer",41351074,.01),Sm(this,"GvnExternalLayer",41351075,.01),Sm(this,"GvnExternalLayer",634360101,0),Sm(this,"GvnExternalLayer",
634360102,0),Sm(this,"GvnExternalLayer",21592080,.1),Sm(this,"GvnExternalLayer",21592081,.1),Sm(this,"GvnExternalLayer",413051059,.05),Sm(this,"GvnExternalLayer",413051060,.05),Sm(this,"GvnExternalLayer",324123E3,.05),Sm(this,"GvnExternalLayer",324123001,.05),Sm(this,"GvnExternalLayer",420706068,.01),Sm(this,"GvnExternalLayer",420706069,.01),Sm(this,"GvnExternalLayer",324123020,.01),Sm(this,"GvnExternalLayer",324123021,.01));Sm(this,"ActiveViewExternalLayer",953563515,.01);Sm(this,"ActiveViewExternalLayer",
953563516,.01);Sm(this,"ActiveViewExternalLayer",953563517,.01);vda(this);var a=Nm();a=tda(a);null!=a&&(this.l=!1,wda(this,a.map(String)))};
Um=function(){Tm||(Tm=new xda);return Tm};
Sm=function(a,b,c,d){g.ib(g.qb(b))||(0,window.isNaN)(c)||0>=c||(c=new Qm(c,d),Vm(a,b).l.set(c.getId(),c))};
vda=function(a){sda()||(0,g.C)(a.g.uc(),function(a){uda(a)},a)};
wda=function(a,b){(0,g.C)(b,function(a){var b=Number(a);a="FORCED_PUB_EXP_LAYER_"+a;(0,window.isNaN)(b)||0>=b||g.ib(g.qb(a))||(Vm(this,a).g=new Qm(b,0,!0))},a)};
Wm=function(a,b){return a.l?!1:(0,g.rj)(a.g.uc(),function(a){return!!a.g&&a.g.getId()==b})};
yda=function(){var a=Um();if(a.l)return"";var b=[];(0,g.C)(a.g.uc(),function(a){(a=a.g)&&a.l&&b.push(a.getId())});
return b.sort().join(",")};
Vm=function(a,b){var c=a.g.get(b);null==c&&(c=new Rm(b),a.g.set(b,c));return c};
Bda=function(a){try{var b=(new g.um(a)).g;b=b.replace(/^www./i,"");return(0,g.rj)(zda,function(a){return Ada(a,b)})}catch(c){return!1}};
Ada=function(a,b){if(g.ib(g.qb(b)))return!1;a=a.toLowerCase();b=b.toLowerCase();return"*."==a.substr(0,2)?(a=a.substr(2),a.length>b.length?!1:b.substr(-a.length)==a&&(b.length==a.length||"."==b.charAt(b.length-a.length-1))):a==b};
Xm=function(a,b){return(new RegExp("^https?://([a-z0-9-]{1,63}\\.)*("+b.join("|").replace(/\./g,"\\.")+")(:[0-9]+)?([/?#]|$)","i")).test(a)};
Zm=function(a,b,c,d){null!=a&&null!=b&&(a=g.Lm(a,b));try{if(null!=c){b=a;var e=(c||{}).viewability||"na";if(g.ib(g.qb(e)))a=b;else{var f=new g.um(b);Gm(f.o,"label")?(g.Cm(f,"acvw",e),a=f.toString().replace(/%2C/g,",")):a=b}}a:{c=a;e=void 0;var k=c.length-11-2;if(!(-1==c.indexOf("URL_SIGNALS")||2048<=k||!e&&!window.Goog_AdSense_Lidar_getUrlSignalsArray))for(e=e||window.Goog_AdSense_Lidar_getUrlSignalsArray(),k={},f=0;f<e.length;++f){k.URL_SIGNALS=e[f];var l=g.Lm(c,k);if(2048>l.length){a=l;break a}}a=
c}}catch(u){}try{l=a;k=!1;Xm(l,Cda)?k=!1:null!=l&&Bda(l)?k=!0:"https:"==window.location.protocol&&(Xm(l,Dda)||Pm.g())&&(k=!0);if(k){var m=new g.um(l);"https"==m.A?a=l:(g.vm(m,"https"),a=m.toString())}else a=l;var n=Um(),p=!Pm.g()||Wm(n,41351089);m=!1;Pm.g()||!Wm(Um(),634360102)||(m=!0);null!=d&&d?Ym.wz(a,p):Pm.l?Ym.MM(a,p,m):Ym.vz(a,p,m)}catch(u){}};
$m=function(a){return(a=a.exec(g.zb))?a[1]:""};
g.an=function(a){return 0<=g.ub(Eda,a)};
g.dn=function(a,b,c){g.ta(a)?(this.date=bn(a,b||0,c||1),cn(this,c||1)):g.Ba(a)?(this.date=bn(a.getFullYear(),a.getMonth(),a.getDate()),cn(this,a.getDate())):(this.date=new Date((0,g.D)()),a=this.date.getDate(),this.date.setHours(0),this.date.setMinutes(0),this.date.setSeconds(0),this.date.setMilliseconds(0),cn(this,a))};
bn=function(a,b,c){b=new Date(a,b,c);0<=a&&100>a&&b.setFullYear(b.getFullYear()-1900);return b};
cn=function(a,b){a.getDate()!=b&&a.date.setUTCHours(a.date.getUTCHours()+(a.getDate()<b?1:-1))};
en=function(){this.g=null;this.o="";this.l=null};
Fda=function(){var a="h."+fn.o;null!=fn.l&&(a+="/n."+fn.l,null!=fn.g&&(a+="/"+fn.g));return a};
gn=function(){this.g=.01>Math.random();this.l=Math.floor(4503599627370496*Math.random())};
Gda=function(a,b){b.id="ima_html5";var c=hn();b.c=a.l;b.domain=c.g;return b};
hn=function(){var a=sd(),b=window.document;return new g.um(a.parent==a?a.location.href:b.referrer)};
jn=function(){g.xf.call(this);new g.rm;this.ca=new g.Im(this);g.I(this,this.ca)};
ln=function(){null!=kn||(kn=new jn);return kn};
mn=function(a){if(a=a.match(/[\d]+/g))a.length=3};
nn=function(){g.xf.call(this);this.g=null;this.ca=new g.Im(this);g.I(this,this.ca);this.C=new g.rm;this.B=new g.rm;this.l=!1;this.o=null};
pn=function(){null!=on||(on=new nn);return on};
qn=function(a){if(g.Aa(window.Goog_AdSense_Lidar_getUrlSignalsArray)){var b={};b.pageSignals=window.Goog_AdSense_Lidar_getUrlSignalsArray();a.g.send("activityMonitor","pageSignals",b)}};
Hda=function(a,b,c){var d=b?a.B.get(b):Pm.B;a={};null!=c&&(a.fullscreen=c);c="";try{c=lba(function(){return d},a)}catch(e){c="sdktle;"+nb(e.name,12)+";"+nb(e.message,40)}return c};
g.rn=function(){};
g.sn=function(a,b){var c=a.g(b);return-1==(0==c?null:c)?"rtl":"ltr"};
un=function(a,b){var c="key_"+a+":"+b,d=tn[c];if(void 0===d||0>d)tn[c]=0;else if(0==d)throw Error('Encountered two active delegates with the same priority ("'+a+":"+b+'").');};
g.vn=function(a){if(a.classList)return a.classList;a=a.className;return g.v(a)&&a.match(/\S+/g)||[]};
g.wn=function(a,b){return a.classList?a.classList.contains(b):g.Ma(g.vn(a),b)};
g.J=function(a,b){a.classList?a.classList.add(b):g.wn(a,b)||(a.className+=0<a.className.length?" "+b:b)};
g.xn=function(a,b){if(a.classList)(0,g.C)(b,function(b){g.J(a,b)});
else{var c={};(0,g.C)(g.vn(a),function(a){c[a]=!0});
(0,g.C)(b,function(a){c[a]=!0});
a.className="";for(var d in c)a.className+=0<a.className.length?" "+d:d}};
g.yn=function(a,b){a.classList?a.classList.remove(b):g.wn(a,b)&&(a.className=(0,g.Bd)(g.vn(a),function(a){return a!=b}).join(" "))};
g.zn=function(a,b){a.classList?(0,g.C)(b,function(b){g.yn(a,b)}):a.className=(0,g.Bd)(g.vn(a),function(a){return!g.Ma(b,a)}).join(" ")};
g.K=function(a,b,c){c?g.J(a,b):g.yn(a,b)};
g.An=function(a,b){var c=!g.wn(a,b);g.K(a,b,c)};
Ida=function(){if(!g.pd)return!1;try{return new window.ActiveXObject("MSXML2.DOMDocument"),!0}catch(a){return!1}};
g.Bn=function(a){if("undefined"!=typeof window.DOMParser)return(new window.DOMParser).parseFromString(a,"application/xml");if(Jda){var b=new window.ActiveXObject("MSXML2.DOMDocument");b.resolveExternals=!1;b.validateOnParse=!1;try{b.setProperty("ProhibitDTD",!0),b.setProperty("MaxXMLSize",2048),b.setProperty("MaxElementDepth",256)}catch(c){}b.loadXML(a);return b}throw Error("Your browser does not support loading xml documents");};
g.Cn=function(){g.xf.call(this);this.g=0;this.endTime=this.startTime=null};
Kda=function(a,b){g.ya(b)||(b=[b]);var c=(0,g.E)(b,function(a){return g.v(a)?a:a.property+" "+a.duration+"s "+a.timing+" "+a.delay+"s"});
g.hh(a,"transition",c.join(","))};
Dn=function(a,b,c,d,e){g.Cn.call(this);this.l=a;this.F=b;this.H=c;this.B=d;this.G=g.ya(e)?e:[e]};
En=function(a,b,c,d){return new Dn(a,b,{opacity:c},{opacity:d},{property:"opacity",duration:b,timing:"ease-in",delay:0})};
g.Fn=function(a,b,c){g.G.call(this);this.Ga=null;this.o=!1;this.B=a;this.A=c;this.g=b||window;this.l=(0,g.z)(this.xC,this)};
Gn=function(a){a=a.g;return a.requestAnimationFrame||a.webkitRequestAnimationFrame||a.mozRequestAnimationFrame||a.oRequestAnimationFrame||a.msRequestAnimationFrame||null};
Hn=function(a){a=a.g;return a.cancelAnimationFrame||a.cancelRequestAnimationFrame||a.webkitCancelRequestAnimationFrame||a.mozCancelRequestAnimationFrame||a.oCancelRequestAnimationFrame||a.msCancelRequestAnimationFrame||null};
g.L=function(a,b,c){g.G.call(this);this.g=a;this.Uc=b||0;this.l=c;this.o=(0,g.z)(this.Mu,this)};
g.In=function(a,b){a.isActive()||a.start(b)};
g.Jn=function(a){a.stop();a.Mu()};
g.Kn=function(a){a.isActive()&&g.Jn(a)};
g.Ln=function(){};
g.Mn=function(a){return":"+(a.g++).toString(36)};
g.Nn=function(a){g.xf.call(this);this.T=a||g.fd();this.Ga=null;this.Qg=!1;this.l=null;this.B=void 0;this.C=this.G=this.H=null};
On=function(a,b){a.G&&(0,g.C)(a.G,b,void 0)};
Pn=function(a,b){this.type=a;this.label=b};
Qn=function(a){new Pn(a,1)};
Rn=function(a){new Pn(a,2)};
Sn=function(a){new Pn(a,3)};
Lda=function(a){if(g.w.JSON)try{return g.w.JSON.stringify(a)}catch(b){}return g.qg(a)};
g.Tn=function(a){if(g.w.JSON)try{return g.w.JSON.parse(a)}catch(b){}return cba(a)};
Un=function(){};
Vn=function(){};
Oda=function(a){var b=Mda++,c={PD:{id:b,mf:a.measure,context:void 0},VH:{id:b,mf:a.XQ,context:void 0},state:{},args:void 0,Zl:!1};return function(){0<arguments.length?(c.args||(c.args=[]),c.args.length=0,c.args.push.apply(c.args,arguments),c.args.push(c.state)):c.args&&0!=c.args.length?(c.args[0]=c.state,c.args.length=1):c.args=[c.state];c.Zl||(c.Zl=!0,Wn[Xn].push(c));Yn||(Yn=!0,window.requestAnimationFrame(Nda))}};
Nda=function(){Yn=!1;var a=Wn[Xn],b=a.length;Xn=(Xn+1)%2;for(var c,d=0;d<b;++d){c=a[d];var e=c.PD;c.Zl=!1;e.mf&&e.mf.apply(e.context,c.args)}for(d=0;d<b;++d)c=a[d],e=c.VH,c.Zl=!1,e.mf&&e.mf.apply(e.context,c.args),c.state={};a.length=0};
g.Zn=function(a,b,c,d,e,f,k,l){this.g=a;this.F=b;this.o=c;this.B=d;this.A=e;this.C=f;this.l=k;this.G=l};
g.$n=function(a,b){if(0==b)return a.g;if(1==b)return a.l;var c=g.Wc(a.g,a.o,b),d=g.Wc(a.o,a.A,b),e=g.Wc(a.A,a.l,b);c=g.Wc(c,d,b);d=g.Wc(d,e,b);return g.Wc(c,d,b)};
g.ao=function(a,b,c){this.A=a;this.B=b;this.g=this.o=a;this.C=c||0};
g.bo=function(a){a.g=Math.min(a.B,2*a.g);a.o=Math.min(a.B,a.g+(a.C?Math.round(a.C*(Math.random()-.5)*2*a.g):0));a.l++};
g.eo=function(a,b,c,d,e,f){a=a.clone();b=b.clone();var k=0;if(d||0!=c)c&4?a.x-=b.width+(d?d.right:0):c&2?a.x-=b.width/2:d&&(a.x+=d.left),c&1?a.y-=b.height+(d?d.bottom:0):d&&(a.y+=d.top);if(f){if(e){k=a;c=b;d=0;65==(f&65)&&(k.x<e.left||k.x>=e.right)&&(f&=-2);132==(f&132)&&(k.y<e.top||k.y>=e.bottom)&&(f&=-5);k.x<e.left&&f&1&&(k.x=e.left,d|=1);if(f&16){var l=k.x;k.x<e.left&&(k.x=e.left,d|=4);k.x+c.width>e.right&&(c.width=Math.min(e.right-k.x,l+c.width-e.left),c.width=Math.max(c.width,0),d|=4)}k.x+c.width>
e.right&&f&1&&(k.x=Math.max(e.right-c.width,e.left),d|=1);f&2&&(d|=(k.x<e.left?16:0)|(k.x+c.width>e.right?32:0));k.y<e.top&&f&4&&(k.y=e.top,d|=2);f&32&&(l=k.y,k.y<e.top&&(k.y=e.top,d|=8),k.y+c.height>e.bottom&&(c.height=Math.min(e.bottom-k.y,l+c.height-e.top),c.height=Math.max(c.height,0),d|=8));k.y+c.height>e.bottom&&f&4&&(k.y=Math.max(e.bottom-c.height,e.top),d|=2);f&8&&(d|=(k.y<e.top?64:0)|(k.y+c.height>e.bottom?128:0));e=d}else e=256;k=e}e=new g.Tg(0,0,0,0);e.left=a.x;e.top=a.y;e.width=b.width;
e.height=b.height;return{rect:e,status:k}};
g.fo=function(a){g.G.call(this);this.Tb=1;this.o=[];this.A=0;this.g=[];this.l={};this.B=!!a};
Pda=function(a,b,c){g.Jf(function(){a.apply(b,c)})};
g.go=function(a){this.g=a};
ho=function(a){this.g=a};
io=function(a){this.data=a};
jo=function(a){return!g.t(a)||a instanceof io?a:new io(a)};
ko=function(a){this.g=a};
g.lo=function(a){var b=a.creation;a=a.expiration;return!!a&&a<(0,g.D)()||!!b&&b>(0,g.D)()};
g.mo=function(a){this.g=a};
Qda=function(){};
no=function(){};
oo=function(a){this.g=a};
po=function(){var a=null;try{a=window.localStorage||null}catch(b){}this.g=a};
qo=function(){var a=null;try{a=window.sessionStorage||null}catch(b){}this.g=a};
so=function(a,b){this.l=a;this.g=null;if(g.pd&&!g.kc(9)){ro||(ro=new g.rm);this.g=ro.get(a);this.g||(b?this.g=window.document.getElementById(b):(this.g=window.document.createElement("userdata"),this.g.addBehavior("#default#userData"),window.document.body.appendChild(this.g)),ro.set(a,this.g));try{this.g.load(this.l)}catch(c){this.g=null}}};
to=function(a){return"_"+(0,window.encodeURIComponent)(a).replace(/[.!~*'()%]/g,function(a){return Rda[a]})};
uo=function(a){try{a.g.save(a.l)}catch(b){throw"Storage mechanism: Quota exceeded";}};
vo=function(a,b){this.l=a;this.g=b+"::"};
g.wo=function(a){var b=new po;return b.isAvailable()?a?new vo(b,a):b:null};
xo=function(a,b){this.Tb=a;this.g=b};
yo=function(a){this.g=[];if(a)a:{if(a instanceof yo){var b=a.Hd();a=a.uc();if(0>=this.g.length){for(var c=this.g,d=0;d<b.length;d++)c.push(new xo(b[d],a[d]));break a}}else b=g.Kb(a),a=g.Jb(a);for(d=0;d<b.length;d++)zo(this,b[d],a[d])}};
zo=function(a,b,c){var d=a.g;d.push(new xo(b,c));b=d.length-1;a=a.g;for(c=a[b];0<b;)if(d=b-1>>1,a[d].Tb>c.Tb)a[b]=a[d],b=d;else break;a[b]=c};
Ao=function(){yo.call(this)};
Sda=function(a){this.Ct=a};
Bo=function(a,b,c){this.A=a;this.l=b;this.g=c||[];this.Dh=new window.Map};
Co=function(a){Ie(this,a,Tda,null)};
Do=function(a){Ie(this,a,null,Uda)};
Eo=function(a){Ie(this,a,null,null)};
Fo=function(a){Ie(this,a,null,null)};
Go=function(a){Ie(this,a,Vda,null)};
Io=function(a){Ie(this,a,null,Ho)};
Ko=function(a){Ie(this,a,null,Jo)};
Lo=function(a){Ie(this,a,Wda,null)};
Mo=function(a){Ie(this,a,null,null)};
Zda=function(a,b){var c=Ne(a,Eo,1);null!=c&&Be(b,1,c,Xda);c=Ne(a,Fo,2);null!=c&&Be(b,2,c,Yda)};
Xda=function(a,b){var c=Je(a,1);null!=c&&Ae(b,1,c);c=Je(a,2);null!=c&&Ae(b,2,c);c=Je(a,3);null!=c&&ze(b,3,c)};
Yda=function(a,b){var c=Je(a,1);null!=c&&Ae(b,1,c);c=Je(a,2);null!=c&&Ae(b,2,c);c=Je(a,3);null!=c&&null!=c&&null!=c&&(ue(b,3,0),re(b.g,c));c=Je(a,4);null!=c&&ze(b,4,c)};
bea=function(a,b){var c=Pe(a,Io,1);0<c.length&&Ce(b,1,c,$da);c=Ne(a,Ko,2);null!=c&&Be(b,2,c,aea)};
$da=function(a,b){var c=Je(a,1);null!=c&&Ae(b,1,c);c=Je(a,2);null!=c&&null!=c&&null!=c&&(ue(b,2,0),re(b.g,c));c=Je(a,3);null!=c&&ze(b,3,c)};
aea=function(a,b){var c=Je(a,1);if(null!=c&&null!=c&&null!=c){ue(b,1,0);var d=b.g;$d(c);pe(d)}c=Je(a,2);null!=c&&null!=c&&(ue(b,2,1),d=b.g,ae(c),se(d,Yd),se(d,Zd));c=Ne(a,Lo,3);null!=c&&Be(b,3,c,cea)};
cea=function(a,b){var c=Pe(a,Mo,1);0<c.length&&Ce(b,1,c,dea)};
dea=function(a,b){var c=Je(a,1);if(null!=c&&null!=c){ue(b,1,1);var d=b.g;ae(c);se(d,Yd);se(d,Zd)}c=Je(a,2);null!=c&&null!=c&&null!=c&&(ue(b,2,0),d=b.g,$d(c),pe(d))};
No=function(a,b){Bo.call(this,a,3,b)};
Po=function(){this.J=new Oo;this.l=new window.Map;this.F=new window.Set;this.o=0;this.A=100;this.flushInterval=3E4;this.g=new g.jg(this.flushInterval);this.g.fa("tick",this.B,!1,this)};
eea=function(a){for(var b=0;b<a.length;b++)a[b].clear()};
Qo=function(){this.l=[];this.g=-1};
fea=function(a){-1==a.g&&(a.g=Aj(a.l,function(a,c,d){return c?a+Math.pow(2,d):a},0));
return a.g};
Ro=function(a,b){this.B=[];this.O=a;this.L=b||null;this.A=this.g=!1;this.o=void 0;this.H=this.T=this.F=!1;this.C=0;this.l=null;this.G=0};
To=function(a,b,c){a.g=!0;a.o=c;a.A=!b;So(a)};
Vo=function(a){if(a.g){if(!a.H)throw new Uo(a);a.H=!1}};
Wo=function(a,b,c){a.B.push([b,c,void 0]);a.g&&So(a)};
Xo=function(a){return(0,g.rj)(a.B,function(a){return g.Aa(a[1])})};
So=function(a){if(a.C&&a.g&&Xo(a)){var b=a.C,c=Yo[b];c&&(g.w.clearTimeout(c.Ga),delete Yo[b]);a.C=0}a.l&&(a.l.G--,delete a.l);b=a.o;for(var d=c=!1;a.B.length&&!a.F;){var e=a.B.shift(),f=e[0],k=e[1];e=e[2];if(f=a.A?k:f)try{var l=f.call(e||a.L,b);g.t(l)&&(a.A=a.A&&(l==b||a.isError(l)),a.o=b=l);if(Nf(b)||"function"===typeof g.w.Promise&&b instanceof g.w.Promise)d=!0,a.F=!0}catch(m){b=m,a.A=!0,Xo(a)||(c=!0)}}a.o=b;d&&(l=(0,g.z)(a.J,a,!0),d=(0,g.z)(a.J,a,!1),b instanceof Ro?(Wo(b,l,d),b.T=!0):b.then(l,
d));c&&(b=new Zo(b),Yo[b.Ga]=b,a.C=b.Ga)};
Uo=function(){Ga.call(this)};
$o=function(){Ga.call(this)};
Zo=function(a){this.Ga=g.w.setTimeout((0,g.z)(this.l,this),0);this.g=a};
ap=function(a){Ie(this,a,gea,null)};
bp=function(a){Ie(this,a,null,null)};
hea=function(a,b){for(;je(b)&&4!=b.l;)switch(b.o){case 1:var c=ne(b);Le(a,1,c);break;case 2:c=ne(b);Le(a,2,c);break;case 3:c=ne(b);Le(a,3,c);break;case 4:c=ne(b);Le(a,4,c);break;case 5:c=he(b.g);Le(a,5,c);break;default:ke(b)}return a};
g.dp=function(a){var b=arguments;if(1<b.length)g.cp[b[0]]=b[1];else{b=b[0];for(var c in b)g.cp[c]=b[c]}};
g.ep=function(a,b){return a in g.cp?g.cp[a]:b};
fp=function(){return g.y("yt.ads.biscotti.lastId_")||""};
gp=function(a){g.ua("yt.ads.biscotti.lastId_",a,void 0)};
ip=function(){var a=hp,b={};b.dt=iea;b.flash="0";a:{try{var c=a.g.top.location.href}catch(f){a=2;break a}a=c?c===a.l.location.href?0:1:2}b=(b.frm=a,b);b.u_tz=-(new Date).getTimezoneOffset();var d=void 0===d?Wh:d;try{var e=d.history.length}catch(f){e=0}b.u_his=e;b.u_java=!!Wh.navigator&&"unknown"!==typeof Wh.navigator.javaEnabled&&!!Wh.navigator.javaEnabled&&Wh.navigator.javaEnabled();Wh.screen&&(b.u_h=Wh.screen.height,b.u_w=Wh.screen.width,b.u_ah=Wh.screen.availHeight,b.u_aw=Wh.screen.availWidth,
b.u_cd=Wh.screen.colorDepth);Wh.navigator&&Wh.navigator.plugins&&(b.u_nplug=Wh.navigator.plugins.length);Wh.navigator&&Wh.navigator.mimeTypes&&(b.u_nmime=Wh.navigator.mimeTypes.length);return b};
jea=function(){var a=hp;var b=a.g;try{var c=b.screenX;var d=b.screenY}catch(m){}try{var e=b.outerWidth;var f=b.outerHeight}catch(m){}try{var k=b.innerWidth;var l=b.innerHeight}catch(m){}b=[b.screenLeft,b.screenTop,c,d,b.screen?b.screen.availWidth:void 0,b.screen?b.screen.availTop:void 0,e,f,k,l];c=ai(!1,a.g.top);d={};e=new Qo;g.w.SVGElement&&g.w.document.createElementNS&&e.set(0);f=sba();f["allow-top-navigation-by-user-activation"]&&e.set(1);f["allow-popups-to-escape-sandbox"]&&e.set(2);g.w.crypto&&
g.w.crypto.subtle&&e.set(3);e=fea(e);return d.bc=e,d.bih=c.height,d.biw=c.width,d.brdim=b.join(),d.vis=Yi(a.l),d.wgl=!!Wh.WebGLRenderingContext,d};
jp=function(a){return a&&window.yterr?function(){try{return a.apply(this,arguments)}catch(b){g.M(b)}}:a};
g.M=function(a,b,c,d,e){var f=g.y("yt.logging.errors.log");f?f(a,b,c,d,e):(f=g.ep("ERRORS",[]),f.push([a,b,c,d,e]),g.dp("ERRORS",f))};
g.kp=function(a){g.M(a,"WARNING",void 0,void 0,void 0)};
g.lp=function(a){return g.ep("EXPERIMENT_FLAGS",{})[a]};
kea=function(){if(!mp)return null;var a=mp();return"open"in a?a:null};
g.np=function(a){switch(a&&"status"in a?a.status:-1){case 200:case 201:case 202:case 203:case 204:case 205:case 206:case 304:return!0;default:return!1}};
g.op=function(a,b){g.Aa(a)&&(a=jp(a));return window.setTimeout(a,b)};
g.pp=function(a,b){g.Aa(a)&&(a=jp(a));return window.setInterval(a,b)};
g.qp=function(a){window.clearTimeout(a)};
g.rp=function(a){a=a.split("&");for(var b={},c=0,d=a.length;c<d;c++){var e=a[c].split("=");if(1==e.length&&e[0]||2==e.length){var f=kb(e[0]||"");e=kb(e[1]||"");f in b?g.ya(b[f])?Ua(b[f],e):b[f]=[b[f],e]:b[f]=e}}return b};
lea=function(a){var b=[];g.Bb(a,function(a,d){var c=g.jb(d),f;g.ya(a)?f=a:f=[a];(0,g.C)(f,function(a){""==a?b.push(c):b.push(c+"="+g.jb(a))})});
return b.join("&")};
g.sp=function(a){"?"==a.charAt(0)&&(a=a.substr(1));return g.rp(a)};
tp=function(a){a=a.split(",");return a=a.map(function(a){return g.sp(a)})};
g.up=function(a){return-1!=a.indexOf("?")?(a=(a||"").split("#")[0],a=a.split("?",2),g.sp(1<a.length?a[1]:a[0])):{}};
g.wp=function(a,b){return vp(a,b||{},!0)};
g.xp=function(a,b){return vp(a,b||{},!1)};
vp=function(a,b,c){var d=a.split("#",2);a=d[0];d=1<d.length?"#"+d[1]:"";var e=a.split("?",2);a=e[0];e=g.sp(e[1]||"");for(var f in b)if(c||!Mb(e,f))e[f]=b[f];return g.Ig(a,e)+d};
yp=function(a){if(!b)var b=window.location.href;var c=g.wg(a)[1]||null,d=g.yg(a);c&&d?(a=g.wg(a),b=g.wg(b),a=a[3]==b[3]&&a[1]==b[1]&&a[4]==b[4]):a=d?g.yg(b)==d&&g.zg(b)==g.zg(a):!0;return a};
zp=function(){if(!a)var a=window.document.location.href;a=g.wg(a)[1]||null;return null!==a&&"https"==a};
Ap=function(a){a=g.yg(a);a=null===a?null:a.split(".").reverse();return null===a?!1:"com"==a[0]&&a[1].match(/^youtube(?:kids|-nocookie)?$/)?!0:!1};
mea=function(a,b){b=void 0===b?{}:b;var c=yp(a),d=!!g.lp("web_ajax_ignore_global_headers_if_set"),e;for(e in Bp){var f=g.ep(Bp[e]);!f||!c&&!Cp(a,e)||d&&void 0!==b[e]||(b[e]=f)}if(c||Cp(a,"X-YouTube-Utc-Offset"))b["X-YouTube-Utc-Offset"]=-(new Date).getTimezoneOffset();g.lp("pass_biscotti_id_in_header_ajax")&&(c||Cp(a,"X-YouTube-Ad-Signals"))&&(c=void 0,c=void 0===c?fp():c,d=Object.assign(ip(),jea()),d.ca_type="image",c&&(d.bid=c),b["X-YouTube-Ad-Signals"]=lea(d));return b};
oea=function(a){var b=g.sp(window.location.search),c={};(0,g.C)(nea,function(a){b[a]&&(c[a]=b[a])});
return g.xp(a,c)};
Cp=function(a,b){var c=g.ep("CORS_HEADER_WHITELIST")||{},d=g.yg(a);return d?(c=c[d])?g.Ma(c,b):!1:!0};
pea=function(a,b){if(window.fetch&&"XML"!=b.format){var c={method:b.method||"GET",credentials:"same-origin"};b.headers&&(c.headers=b.headers);a=Dp(a,b);var d=Ep(a,b);d&&(c.body=d);b.withCredentials&&(c.credentials="include");var e=!1,f;(0,window.fetch)(a,c).then(function(a){if(!e){e=!0;f&&g.qp(f);var c=a.ok,d=function(d){d=d||{};var e=b.context||g.w;c?b.onSuccess&&b.onSuccess.call(e,d,a):b.onError&&b.onError.call(e,d,a);b.Yc&&b.Yc.call(e,d,a)};
"JSON"==(b.format||"JSON")&&(c||400<=a.status&&500>a.status)?a.json().then(d,function(){d(null)}):d(null)}});
b.Ux&&0<b.timeout&&(f=g.op(function(){e||(e=!0,g.qp(f),b.Ux.call(b.context||g.w))},b.timeout))}else g.Fp(a,b)};
g.Fp=function(a,b){var c=b.format||"JSON";a=Dp(a,b);var d=Ep(a,b),e=!1,f,k=Gp(a,function(a){if(!e){e=!0;f&&g.qp(f);var d=g.np(a),k=null,l=400<=a.status&&500>a.status,u=500<=a.status&&600>a.status;if(d||l||u)k=qea(c,a,b.UQ);if(d)a:if(a&&204==a.status)d=!0;else{switch(c){case "XML":d=0==(0,window.parseInt)(k&&k.return_code,10);break a;case "RAW":d=!0;break a}d=!!k}k=k||{};l=b.context||g.w;d?b.onSuccess&&b.onSuccess.call(l,a,k):b.onError&&b.onError.call(l,a,k);b.Yc&&b.Yc.call(l,a,k)}},b.method,d,b.headers,
b.responseType,b.withCredentials);
b.pd&&0<b.timeout&&(f=g.op(function(){e||(e=!0,k.abort(),g.qp(f),b.pd.call(b.context||g.w,k))},b.timeout));
return k};
Dp=function(a,b){b.WQ&&(a=window.document.location.protocol+"//"+window.document.location.hostname+(window.document.location.port?":"+window.document.location.port:"")+a);var c=g.ep("XSRF_FIELD_NAME",void 0),d=b.Bc;d&&(d[c]&&delete d[c],a=g.wp(a,d));return a};
Ep=function(a,b){var c=g.ep("XSRF_FIELD_NAME",void 0),d=g.ep("XSRF_TOKEN",void 0),e=b.postBody||"",f=b.qb,k=g.ep("XSRF_FIELD_NAME",void 0),l;b.headers&&(l=b.headers["Content-Type"]);b.lu||g.yg(a)&&!b.withCredentials&&g.yg(a)!=window.document.location.hostname||"POST"!=b.method||l&&"application/x-www-form-urlencoded"!=l||b.qb&&b.qb[k]||(f||(f={}),f[c]=d);f&&g.v(e)&&(e=g.sp(e),g.Zb(e,f),e=b.Ky&&"JSON"==b.Ky?JSON.stringify(e):g.Gg(e));f=e||f&&!g.Qb(f);!Hp&&f&&"POST"!=b.method&&(Hp=!0,g.M(Error("AJAX request with postData should use POST")));
return e};
qea=function(a,b,c){var d=null;switch(a){case "JSON":a=b.responseText;b=b.getResponseHeader("Content-Type")||"";a&&0<=b.indexOf("json")&&(d=JSON.parse(a));break;case "XML":if(b=(b=b.responseXML)?rea(b):null)d={},(0,g.C)(b.getElementsByTagName("*"),function(a){d[a.tagName]=sea(a)})}c&&Ip(d);
return d};
Ip=function(a){if(g.Ba(a))for(var b in a)"html_content"==b||gb(b,"_html")?a[b]=g.Tc(g.rc("HTML that is escaped and sanitized server-side and passed through yt.net.ajax"),a[b]):Ip(a[b])};
rea=function(a){return a?(a=("responseXML"in a?a.responseXML:a).getElementsByTagName("root"))&&0<a.length?a[0]:null:null};
sea=function(a){var b="";(0,g.C)(a.childNodes,function(a){b+=a.nodeValue});
return b};
g.Jp=function(a,b){b.method="POST";b.qb||(b.qb={});g.Fp(a,b)};
Gp=function(a,b,c,d,e,f,k){function l(){4==(m&&"readyState"in m?m.readyState:0)&&b&&jp(b)(m)}
c=void 0===c?"GET":c;d=void 0===d?"":d;var m=kea();if(!m)return null;"onloadend"in m?m.addEventListener("loadend",l,!1):m.onreadystatechange=l;g.lp("debug_forward_web_query_parameters")&&(a=oea(a));m.open(c,a,!0);f&&(m.responseType=f);k&&(m.withCredentials=!0);c="POST"==c&&(void 0===window.FormData||!(d instanceof window.FormData));if(e=mea(a,e))for(var n in e)m.setRequestHeader(n,e[n]),"content-type"==n.toLowerCase()&&(c=!1);c&&m.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
m.send(d);return m};
Mp=function(){return g.Kp("android")&&g.Kp("chrome")&&!Lp()};
g.Np=function(){return g.Kp("cobalt")};
Op=function(){return g.Kp("cobalt")&&g.Kp("appletv")};
Pp=function(){return g.Kp("(ps3; leanback shell)")||g.Kp("ps3")&&g.Np()};
Qp=function(){return g.Kp("(ps4; leanback shell)")||g.Kp("ps4")&&g.Np()};
g.Rp=function(){return g.Np()&&(g.Kp("ps4 vr")||g.Kp("ps4 pro vr"))};
Sp=function(){var a=/WebKit\/([0-9]+)/.exec(g.zb);return!!(a&&600<=(0,window.parseInt)(a[1],10))};
Tp=function(){return g.Kp("iemobile")||g.Kp("windows phone")&&g.Kp("edge")};
Lp=function(){return g.Kp("trident/")||g.Kp("edge/")};
Up=function(){return g.Kp("smart-tv")&&g.Kp("samsung")};
g.Kp=function(a){var b=g.zb;return b?0<=b.toLowerCase().indexOf(a):!1};
g.Vp=function(a,b,c,d,e){e=void 0===e?"":e;a&&(c&&!g.Np()?a&&(a=g.zc(g.Cc(a)),"about:invalid#zClosurez"===a?a="":(a=g.Mc(Oc(a)),a=g.jb(g.qg(a))),g.ib(a)||(a=g.ud("IFRAME",{src:'javascript:"<body><img src=\\""+'+a+'+"\\"></body>"',style:"display:none"}),g.dd(a).body.appendChild(a))):e?Gp(a,b,"POST",e,d):g.ep("USE_NET_AJAX_FOR_PING_TRANSPORT",!1)||d?Gp(a,b,"GET","",d):tea(a,b))};
Wp=function(a,b,c){c=void 0===c?"":c;try{window.navigator&&window.navigator.sendBeacon&&window.navigator.sendBeacon(a,c)?b&&b():g.Vp(a,b,void 0,void 0,c)}catch(d){g.Vp(a,b,void 0,void 0,c)}};
tea=function(a,b){var c=new window.Image,d=""+uea++;Xp[d]=c;c.onload=c.onerror=function(){b&&Xp[d]&&b();delete Xp[d]};
c.src=a};
Zp=function(a,b){var c=g.Wb(b),d;return g.bg(new g.Pf(function(b,f){c.onSuccess=function(a){g.np(a)?b(a):f(new Yp("Request failed, status="+a.status,"net.badstatus",a))};
c.onError=function(a){f(new Yp("Unknown request error","net.unknown",a))};
c.pd=function(a){f(new Yp("Request timed out","net.timeout",a))};
d=g.Fp(a,c)}),function(a){a instanceof gg&&d.abort();
return Uf(a)})};
g.$p=function(a,b,c,d){function e(d,l,m){return g.bg(d,function(d){return 0>=l||403===d.Wg.status?Uf(new Yp("Request retried too many times","net.retryexhausted",d.Wg)):f(m).then(function(){return e(Zp(a,b),l-1,Math.pow(2,c-l+1)*m)})})}
function f(a){return new g.Pf(function(b){(0,window.setTimeout)(b,a)})}
return e(Zp(a,b),c-1,d)};
Yp=function(a,b,c){Ga.call(this,a+", errorCode="+b);this.errorCode=b;this.Wg=c;this.name="PromiseAjaxError"};
aq=function(a){this.o=void 0===a?null:a;this.l=0;this.g=null};
bq=function(a){var b=new aq;a=void 0===a?null:a;b.l=2;b.g=void 0===a?null:a;return b};
cq=function(a){var b=new aq;a=void 0===a?null:a;b.l=1;b.g=void 0===a?null:a;return b};
eq=function(a){Ga.call(this,a.message||a.description||a.name);this.isMissing=a instanceof dq;this.isTimeout=a instanceof Yp&&"net.timeout"==a.errorCode;this.isCanceled=a instanceof gg};
dq=function(){Ga.call(this,"Biscotti ID is missing from server")};
vea=function(){if("1"===g.Lb(g.ep("PLAYER_CONFIG",{}),"args","privembed"))return Uf(Error("Biscotti ID is not available in private embed mode"));fq||(fq=g.bg(Zp("//googleads.g.doubleclick.net/pagead/id",gq).then(hq),function(a){return iq(2,a)}));
return fq};
hq=function(a){a=a.responseText;if(!g.fb(a,")]}'"))throw new dq;a=JSON.parse(a.substr(4));if(1<(a.type||1))throw new dq;a=a.id;gp(a);fq=cq(a);jq(18E5,2);return a};
iq=function(a,b){var c=new eq(b);gp("");fq=bq(c);0<a&&jq(12E4,a-1);throw c;};
jq=function(a,b){g.op(function(){g.bg(Zp("//googleads.g.doubleclick.net/pagead/id",gq).then(hq,function(a){return iq(b,a)}),g.va)},a)};
kq=function(){try{var a=g.y("yt.ads.biscotti.getId_");return a?a():vea()}catch(b){return Uf(b)}};
g.mq=function(a,b,c){a&&(a.dataset?a.dataset[g.lq(b)]=String(c):a.setAttribute("data-"+b,c))};
g.nq=function(a,b){return a?a.dataset?a.dataset[g.lq(b)]:a.getAttribute("data-"+b):null};
g.lq=function(a){return oq[a]||(oq[a]=String(a).replace(/\-([a-z])/g,function(a,c){return c.toUpperCase()}))};
qq=function(){var a=window.document;if("visibilityState"in a)return a.visibilityState;var b=pq+"VisibilityState";if(b in a)return a[b]};
g.rq=function(a,b){var c;(0,g.rj)(a,function(a){c=b[a];return!!c});
return c};
sq=function(a){var b=g.rq(["requestFullscreen","webkitRequestFullscreen","mozRequestFullScreen","msRequestFullscreen"],a);b&&b.call(a)};
vq=function(a){var b;g.tq()?g.uq()==a&&(b=window.document):b=a;b&&(a=g.rq(["exitFullscreen","webkitExitFullscreen","mozCancelFullScreen","msExitFullscreen"],b))&&a.call(b)};
g.wq=function(a){return g.Ja(["fullscreenchange","webkitfullscreenchange","mozfullscreenchange","MSFullscreenChange"],function(b){return"on"+b.toLowerCase()in a})};
g.tq=function(){return!!g.rq(["fullscreenEnabled","webkitFullscreenEnabled","mozFullScreenEnabled","msFullscreenEnabled"],window.document)};
g.uq=function(){var a=g.rq(["fullscreenElement","webkitFullscreenElement","mozFullScreenElement","msFullscreenElement"],window.document);return a?a:null};
xq=function(a){this.type="";this.state=this.source=this.data=this.currentTarget=this.relatedTarget=this.target=null;this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.ctrlKey=this.altKey=!1;this.rotation=this.clientY=this.clientX=0;this.changedTouches=this.touches=null;if(a=a||window.event){this.event=a;for(var b in a)b in wea||(this[b]=a[b]);this.rotation=a.rotation;(b=a.target||a.srcElement)&&3==b.nodeType&&(b=b.parentNode);this.target=b;if(b=a.relatedTarget)try{b=b.nodeName?b:null}catch(c){b=
null}else"mouseover"==this.type?b=a.fromElement:"mouseout"==this.type&&(b=a.toElement);this.relatedTarget=b;this.clientX=void 0!=a.clientX?a.clientX:a.pageX;this.clientY=void 0!=a.clientY?a.clientY:a.pageY;this.keyCode=a.keyCode?a.keyCode:a.which;this.charCode=a.charCode||("keypress"==this.type?this.keyCode:0);this.altKey=a.altKey;this.ctrlKey=a.ctrlKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.g=a.pageX;this.l=a.pageY}};
yq=function(a){if(window.document.body&&window.document.documentElement){var b=window.document.body.scrollTop+window.document.documentElement.scrollTop;a.g=a.clientX+(window.document.body.scrollLeft+window.document.documentElement.scrollLeft);a.l=a.clientY+b}};
xea=function(a,b,c,d){d=void 0===d?{}:d;a.addEventListener&&("mouseenter"!=b||"onmouseenter"in window.document?"mouseleave"!=b||"onmouseenter"in window.document?"mousewheel"==b&&"MozBoxSizing"in window.document.documentElement.style&&(b="MozMousePixelScroll"):b="mouseout":b="mouseover");return Ob(zq,function(e){var f=g.sa(e[4])&&e[4]==!!d,k=g.Ba(e[4])&&g.Ba(d)&&g.Vb(e[4],d);return!!e.length&&e[0]==a&&e[1]==b&&e[2]==c&&(f||k)})};
g.Cq=function(a,b,c,d){d=void 0===d?{}:d;if(!a||!a.addEventListener&&!a.attachEvent)return"";var e=xea(a,b,c,d);if(e)return e;e=++Aq.count+"";var f=!("mouseenter"!=b&&"mouseleave"!=b||!a.addEventListener||"onmouseenter"in window.document);var k=f?function(d){d=new xq(d);if(!g.Kd(d.relatedTarget,function(b){return b==a},!0))return d.currentTarget=a,d.type=b,c.call(a,d)}:function(b){b=new xq(b);
b.currentTarget=a;return c.call(a,b)};
k=jp(k);a.addEventListener?("mouseenter"==b&&f?b="mouseover":"mouseleave"==b&&f?b="mouseout":"mousewheel"==b&&"MozBoxSizing"in window.document.documentElement.style&&(b="MozMousePixelScroll"),Bq()||g.sa(d)?a.addEventListener(b,k,d):a.addEventListener(b,k,!!d.capture)):a.attachEvent("on"+b,k);zq[e]=[a,b,c,k,d];return e};
yea=function(a,b,c,d){var e=a||window.document;return g.Cq(e,b,function(a){var b=g.Kd(a.target,function(a){return a===e||d(a)},!0);
b&&b!==e&&!b.disabled&&(a.currentTarget=b,c.call(b,a))})};
g.Dq=function(a){a&&("string"==typeof a&&(a=[a]),(0,g.C)(a,function(a){if(a in zq){var b=zq[a],d=b[0],e=b[1],f=b[3];b=b[4];d.removeEventListener?Bq()||g.sa(b)?d.removeEventListener(e,f,b):d.removeEventListener(e,f,!!b.capture):d.detachEvent&&d.detachEvent("on"+e,f);delete zq[a]}}))};
g.Eq=function(a){a=a||window.event;a=a.target||a.srcElement;3==a.nodeType&&(a=a.parentNode);return a};
g.Fq=function(a){a=a||window.event;return a.path&&a.path.length?a.path[0]:g.Eq(a)};
g.Gq=function(a){a=a||window.event;var b=a.relatedTarget;b||("mouseover"==a.type?b=a.fromElement:"mouseout"==a.type&&(b=a.toElement));return b};
g.Hq=function(a){a=a||window.event;var b=a.pageX,c=a.pageY;window.document.body&&window.document.documentElement&&(g.ta(b)||(b=a.clientX+window.document.body.scrollLeft+window.document.documentElement.scrollLeft),g.ta(c)||(c=a.clientY+window.document.body.scrollTop+window.document.documentElement.scrollTop));return new g.Yc(b,c)};
g.Iq=function(a){a=a||window.event;a.returnValue=!1;a.preventDefault&&a.preventDefault()};
g.Jq=function(a){a=a||window.event;return!1===a.returnValue||a.jv&&a.jv()};
g.Kq=function(a){a=a||window.event;return a.keyCode?a.keyCode:a.which};
g.Lq=function(a,b,c,d){return yea(a,b,c,function(a){return g.wn(a,d)})};
g.Mq=function(a,b,c){var d=void 0===d?{}:d;var e;return e=g.Cq(a,b,function(){g.Dq(e);c.apply(a,arguments)},d)};
Nq=function(a){for(var b in zq)zq[b][0]==a&&g.Dq(b)};
Oq=function(a){this.G=a;this.g=null;this.A=0;this.B=null;this.o=0;this.l=[];for(a=0;4>a;a++)this.l.push(0);this.Ua=0;this.F=g.Cq(window,"mousemove",(0,g.z)(this.J,this));this.H=g.pp((0,g.z)(this.C,this),25)};
g.Pq=function(a){g.G.call(this);this.L=[];this.yb=a||this};
Qq=function(a,b,c,d){for(var e=0;e<c.length;e++)a.M(b,c[e],d)};
g.Rq=function(a){for(;a.L.length;){var b=a.L.pop();b.target.removeEventListener(b.name,b.ll)}};
g.N=function(a){a=void 0===a?!1:a;g.G.call(this);this.ha=new g.fo(a);g.I(this,this.ha)};
Sq=function(a,b,c){for(var d in b)a.subscribe(d,b[d],c)};
Tq=function(a,b,c){for(var d in b)a.unsubscribe(d,b[d],c)};
g.Vq=function(a,b,c,d){g.N.call(this);this.o=!!b;this.C=a;this.H=c||a;this.G=!!d;this.g=new g.Pq(this);g.I(this,this.g);this.B=this.F=null;this.A=this.l=!1;b&&(g.rd&&a.setAttribute("draggable","true"),a.style.touchAction="none");Uq(this)};
Wq=function(a,b,c){a.g.M(a.H,b,c,void 0,!a.o)};
Uq=function(a){a.B=null;a.F=null;Wq(a,Xq("over"),a.Qv);Wq(a,"touchstart",a.Ip);a.o&&Wq(a,Xq("down"),a.RH)};
Yq=function(a,b){for(var c=0;c<b.changedTouches.length;c++){var d=b.changedTouches[c];if(d.identifier==a.F)return d}return null};
Xq=function(a){return window.navigator.msPointerEnabled?"MSPointer"+a.charAt(0).toUpperCase()+a.substr(1):"mouse"+a};
Zq=function(a){a=a||{};this.url=a.url||"";this.args=a.args||g.Wb(zea);this.assets=a.assets||{};this.attrs=a.attrs||g.Wb(Aea);this.fallback=a.fallback||null;this.fallbackMessage=a.fallbackMessage||null;this.html5=!!a.html5;this.disable=a.disable||{};this.loaded=!!a.loaded;this.messages=a.messages||{}};
Bea=function(a){a instanceof Zq||(a=new Zq(a));return a};
g.dr=function(a,b,c){var d=g.$q();if(d){var e=d.subscribe(a,function(){var d=arguments;var k=function(){g.ar[e]&&b.apply(c||window,d)};
try{br[a]?k():g.op(k,0)}catch(l){g.M(l)}},c);
g.ar[e]=!0;g.cr[a]||(g.cr[a]=[]);g.cr[a].push(e);return e}return 0};
g.fr=function(a,b){var c=g.dr(a,function(a){b.apply(void 0,arguments);g.er(c)},void 0);
return c};
g.er=function(a){var b=g.$q();b&&(g.ta(a)?a=[a]:g.v(a)&&(a=[(0,window.parseInt)(a,10)]),(0,g.C)(a,function(a){b.unsubscribeByKey(a);delete g.ar[a]}))};
g.gr=function(a,b){var c=g.$q();return c?c.publish.apply(c,arguments):!1};
g.hr=function(a,b){br[a]=!0;var c=g.$q();c&&c.publish.apply(c,arguments);br[a]=!1};
g.$q=function(){return g.y("ytPubsubPubsubInstance")};
nr=function(){g.qp(ir);g.qp(jr);jr=0;if(!g.Qb(kr)){for(var a in kr){var b=lr[a];b&&(Cea(a,b),delete kr[a])}g.Qb(kr)||mr()}};
mr=function(){g.lp("web_gel_timeout_cap")&&!jr&&(jr=g.op(nr,3E4));g.qp(ir);ir=g.op(nr,g.ep("LOGGING_BATCH_TIMEOUT",1E4))};
or=function(a,b){b=void 0===b?"":b;kr[a]=kr[a]||{};kr[a][b]=kr[a][b]||[];return kr[a][b]};
Cea=function(a,b){var c=Dea[a],d=pr[a]||{};pr[a]=d;var e=Math.round(g.qr());for(n in kr[a]){var f={context:g.rr(b.g)};f[c]=or(a,n);d.dispatchedEventCount=d.dispatchedEventCount||0;d.dispatchedEventCount+=f[c].length;var k=sr[n];if(k)a:{var l=n;if(k.videoId)var m="VIDEO";else if(k.playlistId)m="PLAYLIST";else break a;f.credentialTransferTokenTargetId=k;f.context=f.context||{};f.context.user=f.context.user||{};f.context.user.credentialTransferTokens=[{token:l,scope:m}]}delete sr[n];f.requestTimeMs=
e;if(k=g.ep("EVENT_ID",void 0))m=(g.ep("BATCH_CLIENT_COUNTER",void 0)||0)+1,m>Eea&&(m=1),g.dp("BATCH_CLIENT_COUNTER",m),k={serializedEventId:k,clientCounter:m},f.serializedClientEventId=k,tr&&ur&&g.lp("log_gel_rtt_web")&&(f.previousBatchInfo={serializedClientEventId:tr,roundtripMs:ur}),tr=k,ur=0;g.vr(b,a,f,{retry:Fea.has(a),onSuccess:Gea.bind(this,g.qr())})}if(d.previousDispatchMs){c=e-d.previousDispatchMs;var n=d.diffCount||0;d.averageTimeBetweenDispatchesMs=n?(d.averageTimeBetweenDispatchesMs*n+
c)/(n+1):c;d.diffCount=n+1}d.previousDispatchMs=e};
Gea=function(a){ur=Math.round(g.qr()-a)};
Hea=function(){};
g.xr=function(a,b){return wr(a,1,b)};
yr=function(){};
g.zr=function(){return!!g.y("yt.scheduler.instance")};
wr=function(a,b,c){(0,window.isNaN)(c)&&(c=void 0);var d=g.y("yt.scheduler.instance.addJob");return d?d(a,b,c):void 0===c?(a(),window.NaN):g.op(a,c||0)};
g.Ar=function(a){if(!(0,window.isNaN)(a)){var b=g.y("yt.scheduler.instance.cancelJob");b?b(a):g.qp(a)}};
Br=function(a){var b=g.y("yt.scheduler.instance.setPriorityThreshold");b&&b(a)};
Er=function(){var a={},b=void 0===a.g?!0:a.g;a=void 0===a.l?!1:a.l;if(null==g.y("_lact",window)){var c=(0,window.parseInt)(g.ep("LACT"),10);c=(0,window.isFinite)(c)?(0,g.D)()-Math.max(c,0):-1;g.ua("_lact",c,window);g.ua("_fact",c,window);-1==c&&Cr();g.Cq(window.document,"keydown",Cr);g.Cq(window.document,"keyup",Cr);g.Cq(window.document,"mousedown",Cr);g.Cq(window.document,"mouseup",Cr);b&&(a?g.Cq(window,"touchmove",function(){Dr("touchmove",200)},{passive:!0}):(g.Cq(window,"resize",function(){Dr("resize",
200)}),g.Cq(window,"scroll",function(){Dr("scroll",200)})));
new Oq(function(){Dr("mouse",100)});
g.Cq(window.document,"touchstart",Cr,{passive:!0});g.Cq(window.document,"touchend",Cr,{passive:!0})}};
Dr=function(a,b){Fr[a]||(Fr[a]=!0,g.xr(function(){Cr();Fr[a]=!1},b))};
Cr=function(){null==g.y("_lact",window)&&Er();var a=(0,g.D)();g.ua("_lact",a,window);-1==g.y("_fact",window)&&g.ua("_fact",a,window);(a=g.y("ytglobal.ytUtilActivityCallback_"))&&a()};
Gr=function(){var a=g.y("_lact",window),b;null==a?b=-1:b=Math.max((0,g.D)()-a,0);return b};
g.Hr=function(a,b,c,d,e){var f={};f.eventTimeMs=Math.round(d||g.qr());f[a]=b;f.context={lastActivityMs:String(d?-1:Gr())};e?(a={},e.videoId?a.videoId=e.videoId:e.playlistId&&(a.playlistId=e.playlistId),sr[e.token]=a,e=or("log_event",e.token)):e=or("log_event");e.push(f);c&&(lr.log_event=new c);e.length>=(Number(g.lp("web_logging_max_batch")||0)||20)?nr():mr()};
g.rr=function(a){a={client:{hl:a.jp,gl:a.ip,clientName:a.hp,clientVersion:a.innertubeContextClientVersion}};var b=window.devicePixelRatio;b&&1!=b&&(a.client.screenDensityFloat=String(b));g.ep("DELEGATED_SESSION_ID")&&!g.lp("pageid_as_header_web")&&(a.user={onBehalfOfUser:g.ep("DELEGATED_SESSION_ID")});return a};
Iea=function(a,b,c){c=void 0===c?{}:c;var d={"X-Goog-Visitor-Id":c.visitorData||g.ep("VISITOR_DATA","")};if(b&&b.includes("www.youtube-nocookie.com"))return d;(b=c.SQ||g.ep("AUTHORIZATION"))||(a?b="Bearer "+g.y("gapi.auth.getToken")().QQ:b=g.qm());b&&(d.Authorization=b,d["X-Goog-AuthUser"]=g.ep("SESSION_INDEX",0),g.lp("pageid_as_header_web")&&(d["X-Goog-PageId"]=g.ep("DELEGATED_SESSION_ID")));return d};
g.Jr=function(a,b,c,d){Ir.set(""+a,b,c,"/",void 0===d?"youtube.com":d,!1)};
g.Kr=function(a,b,c){Ir.remove(""+a,void 0===b?"/":b,void 0===c?"youtube.com":c)};
Lr=function(){var a;(a=g.wo("yt.innertube"))||(a=new so("yt.innertube"),a=a.isAvailable()?a:null);this.g=a?new ko(a):null;this.l=window.document.domain||window.location.hostname};
g.Mr=function(a){this.g=a||{innertubeApiKey:g.ep("INNERTUBE_API_KEY",void 0),innertubeApiVersion:g.ep("INNERTUBE_API_VERSION",void 0),hp:g.ep("INNERTUBE_CONTEXT_CLIENT_NAME","WEB"),innertubeContextClientVersion:g.ep("INNERTUBE_CONTEXT_CLIENT_VERSION",void 0),jp:g.ep("INNERTUBE_CONTEXT_HL",void 0),ip:g.ep("INNERTUBE_CONTEXT_GL",void 0),Vl:g.ep("INNERTUBE_HOST_OVERRIDE",void 0)||"",pD:!!g.ep("INNERTUBE_USE_THIRD_PARTY_AUTH",!1)}};
g.vr=function(a,b,c,d){!g.ep("VISITOR_DATA")&&.01>Math.random()&&g.M(Error("Missing VISITOR_DATA when sending innertube request."),"WARNING");c={headers:{"Content-Type":"application/json"},method:"POST",qb:c,Ky:"JSON",pd:function(){d.pd()},
Ux:d.pd,onSuccess:function(a,b){if(d.onSuccess)d.onSuccess(b)},
ZQ:function(a){if(d.onSuccess)d.onSuccess(a)},
onError:function(a,b){if(d.onError)d.onError(b)},
YQ:function(a){if(d.onError)d.onError(a)},
timeout:d.timeout,withCredentials:!0};var e="",f=a.g.Vl;f&&(e=f);f=Iea(a.g.pD||!1,e,d);Object.assign(c.headers,f);c.headers.Authorization&&!e&&(c.headers["x-origin"]=window.location.origin);a=""+e+("/youtubei/"+a.g.innertubeApiVersion+"/"+b)+"?alt=json&key="+a.g.innertubeApiKey;try{g.lp("use_fetch_for_op_xhr")?pea(a,c):g.Jp(a,c)}catch(k){if("InvalidAccessError"==k)g.M(Error("An extension is blocking network request."),"WARNING");else throw k;}};
Nr=function(a,b,c){var d=g.Mr;g.ep("ytLoggingEventsDefaultDisabled",!1)&&g.Mr==g.Mr&&(d=null);g.Hr(a,b,d,c,void 0)};
Oo=function(){};
g.Or=function(a){this.g=a};
g.Pr=function(a){return new g.Or({trackingParams:a})};
g.Qr=function(a){var b={};void 0!==a.g.trackingParams?b.trackingParams=a.g.trackingParams:(b.veType=a.g.veType,null!=a.g.veCounter&&(b.veCounter=a.g.veCounter),null!=a.g.elementIndex&&(b.elementIndex=a.g.elementIndex));void 0!==a.g.dataElement&&(b.dataElement=g.Qr(a.g.dataElement));void 0!==a.g.youtubeData&&(b.youtubeData=a.g.youtubeData);return b};
Rr=function(a){return!a.g.trackingParams&&!!a.g.veType};
g.Sr=function(a,b,c){a={csn:a,parentVe:g.Qr(b),childVes:(0,g.E)(c,function(a){return g.Qr(a)})};
g.Hr("visualElementAttached",a,g.Mr)};
g.Tr=function(a,b){g.Hr("visualElementShown",{csn:a,ve:g.Qr(b),eventType:1},g.Mr)};
g.Vr=function(a,b){g.Hr("visualElementGestured",{csn:a,ve:g.Qr(b),gestureType:"INTERACTION_LOGGING_GESTURE_TYPE_GENERIC_CLICK"},g.Mr)};
Xr=function(a,b){var c=Object.keys(a).join("");Wr("info_"+c+"_"+b)||(a.clientActionNonce=b,Nr("latencyActionInfo",a))};
Wr=function(a){Yr[a]=Yr[a]||{count:0};var b=Yr[a];b.count++;b.time=g.qr();Zr||(Zr=wr(Jea,0,5E3));if(10<b.count){if(11==b.count){b=Error("CSI data exceeded logging limit with key: "+a);var c=0==a.indexOf("info")?"WARNING":"ERROR";var d=d||{};d.name=g.ep("INNERTUBE_CONTEXT_CLIENT_NAME",1);d.version=g.ep("INNERTUBE_CONTEXT_CLIENT_VERSION",void 0);a=b;b=void 0===c?"ERROR":c;b=void 0===b?"ERROR":b;c=window&&window.yterr||!1;if(a&&c&&!(5<=$r)){var e=a.stacktrace,f=a.columnNumber;a.hasOwnProperty("params")&&
(d.params=JSON.stringify(a.params).substr(0,500));a=Qaa(a);e=e||a.stack;c=a.lineNumber.toString();(0,window.isNaN)(c)||(0,window.isNaN)(f)||(c=c+":"+f);window.yterr&&g.Aa(window.yterr)&&window.yterr(a);if(!(as[a.message]||0<=e.indexOf("/YouTubeCenter.js")||0<=e.indexOf("/mytube.js"))){b={Bc:{a:"logerror",t:"jserror",type:a.name,msg:a.message.substr(0,1E3),line:c,level:b,"client.name":d.name},qb:{url:g.ep("PAGE_NAME",window.location.href),file:a.fileName},method:"POST"};d.version&&(b["client.version"]=
d.version);e&&(b.qb.stack=e);for(var k in d)b.qb["client."+k]=d[k];if(d=g.ep("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS",void 0))for(var l in d)b.qb[l]=d[l];g.Fp(g.ep("ECATCHER_REPORT_HOST","")+"/error_204",b);as[a.message]=!0;$r++}}}return!0}return!1};
Jea=function(){var a=g.qr(),b;for(b in Yr)6E4<a-Yr[b].time&&delete Yr[b];Zr=0};
cs=function(){if(window.crypto&&window.crypto.getRandomValues)try{var a=Array(16),b=new window.Uint8Array(16);window.crypto.getRandomValues(b);for(var c=0;c<a.length;c++)a[c]=b[c];return a}catch(e){}a=Array(16);for(b=0;16>b;b++){c=(0,g.D)();for(var d=0;d<c%23;d++)a[b]=Math.random();a[b]=Math.floor(256*Math.random())}if(bs)for(b=1,c=0;c<bs.length;c++)a[b%16]=a[b%16]^a[(b-1)%16]/4^bs.charCodeAt(c),b++;return a};
ds=function(){for(var a=cs(),b=[],c=0;c<a.length;c++)b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a[c]&63));return b.join("")};
g.es=function(){return(0,g.E)(cs(),function(a){return(a&15).toString(16)}).join("")};
fs=function(a){a=void 0===a?0:a;return 0==a?"client-screen-nonce":"client-screen-nonce."+a};
gs=function(a){a=void 0===a?0:a;return 0==a?"ROOT_VE_TYPE":"ROOT_VE_TYPE."+a};
hs=function(a){return g.ep(gs(void 0===a?0:a),void 0)};
g.is=function(){var a=hs(0),b;a?b=new g.Or({veType:a,youtubeData:void 0}):b=null;return b};
g.js=function(a){a=void 0===a?0:a;var b=g.ep(fs(a));b||0!=a||(b=g.ep("EVENT_ID"));return b?b:null};
ls=function(a,b,c){c=void 0===c?0:c;if(a!==g.ep(fs(c))||b!==g.ep(gs(c)))g.dp(fs(c),a),g.dp(gs(c),b),0==c&&(b=function(){(0,window.setTimeout)(function(){a&&g.Hr("foregroundHeartbeatScreenAssociated",{clientDocumentNonce:ks,clientScreenNonce:a},g.Mr)},0)},"requestAnimationFrame"in window?window.requestAnimationFrame(b):b())};
g.os=function(a,b,c){var d=c&&0<c?c:0;c=d?(0,g.D)()+1E3*d:0;if((d=d?(0,g.ms)():ns())&&window.JSON){g.v(b)||(b=JSON.stringify(b,void 0));try{d.set(a,b,c)}catch(e){d.remove(a)}}};
g.ps=function(a){var b=ns(),c=(0,g.ms)();if(!b&&!c||!window.JSON)return null;try{var d=b.get(a)}catch(e){}if(!g.v(d))try{d=c.get(a)}catch(e){}if(!g.v(d))return null;try{d=JSON.parse(d,void 0)}catch(e){}return d};
g.qs=function(a){try{var b=ns(),c=(0,g.ms)();b&&b.remove(a);c&&c.remove(a)}catch(d){}};
g.rs=function(){return g.ps("yt-remote-session-screen-id")};
us=function(a,b,c){g.v(a)&&(a={mediaContentUrl:a,startSeconds:b,suggestedQuality:c});b=/\/([ve]|embed)\/([^#?]+)/.exec(a.mediaContentUrl);a.videoId=b&&b[2]?b[2]:null;return ts(a)};
ts=function(a,b,c){if(g.Ba(a)){b=["endSeconds","startSeconds","mediaContentUrl","suggestedQuality","videoId"];c={};for(var d=0;d<b.length;d++){var e=b[d];a[e]&&(c[e]=a[e])}return c}return{videoId:a,startSeconds:b,suggestedQuality:c}};
vs=function(a,b,c,d){!a&&(void 0===c?0:c)&&g.kp(Error("Player URL validator detects invalid url. "+(void 0===d?"":d)+": "+b));return a};
ws=function(a){return(a=Kea.exec(a))?a[0]:""};
xs=function(a){var b=void 0===b?!1:b;return vs(Lea.test(a),a,b,"Nielsen OCR URL")};
ys=function(a){var b=void 0===b?!1:b;return vs(Mea.test(a),a,b,"Active View 3rd Party Integration URL")};
zs=function(a){var b=void 0===b?!1:b;return vs(Nea.test(a),a,b,"Google/YouTube Brand Lift URL")};
As=function(a){var b=void 0===b?!1:b;return vs(Oea.test(a),a,b,"Trusted Stream URL")};
g.Bs=function(a){var b=void 0===b?!1:b;return vs(Pea.test(a),a,b,"Trusted Image URL")};
g.Cs=function(a){var b=void 0===b?!1:b;return vs(Qea.test(a),a,b,"Trusted Promoted Video Domain URL")};
Ds=function(a,b){b=void 0===b?!1:b;return vs(Rea.test(a),a,b,"Captions URL")};
Es=function(a){a=new g.um(a);g.vm(a,window.document.location.protocol);g.wm(a,window.document.location.hostname);window.document.location.port&&g.xm(a,window.document.location.port);return a.toString()};
Fs=function(a){a=new g.um(a);g.vm(a,window.document.location.protocol);return a.toString()};
g.Gs=function(){return"ytp-id-"+Sea++};
g.Is=function(a){g.G.call(this);this.g={};this.Ta={};this.element=Hs(this,a)};
Hs=function(a,b,c){c=c||"svg"==b.D;if(c){var d=window.document.createElementNS("http://www.w3.org/2000/svg",b.D);g.Js&&(b.N||(b.N={}),b.N.focusable="false")}else d=g.vd(b.D);var e;if(e=b.I){if(e=Ks(a,d,"class",e))Ls(a,d,"class",e),a.g[e]=d}else if(e=b.W){for(var f=0;f<e.length;f++)a.g[e[f]]=d;Ls(a,d,"class",e.join(" "))}if(e=b.V)c=Ks(a,d,"child",e),null!=c&&d.appendChild(g.wd(c));else if(e=b.K)for(var k=f=0;k<e.length;k++){var l=e[k];if(l)if(g.v(l))l=Ks(a,d,"child",l),null!=l&&d.appendChild(g.wd(l));
else if(l.element)d.appendChild(l.element);else{var m=l;l=Hs(a,m,c);d.appendChild(l);m.La&&(m=g.Gs(),l.id=m,l=window.document.createElementNS("http://www.w3.org/2000/svg","use"),l.setAttribute("class","ytp-svg-shadow"),l.setAttributeNS("http://www.w3.org/1999/xlink","href","#"+m),zd(d,l,f++))}}if(b=b.N){c=d;for(var n in b)e=b[n],null!=e&&Ls(a,c,n,g.v(e)?Ks(a,c,n,e):e)}return d};
Ks=function(a,b,c,d){return"{{"==d.substr(0,2)?(a.Ta[d]=[b,c],null):d};
Ls=function(a,b,c,d){if("child"==c){g.yd(b);if(!g.ya(d)||g.Ba(d)&&g.v(d.D))d=[d];c=[];for(var e=0;e<d.length;e++){var f=d[e];if(null!=f){var k=f.nodeType;if(1==k||3==k)c.push(f);else if(g.Ba(f)&&g.v(f.D))c.push(Hs(a,f));else if(f.element)c.push(f.element);else if(g.v(f)&&-1!=f.indexOf("\n"))for(f=f.split("\n"),k=0;k<f.length;k++)0<k&&c.push(g.vd("BR")),c.push(g.wd(f[k]));else c.push(g.wd(f))}}for(a=0;a<c.length;a++)b.appendChild(c[a])}else"style"==c?b.style.cssText=d?d:"":null===d?b.removeAttribute(c):
b.setAttribute(c,d.toString())};
g.P=function(a){g.Is.call(this,a);this.dd="";this.da=!0;this.Z=[]};
g.Ms=function(a,b){b?a.show():a.hide()};
g.Ns=function(a){g.P.call(this,a);this.Y=new g.N;g.I(this,this.Y)};
g.Ps=function(a,b,c,d){g.Ns.call(this,a);this.priority=b;c&&g.Os(this,c);d&&this.jb(d)};
g.Qs=function(a,b,c){a=void 0===a?{}:a;b=void 0===b?[]:b;c=void 0===c?!1:c;b.push("ytp-menuitem");"role"in a||(a.role="menuitem");c||"tabindex"in a||(a.tabindex="0");return{D:c?"a":"div",W:b,N:a,K:[{D:"div",I:"ytp-menuitem-label",V:"{{label}}"},{D:"div",I:"ytp-menuitem-content",V:"{{content}}"}]}};
g.Os=function(a,b){a.updateValue("label",b)};
Ts=function(a,b){g.G.call(this);this.app=a;this.g=!0;this.o=null;this.H={};this.J={};this.A={};this.F=[];this.C={};this.B={};this.l=null;this.L=new window.Set;this.playerType=b;Rs(this,"cueVideoById",this.iw);Rs(this,"loadVideoById",this.eF);Rs(this,"cueVideoByUrl",this.RE);Rs(this,"loadVideoByUrl",this.fF);Rs(this,"playVideo",this.Kb);Rs(this,"pauseVideo",this.Lb);Rs(this,"stopVideo",this.Kc);Rs(this,"clearVideo",this.PE);Rs(this,"getVideoBytesLoaded",this.WE);Rs(this,"getVideoBytesTotal",this.XE);
Rs(this,"getVideoLoadedFraction",this.Up);Rs(this,"getVideoStartBytes",this.YE);Rs(this,"cuePlaylist",this.QE);Rs(this,"loadPlaylist",this.dF);Rs(this,"nextVideo",this.gi);Rs(this,"previousVideo",this.Qj);Rs(this,"playVideoAt",this.mw);Rs(this,"setShuffle",this.setShuffle);Rs(this,"setLoop",this.hF);Rs(this,"getPlaylist",this.Ve);Rs(this,"getPlaylistIndex",this.kw);Rs(this,"getPlaylistId",this.getPlaylistId);Rs(this,"loadModule",this.fi);Rs(this,"unloadModule",this.Rj);Rs(this,"setOption",this.md);
Rs(this,"getOption",this.Ub);Rs(this,"getOptions",this.bh);Rs(this,"mute",this.mute);Rs(this,"unMute",this.We);Rs(this,"isMuted",this.isMuted);Rs(this,"setVolume",this.setVolume);Rs(this,"getVolume",this.Jb);Rs(this,"seekTo",this.Ab);Rs(this,"getPlayerState",this.Kd);Rs(this,"getPlaybackRate",this.Pb);Rs(this,"setPlaybackRate",this.be);Rs(this,"getAvailablePlaybackRates",this.di);Rs(this,"getPlaybackQuality",this.Pj);Rs(this,"setPlaybackQuality",this.tm);Rs(this,"getAvailableQualityLevels",this.Sp);
Rs(this,"getCurrentTime",this.ya);Rs(this,"getDuration",this.ec);Rs(this,"addEventListener",this.addEventListener);Rs(this,"removeEventListener",this.removeEventListener);Rs(this,"getDebugText",this.Oj);Rs(this,"getVideoData",this.getVideoData);Rs(this,"addCueRange",this.hw);Rs(this,"removeCueRange",this.nw);Rs(this,"setSize",this.iF);Rs(this,"getApiInterface",this.TE);Rs(this,"destroy",this.SE);Rs(this,"showVideoInfo",this.pw);Rs(this,"hideVideoInfo",this.aF);Rs(this,"isVideoInfoVisible",this.cF);
this.app.g.Sb||(Rs(this,"getVideoEmbedCode",this.lw),Rs(this,"getVideoUrl",this.getVideoUrl));Rs(this,"getMediaReferenceTime",this.VE);Rs(this,"getSphericalProperties",this.Tp);Rs(this,"setSphericalProperties",this.Wp);Ss(this,"getInternalApiInterface",this.UE);Ss(this,"getAdState",this.jw);Ss(this,"sendAbandonmentPing",this.gF);Ss(this,"setAutonav",this.ow);Ss(this,"setAutonavState",this.Vp);Ss(this,"startInteractionLogging",this.jF);Ss(this,"isNotServable",this.bF);Ss(this,"channelSubscribed",this.NE);
Ss(this,"channelUnsubscribed",this.OE);Ss(this,"handleExternalCall",this.ZE)};
Rs=function(a,b,c){a.H[b]=function(b){for(var d=[],f=0;f<arguments.length;++f)d[f-0]=arguments[f];return c.apply(a,d)};
Ss(a,b,c);a.F.push(b)};
Us=function(a,b,c){a.J[b]=function(b){for(var d=[],f=0;f<arguments.length;++f)d[f-0]=arguments[f];return c.apply(a,d)};
Ss(a,b,c);a.F.push(b)};
Ss=function(a,b,c){a.A[b]=function(b){for(var d=[],f=0;f<arguments.length;++f)d[f-0]=arguments[f];return c.apply(a,d)}};
Vs=function(a){a.l||(a.l={},g.Fa(a.l,a.H),g.Fa(a.l,a.J),a.l.addEventListener=(0,g.z)(a.iC,a),a.l.removeEventListener=(0,g.z)(a.jC,a));return a.l};
Ws=function(a,b,c){g.R(a.app.g.experiments,"web_player_gel_logging_killswitch")||Nr(b,c)};
Ys=function(a,b,c){b=g.Uc(Math.floor(b),0,100);(0,window.isFinite)(b)&&Xs(a.app,{volume:b,muted:a.isMuted()},c)};
Zs=function(a,b){Xs(a.app,{muted:!0,volume:a.Jb()},b)};
$s=function(a,b){Xs(a.app,{muted:!1,volume:Math.max(5,a.Jb())},b)};
g.bt=function(a){return(a=at(a.app.C))?a.g:null};
ct=function(a,b,c){this.name=a;this.id=b;this.isDefault=c};
g.dt=function(a){this.languageCode=a.languageCode;this.languageName=a.languageName||null;this.g=a.languageOriginal||null;this.id=a.id||null;this.isDefault=a.is_default||!1};
g.et=function(a){a=void 0===a?{}:a;this.F=a.format||3;this.l=a.languageCode||"";this.o=a.languageName;this.A=a.kind||"";this.B=a.name;this.Ga=a.id;this.J=a.is_servable;this.G=a.is_translateable;this.H=a.url||null;this.C=a.vss_id||"";this.isDefault=a.is_default;this.g=null;if(a=a.translationLanguage)this.g=new g.dt(a)};
g.ft=function(a){var b=a.o||"",c=[b];"asr"==a.A&&-1==b.indexOf("(")&&c.push(" (Automatic Captions)");a.B&&c.push(" - "+a.B);a.g&&c.push(" >> "+a.g.languageName);return c.join("")};
gt=function(a,b){this.id=a;this.ib=b;this.captionTracks=[];this.Gl=this.so=this.g=null;this.eo="UNKNOWN"};
ht=function(a,b,c){this.sampleRate=a||0;this.g=b||0;this.spatialAudioType=c||0};
Tea=function(a,b,c,d){this.displayName=a;this.vssId=b;this.languageCode=c;this.kind=void 0===d?"":d};
kt=function(a,b,c,d,e,f,k,l,m,n,p,u){this.width=a;this.height=b;this.quality=f||it(a,b);this.g=g.jt[this.quality];this.isAccelerated=!!k;this.fps=c||0;this.stereoLayout=!e||null!=d&&0!=d&&1!=d?0:e;this.projectionType=d?2==d&&2==e?3:d:0;(a=l)||(a=g.jt[this.quality],0==a?a="Auto":(b=this.fps,c=this.projectionType,a=a+(2==c||3==c||4==c?"s":"p")+(55<b?"60":49<b?"50":39<b?"48":"")));this.qualityLabel=a;this.l=m||"";this.primaries=n||"";this.o=!1!==p;this.streamType=u||0};
lt=function(a){return 1280<=a.width||720<=a.height};
mt=function(a){return"smpte2084"==a.l||"arib-std-b67"==a.l};
it=function(a,b){for(var c=Math.max(a,b),d=Math.min(a,b),e=nt[0],f=0;f<nt.length;f++){var k=nt[f],l=g.jt[k];if(c>=1.3*Math.floor(16*l/9)||d>=1.3*l)return e;e=k}return"tiny"};
pt=function(a,b,c,d,e,f,k,l,m){this.id=a;this.containerType=0<=b.indexOf("/mp4")?1:0<=b.indexOf("/webm")?2:0<=b.indexOf("/x-flv")?3:0<=b.indexOf("/vtt")?4:0;this.mimeType=b;this.g=k||0;this.A=l||0;this.audio=void 0===c?null:c;this.video=void 0===d?null:d;this.ib=void 0===e?null:e;this.captionTrack=void 0===m?null:m;this.Ec=void 0===f?null:f;this.l=Uea[g.ot(this)]||"";this.o=null};
g.ot=function(a){return a.id.split(";",1)[0]};
qt=function(a){return"9"==a.l||"("==a.l||"9h"==a.l||"(h"==a.l};
rt=function(a){return"9h"==a.l||"(h"==a.l};
g.tt=function(a){return 1==a.containerType};
ut=function(a){return"application/x-mpegURL"==a.mimeType};
vt=function(a){return/(opus|vorbis|mp4a|dtse|ac-3|ec-3)/.test(a)};
g.wt=function(a){return a.includes("vtt")||a.includes("text/mp4")};
xt=function(a,b,c,d,e,f,k){var l=new ht;b in g.jt||(b="small");d&&e?(e=(0,window.parseInt)(e,10),d=(0,window.parseInt)(d,10)):(e=g.jt[b],d=Math.round(16*e/9));b=new kt(d,e,0,null,void 0,b,f,void 0,void 0,void 0,k);a=(0,window.unescape)(a.replace(/&quot;/g,'"'));return new pt(c,a,l,b)};
Vea=function(a,b){this.experimentIds=a?a.split(","):[];this.flags=g.rp(b||"");var c={};(0,g.C)(this.experimentIds,function(a){c[a]=!0});
this.experiments=c;this.g=!!c["9414740"]};
g.R=function(a,b){return"true"==a.flags[b]};
g.S=function(a,b){return(0,window.parseFloat)(a.flags[b])||0};
g.zt=function(a,b){var c=a.flags[b];return c?c.toString():""};
At=function(){var a=g.y("yt.player.utils.videoElement_");a||(a=g.vd("VIDEO"),g.ua("yt.player.utils.videoElement_",a,void 0));return a};
Bt=function(a){var b=At();return!!(b&&b.canPlayType&&b.canPlayType(a))};
Dt=function(a){if(/opus/.test(a)&&(g.Ct&&!g.an("38")||g.Ct&&g.Kp("crkey")))return!1;if(window.MediaSource&&window.MediaSource.isTypeSupported)return window.MediaSource.isTypeSupported(a);if(/webm/.test(a)&&!Qp())return!1;'audio/mp4; codecs="mp4a.40.2"'==a&&(a='video/mp4; codecs="avc1.4d401f"');return!!Bt(a)};
g.Et=function(){var a=At();return!!a.webkitSupportsPresentationMode&&g.Aa(a.webkitSetPresentationMode)};
g.Ft=function(){return"pictureInPictureEnabled"in window.document&&!!window.document.pictureInPictureEnabled};
Gt=function(){var a=At();try{var b=a.muted;a.muted=!b;return a.muted!=b}catch(c){}return!1};
Ht=function(a,b){this.g=a;this.l=b;this.o=0;Object.defineProperty(this,"timestampOffset",{get:this.rN,set:this.vN});Object.defineProperty(this,"buffered",{get:this.pN})};
Wea=function(){this.length=0};
It=function(a){this.activeSourceBuffers=this.sourceBuffers=[];this.g=a;this.l=window.NaN;this.o=0;Object.defineProperty(this,"duration",{get:this.qN,set:this.uN});Object.defineProperty(this,"readyState",{get:this.sN});this.g.addEventListener("webkitsourceclose",(0,g.z)(this.tN,this),!0)};
Jt=function(){this.length=1};
Kt=function(){this.buffered=new Jt};
Lt=function(a,b){return{start:function(b){return a[b]},
end:function(a){return b[a]},
length:a.length}};
Mt=function(a,b){b=void 0===b?",":b;var c="";if(a)for(var d=0;d<a.length;d++)c+=a.start(d).toFixed(3)+"-"+a.end(d).toFixed(3)+b;return c};
Nt=function(a,b){if(!a)return-1;try{for(var c=0;c<a.length;c++)if(a.start(c)<=b&&a.end(c)>=b)return c}catch(d){}return-1};
Ot=function(a,b){if(!a)return window.NaN;var c=Nt(a,b);return 0<=c?a.end(c):window.NaN};
Pt=function(a){return a&&a.length?a.end(a.length-1):window.NaN};
Qt=function(a,b){var c=Ot(a,b);return 0<=c?c-b:0};
Rt=function(a,b,c){for(var d=[],e=[],f=0;f<a.length;f++)a.end(f)<b||a.start(f)>c||(d.push(Math.max(b,a.start(f))-b),e.push(Math.min(c,a.end(f))-b));return Lt(d,e)};
St=function(a){this.g=a;this.o=this.A=null;this.l=!1};
Tt=function(a,b,c){this.g=a;this.l=b;this.A=c;this.o=0};
Ut=function(a,b){this.g=a;this.l=!!b;this.o=!1};
Vt=function(a,b){b=void 0===b?!1:b;g.G.call(this);this.B=new g.Pq(this);g.I(this,this.B);this.l=this.g=null;this.o=a;var c=this.o;c=c.DG?c.g.webkitMediaSourceURL:window.URL.createObjectURL(c);this.Fj=new Ut(c,!0);this.C=b;this.A=null;Qq(this.B,this.o,["sourceopen","webkitsourceopen"],this.G);Qq(this.B,this.o,["sourceclose","webkitsourceclose"],this.F)};
Xea=function(a,b){Wt(a)?g.Jf(function(){return b(a)}):a.A=b};
Xt=function(a,b){return"fakesb"==b?new Kt:a.o.addSourceBuffer(b)};
Wt=function(a){try{return"open"==a.o.readyState}catch(b){return!1}};
Yt=function(a){try{return"closed"==a.o.readyState}catch(b){return!0}};
Zt=function(a){return!!(a.g&&a.g.Hf()||a.l&&a.l.Hf())};
$t=function(){return!(!window.MediaSource||!window.MediaSource.isTypeSupported)};
au=function(a){return a.g?!!a.g.supports(0):$t()};
bu=function(a,b,c){if(!a.g||!a.l)return null;var d=a.g.oq()?a.g.g:a.g,e=a.l.oq()?a.l.g:a.l,f=new Vt(a.o,!0);f.Fj=a.Fj;f.g=new Tt(d,b,c);f.l=new Tt(e,b,c);Wt(a)||a.g.Br(a.g.Fm());return f};
Yea=function(a,b,c){this.g=a;this.B=b;this.C=void 0===c?!1:c;this.A=!!g.y("cast.receiver.platform.canDisplayType");a=g.y("cast.receiver.platform.getValue");this.l=!this.A&&a&&a("max-video-resolution-vpx")||null;this.o={}};
eu=function(a,b){var c=a.canPlayType?a.canPlayType(b):!1;cu?c=c||Zea[b]:2.2==du?c=c||$ea[b]:Mp()&&(c=c||afa[b]);return!!c};
bfa=function(a,b){if("0"==g.ot(b))return!0;var c=b.mimeType;if(b.video&&(mt(b.video)||"bt2020"==b.video.primaries)&&!(24<window.screen.pixelDepth||fu(a,gu))||"338"==g.ot(b)&&!(g.Ct?g.an(53):g.hu&&g.an(64)&&g.R(a.g,"html5_firefox_ambisonic_opus")))return!1;var d={};b.video&&(b.video.width&&(d[iu.name]=b.video.width),b.video.height&&(d[ju.name]=b.video.height),b.video.fps&&(d[ku.name]=b.video.fps),b.video.l&&(d[gu.name]=b.video.l),b.g&&(d[lu.name]=8*b.g),"("==b.l&&(d[mu.name]="subsample"),2==b.video.projectionType||
3==b.video.projectionType||4==b.video.projectionType)&&(d[nu.name]="true");b.audio&&b.audio.g&&(d[ou.name]=b.audio.g);for(var e in pu){var f=pu[e],k;if(k=d[f.name])(k=f==gu&&0<b.mimeType.indexOf("vp09.02"))||(k=b,k=g.R(a.g,"html5_ignore_h264_framerate_cap")&&f==ku&&("H"==k.l||"h"==k.l)),k=!(k||f==nu&&!g.R(a.g,"html5_decode_to_texture_cap"));if(k)if(fu(a,f))if(a.l){if(a.l[f.name]<d[f.name])return!1}else c=c+"; "+f.name+"="+d[f.name];else if(rt(b)&&f==gu)return!1}!g.R(a.g,"disable_html5_cast_hdcp_filter2")&&
a.A&&b.video&&1080<b.video.g&&b.Ec&&(c+="; hdcp=2.2");return"227"!=g.ot(b)||g.R(a.g,"html5_enable_1080p_hq_cenc")?qu(a,c):!1};
ru=function(){var a=Mp()&&!g.an(29),b=g.Kp("google tv")&&g.Kp("chrome")&&!g.an(30),c=Op();return a||b||c?!1:!!(window.MediaSource||window.WebKitMediaSource||window.HTMLMediaElement&&window.HTMLMediaElement.prototype.webkitSourceAddId)};
g.tu=function(){return!(!eu(At(),"application/x-mpegURL")&&!ru())};
fu=function(a,b){if(!(b.name in a.o)){var c=a.o,d=b.name;if(a.l)var e=!!a.l[b.name];else b==lu&&g.R(a.g,"html5_ignore_bad_bitrates")&&qu(a,'video/webm; codecs="vp9"; width=3840; height=2160; bitrate=2000000')&&!qu(a,'video/webm; codecs="vp9"; width=3840; height=2160; bitrate=20000000')?e=!1:(b.video?(e='video/webm; codecs="vp9"',qu(a,e)||(e='video/mp4; codecs="avc1.4d401e"')):(e='audio/webm; codecs="opus"',qu(a,e)||(e='audio/mp4; codecs="mp4a.40.2"')),e=qu(a,e+"; "+b.name+"="+b.valid)&&!qu(a,e+"; "+
b.name+"="+b.gg));c[d]=e}return a.o[b.name]};
qu=function(a,b){return a.A?window.cast.receiver.platform.canDisplayType(b):Dt(b)};
cfa=function(a){return g.uu||Up()&&!g.R(a.g,"html5_samsung_vp9_live")?!1:!0};
vu=function(a){this.nf=a};
wu=function(a,b){if(b)return bq();for(var c={},d=At(),e=g.q(a),f=e.next();!f.done;f=e.next())if(f=f.value,eu(d,f.Me().mimeType)){var k=f.nf.za().quality;c[k]&&2!=c[k].Me().containerType||(c[k]=f)}var l=[];c.auto&&l.push(c.auto);(0,g.C)(nt,function(a){(a=c[a])&&l.push(a)});
return l.length?cq(l):bq()};
xu=function(a,b,c,d){this.l=a||0;this.g=b||0;this.o=c;this.reason=d};
yu=function(a,b){return a.l==b.l&&a.g==b.g&&a.o==b.o&&a.reason==b.reason};
zu=function(a,b,c,d){return new xu(g.jt[a]||0,g.jt[b]||0,c,d)};
Au=function(a){var b=g.jt.auto;return a.l==b&&a.g==b};
Cu=function(a,b){if(b.o&&Au(b))return Bu;if(b.o||Au(a))return b;if(a.o||Au(b))return a;var c=a.l&&b.l?Math.max(a.l,b.l):a.l||b.l,d=a.g&&b.g?Math.min(a.g,b.g):a.g||b.g;c=Math.min(c,d);return c==a.l&&d==a.g?a:new xu(c,d,!1,d==a.g?a.reason:b.reason)};
Du=function(a){var b=a.g||a.l;return Pb(dfa,function(a){return g.jt[a]==b})||"auto"};
Eu=function(a,b){var c=g.jt[b];return a.l<=c&&(!a.g||a.g>=c)};
Fu=function(a,b,c,d,e,f,k,l){this.duration=c;this.endTime=b+c;this.ingestionTime=d;this.vb=a;this.sourceURL=e;this.startTime=b;this.l=k||0;this.range=f||null;this.g=l||!1};
g.Gu=function(){this.segments=[]};
Hu=function(a,b){if(b>a.rb())a.segments=[];else{var c=g.Ia(a.segments,function(a){return a.vb>=b},a);
0<c&&a.segments.splice(0,c)}};
Iu=function(a,b,c,d,e){e=void 0===e?!1:e;this.data=a;this.offset=b;this.size=c;this.type=d;this.g=e?0:8;this.dataOffset=this.offset+this.g;this.l=e};
Ju=function(a){var b=a.data.getUint8(a.offset+a.g);a.g+=1;return b};
Ku=function(a){var b=a.data.getInt32(a.offset+a.g);a.g+=4;return b};
Lu=function(a){var b=a.data.getUint32(a.offset+a.g);a.g+=4;return b};
Mu=function(a){var b=a.data;var c=a.offset+a.g;b=4294967296*b.getUint32(c)+b.getUint32(c+4);a.g+=8;return b};
Nu=function(a,b){b=void 0===b?window.NaN:b;if((0,window.isNaN)(b))var c=a.size;else for(c=a.g;c<a.size&&a.data.getUint8(a.offset+c)!=b;)++c;var d=new window.Uint8Array(a.data.buffer,a.offset+a.g,c-a.g);a.g=Math.min(c+1,a.size);return String.fromCharCode.apply(String,d)};
Ou=function(a){this.data=new window.DataView(new window.ArrayBuffer(a));this.g=0};
Pu=function(a,b){a.data.setInt32(a.g,b);a.g+=4};
Qu=function(a,b){for(var c=0;c+4<=b.size;)Pu(a,b.data.getUint32(b.offset+c)),c+=4;for(;c<b.size;)a.data.setUint8(a.g++,b.data.getUint8(b.offset+c++))};
Ru=function(a,b,c,d,e,f){this.g=a;this.durationSecs=b;this.context=c;this.identifier=d;this.event=e;this.l=f};
Tu=function(a,b,c){this.g=a;this.uri=b||"http://youtube.com/streaming/metadata/segment/102015";this.A=void 0===c?null:c;this.l=Su(this,"Sequence-Number");this.H=Su(this,"Segment-Count");this.J=this.g["Segment-Durations-Ms"]||"";this.ingestionTime=Su(this,"Ingestion-Walltime-Us")/1E6;this.o=(Su(this,"First-Frame-Time-Us")+Su(this,"First-Frame-Uncertainty-Us"))/1E6;this.G=Su(this,"Target-Duration-Us")/1E6;this.F="T"==this.g["Overlayed-With-Slate"];this.C="T"==this.g["Stream-Finished"];this.B="T"==this.g.Streamable};
Su=function(a,b){return(0,window.parseInt)(a.g[b],10)||0};
Uu=function(a,b,c,d,e){this.l=a||0;this.pitch=b||0;this.yaw=c||0;this.roll=d||0;this.g=e;e.getUint32(4)};
Vu=function(a){var b={};a=a.split("\r\n");for(var c=0;c<a.length;c++){if(0==a[c].length)return b;var d=a[c].match(/([^:]+):\s+([\S\s]+)/);null!=d&&(b[d[1]]=d[2])}return null};
ffa=function(a,b,c){var d=Wu(a,0,1836019558);if(!d)return null;var e=Wu(a,d.dataOffset,1835427940),f=Wu(a,d.dataOffset,1953653094),k=efa(a,d.dataOffset);if(!e||!f)return null;var l=Wu(a,f.dataOffset,1952868452),m=Wu(a,f.dataOffset,1953658222),n=Wu(a,f.dataOffset,1952867444);if(!l||!m||!n)return null;var p=Wu(a,f.dataOffset,1935763823),u=Wu(a,f.dataOffset,1935763834),x=0;if(p){x=Ku(p);var B=Ku(p);if(0!=x||1!=B)return null;x=Ku(p)}B=Wu(a,f.dataOffset,1935828848);f=Wu(a,f.dataOffset,1936158820);var F=
Ku(l),H=Ku(l),Q=F&2,O=F&1?Mu(l):0,ab=Q?Ku(l):0,Cb=F&8?Ku(l):0,de=F&16?Ku(l):0,ng=F&32?Ku(l):0;F=Ku(m);var Ub=F&1,ve=F&4,dh=F&256;l=F&512;var ul=F&1024,hfa=F&2048;F=Ku(m);var ifa=Ub?Ku(m):0,jfa=ve?Ku(m):0;Ub=[];for(var qW=[],SG=[],TG=[],rW=0,ee=0,Ur=0;Ur<F;Ur++){var kfa=dh?Ku(m):Cb;l&&Ub.push(Ku(m));var co=ng;ve&&0==Ur?co=jfa:ul&&(co=Ku(m));qW.push(co);co=hfa?Ku(m):0;0==Ur&&(rW=co);SG.push(ee+co);TG.push(Ur);ee+=kfa}1<=Math.abs(ee-b)&&c({flaw:"segDurMismatch",dts:ee.toFixed(),seg:b.toFixed()});g.bb(TG,
function(a,b){return SG[a]-SG[b]});
c=[];for(ee=0;ee<F;ee++)c[TG[ee]]=ee;ee=Q?4:0;ng=16*F;ve=Aj(k,function(a,b){return a+b.size},0);
dh=68+ee+n.size+ng+(p?p.size:0)+(u?u.size:0)+(B?B.size:0)+(f?f.size:0)+ve;Cb=dh-d.size;m=new Ou(dh+d.offset);d.offset&&m.wl(a,0,d.offset);Pu(m,dh);Pu(m,1836019558);Qu(m,e);Pu(m,dh-24-ve);Pu(m,1953653094);Pu(m,16+ee);Pu(m,1952868452);Pu(m,131072|(Q?2:0));Pu(m,H);Q&&Pu(m,ab);Qu(m,n);Pu(m,20+ng);Pu(m,1953658222);Pu(m,16781057);Pu(m,F);Pu(m,O+ifa+Cb);for(a=ee=0;a<F;a++)e=c[a],d=Math.round(b*e/F),e=Math.round(b*(e+1)/F)-d,d=d-ee+rW,Pu(m,e),Pu(m,l?Ub[a]:de),Pu(m,qW[a]),Pu(m,d),ee+=e;p&&(Pu(m,p.size),Pu(m,
1935763823),Pu(m,0),Pu(m,1),Pu(m,x+Cb));u&&Qu(m,u);B&&Qu(m,B);f&&Qu(m,f);b=g.q(k);for(k=b.next();!k.done;k=b.next())Qu(m,k.value);return m.data.buffer};
Xu=function(a,b){var c=Wu(a.data,a.dataOffset,1952868452),d=Wu(a.data,a.dataOffset,1953658222),e=Ku(c);Ku(c);e&2&&Ku(c);c=e&8?Ku(c):0;var f=Ku(d),k=f&1;e=f&4;var l=f&256,m=f&512,n=f&1024;f&=2048;var p=Lu(d);k&&Ku(d);e&&Ku(d);for(var u=k=0;u<p;u++){var x=l?Ku(d):c;m&&Ku(d);e&&0==u||!n||Ku(d);f&&Ku(d);k+=x}return k/b};
$u=function(a){a=new window.DataView(a.buffer,a.byteOffset,a.byteLength);return(a=g.Yu(a,1836476516))?Zu(a):window.NaN};
gfa=function(a){var b=g.Yu(a,1937011556);if(!b)return null;b=Wu(a,b.dataOffset+8,1635148593);if(!b)return null;var c=Wu(a,b.dataOffset+78,1936995172),d=Wu(a,b.dataOffset+78,1937126244);if(!d)return null;b=null;if(c)switch(c.skip(4),Ju(c)){default:b=0;break;case 1:b=2;break;case 2:b=1;break;case 3:b=255}var e=c=null,f=null;if(d=Wu(a,d.dataOffset,1886547818)){var k=Wu(a,d.dataOffset,1886546020),l=Wu(a,d.dataOffset,2037673328);if(!l&&(l=Wu(a,d.dataOffset,1836279920),!l))return null;k&&(k.skip(4),c=Ku(k)/
65536,f=Ku(k)/65536,e=Ku(k)/65536);a=new window.DataView(l.data.buffer,l.dataOffset,l.size-8);return new Uu(b,c,f,e,a)}return null};
Wu=function(a,b,c){for(;av(a,b);){var d=bv(a,b);if(d.type==c)return d;b+=d.size}return null};
g.Yu=function(a,b){for(var c=0;av(a,c);){var d=bv(a,c);if(d.type==b)return d;c=cv(d.type)?c+8:c+d.size}return null};
dv=function(a,b){if(a.data.getUint8(a.dataOffset)){var c=a.data,d=a.dataOffset+4;c.setUint32(d,Math.floor(b/4294967296));c.setUint32(d+4,b&4294967295)}else a.data.setUint32(a.dataOffset+4,b)};
ev=function(a){if(a.data.getUint8(a.dataOffset)){var b=a.data;a=a.dataOffset+4;return 4294967296*b.getUint32(a)+b.getUint32(a+4)}return a.data.getUint32(a.dataOffset+4)};
bv=function(a,b){var c=a.getUint32(b),d=a.getUint32(b+4);return new Iu(a,b,c,d)};
Zu=function(a){var b=a.data.getUint8(a.dataOffset)?20:12;return a.data.getUint32(a.dataOffset+b)};
fv=function(a){a=new Iu(a.data,a.offset,a.size,a.type,a.l);var b=Ju(a);a.skip(7);var c=Lu(a);if(0==b){b=Lu(a);var d=Lu(a)}else b=Mu(a),d=Mu(a);a.skip(2);var e=a.data.getUint16(a.offset+a.g);a.g+=2;for(var f=[],k=[],l=0;l<e;l++){var m=Lu(a);f.push(m);k.push(Lu(a));a.skip(4)}return{Mr:c,eC:b,qu:d,jr:f,wk:k}};
gv=function(a){return a.data.getUint32(a.dataOffset+8)};
av=function(a,b){if(8>a.byteLength-b)return!1;var c=a.getUint32(b);if(8>c||a.byteLength-b<c)return!1;c=a.getUint32(b+4);if(1635148593==c||1635148611==c||1937126244==c||1936995172==c)return!0;for(c=4;8>c;c++){var d=a.getInt8(b+c);if(97>d||122<d)return!1}return!0};
cv=function(a){return 1701082227==a||1836019558==a||1836019574==a||1835297121==a||1835626086==a||1937007212==a||1953653094==a||1953653099==a};
hv=function(a){return(a=Wu(a,0,1836019558))?a.offset+a.size:null};
iv=function(a,b){for(var c=Wu(a,0,b);c;){var d=c;d.type=1936419184;d.data.setUint32(d.offset+4,1936419184);c=Wu(a,c.offset+c.size,b)}};
efa=function(a,b){for(var c=[];av(a,b);){var d=bv(a,b);1886614376==d.type&&c.push(d);b+=d.size}return c};
jv=function(a,b){for(var c=0,d=[];av(a,c);){var e=bv(a,c);e.type==b&&d.push(e);c=cv(e.type)?c+8:c+e.size}return d};
kv=function(a){for(var b=new window.Uint8Array(a.length),c=0;c<a.length;c++)b[c]=a.charCodeAt(c);return b};
lv=function(a){return String.fromCharCode.apply(null,a)};
mv=function(a,b){this.l=a;this.g=0;this.o=b||0};
nv=function(a){return a.g>=a.l.byteLength};
tv=function(a,b){var c=new mv(b);if(!ov(c,[408125543,374648427,174,224]))return!1;c=pv(c);if(qv(c,a)){for(var d=0;a;)a>>>=8,d++;var e=c.o+c.g-d;d=rv(c,!0)+d-1;var f;f||(f=Math.ceil(Math.log(d+2)/Math.log(2)/7));var k=1<<8-f;for(c=[];c.length<f-1;)c.unshift(d%256),d=Math.floor(d/256);c.unshift(d|k);b.setUint8(e,236);for(f=0;f<c.length;f++)b.setUint8(e+1+f,c[f]);return!0}return!1};
vv=function(a){uv(new mv(a));tv(30320,a)&&tv(21432,a)};
lfa=function(a){var b=new mv(a);uv(b);if(ov(b,[408125543,374648427,174,224]))b=pv(b);else return null;for(var c=a=null;!nv(b);){var d=rv(b,!1);if(21432==d)switch(wv(b)){default:a=0;break;case 1:a=1;break;case 3:a=2;break;case 15:a=255}else 30320==d?c=pv(b):xv(b)}if(!c)return null;for(var e,f=d=b=null;!nv(c);)switch(rv(c,!1)){case 30321:if(3!=wv(c))return null;break;case 30324:b=yv(c);break;case 30323:f=yv(c);break;case 30325:d=yv(c);break;case 30322:e=rv(c,!0);e=zv(c,e);e=new window.DataView(e.buffer,
e.byteOffset,e.byteLength);break;default:xv(c)}return e?new Uu(a,b,f,d,e):null};
pv=function(a){var b=rv(a,!0),c=a.l.byteOffset+a.g;c=new window.DataView(a.l.buffer,c,Math.min(b,a.l.buffer.byteLength-c));c=new mv(c,a.o+a.g);a.g+=b;return c};
wv=function(a){for(var b=rv(a,!0),c=Av(a),d=1;d<b;d++)c=256*c+Av(a);return c};
yv=function(a){var b=rv(a,!0),c=0;4==b?c=a.l.getFloat32(a.g):8==b&&(c=a.l.getFloat64(a.g));a.g+=b;return c};
Bv=function(a){var b=rv(a,!0);return lv(zv(a,b))};
xv=function(a){var b=rv(a,!0);a.g+=b};
uv=function(a){var b=a.g;a.g=0;var c=!1;qv(a,440786851)&&(a.g=0,qv(a,408125543)&&(c=!0));a.g=b;return c};
Cv=function(a){var b=a.g;a.g=0;var c=1E6;ov(a,[408125543,357149030,2807729])&&(c=wv(a));a.g=b;return c};
mfa=function(a,b){var c=a.g;a.g=0;if(!Dv(a)||!qv(a,160))return a.g=c,window.NaN;rv(a,!0);var d=a.g;if(!qv(a,161))return a.g=c,window.NaN;rv(a,!0);Av(a);var e=Av(a)<<8|Av(a);a.g=d;if(!qv(a,155))return a.g=c,window.NaN;d=wv(a);a.g=c;return(e+d)*b/1E9};
Dv=function(a){if(!Ev(a)||!qv(a,524531317))return!1;rv(a,!0);return!0};
Ev=function(a){if(uv(a)){if(!qv(a,408125543))return!1;rv(a,!0)}return!0};
ov=function(a,b){for(var c=0;c<b.length;c++){if(!qv(a,b[c]))return!1;c!=b.length-1&&rv(a,!0)}return!0};
qv=function(a,b,c){c=void 0===c?!1:c;if(nv(a))return!1;for(var d=a.g;rv(a,!1)!=b;)if(xv(a),d=a.g,nv(a))return!1;c&&(a.g=d);return!0};
rv=function(a,b){var c=Av(a);if(1==c){for(var d=c=0;7>d;d++)c=256*c+Av(a);return c}d=128;for(var e=0;6>e&&d>c;e++)c=256*c+Av(a),d*=128;return b?c-d:c};
Av=function(a){return a.l.getUint8(a.g++)};
zv=function(a,b){var c=new window.Uint8Array(a.l.buffer,a.l.byteOffset+a.g,b);a.g+=b;return c};
g.Fv=function(a,b){this.start=a;this.end=b;this.length=b-a+1};
Gv=function(a){a=a.split("-");return 2==a.length&&(a=new g.Fv((0,window.parseInt)(a[0],10),(0,window.parseInt)(a[1],10)),!(0,window.isNaN)(a.start)&&!(0,window.isNaN)(a.end)&&!(0,window.isNaN)(a.length)&&0<a.length)?a:null};
Hv=function(a,b){return new g.Fv(a,a+b-1)};
Jv=function(a,b,c,d,e,f,k,l,m,n){this.g=b;this.range=c;this.type=a;this.F="";this.l=-1;this.F=d;this.l=0<=e?e:-1;this.startTime=f||0;this.duration=k||0;this.o=l||0;this.Na=0<=m?m:this.range?this.range.length:window.NaN;this.G=!!n;this.range?(this.A=this.o+this.Na==this.range.length,this.C=this.startTime+this.duration*this.o/this.range.length,this.H=this.duration*this.Na/this.range.length,this.B=this.C+this.H):(this.A=0!=this.Na,Iv(this));this.J=[]};
Iv=function(a){a.C=a.startTime;a.H=a.duration;a.B=a.C+a.H};
nfa=function(a,b,c){var d=!(!b||b.g!=a.g||b.type!=a.type||b.l!=a.l);return c?d&&(a.range&&b.range?b.range.end==a.range.end:b.range==a.range)&&b.o+b.Na==a.o+a.Na:d};
Kv=function(a){return 1==a.type||2==a.type};
Lv=function(a,b,c){return c||a.g==b.g?a.range&&b.range?a.range.start+a.o+a.Na==b.range.start+b.o:a.l==b.l?a.o+a.Na==b.o:a.l+1==b.l&&0==b.o&&a.A:!1};
Mv=function(a,b){return Lv(a,b)||1E-6>=Math.abs(a.B-b.C)||a.l+1==b.l&&0==b.o&&a.A?!0:!1};
ofa=function(a){1==a.length||(0,g.em)(a,function(a){return!!a.range});
for(var b=1;b<a.length;b++);b=a[a.length-1];return new g.Fv(a[0].range.start+a[0].o,b.range.start+b.o+b.Na-1)};
Ov=function(a){var b="";g.Bb(Nv(a),function(a,d){b+=d+"="+a+","});
return b.slice(0,-1)};
Nv=function(a){var b={};b.itag=g.ot(a.g.info);b.type=a.type;b.seg=String(a.l);a.range&&(b.range=""+(a.range.start+a.o)+"-"+(a.range.start+a.o+a.Na-1));b.time=""+a.C.toFixed(1)+"-"+(a.C+a.H).toFixed(1);b.off=String(a.o);b.len=String(a.Na);a.A&&(b.end="1");a.G&&(b.eos="1");return b};
Pv=function(a,b,c,d){a=new Jv(a.type,a.g,a.range,"reslice_"+a.F,a.l,a.startTime,a.duration,b,c,d&&a.G);a.A=d;return a};
Qv=function(a,b){var c=b.l;a.F="updateWithEmsg";a.l=c;b.C&&(a.G=b.C)};
Rv=function(a,b){var c=b.vb;a.F="updateWithSegmentInfo";a.l=c;if(a.startTime!=b.startTime||a.duration!=b.duration)a.startTime=b.startTime,a.duration=b.duration,Iv(a)};
Sv=function(a,b,c,d,e){this.info=a;this.g=b;this.range=c;this.l=null;this.A=d;this.o=e};
Tv=function(a){return a.range?new window.DataView(a.g,a.range.start,a.range.length):new window.DataView(a.g)};
Uv=function(a){if(a.g.slice)return new window.Uint8Array(a.g.slice(a.range.start,a.range.end+1));a=new window.Uint8Array(a.g,a.range.start,a.range.end+1);return new window.Uint8Array(a)};
Vv=function(a,b){b=Math.min(b,a.info.Na);var c=new Jv(a.info.type,a.info.g,a.info.range,"splitSlice1_"+a.info.F,a.info.l,a.info.startTime,a.info.duration,a.info.o,b,!1);c.A=!1;var d=Hv(a.range.start,b);c=new Sv(c,a.g,d,a.A,a.o);var e=new Jv(a.info.type,a.info.g,a.info.range,"splitSlice2_"+a.info.F,a.info.l,a.info.startTime,a.info.duration,a.info.o+b,a.info.Na-b,a.info.G);e.A=a.info.A;d=new g.Fv(d.end+1,a.range.end);d=new Sv(e,a.g,d,a.A,!1);return[c,d]};
Wv=function(a){if(g.tt(a.info.g.info)){var b=a.info.g.g;for(var c=window.NaN,d=window.NaN,e=0,f=new window.DataView(a.g);av(f,e);){var k=bv(f,e);1936286840==k.type?d=gv(k):1836476516==k.type?d=Zu(k):1952867444==k.type&&(0,window.isNaN)(c)&&(c=ev(k));e=cv(k.type)?e+8:e+k.size}!d&&b&&(d=$u(b));b=c/d}else b=new mv(Tv(a)),c=a.o?b:new mv(new window.DataView(a.info.g.g.buffer)),d=Cv(c),c=b.g,b.g=0,Dv(b)?qv(b,231)?(d=wv(b)*d/1E9,b.g=c,b=d):(b.g=c,b=window.NaN):(b.g=c,b=window.NaN);return b||a.info.C};
Xv=function(a,b){if(g.tt(a.info.g.info)){for(var c=a.info.g.g,d=new window.DataView(a.g),e=window.NaN,f=window.NaN,k=0;av(d,k);){var l=bv(d,k);(0,window.isNaN)(e)&&(1936286840==l.type?e=gv(l):1836476516==l.type&&(e=Zu(l)));if(1952867444==l.type){!e&&c&&(e=$u(c));var m=ev(l);(0,window.isNaN)(f)&&(f=Math.round(b*e)-m);dv(l,m+f)}k=cv(l.type)?k+8:k+l.size}return!0}c=new mv(new window.DataView(a.g));e=a.o?c:new mv(new window.DataView(a.info.g.g.buffer));d=b;f=Cv(e);e=c.g;c.g=0;if(Dv(c)&&qv(c,231))if(k=
rv(c,!0),d=Math.floor(1E9*d/f),Math.ceil(Math.log(d)/Math.log(2)/8)>k)c=!1;else{for(f=k-1;0<=f;f--)c.l.setUint8(c.g+f,d&255),d>>>=8;c.g=e;c=!0}else c=!1;return c};
Yv=function(a){if(g.tt(a.info.g.info)){var b=0;var c=new window.DataView(a.g);c=jv(c,1936286840);c=g.q(c);for(var d=c.next();!d.done;d=c.next())d=fv(d.value),b+=d.wk[0]/d.Mr;b=b||window.NaN;if(!(0<=b))a:{b=a.info.g.g;c=0;d=new window.DataView(a.g);for(var e,f=0;av(d,c);){var k=bv(d,c);if(1836476516==k.type)e=Zu(k);else if(1836019558==k.type){!e&&b&&(e=$u(b));if(!e){b=window.NaN;break a}var l=Wu(k.data,k.dataOffset,1953653094);f+=Xu(l,e)}c=cv(k.type)?c+8:c+k.size}b=f||window.NaN}}else e=new mv(new window.DataView(a.g)),
b=a.o?e:new mv(new window.DataView(a.info.g.g.buffer)),b=mfa(e,Cv(b));return b||a.info.H};
Zv=function(a){return g.tt(a.info.g.info)?a.l?a.l.F&&!!Wu(new window.DataView(a.g),0,1718909296):!1:uv(new mv(new window.DataView(a.g)))};
$v=function(a){var b;if(g.tt(a.info.g.info)){var c=Tv(a);if(b=Wu(c,0,1701671783)){b.skip(4);c=Nu(b,0);Nu(b,0);Lu(b);Lu(b);Lu(b);Lu(b);var d=Nu(b);b=b.offset;c=(d=Vu(d))?new Tu(d,c,b):null}else c=null}else{c=new mv(Tv(a));b=c.g;c.g=0;var e=d=null;if(ov(c,[408125543,307544935,29555,26568]))for(var f=pv(c);!nv(f);){var k=rv(f,!1);17543==k?e=Vu(Bv(f)):17827==k?d=Bv(f):xv(f)}c.g=b;c=e?new Tu(e,d):null}a.l=c};
g.aw=function(){this.xA=this.uA=!1;this.vv=2;this.B=20971520;this.C=8388608;this.o=window.NaN;this.ga=3145728;this.L=62914560;this.ka=10485760;this.Fx=this.pa=0;this.G=window.NaN;this.Qd=0;this.ie=this.Ys=2;this.Ia=3;this.Of=!1;this.rs=2;this.Fc=25;this.O=2097152;this.qs=1048576;this.Z=!1;this.H=1800;this.Cb=5;this.Wb=10;this.nb=15;this.ab=1;this.l=1.15;this.A=1.05;this.Zy=8;this.mz=!0;var a;!(a=g.Kp("xboxone"))&&(a=Sp())&&(a=/WebKit\/([0-9]+)/.exec(g.zb),a=!(a&&602<=(0,window.parseInt)(a[1],10)));
this.HB=a||Mp();this.Oc=!1;this.xs=!0;this.Nc=this.zc=this.F=!1;this.ts=.8;this.sc=!1;this.ms=!0;this.R=this.Qk=!1;this.fv=25;this.IB=this.os=!1;this.oa=6;this.Uk=this.ba=!1;this.Fd=.5;this.he=this.Ta=!1;this.Mb=0;this.Ik=this.az=!1;this.Mc=0;this.Vk=!1;this.Is=2;this.Ca=5E3;this.da=this.T=!1;this.J=.5;this.Ya=2;this.Va=this.Fs=0;this.Gs=1.5;this.Hs=this.fd=.5;this.Oa=this.Bl=!1;this.ob=15;this.yb=1;this.uu=!0;this.ws=this.Sz=this.sa=this.Mk=!1;this.uv=0;this.As=this.Jk=this.PA=this.Tk=this.ed=this.Bs=
this.AA=this.yA=this.iA=!1;this.Rk=1;this.Sk=0;this.Pk=this.Cs=this.Y=this.g=!1;this.cd=0;this.Ws=this.fl=this.ge=this.ct=this.ha=this.dd=this.wa=this.Es=this.Lc=this.Ja=this.xh=!1;this.Cx=0;this.Nf=this.Lk=this.Xs=this.xg=this.Ok=this.ys=this.zs=this.preferLowQualityAudio=this.Kk=this.Ks=this.Ts=this.Nk=this.Cc=this.X=!1};
pfa=function(a,b){1080<b.za().g&&!a.uA&&(a.B=36700160,a.C=5242880,a.ga=10485760,a.O=4194304,a.uA=!0);2160<b.za().g&&!a.xA&&(a.B=104857600,a.G=13107200,a.xA=!0);a.qs=Math.max(65536,Math.min(a.O,5*b.g))};
qfa=function(){this.A=this.g=this.l=this.o=this.B=0};
bw=function(a,b){a[b]||(a[b]=new qfa);return a[b]};
dw=function(a){a=a.split("");cw.zP(a,18);cw.ZF(a,2);cw.zP(a,6);cw.ZF(a,2);cw.pL(a,72);return a.join("")};
g.ew=function(a){this.A=a;this.B=this.l=this.C="";this.g={};this.o=""};
gw=function(a){fw(a);return a.B};
hw=function(a){fw(a);return Fb(a.g,function(a){return null!==a})};
jw=function(a){fw(a);if("/videoplayback"!=a.l){var b=a.clone();b.set("playerfallback","1");return b}var c=a.Ib();b=new g.um(c);if(iw){var d=a.get("fvip");a=(0,window.decodeURIComponent)(a.get("mn")||"").split(",");if(d&&a&&1<a.length&&a[1])return c=b.g.replace(/^[^.]*/,""),g.wm(b,"r"+d+"---"+a[1]+c),b=new g.ew(b.toString()),b.set("fallback_count","1"),b}d=b.g.match("\\.a1\\.googlevideo\\.com$");b.g.match("\\.googlevideo\\.com$")?(g.wm(b,"redirector.googlevideo.com"),c=b.toString()):b.g.match("r[1-9].*\\.c\\.youtube\\.com$")?
(g.wm(b,"www.youtube.com"),c=b.toString()):c=Es(c);b=new g.ew(c);b.set("cmo=pf","1");d&&b.set("cmo=td","a1.googlevideo.com");return b};
fw=function(a){if(a.A){if(!As(a.A))throw Error("Untrusted URL: "+a.A);var b=g.Dm(a.A);a.C=b.A;a.B=b.g+(null!=b.B?":"+b.B:"");var c=b.l;if(0==c.indexOf("/videoplayback"))a.l="/videoplayback",c=c.substr(14);else if(0==c.indexOf("/api/manifest")){var d=c.indexOf("/",12),e=c.indexOf("/",d+1);0<d&&0<e?(a.l=c.substr(0,e),c=c.substr(e+1)):(a.l=c,c="")}else a.l=c,c="";d=a.g;a.g=kw(c);g.Fa(a.g,lw(b.o.toString()));g.Fa(a.g,d);"index.m3u8"==a.g.file&&(delete a.g.file,a.l+="/file/index.m3u8");a.A="";a.o=""}};
rfa=function(a){fw(a);var b=a.C+(a.C?"://":"//")+a.B+a.l;if(hw(a)){var c=[];g.Bb(a.g,function(a,b){null!==a&&c.push(b+"="+a)});
b+="?"+c.join("&")}return b};
kw=function(a){a=a.split("/");var b=0;a[0]||b++;for(var c={};b<a.length;b+=2)a[b]&&mw(c,a[b],a[b+1]);return c};
lw=function(a){a=a.split("&");for(var b={},c=0;c<a.length;c++){var d=a[c],e=d.indexOf("=");0<e?mw(b,d.substr(0,e),d.substr(e+1)):d&&(b[d]="")}return b};
mw=function(a,b,c){if("cmo"==b){var d;0<=(d=c.indexOf("="))?(b="cmo="+c.substr(0,d),c=c.substr(d+1)):0<=(d=c.indexOf("%3D"))&&(b="cmo="+c.substr(0,d),c=c.substr(d+3))}a[b]=c};
nw=function(a){this.g=a;this.l={};this.o=""};
sfa=function(a,b){var c=b.indexOf("?");if(0<c){var d=lw(b.substr(c+1));g.Bb(d,function(a,b){this.set(b,a)},a);
b=b.substr(0,c)}c=kw(b);g.Bb(c,function(a,b){this.set(b,a)},a)};
tfa=function(a){var b=a.g.Ib(),c=[];g.Bb(a.l,function(a,b){c.push(b+"="+a)});
if(!c.length)return b;var d=c.join("&");a=hw(a.g)?"&":"?";return b+a+d};
ow=function(a,b){var c=new g.ew(b),d=c.get("req_id");d&&a.set("req_id",d);g.Bb(a.l,function(a,b){c.set(b,null)});
return c};
ufa=function(a){this.B=a.clone();this.o=a;this.l=null;this.A=this.g=0};
qw=function(a,b,c){var d=bw(c,gw(a.o));if(d.l>=b.Is||1<=d.g)if(a=pw(a),c=bw(c,gw(a)),c.l+c.g<=d.l+d.g)return!0;return!1};
g.rw=function(a,b){var c=b?pw(a):a.o;return new nw(c)};
pw=function(a){a.l||(a.l=jw(a.B));return a.l};
tw=function(a){return 1<a.g?a.A+1E3*Math.pow(1.6,a.g-1)<g.qr():!0};
g.uw=function(a,b,c){b.g===a.o&&(a.o=ow(b,c));b.g===a.l&&(a.l=ow(b,c))};
vw=function(a,b){this.l=a[0].g.A;this.A=b||"";this.g=a;this.range=this.g[0].range&&0<this.g[0].Na?ofa(this.g):null;this.B=this.o=window.NaN;this.C=this.requestId=null};
ww=function(a){return!Kv(a.g[a.g.length-1])};
xw=function(a){return Kv(a.g[0])};
yw=function(a){return 4==a.g[a.g.length-1].type};
g.zw=function(a,b,c,d){/http[s]?:\/\//.test(a.A)?b=new nw(new g.ew(a.A)):(b=null===a.C?qw(a.l,b,c):a.C,b=g.rw(a.l,b),a.A&&sfa(b,a.A));(d=d||a.range)&&b.set("range",d.toString());a.requestId&&b.set("req_id",a.requestId);(0,window.isNaN)(a.o)||b.set("headm",a.o.toString());(0,window.isNaN)(a.B)||b.set("mffa",a.B+"ms");return b};
Aw=function(a){if(a.range)return a.range.length;a=a.g[0];return Math.round(a.H*a.g.info.g)};
vfa=function(a,b,c){return a.range?new g.Fv(a.range.start+b,a.range.end):Hv(b,c)};
Bw=function(a,b,c){this.info=b;this.initRange=c||null;this.G=this.g=null;this.C=!1;this.B=null;this.J=0;this.A=new ufa(a);this.o=null;this.L=window.NaN};
Cw=function(a,b){a.info&&a.info.video&&4==a.info.video.projectionType&&!a.o&&(g.tt(a.info)?a.o=gfa(b):2==a.info.containerType&&(a.o=lfa(b)))};
Dw=function(a,b,c,d,e,f){f=void 0===f?0:f;Bw.call(this,a,b,d);this.index=e||new g.Gu;this.F=f;this.O=c;this.H=!0;if(this.l=!c)this.C=!0};
Ew=function(a,b,c,d,e){e=void 0===e?window.Infinity:e;this.segments=[];this.g=a;this.B=void 0===b?0:b;this.l=void 0===c?!1:c;this.o=-1;this.A=void 0===d?0:d;this.C=e};
Gw=function(a,b,c){b=Fw(a,b);return 0<=b&&(c||!a.segments[b].g)};
Hw=function(a){return a.segments.length?a.segments[a.segments.length-1]:null};
Fw=function(a,b){return g.Za(a.segments,{vb:b},function(a,b){return a.vb-b.vb})};
Iw=function(a,b,c){return new Fu(b,Math.max(0,c.startTime-(c.vb-b)*a.g),a.g,0,"sq/"+b,void 0,void 0,!0)};
Jw=function(a,b,c,d,e,f,k){d=void 0===d?!1:d;e=void 0===e?14400:e;f=void 0===f?0:f;k=void 0===k?window.Infinity:k;Dw.call(this,a,b,"",void 0,void 0,c);this.index=new Ew(c||0,e,d,f,k)};
wfa=function(a,b,c,d,e){this.vb=a;this.g=b;this.durationSecs=c;this.l=d||window.NaN;this.o=e||window.NaN};
Kw=function(a,b,c){for(;a;a=a.parentNode)if(a.attributes&&(!c||a.nodeName==c)){var d=a.getAttribute(b);if(d)return d}return""};
Lw=function(a,b){for(var c=a;c;c=c.parentNode){var d=c.getElementsByTagName(b);if(0<d.length)return d[0]}return null};
Mw=function(a){if(!a)return 0;var b=a.match(/PT(([0-9]*)H)?(([0-9]*)M)?(([0-9.]*)S)?/);return b?3600*(0,window.parseFloat)(b[2]||0)+60*(0,window.parseFloat)(b[4]||0)+(0,window.parseFloat)(b[6]||0):(0,window.parseFloat)(a)};
Nw=function(a){return a.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.(\d{3})$/)?a+"Z":a};
Ow=function(){this.g=[];this.l=null;this.B=0;this.A=[];this.o=!1;this.C=""};
xfa=function(a){var b=a.A;a.A=[];return b};
yfa=function(){this.A=[];this.g=null;this.l={};this.o={}};
Cfa=function(a,b,c){var d=[];b=Array.from(b.getElementsByTagName("SegmentTimeline"));b=g.q(b);for(var e=b.next();!e.done;e=b.next()){e=e.value;var f=e.parentNode.parentNode,k=null;"Period"==f.nodeName?k=zfa(a):"AdaptationSet"==f.nodeName?k=Afa(a,f.attributes.id?f.attributes.id.value:f.attributes.mimetype.value):"Representation"==f.nodeName&&(k=Bfa(a,f.attributes.id.value));if(null==k)return;k.update(e,c);Ua(d,xfa(k))}Ua(a.A,d);jaa(a.A,function(a){return 1E3*a.g+a.l})};
Dfa=function(a){a.g&&(a.g.g=[]);g.Bb(a.l,function(a){a.g=[]});
g.Bb(a.o,function(a){a.g=[]})};
zfa=function(a){a.g||(a.g=new Ow);return a.g};
Afa=function(a,b){a.l[b]||(a.l[b]=new Ow);return a.l[b]};
Bfa=function(a,b){a.o[b]||(a.o[b]=new Ow);return a.o[b]};
Pw=function(a,b,c,d,e){Bw.call(this,a,b,d||void 0);this.index=new g.Gu;this.indexRange=e;this.l=c};
Qw=function(a,b,c){var d=a.index.Ho(b),e=a.index.od(b),f=a.index.Df(b),k;c?f=k=0:0<a.info.g&&(k=a.info.g*f);a=new Jv(3,a,null,"otfCreateRequestInfoForSegment",b,e,f,0,k,b==a.index.rb()&&0<k);return new vw([a],d)};
Efa=function(a,b){if(!a.index.Ob()){for(var c=[],d=b.H,e=b.J.split(",").filter(function(a){return 0<a.length}),f=0,k=0,l=0,m=/^(\d+)/,n=/r=(\d+)/,p=0;p<d;p++){if(0>=l)if(l=e.shift(),k=(k=m.exec(l))?+k[1]/1E3:0)l=(l=n.exec(l))?+l[1]:0,l+=1;
else return;c.push(new Fu(p,f,k,window.NaN,"sq/"+(p+1)));f+=k;l--}a.index.append(c)}};
g.Rw=function(){this.Ba=0;this.g=new window.Float64Array(128);this.l=new window.Float64Array(128);this.A=1;this.o=!1};
Sw=function(a){if(a.g.length<a.Ba+1){var b=2*a.g.length;b+=2;var c=a.g;a.g=new window.Float64Array(b+1);var d=a.l;a.l=new window.Float64Array(b+1);for(b=0;b<a.Ba+1;b++)a.g[b]=c[b],a.l[b]=d[b]}};
g.Tw=function(a,b,c,d,e,f){Bw.call(this,a,b,c||void 0);this.indexRange=d;this.F=null;this.index=new g.Rw;this.l=e;this.lastModified=f};
Uw=function(a,b,c,d){for(var e=[];b<=a.index.rb();b++){var f=a.index,k=b;f=Hv(f.zm(k),k+1<f.Ba||f.o?f.g[k+1]-f.g[k]:-1);k=a.index.od(b);var l=a.index.Df(b),m=Math.max(0,c-f.start),n=Math.min(f.end+1,c+d)-(f.start+m);e.push(new Jv(3,a,f,"getRequestInfoForRange_",b,k,l,m,n,b==a.index.rb()&&m+n==f.length));if(f.start+m+n>=c+d)break}return new vw(e)};
Ffa=function(a,b){return Vw(function(a,b){return g.$p(a,b,4,1E3)},a,b)};
g.Ww=function(a){var b;a.responseType&&"text"!=a.responseType?"arraybuffer"==a.responseType&&(b=lv(new window.Uint8Array(a.response))):b=a.responseText;return!b||2048<b.length?"":0==b.indexOf("https://")?b:""};
Vw=function(a,b,c){return a(b,c).then(function(b){var d=g.Ww(b);return d?Vw(a,d,c):b})};
Xw=function(a,b,c){a=void 0===a?"":a;b=void 0===b?null:b;c=void 0===c?!1:c;g.N.call(this);this.R=this.duration=0;this.xf=this.isLive=this.o=!1;this.J=g.qr();this.F=window.Infinity;this.g={};this.sourceUrl=a||"";this.C=this.O=0;this.B=null;this.da=!!b&&g.R(b,"html5_live_nonzero_first_segment_start_time");this.l=!1;this.L=[];this.ba=!!b&&g.R(b,"html5_live_self_init_segments");this.A=null;this.ga=c;this.X=!b||!g.R(b,"html5_manifest_without_credentials");this.G=0;this.T=!!b&&g.R(b,"disable_html5_manifest_namespace_redux");
this.Z="";this.H=window.NaN;this.Y=b&&g.R(b,"disable_html5_duration_caching")?window.Infinity:10};
Yw=function(a){return Fb(a.g,function(a){return!!a.info.Ec})};
Gfa=function(a){return Fb(a.g,function(a){return g.wt(a.info.mimeType)})};
Hfa=function(a){return g.Gb(a.g,function(a){return a.info.video?a.Sm():!0})};
Zw=function(a,b){a.g[b.info.id]=b};
ax=function(a,b,c,d,e,f){var k=Ifa(a);return d||e?Jfa(a,e,b,f):3==k&&$w?Kfa(a,b,c,f):Lfa(a,b,c,f)};
Lfa=function(a,b,c,d){c=void 0===c?0:c;var e=new Xw("",d,!1);e.duration=c||0;(0,g.C)(a,function(a){var c=bx(a,b,e.duration),d=Gv(a.init),f=Gv(a.index),n=(0,window.parseInt)(a.clen,10),p=cx(a.url,a.sp,a.s);a=(0,window.parseInt)(a.lmt,10);p&&Zw(e,new g.Tw(p,c,d,f,n,a))});
return e};
Kfa=function(a,b,c,d){c=void 0===c?0:c;var e=new Xw("",d,!1);e.duration=c||0;(0,g.C)(a,function(a){var c=bx(a,b,e.duration),d=cx(a.url,a.sp,a.s);if(g.tt(c)&&d)if(c.video&&3==c.video.streamType)Zw(e,new Pw(d,c,"sq/0",null,null));else{var f=Gv(a.init);a=Gv(a.index);Zw(e,new Pw(d,c,"",f,a))}});
return e};
Jfa=function(a,b,c,d){var e=new Xw("",d,!0);(0,g.C)(a,function(a){var f=bx(a,c),l=cx(a.url,a.sp,a.s),m=(0,window.parseInt)(a.target_duration_sec,10);a=(0,window.parseInt)(a.max_dvr_duration_sec,10)||14400;var n=(0,window.parseInt)(l.get("min_sq"),10)||0,p=(0,window.parseInt)(l.get("max_sq"),10)||window.Infinity,u=!g.wt(f.mimeType);l&&(d&&g.R(d,"html5_manifestless_post_live_exclude_placeholders")&&b&&20<p&&(p-=5),Zw(e,new Jw(l,f,m,d&&g.R(d,"html5_manifestless_interpolate")&&u,a,n,p)))});
e.o=!b;e.xf=!0;e.l=!0;e.isLive=!b;return e};
bx=function(a,b,c){c=void 0===c?0:c;var d=a.type,e=a.itag,f=Mfa(a),k=null,l=null;/(vp9|vp09|vp8|avc1|av01)/.test(d)&&(k=(a.size||"640x360").split("x"),k=new kt(+k[0],+k[1],+a.fps,+a.projection_type,+a.stereo_layout,void 0,!!a.isAccelerated,a.quality_label,a.eotf,a.primaries,!!a.isAcceleratedUiEnabled,+a.stream_type),d=Nfa(d,k));var m=null,n=null;vt(d)&&(m=new ht(+a.audio_sample_rate||void 0,Ofa[e]||0,+a.spatial_audio_type),a.name&&(n=new ct(a.name,a.audio_track_id,"1"==a.isDefault)));a.caption_display_name&&
a.caption_vss_id&&a.caption_language_code&&(l=new Tea(a.caption_display_name,a.caption_vss_id,a.caption_language_code,a.caption_kind));e=(0,window.parseInt)(a.bitrate,10)/8;var p=(0,window.parseInt)(a.clen,10);c=c&&p?p/c:0;var u=null;b&&a.drm_families&&(u={},(0,g.C)(a.drm_families.split(","),function(a){u[a]=b[a]}));
return new pt(f,d,m,k,n,u,e,c,l)};
Ifa=function(a){return(0,g.rj)(a,function(a){return 3==+a.stream_type})?3:0};
Mfa=function(a){var b=a.itag,c=a.xtags;c&&(b=a.itag+";"+c);return b};
dx=function(a,b){return a.B?g.Va(a.B.A,b):a.L.length?g.Va(a.L,b):[]};
cx=function(a,b,c){b=void 0===b?"":b;c=void 0===c?"":c;var d=new g.ew(a);a.match(/https:\/\/yt.akamaized.net/)||d.set("alr","yes");c&&d.set(b,(0,window.encodeURIComponent)(dw((0,window.decodeURIComponent)(c))));return d};
gx=function(a,b){var c=Kw(b,"id");c=c.replace(":",";");var d=Kw(b,"mimeType"),e=Kw(b,"codecs");d=e?d+'; codecs="'+e+'"':d;e=(0,window.parseInt)(Kw(b,"bandwidth"),10)/8;var f=(0,window.parseInt)(Lw(b,"BaseURL").getAttribute(ex(a,"contentLength")),10);f=a.duration&&f?f/a.duration:0;var k=null;if(/(vp9|vp09|vp8|avc1|av01)/.test(d)){k=(0,window.parseInt)(Kw(b,"width"),10);var l=(0,window.parseInt)(Kw(b,"height"),10),m=(0,window.parseInt)(Kw(b,"frameRate"),10),n=Pfa(Kw(b,ex(a,"projectionType")));a:switch(Kw(b,
ex(a,"stereoLayout"))){case "layout_left_right":var p=1;break a;case "layout_top_bottom":p=2;break a;default:p=0}Kw(b,"video_level");k=new kt(k,l,m,n,p,void 0,void 0,void 0,void 0,void 0,void 0)}m=l=null;if(vt(d))if(l=(0,window.parseInt)(Kw(b,"audioSamplingRate"),10),m=(0,window.parseInt)(Kw(b.getElementsByTagName("AudioChannelConfiguration")[0],"value"),10),n=Qfa(Kw(b,ex(a,"spatialAudioType"))),l=new ht(l,m,n),m=Kw(b,"lang")||"und",n=Lw(b,"Role")){var u=Kw(n,"value")||"";Mb(fx,u)?(n=m+"."+fx[u],
p="main"==u,m=Kw(b,ex(a,"langName"))||m+" - "+u,m=new ct(m,n,p)):m=null}else m=null;p=null;if(n=Lw(b,"ContentProtection"))if(g.Np())if((p=n.attributes.schemeIdUri)&&"http://youtube.com/drm/2012/10/10"==p.value)for(p={},n=n.firstChild;null!=n;n=n.nextSibling)"yt:SystemURL"==n.nodeName&&(p[n.attributes.type.value]=n.textContent.trim());else p=null;else if((p=n.attributes.schemeIdUri)&&"http://youtube.com/drm/2012/10/10"==p.textContent)for(p={},n=n.firstChild;null!=n;n=n.nextSibling)"SystemURL"==n.localName&&
"http://youtube.com/yt/2012/10/10"==n.namespaceURI&&(p[n.attributes.type.textContent]=n.textContent.trim());else p=null;return new pt(c,d,l,k,m,p,e,f)};
Pfa=function(a){switch(a){case "equirectangular":return 2;case "equirectangular_threed_top_bottom":return 3;case "mesh":return 4;case "rectangular":return 1;default:return 0}};
Qfa=function(a){switch(a){case "spatial_audio_type_ambisonics_5_1":return 1;case "spatial_audio_type_ambisonics_quad":return 2;case "spatial_audio_type_foa_with_non_diegetic":return 3;default:return 0}};
hx=function(a,b){b=void 0===b?"":b;a.C=1;a.J=g.qr();return g.bg(Ffa(b||a.sourceUrl,{format:"RAW",method:"GET",withCredentials:a.X}).then((0,g.z)(a.EC,a)),(0,g.z)(a.GC,a))};
ix=function(a,b){var c=new Xw,d;for(d in a)c[d]=g.Xb(a[d]);var e={},f=!1;g.Bb(a.g,function(a,c){if(a){var d=b(a,c);d?(e[c]=d,f=!0):e[c]=a}});
c.g=e;return f?c:null};
Rfa=function(a,b,c){var d=a.getAttribute("media"),e=null;c||(a=a.getAttribute("mediaRange"),null!=a&&(0<=(0,window.parseInt)(a.split("-")[1],10)?e=Gv(a):d=d+"?range="+a));return new Fu(b.vb,b.g,b.durationSecs,b.l,d,e,b.o)};
jx=function(a){return a.isLive&&g.qr()-a.J>=a.F};
kx=function(a){var b=a.F;(0,window.isFinite)(b)&&(jx(a)?a.zw():(b=Math.max(0,a.J+b-g.qr()),a.A||(a.A=new g.L(a.zw,b,a),g.I(a,a.A)),a.A.start(b)))};
Sfa=function(a){a=a.g;for(var b in a){var c=a[b].index;if(c.Ob())return c.rb()+1}return 0};
lx=function(a){if(!(0,window.isNaN)(a.H))return a.H;var b=a.g,c;for(c in b){var d=b[c].index;if(d.Ob()){b=0;for(c=d.pe();c<=d.rb();c++)b+=d.Df(c);b/=d.Jh();b=.5*Math.round(b/.5);d.Jh()>a.Y&&(a.H=b);return b}if(a.isLive&&(d=b[c],d.F))return d.F}return window.NaN};
mx=function(a,b){for(var c in a.g){var d=a.g[c].index;if(d.Ob()){var e=d.sf(b),f=d.bq(e);if(f)return f+b-d.od(e)}}return window.NaN};
Tfa=function(a,b){g.Bb(a.g,function(a){g.Bb(b,function(b,c){var d=a.A;d.o.set(c,b);d.B.set(c,b);d.l&&d.l.set(c,b)})})};
Ufa=function(a,b,c){var d=!1,e;for(e in a.g){var f=g.wt(a.g[e].info.mimeType)||!!a.g[e].info.video;c==f&&(f=a.g[e].index,Gw(f,b.vb)||(f.yw(b),d=!0))}return d};
nx=function(a,b,c){for(var d in a.g){var e=g.wt(a.g[d].info.mimeType)||!!a.g[d].info.video;if(c==e){e=a.g[d].index;var f=Fw(e,b);0<=f&&e.segments.splice(f,1)}}};
ex=function(a,b){return a.T?"yt:"+b:a.Z+":"+b};
Nfa=function(a,b){null===ox&&(ox=window.MediaSource&&window.MediaSource.isTypeSupported&&window.MediaSource.isTypeSupported('video/webm; codecs="vp09.02.51.10.01.09.16.09"')&&!window.MediaSource.isTypeSupported('video/webm; codecs="vp09.02.51.10.01.09.99.99"'));if(!ox&&!px||'video/webm; codecs="vp9"'!=a&&'video/webm; codecs="vp9.2"'!=a)return a;var c="00",d="08",e="01",f="01",k="01";'video/webm; codecs="vp9.2"'==a&&(c="02",d="10","bt2020"==b.primaries&&(k=e="09"),"smpte2084"==b.l&&(f="16"),"arib-std-b67"==
b.l&&(f="18"));return'video/webm; codecs="'+["vp09",c,"51",d,"01",e,f,k].join(".")+'"'};
Vfa=function(a){return g.Ja(Object.values(a.g),function(a){return a.info.Ec&&a.info.video?480<a.info.video.g&&"H"==a.info.l:!1})};
qx=function(){g.N.call(this);this.Ea={}};
Wfa=function(){var a=g.ps("yt-player-volume")||{},b=a.volume;return{volume:(0,window.isNaN)(b)?100:g.Uc(Math.floor(b),0,100),muted:!!a.muted}};
rx=function(a){g.os("yt-player-bandwidth",a,2592E3)};
sx=function(){return g.ps("yt-player-quality")||"auto"};
tx=function(a){return+(g.ps("yt-player-performance-cap")||{})[a]||0};
ux=function(){return g.ps("yt-player-headers-readable")||!1};
Xfa=function(){this.l=0;this.C=this.bandwidthEstimate=this.B=this.o=this.A=window.NaN;this.g=""};
Yfa=function(){this.A=2048;this.g=17;this.o=13E4;this.F=.5;this.l=!1;this.B=0;this.C=!1};
vx=function(a){this.B=Math.exp(Math.log(.5)/a);this.o=this.A=0};
xx=function(a,b,c,d){c=void 0===c?.5:c;d=void 0===d?0:d;this.L=b;this.o=Math.round(a*this.L);this.B=Array(this.o);for(a=0;a<this.o;a++)this.B[a]=window.Infinity;this.J=wx(this);this.A=0;this.C=!1;this.G=!0;this.F=c;this.H=d};
wx=function(a){for(var b=Array(a.o),c=0;c<a.o;c++)b[c]=c;return b};
yx=function(a,b){if(!a.C&&0==a.A)return 0;a.G&&(g.bb(a.J,function(b,d){return a.B[b]-a.B[d]}),a.G=!1);
return a.B[a.J[Math.round(b*((a.C?a.o:a.A)-1))]]||0};
Zfa=function(a){this.policy=a;this.H=this.J=0;this.B=-1;this.G=this.o=g.qr();this.F=new xx(4,1,.6,.4);this.A=new xx(10,1,.5,.4);this.g=a.l?new vx(a.g):new xx(a.g,20,.5,.4);this.C=new xx(5,1,.25);this.l=new xx(30,1,.5);a=g.ps("yt-player-bandwidth")||{};this.g.l(this.policy.F,0<a.byterate?a.byterate:this.policy.o);0<a.delay&&this.F.l(1,Math.min(+a.delay,2));0<a.stall&&this.A.l(1,+a.stall);0<a.init&&(this.G=Math.min(a.init,this.G));this.B=g.qr()};
Ax=function(a,b,c){b=Math.max(b,a.policy.A);a.A.l(1,c/b);zx(a)};
Bx=function(a){a=a.F.g();a=(0,window.isNaN)(a)?.5:a;return a=Math.min(a,5)};
Cx=function(a,b,c){(0,window.isNaN)(c)||(a.H+=c);(0,window.isNaN)(b)||(a.J+=b)};
Dx=function(a){a=a.g.g();return 0<a?a:1};
g.Ex=function(a){var b=Dx(a);b=1/((a.A.g()||0)+1/b);a=a.C.g();return Math.max(b,0<a?a:1)};
Fx=function(a){var b={};b.delay=Bx(a);b.stall=a.A.g()||0;b.byterate=Dx(a);b.init=a.G;return b};
zx=function(a){-1<a.B&&3E4<g.qr()-a.B&&(rx(Fx(a)),a.B=g.qr())};
Gx=function(a){return 4E3<=g.qr()-a.o};
T=function(a,b){return void 0==b?a:"1"==b?!0:!1};
Hx=function(a,b,c){for(var d in c)if(c[d]==b)return c[d];return a};
Ix=function(a,b){return void 0==b?a:Number(b)};
Jx=function(a,b){return void 0==b?a:b.toString()};
Kx=function(a,b){if(b){if("fullwidth"==a)return window.Infinity;if("fullheight"==a)return 0}if(a){var c=a.match($fa);if(c){var d=(0,window.parseFloat)(c[2]);if(0<d)return(0,window.parseFloat)(c[1])/d}}return window.NaN};
Lx=function(a){return a.docid||a.video_id||a.videoId||a.id};
Nx=function(){this.g=g.ep("ALT_PREF_COOKIE_NAME","PREF");var a=Ir.get(""+this.g,void 0);if(a){a=(0,window.decodeURIComponent)(a).split("&");for(var b=0;b<a.length;b++){var c=a[b].split("="),d=c[0];(c=c[1])&&(Mx[d]=c.toString())}}};
aga=function(){Nx.getInstance();var a="f"+(Math.floor(140/31)+1);a=void 0!==Mx[a]?Mx[a].toString():null;return!!(((null!=a&&/^[A-Fa-f0-9]+$/.test(a)?(0,window.parseInt)(a,16):null)||0)&65536)};
Ox=function(a){if(/^f([1-9][0-9]*)$/.test(a))throw Error("ExpectedRegexMatch: "+a);};
Px=function(a){if(!/^\w+$/.test(a))throw Error("ExpectedRegexMismatch: "+a);};
iy=function(a){g.G.call(this);a=g.Wb(a);this.Oa=this.ha="";this.Ik=Jx("",a.csp_nonce);this.experiments=new Vea(a.fexp,a.fflags);this.forcedExperiments=a.forced_experiments||null;try{var b=window.document.location.toString()}catch(e){b=""}this.Ya=b;this.Cb=(b=window.location.ancestorOrigins)?Array.from(b):[];this.g=T(!1,a.is_embed);this.Nk=T(!1,a.hide_thumbnail);this.loaderUrl=this.g?Jx("",a.loaderUrl):this.Ya;this.sb=cga.test(this.loaderUrl);b=this.loaderUrl;var c=void 0===c?!1:c;this.Qk=vs(dga.test(b),
b,c,"Trusted Ad Domain URL");this.oa=T(!1,a.privembed);this.protocol=0==this.Ya.indexOf("http:")?"http":"https";this.baseYtUrl=ws(a.BASE_YT_URL||"")||ws(this.Ya)||this.protocol+"://www.youtube.com/";c=a.el;b="detailpage";"adunit"==c?b=this.g?"embedded":"detailpage":"embedded"==c||this.sb?b=Hx(b,c,ega):c&&(b="embedded");this.R=b;Er();c=null;b=a.ps;var d=g.Ma(Qx,b);!b||d&&!this.sb||(c=b);this.playerStyle=c;this.F=(this.Sb=g.Ma(Qx,this.playerStyle))&&"play"!=this.playerStyle&&"jamboard"!=this.playerStyle;
this.Pk=!this.F;c={};this.l=(c.c=a.c||"web",c.cver=a.cver||"html5",c.cplayer="UNIPLAYER",c);this.H=T(!1,a.disableplaybackui);this.ga=!this.H&&!(!At().defaultPlaybackRate||g.kh&&!g.Kp("chrome")||Rx||Sx||g.Kp("android")||g.Kp("silk"));this.o=T("blazer"==this.playerStyle,a.is_html5_mobile_device);this.o?c=!0:(c=(0,window.parseInt)((0,g.D)()/1E3,10),b=Nx.getInstance(),c=this.la("block_desktop_background_playback_with_mobile_cookie")&&b&&c>(0,window.parseInt)(b.get("dhmu",c.toString()),10));this.Ok=c;
this.da="3"==this.A||this.o||T(!1,a.use_media_volume);this.L=Gt();this.Tk=g.Tx;this.isDni=T(!1,a.is_dni);this.ka=T(!1,a.forcenewui);this.Wb=T(!1,a.opt_out_deprecation);this.B=(this.ka||this.la("embed_new_info_bar"))&&Ux(this)&&!this.Wb;this.ge=(this.ka||this.la("embed_api_deprecation"))&&Ux(this)&&!this.isDni&&!this.Wb||T(!Vx(this)&&!g.Wx(this)&&!this.Sb,a.showinfo);this.fd=T(!1,a.playsinline);c=this.o&&Xx&&0<du&&2.3>=du;b=this.o;b=g.Yx(this)||!c&&T(b,a.use_native_controls)?"3":"1";this.A="0"!=a.controls?
b:"0";this.useTabletControls=this.o;this.color=Hx("red",a.color,fga);this.Rk="3"==this.A||T(!1,a.modestbranding)&&"red"==this.color;this.X=!this.g;this.he=(b=!this.X&&!g.Wx(this)&&!this.F&&!this.Sb&&!Vx(this))&&!this.Rk&&"1"==this.A;this.Cc=g.Zx(this)&&b&&"0"==this.A&&!this.he;this.Bl=this.Sk=c;this.ie=!Sx||g.jc(601)?!0:!1;this.Mk=this.g||!1;this.pa=g.Wx(this)?"":(this.loaderUrl||a.post_message_origin||"").substring(0,128);this.widgetReferrer=Jx("",a.widget_referrer);this.ab=(!this.sb||T(!0,a.enablecastapi))&&
"1"==this.A&&!this.o&&(g.Wx(this)||g.Zx(this)||g.$x(this));this.Lc=!this.o&&!g.Kp("nintendo wiiu")&&!g.Kp("nintendo 3ds")||g.ay||T(!1,a.autoplayoverride);this.Mc=T(!1,a.mutedautoplay)&&!1;c=(g.Wx(this)||Vx(this))&&"blazer"==this.playerStyle;this.ob=!T(!0,a.fs);this.ba=!this.ob&&(c||g.tq());this.xh=this.la("uniplayer_block_pip")&&Mp()&&g.an(58)&&!(g.by&&g.Kp("version/"));this.Ca=(this.ka||this.la("embed_api_deprecation"))&&Ux(this)&&!this.isDni&&!this.Wb||T(!this.Sb,a.rel);this.Vk=T(!1,a.co_rel);this.Ia=
g.$x(this);this.zc="blazer"==this.playerStyle;switch(this.playerStyle){case "blogger":c="bl";break;case "gmail":c="gm";break;case "books":c="gb";break;case "docs":c="gd";break;case "google-live":c="gl";break;case "play":c="gp";break;case "chat":c="hc";break;case "hangouts-meet":c="hm";break;case "photos-edu":case "picasaweb":c="pw";break;default:c="yt"}this.Z=c;this.Dc=Jx("",a.authuser);this.fl=(this.g&&!this.oa||!!this.Dc)&&T(!this.F,this.sb?a.showwatchlater:void 0);this.cd=T(!1,a.disablekb);this.Nc=
Jx("",a.ecver);this.loop=T(!1,a.loop);this.pageId=Jx("",a.pageid);this.Uk=T(!0,a.canplaylive);this.Jk=T(this.Sb,a.ss);(c=a.video_container_override)?(b=c.split("x"),2!=b.length?c=null:(c=(0,window.parseInt)(b[0],10),b=(0,window.parseInt)(b[1],10),c=(0,window.isNaN)(c)||(0,window.isNaN)(b)||0>=c*b?null:new g.ad(c,b))):c=null;this.Nf=c;this.mute=T(!1,a.mute);this.useMiniplayerUi=T(!1,a.use_miniplayer_ui);this.storeUserVolume=!this.mute&&T("0"!=this.A,a.store_user_volume);this.Qf="3"==this.A?3:Hx(void 0,
a.iv_load_policy,cy);this.Sf=Jx("",a.cc_lang_pref);c=Hx(2,a.cc_load_policy,cy);"3"==this.A&&2==c&&(c=3);this.Tf=c;this.Mb=Jx("en_US",a.hl);this.region=Jx("US",a.cr);this.hostLanguage=Jx("en",a.host_language);this.xg=!this.oa&&Math.random()<g.S(this.experiments,"web_player_api_logging_fraction");this.C=!this.oa&&!this.la("web_player_interaction_logging_killswitch");this.nb=new window.Set;this.deviceHasDisplay=T(!0,a.deviceHasDisplay);this.Qe=Ix(this.Qe,a.ismb);c=a;g.zt(this.experiments,"html5_qoe_intercept")?
c=g.zt(this.experiments,"html5_qoe_intercept"):this.Pk?(c=c.vss_host||"s.youtube.com",this.la("www_for_videostats")&&"s.youtube.com"==c&&(c=dy(this.baseYtUrl)||"www.youtube.com")):c="video.google.com";this.Of=c;this.Lf(a);this.G=new qx;g.I(this,this.G);this.J=this.o&&!this.la("enable_svg_mode_on_embed_mobile");this.yb={innertubeApiKey:Jx("",a.innertube_api_key),innertubeApiVersion:Jx("",a.innertube_api_version),hp:this.l.c,innertubeContextClientVersion:Jx("",a.innertube_context_client_version),jp:this.hostLanguage,
ip:this.region,Vl:""};this.Qd=void 0!=window.WebKitPlaybackTargetAvailabilityEvent;c=this.experiments;b=this.la("html5_force_hfr_support")?!0:ey(this)||Pp()||Qp()||fy(this);if(d=g.Ct)d=/Chrome\/(\d+)/.exec(g.zb),d=56<=(d?(0,window.parseFloat)(d[1]):window.NaN);this.T=new Yea(c,b,d||fy(this));c=new Yfa;g.gy(this)&&(c.l=!0,c.F=.1);g.R(this.experiments,"html5_ewma_bandwidth_estimator")&&(c.l=!0);g.R(this.experiments,"html5_pctile_bandwidth_estimator")&&(c.l=!1);this.Qe&&(c.o=this.Qe/8);c.g=g.S(this.experiments,
"html5_bandwidth_window_size")||c.g;c.C=g.R(this.experiments,"html5_dont_predict_end_time_in_past");this.schedule=new Zfa(c);this.enableSafetyMode=T(!1,a.enable_safety_mode);this.Ja=T(this.H?!1:g.Wx(this)&&"blazer"!=this.playerStyle,a.autonav);this.sa=T(!1,a.send_visitor_id_header)||this.experiments.g;this.Rf=!1;this.Fd=Bu;this.ed=g.qr();this.Y=0;this.Gd=!1;this.transparentBackground=T(!1,a.transparent_background);this.disableNativeContextMenu=T(!1,"docs"==this.playerStyle?a.disable_native_context_menu:
void 0);this.Lk=ey(this)&&this.la("enable_skip_intro_button");this.dd=Jx("",a.embed_config);this.useFastSizingOnWatchDefault=T(!0,a.use_fast_sizing_on_watch_default);this.Oc=!1;this.externalFullscreen=T(!1,a.external_fullscreen);this.fullWindow=T(!1,a.full_window);this.showMiniplayerButton=T(!1,a.show_miniplayer_button);this.xk=T(!1,a.cc_auto_caps);this.Kk=T(!1,a.embedding_app);this.wa=!g.hy(this)&&"WEB_KIDS"!=this.l.c};
jy=function(a,b){return!a.Sb&&Mp()&&g.an(55)&&!b};
g.ky=function(a){a=dy(a.baseYtUrl);return"www.youtube-nocookie.com"==a?"www.youtube.com":a};
g.ly=function(a){return"gaming"==a.playerStyle?"gaming.youtube.com":g.ky(a)};
g.my=function(a,b,c){return a.protocol+"://i1.ytimg.com/vi/"+b+"/"+(c||"hqdefault.jpg")};
g.ny=function(a){return g.Wx(a)&&"gaming"!=a.playerStyle&&!g.hy(a)};
g.Yx=function(a){return Sx&&!a.fd||g.Kp("nintendo wiiu")||g.Kp("nintendo 3ds")?!0:!1};
g.gy=function(a){if(!a.la("html5_tv_interface_check_killswitch")&&/^TVHTML5/.test(a.l.c))return!0;var b=g.Ct&&g.Kp("crkey")&&a.la("html5_tv_chromecast_check_killswitch");a=a.l.cplatform;return b||"TV"==a};
fy=function(a){return"CHROMECAST ULTRA/STEAK"==a.l.cmodel||"CHROMECAST/STEAK"==a.l.cmodel};
g.oy=function(){return 1<window.devicePixelRatio?window.devicePixelRatio:1};
ey=function(a){return"web"==a.l.c.toLowerCase().substr(0,3)};
g.hy=function(a){return"WEB_UNPLUGGED"==a.l.c};
g.py=function(a){return g.hy(a)||"TV_UNPLUGGED_CAST"==a.l.c||"TVHTML5_UNPLUGGED"==a.l.c};
qy=function(a){return"WEB_REMIX"==a.l.c};
g.sy=function(a){return(a.deviceHasDisplay&&g.Ct&&!cu&&"3"!==a.A?g.by?a.g&&g.jc(51):!0:!1)||(a.deviceHasDisplay&&g.hu&&!cu&&"3"!==a.A?g.by?a.g&&g.jc(48):g.jc(38):!1)||(a.deviceHasDisplay&&g.kh&&!cu&&"3"!==a.A?g.by?a.g&&g.jc(37):g.jc(27):!1)||a.deviceHasDisplay&&g.Js&&!Tp()&&g.jc(11)||a.deviceHasDisplay&&g.ry&&g.jc("604.4")};
ty=function(a){if(g.Zx(a)&&Xx)return!1;if(g.hu){if(!g.jc(47)||!g.jc(52)&&g.jc(51))return!1}else if(g.ry)return!1;return window.AudioContext||window.webkitAudioContext?!0:!1};
g.Wx=function(a){return"detailpage"==a.R};
g.Zx=function(a){return"embedded"==a.R};
g.uy=function(a){return"leanback"==a.R};
Vx=function(a){return"adunit"==a.R||"gvn"==a.playerStyle};
g.$x=function(a){return"profilepage"==a.R};
Ux=function(a){return a.g&&g.Zx(a)&&!Vx(a)&&!a.Sb};
dy=function(a){var b=g.yg(a);return(a=g.zg(a))?b+":"+a:b};
gga=function(){this.H=this.L=this.l=this.B=this.A=this.aacHigh=this.F=this.C=!1;this.G=!0;this.g=0;this.o=this.J=!1};
hga=function(a){if(a.F)return["f"];var b="19 9h 9 h 8 (h ( H *".split(" ");a.J&&b.unshift("1");a.l&&b.unshift("h");return b};
iga=function(a){var b=["o","a","v","A","V"];a.A&&(b=["m","M"].concat(b));a.B&&(b=["meac3","MEAC3","mac3","MAC3"].concat(b));a.C&&(b=["so","sa"].concat(b));a.L&&b.unshift("a");a.aacHigh&&b.unshift("ah");return b};
vy=function(a,b,c,d){this.flavor=a;this.g=b;this.A=c;this.o={};this.l=null;this.fairPlayCert="";this.aj=this.bj=-1;this.Ck=null;this.B=!!d&&g.R(d,"edge_nonprefixed_eme")};
yy=function(a){return a.B?!1:!a.l&&!!wy()&&"com.microsoft.playready"==a.g};
zy=function(a){return"com.microsoft.playready"==a.g};
Ay=function(a){return g.uu&&"com.microsoft.playready"==a.g&&!!window.navigator.requestMediaKeySystemAccess};
By=function(a){return!a.l&&!!wy()&&"com.apple.fps.1_0"==a.g};
wy=function(){var a=window.MSMediaKeys;Sp()&&!a&&(a=window.WebKitMediaKeys);return a&&a.isTypeSupported?a:null};
Cy=function(a){return window.navigator.requestMediaKeySystemAccess?g.Ct?g.an("45"):g.uu||g.pd?g.R(a,"edge_nonprefixed_eme"):g.hu?g.an("47"):!g.R(a,"html5_disable_nonprefixed_eme_for_other"):!1};
Dy=function(a,b,c){this.videoInfos=a;this.g=b||null;this.audioTracks=[];this.l=c||null;if(this.g){var d={};(0,g.C)(this.g,(0,g.z)(function(a){if(a.ib&&!d[a.id]){var b=new gt(a.id,a.ib);d[a.id]=b;this.audioTracks.push(b)}},this))}};
jga=function(a){return Ey()?Fy(a.videoInfos).then(function(){return a},function(){return a}):cq(a)};
Fy=function(a){var b=Ey();if(!b)return cq(a);var c=(0,g.E)(a,function(a){return b&&b.decodingInfo({type:"media-source",video:a.video?{contentType:a.mimeType,width:a.video.width||640,height:a.video.height||360,bitrate:8*a.g||1E6,framerate:a.video.fps||30}:null})});
return g.Yf(c).then(function(b){for(var c=0;c<b.length;c++)a[c].o=b[c].smooth;return a},function(){return a})};
Ey=function(){return window.navigator.mediaCapabilities};
Gy=function(a,b,c){var d={},e;for(e in c.g){var f=c.g[e],k=g.ot(f.info);("304"==k||"266"==k)&&a.G||a.H&&"h"==f.info.l&&f.info.video&&1080<f.info.video.g||!bfa(b,f.info)||(d[f.info.l]=d[f.info.l]||[],d[f.info.l].push(f.info))}return d};
kga=function(a,b,c){var d={};g.Bb(b,function(b,f){var e=b.filter(function(b){if(b.Ec){var d;if(d=c&&b.Ec[c.flavor]&&c.o[b.mimeType])(b="("!=b.l&&"(h"!=b.l)||(b=fu(a,mu)||a.C),d=b;b=d?!0:!1}else b=!0;return b});
e.length&&(d[f]=e)});
return d};
Ky=function(a,b,c,d){function e(a){return!!f[a]}
var f=Gy(a,b,c),k=a.o&&Ey();if(0<a.g&&f["9"]&&f["1"]&&!k){var l=f["1"].filter(function(b){return b.za().g<=a.g});
l=f["9"].filter(function(b){return b.za().g>a.g}).concat(l);
l.length&&(f["19"]=l)}Yw(c)&&(f=kga(b,f,d));d=hga(a);l=iga(a);var m=g.Ja(d,e),n=g.Ja(l,e);if(!m||!n)return bq();if("9"==m&&f.h){l=function(a,b){return Math.max(a,b.za().height)};
var p=Aj(f["9"],l,0);Aj(f.h,l,0)>1.5*p&&(m="h");c.xf&&!cfa(b)&&(m="h")}c=f[m];l=f[n];c=Hy(b,c);if(!c.length)return bq();Iy(c,l);return k&&"9"==m&&"19"==d[0]&&f["9"]&&f["1"]?(k=function(){return lga(b,f,a,m,n)},Fy(f["1"]).then(k,k)):cq(new Dy(c,l,Jy(b,f,m,n)))};
lga=function(a,b,c,d,e){if(!d||!e)return bq();var f=b["1"],k=c.g;f.forEach(function(a){a.o&&(k=a.za().g)});
k=Math.min(k,c.g);c=mga(b["9"],f,k);f=b[e];Iy(c,f);return cq(new Dy(c,f,Jy(a,b,d,e)))};
mga=function(a,b,c){var d=b.filter(function(a){return a.za().g<=c});
b=a.filter(function(a){return a.za().g>c});
d=d.concat(b);return d.length&&d.length>=b.length?d:a};
Jy=function(a,b,c,d){var e=b.h;"f"==c&&(e=b[c]);var f=b.a;c=b[c]!=e;b=b[d]!=f;return e&&f&&(c||b)?(e=Hy(a,e),Iy(e,f),new Dy(e,f)):null};
Iy=function(a,b){g.bb(a,function(a,b){return b.za().height*b.za().width-a.za().height*a.za().width||b.g-a.g});
g.bb(b,function(a,b){return b.g-a.g})};
Hy=function(a,b){var c=(0,g.rj)(b,function(a){return 32<a.za().fps});
c&&(b=a.B||fu(a,ku)?(0,g.Bd)(b,function(a){var b;(b=32<a.za().fps)||(a=a.za(),b=!(854<a.width||480<a.height));return b}):(0,g.Bd)(b,function(a){return!(32<a.za().fps)}));
c&&Pp()&&(b=(0,g.Bd)(b,function(a){return"299"!=g.ot(a)}));
return b};
Ly=function(a,b,c){g.G.call(this);this.g=[];this.l={};this.A={};this.C=null;this.B=b;this.F=!1;this.o=[];nga(this,a,!c)};
nga=function(a,b,c){for(var d in b)for(var e=g.q(b[d]),f=e.next();!f.done;f=e.next()){f=f.value;if(!f.Ec)return;for(var k in f.Ec){if(!My[k])return;for(var l=g.q(My[k]),m=l.next();!m.done;m=l.next())m=m.value,a.l[m]=a.l[m]||new vy(k,m,f.Ec[k],a.B),a.A[k]=a.A[k]||{},a.A[k][f.mimeType]=!0}}Op()?(a.g=["com.youtube.fairplay"],a.l["com.youtube.fairplay"]=new vy("fairplay","com.youtube.fairplay","",a.B),a.A.fairplay={'audio/mp4; codecs="avc1.4d4015"':!0,'video/mp4; codecs="mp4a.40.2"':!0}):a.g=(c?g.Sa(My.widevine,
My.playready):My.playready).filter(function(b){return!!a.l[b]})};
Ny=function(a){if(!a.ea())if(0==a.g.length)a.C(a.o);else{var b=a.g[0],c=a.l[b],d={initDataTypes:["cenc","webm"],audioCapabilities:[],videoCapabilities:[]};zy(c)&&(d.initDataTypes=["keyids","cenc"]);for(var e in a.A[c.flavor]){var f=0==e.indexOf("audio/"),k=f?d.audioCapabilities:d.videoCapabilities;"widevine"!=c.flavor||a.F?k.push({contentType:e}):f?k.push({contentType:e,robustness:"SW_SECURE_CRYPTO"}):(k.push({contentType:e,robustness:"HW_SECURE_ALL"}),k.push({contentType:e,robustness:"SW_SECURE_DECODE"}))}window.navigator.requestMediaKeySystemAccess(b,
[d]).then(jp((0,g.z)(a.H,a,c)),jp((0,g.z)(a.G,a)))}};
oga=function(a,b){function c(a){b.o[a.contentType]=!0}
if(zy(b)){var d=At(),e;for(e in a.A[b.flavor])b.o[e]=!!d.canPlayType(e)}else b.l&&(d=b.l.getConfiguration(),d.audioCapabilities&&d.audioCapabilities.forEach(c),d.videoCapabilities&&d.videoCapabilities.forEach(c))};
qga=function(a){if(wy()&&g.ry)a.o.push(new vy("fairplay","com.apple.fps.1_0","",a.B));else{var b=pga(),c=g.Ja(a.g,function(c){var d=a.l[c],f=!1,k=!1,l;for(l in a.A[d.flavor])b(l,c)&&(d.o[l]=!0,f=f||0==l.indexOf("audio/"),k=k||0==l.indexOf("video/"));return f&&k});
c&&a.o.push(a.l[c]);a.g=[]}a.C(a.o)};
pga=function(){var a=wy();if(a&&a.isTypeSupported){var b=a.isTypeSupported;return function(a,d){return b(d,a)}}return(a=At())&&(a.addKey||a.webkitAddKey)?(0,g.z)(a.canPlayType,a):function(){return!1}};
g.Oy=function(a,b,c){this.errorCode=a;this.g=b;this.details=c||{}};
Py=function(a){var b;for(b in a){var c=(""+a[b]).replace(/[:,]/g,"_");var d=(d?d+";":"")+b+"."+c}return d||""};
rga=function(a,b,c,d,e,f,k,l,m,n){this.itag=a;this.url=b;this.g=c;this.width=d;this.height=e;this.bitrate=k;this.fps=f;this.audioItag=l||null;this.l=m||"";this.ib=void 0===n?null:n};
Qy=function(a){for(var b={},c=0,d=a.length;c<d;++c){var e=a[c],f=e.type.match(/codecs="([^"]*)"/);f=f?f[1]:"";var k=null;e.audio_track_id&&(k=new ct(e.name,e.audio_track_id,!!e.is_default));e=new rga(e.itag,e.url,f,+e.width,+e.height,+e.fps,+e.bitrate,e.audio_itag,e.drm_families,k);b[e.itag]=b[e.itag]||[];b[e.itag].push(e)}return b};
sga=function(a,b,c,d){this.o=a;this.g=b;this.B=0;this.l="";this.A=c;this.C=d};
Sy=function(a,b,c,d){b.push("#EXT-X-STREAM-INF:BANDWIDTH="+(c.bitrate+d.bitrate)+","+('CODECS="'+c.g+","+d.g+'",')+("RESOLUTION="+c.width+"x"+c.height+",")+('AUDIO="'+d.itag.toString()+'",')+"CLOSED-CAPTIONS=NONE");b.push(Ry(a,c.url))};
Ry=function(a,b){return a.A?g.Ig(b,{cpn:a.A}):b};
tga=function(a,b){var c="#EXT-X-MEDIA:TYPE=AUDIO,",d="YES",e="audio";if(b.ib){e=b.ib;var f=e.getId().split(".")[0];f&&(c+='LANGUAGE="'+f+'",');a.l||e.isDefault||(d="NO");e=e.name}f=Ry(a,b.url);return c=c+('NAME="'+e+'",'+("DEFAULT="+d+",AUTOSELECT=YES,"))+('GROUP-ID="'+b.itag.toString()+'",'+('URI="'+f+'"'))};
uga=function(a){for(var b=[],c=[],d=0,e=a.g.length;d<e;++d){var f=a.g[d];f.bitrate<=a.B?b.push(f):c.push(f)}b.sort(function(a,b){return b.bitrate-a.bitrate});
c.sort(function(a,b){return a.bitrate-b.bitrate});
a.g=b.concat(c)};
Ty=function(a,b,c){this.nf=a;this.l=b;this.g=null;this.o=c};
wga=function(a,b,c,d,e){if(!(cu||Sp()||Op()))return bq();var f=vga(c),k=Qy(c);if(!k)return bq();c={};var l=(c.fairplay="https://youtube.com/api/drm/fps?ek=uninitialized",c),m;c=[];var n=[],p=[],u=g.S(a.experiments,"html5_hls_min_video_height"),x=g.R(a.experiments,"html5_hls_pair_all_audio"),B;for(B in k)if(!g.R(a.experiments,"html5_disable_drm_hfr_1080")||"383"!=B&&"373"!=B){var F=g.q(k[B]);for(m=F.next();!m.done;m=F.next()){var H=m.value;if(H.width){if(!(H.height<u)){var Q=k[H.audioItag];if(Q&&(c.push(H),
m="fairplay"==H.l?l:null,p.push(Uy(Q,[H],e,H.itag,H.width,H.height,H.fps,f,x,void 0,void 0,m)),!O||H.width*H.height*H.fps>O.width*O.height*O.fps))var O=H}}else n.push(H)}}m=p.reduce(function(a,b){return!!b.nf.Ec&&a},!0)?l:null;
d=Math.max(d,g.S(a.experiments,"html5_hls_initial_bitrate"));O=O||{};p.push(Uy(n,c,e,"93",void 0===O.width?0:O.width,void 0===O.height?0:O.height,void 0===O.fps?0:O.fps,f,x,"auto",d,m));return wu(p,jy(a,b))};
Uy=function(a,b,c,d,e,f,k,l,m,n,p,u){d=new pt(d,"application/x-mpegURL",new ht,new kt(e,f,k,null,void 0,n),void 0,u);a=new sga(a,b,c,m);a.B=p?p:1369843;return new Ty(d,a,l)};
vga=function(a){a=g.q(a);for(var b=a.next();!b.done;b=a.next())if(b=b.value,b.url&&(b=b.url.split("expire/"),!(1>=b.length)))return+b[1].split("/")[0];return window.NaN};
Vy=function(a,b){this.nf=a;this.g=b};
Wy=function(a,b,c,d){var e=[];c=g.q(c);for(var f=c.next();!f.done;f=c.next()){var k=f.value;if(k.url){f=new g.ew(k.url);k.s&&f.set(k.sp,(0,window.encodeURIComponent)(dw((0,window.decodeURIComponent)(k.s))));for(var l in d)f.set(l,d[l]);k=xt(k.type,k.quality,k.itag,k.width,k.height,!!k.isAccelerated,!!k.isAcceleratedUiEnabled);e.push(new Vy(k,f))}}return wu(e,jy(a,b))};
Xy=function(a,b){this.nf=a;this.g=b};
xga=function(a){var b=[];(0,g.C)(a,function(a){if(a.url){var c=xt(a.type,"medium","0");b.push(new Xy(c,a.url))}});
return b};
Yy=function(a){if(a){var b=[],c;for(c in a)yga.has(c)||b.push(c);b.length&&(b.sort(),g.M(Error("Unknown house brand player vars: "+b.join(",")),"WARNING"))}};
g.Zy=function(a,b,c,d){this.Te=new window.Set;this.H=a;this.J=b;a=c.split("#");this.C=(0,window.parseInt)(a[0],10);this.B=(0,window.parseInt)(a[1],10);this.o=(0,window.parseInt)(a[2],10);this.columns=(0,window.parseInt)(a[3],10);this.rows=(0,window.parseInt)(a[4],10);this.g=(0,window.parseInt)(a[5],10);this.A=a[6];this.F=a[7];this.L=d};
g.$y=function(a,b){b>=a.uq()&&a.ak();var c=Math.floor(b/(a.columns*a.rows)),d=a.columns*a.rows,e=b%d,f=e%a.columns;e=Math.floor(e/a.columns);var k=a.ak()+1-d*c;if(k<a.columns){var l=k;d=1}else l=a.columns,d=k<d?Math.ceil(k/a.columns):a.rows;return{url:a.Ib(c),column:f,columns:l,row:e,rows:d,Iq:a.C*l,Hq:a.B*d}};
az=function(a){g.N.call(this);this.A=new Ao;this.l=null;this.G=new window.Set;this.F=a||""};
g.cz=function(a,b,c){for(c=g.bz(a,c);0<=c;){var d=a.g[c];if(d.Ob(Math.floor(b/(d.columns*d.rows)))&&(d=g.$y(d,b)))return d;c--}return g.$y(a.g[0],b)};
g.ez=function(a,b,c){c=g.bz(a,c);for(var d,e;0<=c;c--)if(d=a.g[c],e=Math.floor(b/(d.columns*d.rows)),!d.Ob(e)){d=a;var f=c,k=f+"-"+e;d.G.has(k)||(d.G.add(k),zo(d.A,f,{Bv:f,vx:e}))}dz(a)};
dz=function(a){if(!a.l&&!a.A.isEmpty()){var b=a.A.remove(),c=new window.Image;a.F&&(c.crossOrigin=a.F);c.src=a.g[b.Bv].Ib(b.vx);c.onload=(0,g.z)(a.H,a,b.Bv,b.vx);a.l=c}};
fz=function(a,b,c,d){d=void 0===d?!1:d;az.call(this,c);this.isLive=d;this.g=this.o(a,b);this.B=new window.Map;1<this.g.length&&this.g[0].isDefault()&&this.g.splice(0,1)};
g.gz=function(a,b,c){return(a=a.g[b])?a.Im(c):-1};
g.bz=function(a,b){var c=a.B.get(b);if(c)return c;c=a.g.length;for(var d=0;d<c;d++)if(a.g[d].C>=b)return a.B.set(b,d),d;a.B.set(b,c-1);return c-1};
hz=function(a,b,c,d){c=c.split("#");c=[c[1],c[2],0,c[3],c[4],-1,c[0],""].join("#");g.Zy.call(this,a,b,c,0);this.l=null;this.G=d?3:0};
iz=function(a,b,c){fz.call(this,a,0,void 0,b);for(a=0;a<this.g.length;a++)this.g[a].Ez(c)};
kz=function(a,b){var c={},d;for(d in jz){var e=b?b+d:d;e=a[e+"_webp"]||a[e];g.Bs(e)&&(c[jz[d]]=e)}return c};
g.lz=function(a,b){this.version=a;this.args=b};
g.mz=function(a,b){this.topic=a;this.g=b};
g.oz=function(a,b){var c=nz();c&&c.publish.call(c,a.toString(),a,b)};
g.sz=function(a,b,c){var d=nz();if(!d)return 0;var e=d.subscribe(a.toString(),function(d,k){var f=g.y("ytPubsub2Pubsub2SkipSubKey");f&&f==e||(f=function(){if(pz[e])try{if(k&&a instanceof g.mz&&a!=d)try{var f=a.g,l=k;if(!l.args||!l.version)throw Error("yt.pubsub2.Data.deserialize(): serializedData is incomplete.");try{if(!f.wg){var p=new f;f.wg=p.version}var u=f.wg}catch(x){}if(!u||l.version!=u)throw Error("yt.pubsub2.Data.deserialize(): serializedData version is incompatible.");try{k=window.Reflect.construct(f,
g.Ta(l.args))}catch(x){throw x.message="yt.pubsub2.Data.deserialize(): "+x.message,x;}}catch(x){throw x.message="yt.pubsub2.pubsub2 cross-binary conversion error for "+a.toString()+": "+x.message,x;}b.call(c||window,k)}catch(x){g.M(x)}},qz[a.toString()]?g.zr()?g.xr(f):g.op(f,0):f())});
pz[e]=!0;rz[a.toString()]||(rz[a.toString()]=[]);rz[a.toString()].push(e);return e};
vz=function(a,b){var c=g.sz(tz,function(d){a.apply(b,arguments);g.uz(c)},b);
return c};
g.uz=function(a){var b=nz();b&&(g.ta(a)&&(a=[a]),(0,g.C)(a,function(a){b.unsubscribeByKey(a);delete pz[a]}))};
nz=function(){return g.y("ytPubsub2Pubsub2Instance")};
wz=function(){var a=g.ep("TIMING_TICK_EXPIRATION");a||(a={},g.dp("TIMING_TICK_EXPIRATION",a));return a};
zga=function(){var a=wz(),b;for(b in a)g.Ar(a[b]);g.dp("TIMING_TICK_EXPIRATION",{})};
xz=function(a,b){g.lz.call(this,1,arguments)};
yz=function(a,b){g.lz.call(this,1,arguments);this.g=a};
Bz=function(a){zz(a);Aga();Az(!1,a);a||(g.ep("TIMING_ACTION")&&g.dp("PREVIOUS_ACTION",g.ep("TIMING_ACTION")),g.dp("TIMING_ACTION",""))};
Jz=function(a,b,c,d,e){d=d?d:a;Cz("c",d);Bz(d);e&&(Dz(d).useGel=e);g.dp(d+"TIMING_AFT_KEYS",b);g.dp(d+"TIMING_ACTION",a);Ez("yt_sts","c",d);Fz("_start",c,d);Gz(d)&&(a={},a.actionType=Bga[g.ep((d||"")+"TIMING_ACTION",void 0)]||"LATENCY_ACTION_UNKNOWN",b=Hz(d),Xr(a,b));g.ua("ytglobal.timing"+(d||"")+"ready_",!0,void 0);Iz(d)};
Fz=function(a,b,c){if(!b&&"_"!=a[0]){var d=a;Kz.mark&&(g.fb(d,"mark_")||(d="mark_"+d),c&&(d+=" ("+c+")"),Kz.mark(d))}d=Lz(c);var e=b||g.qr();d[a]&&(d["_"+a]=d["_"+a]||[d[a]],d["_"+a].push(e));d[a]=e;e=wz();var f=e[a];f&&(g.Ar(f),e[a]=0);Mz(c)["tick_"+a]=b;c||b||g.qr();Gz(c)?(e=Hz(c),"_start"==a?Wr("baseline_"+e)||Nr("latencyActionBaselined",{clientActionNonce:e},b):Wr("tick_"+a+"_"+e)||Nr("latencyActionTicked",{tickName:a,clientActionNonce:e},b),b=!0):b=!1;b||Iz(c);return d[a]};
Nz=function(a){var b="above_the_fold";Kz&&Kz.measure&&(g.fb(b,"measure_")||(b="measure_"+b),a?Kz.measure(b,a):Kz.measure(b))};
Oz=function(a,b){var c=Lz(b);return a in c};
Pz=function(a){Oz("_start","video_to_ad")&&Fz(a,void 0,"video_to_ad")};
Ez=function(a,b,c){Dz(c).info[a]=b;Mz(c)["info_"+a]=b;if(Gz(c))if(a in Qz){var d=Qz[a];g.Ma(Cga,d)&&(b=!!b);a in Rz&&(b=Rz[a]+b.toUpperCase());if(Gz(c)){a={};d=d.split(".");for(var e=a,f=0;f<d.length-1;f++)e[d[f]]=e[d[f]]||{},e=e[d[f]];e[d[d.length-1]]=b;c=Hz(c);Xr(a,c)}}else g.Ma(Dga,a)||g.M(Error("Unknown label "+a+" logged with GEL CSI."))};
Sz=function(a){var b=Lz(a);if(b.aft)return b.aft;a=g.ep((a||"")+"TIMING_AFT_KEYS",["ol"]);for(var c=a.length,d=0;d<c;d++){var e=b[a[d]];if(e)return e}return window.NaN};
Iz=function(a){if(!Tz(a)){var b=g.ep((a||"")+"TIMING_ACTION",void 0),c=Lz(a);if(g.y("ytglobal.timing"+(a||"")+"ready_")&&b&&c._start&&(b=Sz(a)))if(Uz||(g.oz(Ega,new xz(Math.round(b-c._start),a)),Uz=!0),a)Vz(a);else{b=!0;var d=g.ep("TIMING_WAIT",[]);if(d.length)for(var e=0,f=d.length;e<f;++e)if(!(d[e]in c)){b=!1;break}b&&Vz(a)}}};
Fga=function(){switch(qq()){case "hidden":return 0;case "visible":return 1;case "prerender":return 2;case "unloaded":return 3}return-1};
Cz=function(a,b){if(!Tz(b)){var c=g.ep("CSI_SERVICE_NAME","youtube");g.ep((b||"")+"TIMING_ACTION",void 0)&&c&&(Fz("aa",void 0,b),Ez("ap",1,b),Ez("yt_fss",a,b),Vz(b))}};
Hz=function(a){var b=Dz(a).nonce;b||(b=ds(),Dz(a).nonce=b);return b};
Lz=function(a){return Dz(a).tick};
Mz=function(a){a=Dz(a);"gel"in a||(a.gel={});return a.gel};
Dz=function(a){return g.y("ytcsi."+(a||"")+"data_")||zz(a)};
zz=function(a){var b={tick:{},info:{}};g.ua("ytcsi."+(a||"")+"data_",b,void 0);return b};
Tz=function(a){return!!g.y("yt.timing."+(a||"")+"pingSent_")};
Az=function(a,b){g.ua("yt.timing."+(b||"")+"pingSent_",a,void 0)};
Gga=function(a){var b=Lz(a),c=b.pbr,d=b.vc;b=b.pbs;return c&&d&&b&&c<d&&d<b&&1==Dz(a).info.yt_pvis};
Gz=function(a){return!!g.lp("csi_on_gel")||!!Dz(a).useGel};
Vz=function(a){zga();if(!Gz(a)){var b=Lz(a),c=Dz(a).info,d=b._start;for(k in b)if(g.fb(k,"_")&&g.ya(b[k])){var e=k.slice(1);if(e in Hga){var f=(0,g.E)(b[k],function(a){return Math.round(a-d)});
c["all_"+e]=f.join()}delete b[k]}f=g.ep("CSI_SERVICE_NAME","youtube");var k={v:2,s:f,action:g.ep((a||"")+"TIMING_ACTION",void 0)};e=Ez.srt;void 0!==b.srt&&delete c.srt;if(c.h5jse){var l=window.location.protocol+g.y("ytplayer.config.assets.js");(l=Kz.getEntriesByName?Kz.getEntriesByName(l)[0]:null)?c.h5jse=Math.round(c.h5jse-l.responseEnd):delete c.h5jse}b.aft=Sz(a);Gga(a)&&"youtube"==f&&(Ez("yt_lt","hot_bg",a),f=b.vc,l=b.pbs,delete b.aft,c.aft=Math.round(l-f));for(var m in c)"_"!=m.charAt(0)&&(k[m]=
c[m]);b.ps=g.qr();m={};f=[];for(var n in b)"_"!=n.charAt(0)&&(l=Math.round(b[n]-d),m[n]=l,f.push(n+"."+l));k.rt=f.join(",");(b=g.y("ytdebug.logTiming"))&&b(k,m);Iga(k,!!c.ap,a);g.oz(tz,new yz(m.aft+(e||0),a))}};
Iga=function(a,b,c){if(g.lp("debug_csi_data")){var d=g.y("yt.timing.csiData");d||(d=[],g.ua("yt.timing.csiData",d,void 0));d.push({page:window.location.href,time:new Date,args:a})}d="";for(var e in a)d+="&"+e+"="+a[e];a="/csi_204?"+d.substring(1);window.navigator&&window.navigator.sendBeacon&&b?Wp(a):g.Vp(a);Az(!0,c)};
g.Wz=function(a){if(a.simpleText)return a.simpleText;if(a.runs){var b=[];a=g.q(a.runs);for(var c=a.next();!c.done;c=a.next())c=c.value,c.text&&b.push(c.text);return b.join("")}return""};
g.Xz=function(a,b){g.N.call(this);this.Ra=a;this.adModule=!1;this.Ki=this.adaptiveFormats="";this.Ec=null;this.drmParams="";this.allowEmbed=!0;this.yg=this.backgroundable=!1;this.Ie="";this.Cg=this.Zk=this.Yk=!1;this.relativeLoudness=window.NaN;this.watchAjaxToken=null;this.author="";this.Wf=0;this.Zn=this.cu=this.xk=this.nl=!1;this.clientScreenNonce=this.clientPlaybackNonce=this.videoCountText=this.channelBanner=this.channelPath=this.ol="";this.contentCheckOk=!1;this.ne=0;this.enableCardioBeforePlayback=
this.enableCardio=!1;this.endSeconds=0;this.Af=!1;this.Qe=this.Oh=0;this.pipable=this.Qh=!1;this.By=0;this.isLowLatencyLiveStream=this.isLiveDefaultBroadcast=this.isLiveDestination=this.yj=this.ra=this.wj=this.isListed=this.pp=this.oi=!1;this.latencyClass="UNKNOWN";this.isMdxPlayback=this.isPremiere=!1;this.mdxControlMode=null;this.isPharma=!1;this.bf=0;this.reloadReason="";this.vp=this.rv=this.jg=!1;this.fm="";this.gm=0;this.Cn=!1;this.liveChunkReadahead=window.NaN;this.liveStartWalltime=0;this.yp=
null;this.Dj=this.lengthSeconds=0;this.playerParams=this.musicVideoType=null;this.paygated=!1;this.xc=[];this.profilePicture=void 0;this.racyCheckOk=!1;this.rootVeType=0;this.xa=null;this.autonavState=1;this.Gd=this.Kz=this.Dr=!1;this.un=this.wf=this.startSeconds=0;this.spacecastModule=!1;this.Wk=null;this.En=this.Yn=this.sA=Bu;this.Ai=this.suggestions=null;this.hlsFormats=this.Ei=this.expandedSubtitle=this.expandedTitle=this.subtitle=this.title="";this.sd=this.De=this.Dd=this.rk=this.Ul=null;this.In=
"vvt";this.ypcOfferButtonFormattedText=null;this.BA="";this.ypcOverlayTimeout=window.NaN;this.ypcVid=this.ypcItemUrl=this.ypcItemTitle=this.ypcItemThumbnail=this.es=this.ypcOfferId=this.ypcFullVideoMessage=this.ypcOfferHeadline=this.ypcOfferDescription=this.ypcOfferButtonText="";this.ypcTrailerPlayerVars=null;this.requiresPurchase=!1;this.Qc={};this.clipStart=0;this.clipEnd=window.Infinity;this.heartbeatToken="";this.heartbeatRetries=this.heartbeatInterval=window.NaN;this.mh=this.Vh=this.zh=this.sj=
this.heartbeatSoftFail=!1;this.Ju="";this.hn=this.rr=this.Iu=0;this.kv=!1;this.pn=!0;this.tg={};this.captionTracks=[];this.Pi=[];this.bo=0;this.captionTranslationLanguages=[];this.Qi=!1;this.chapterMarkers=[];this.Vi=new gt("und",new ct("Default","und",!0));this.wp=0;this.xi=this.fz=!1;this.Re=null;this.mk=[];this.zg=[];this.sh={};this.Wr=this.ir="";this.slotPosition=-1;this.breakType=0;this.qz=new g.L(this.rz,5E3,this);g.I(this,this.qz);this.Lo=0;this.Ku=!0;this.bd=this.Xa=null;this.np=this.Hz=this.xj=
this.ig=!1;this.kp=this.mp=window.NaN;this.defraggedFromSubfragments=this.hasSubfragmentedFmp4=!1;this.liveExperimentalContentId=window.NaN;this.preferLowQualityAudio=this.Xr=this.Yr=!1;this.Wm=[];this.Vm=[];this.isDni=!1;this.dniColor="#cc181e";this.nk="";this.isVisualizerEligible=!1;this.qd="";this.zj=this.hv=!1;this.multifeedMetadataList=this.ypcClickwrapMessage="";this.Jy=this.Yq=this.lp=window.NaN;var c=this.la("web_player_response_player_config_parsing");this.Cy=c&&!this.la("web_player_response_audio_config_killswitch");
this.Dy=c&&!this.la("web_player_response_fairplay_config_killswitch");this.pM=c&&!this.la("web_player_response_start_config_killswitch");this.kk=c&&!this.la("web_player_response_misc_player_config_killswitch");this.Zq=this.la("web_player_response_heartbeat_parsing");this.Ey=g.R(this.Ra.experiments,"web_player_response_streaming_data_parsing")&&!g.R(this.Ra.experiments,"web_player_response_license_info_killswitch");this.nM=!this.la("web_player_response_manifest_url_parsing_killswitch");this.Fy=this.la("web_player_response_overlay_parsing");
this.Gy=(c=this.la("web_player_response_playback_tracking_parsing"))&&!this.la("web_player_response_ptracking_killswitch");this.qM=c&&!this.la("web_player_response_ppv_remarketing_killswitch");this.rM=c&&!this.la("web_player_response_qoe_killswitch");this.sM=c&&!this.la("web_player_response_remarketing_killswitch");this.Hy=c&&!this.la("web_player_response_videostats_killswitch");this.tM=!this.la("web_player_ypc_clickwrap_killswitch");this.la("web_player_ux_module_wait")&&this.Ra.wa&&this.xc.push("ux");
this.Nd={};this.keywords={};this.setData(b)};
aA=function(a,b,c){b=b||{};var d={};if(c){var e;b.raw_player_response?e=b.raw_player_response:b.player_response&&(e=g.Tn(b.player_response));if(e)for(d=null!=e?e:{},a.Xa||(a.Xa={}),c=0;c<Yz.length;c++)e=Yz[c],e in d&&(a.Xa[e]=d[e])}else d=a.Xa||{};if(c=Zz(d))a.Ie=Fs(c.invideoUrl),a.Yk=!!c.adsOnly,a.Zk=!!c.allowInPlaceSwitch;else{if(c=b.iv_invideo_url)a.Ie=Fs(c);a.Yk=T(a.Yk,b.iv_ads_only);a.Zk=T(a.Zk,b.iv_allow_in_place_switch)}if(c=b.cta_conversion_urls)a.lt=c;a.isPharma=T(a.isPharma,b.is_pharma);
a.author=Jx(a.author,b.author);a.nl=T(a.nl,b.cc_asr);a.xk=T(a.xk,b.cc_auto_caps);if(c=b.ttsurl)Ds(c)?a.ol=c:(c=Es(c),Ds(c,!0)&&(a.ol=c));if(d.captions&&d.captions.playerCaptionsTracklistRenderer)Jga(a,d.captions.playerCaptionsTracklistRenderer);else{c=b.caption_tracks;e=b.caption_audio_tracks;if(c&&e){Kga(a,c);Lga(a,e);if(c=b.default_audio_track_index)a.bo=(0,window.parseInt)(c,10)||0;(c=b.caption_translation_languages)&&Mga(a,c)}a.Qi=T(a.Qi,b.cc_contribute)}a.channelPath=Jx(a.channelPath,b.channel_path);
a.channelBanner=Jx(a.channelBanner,b.channel_banner);a.videoCountText=Jx(a.videoCountText,b.video_count_text);d.chapterMarkers&&(a.chapterMarkers=d.chapterMarkers);a.autonavState=Hx(a.autonavState,b.autonav_state,Nga);a.clientPlaybackNonce=Jx(a.clientPlaybackNonce,b.cpn);a.subscribed=T(a.subscribed,b.subscribed);a.shortViewCount=Jx(a.shortViewCount,b.short_view_count_text);a.title=Jx(a.title,b.title);a.subtitle=Jx(a.subtitle,b.subtitle);a.expandedTitle=Jx(a.expandedTitle,b.expanded_title);a.expandedSubtitle=
Jx(a.expandedSubtitle,b.expanded_subtitle);a.Ki=Jx(a.Ki,b.aria_label);a.ypcPreview=Jx(a.ypcPreview,b.ypc_preview);a.ypcOrigin=Jx(a.ypcOrigin,b.ypc_origin);a.ypcClickwrapMessage=Jx(a.ypcClickwrapMessage,b.ypc_clickwrap_message);a.paygated=T(a.paygated,b.paygated);a.requiresPurchase=T(a.requiresPurchase,b.requires_purchase);if(d=b.keywords)a.keywords=$z(d.split(","));if(d=b.rvs)a.suggestions=tp(d);a.contentCheckOk=T(a.contentCheckOk,"1"==b.cco);a.racyCheckOk=T(a.racyCheckOk,"1"==b.rco);a.oauthToken=
Jx(a.oauthToken,b.oauth_token);a.fm=Jx(a.fm,b.kpt);a.visitorData=Jx(a.visitorData,b.visitor_data);if(d=b.session_data)a.Zc=g.rp(d);if(d=b.endscreen_autoplay_session_data)a.iu=g.rp(d);a.hu=Jx(a.hu,b.endscreen_ad_tracking_data);a.wA=T(a.wA,b.wait_for_vast_info_cards_xml);a.Hr=T(a.Hr,b.suppress_creator_endscreen);a.ag=Jx(a.ag,b.wpid);a.dA=Jx(a.dA,b.tracking_list||b.tv_list);!a.kk&&b.intro_start_ms&&b.intro_end_ms&&(a.mp=(0,window.parseInt)(b.intro_start_ms,10),a.kp=(0,window.parseInt)(b.intro_end_ms,
10));(0,g.C)(Oga,function(a){a in b&&(this.Nd[a]=b[a])},a)};
Pga=function(a){if(!a||!a.adPlacements)return!1;a=g.q(a.adPlacements);for(var b=a.next();!b.done;b=a.next())if(b=b.value.adPlacementRenderer,null!=b&&"AD_PLACEMENT_KIND_START"==(b.config&&b.config.adPlacementConfig&&b.config.adPlacementConfig.kind))return!0;return!1};
bA=function(a){return!(!a.xa||!a.xa.videoInfos.length)};
dA=function(a,b){b=void 0===b?!1:b;var c=a.zj,d=!!a.ma&&(a.ma.yf()||a.ma.zf()||a.ma.Oe()),e=a.Ra,f=!!a.ma&&a.ma.xf,k=b,l=a.Xr,m=a.isAd(),n=new gga;n.F=cA(a);n.aacHigh=l&&e.sb;g.Kp("windows nt 5.1")&&!g.hu&&(n.l=!0);d&&Xx&&6>=du&&(n.l=!0);if(l=d)l=e.la("disable_html5_ambisonic_audio")||!(g.sy(e)||e.la("html5_enable_spherical")||e.la("html5_enable_spherical3d"))?!1:ty(e);l&&(n.C=!0);if(k||c)n.l=!0,n.L=!0;fu(e.T,ou)&&(n.A=!0,g.R(e.experiments,"html5_ac3_killswitch")||(n.B=!0));if(f||d)n.G=!1;n.H=!1;
n.o=g.R(e.experiments,"html5_medcap_av1_hybrid");c=g.S(e.experiments,"html5_av1_thresh");(d=tx("1"))&&(c=Math.min(c,d));m&&(c=0);try{var p=+window.localStorage["yt-player-av1-pref"];n.o=n.o&&!p;c=p||c}catch(u){}0<c&&2160>c&&window.SourceBuffer&&window.SourceBuffer.prototype.changeType&&(n.g=c);2160<=c&&(n.J=!0);return n};
Rga=function(a,b){var c;(c=!a.adaptiveFormats)||(c=!(!Op()&&a.adaptiveFormats));if(c)return!1;c=ax(eA(a,a.adaptiveFormats),a.Ec,a.lengthSeconds,a.ra,a.yj,b);var d;if(d=c.l)d=!(g.R(b,"html5_manifestless_vp9")||!Qga(c));if(d)return c.dispose(),!1;fA(a,c);a.ma.o&&c.subscribe("cuepointsadded",a.Ht,a);Yw(a.ma)&&(a.Vh=!0);return!0};
Qga=function(a){return a.l&&Dt('video/webm; codecs="vp9"')&&Fb(a.g,function(a){return qt(a.info)})};
gA=function(a){return!(!a.ma||!a.ma.l)};
iA=function(a){if(!(a.xa&&a.xa.videoInfos.length&&g.tt(a.xa.videoInfos[0])&&gA(a))||g.Np()&&!a.la("html5_streaming_xhr_try_cobalt")||g.uu&&!a.la("html5_streaming_xhr_try_edge"))return!1;var b=a.la("html5_streaming_response_mediastream_rewrite_v2"),c="ULTRALOW"==a.latencyClass;a=21530001==hA(a);return b||c||a};
jA=function(a){return iA(a)&&(!a.la("html5_live_benchmark_incremental_parsing")||"ULTRALOW"==a.latencyClass||21530001==hA(a))};
hA=function(a){return a.isLowLatencyLiveStream&&void 0!=a.ma&&5<=lx(a.ma)?21530001:a.liveExperimentalContentId};
kA=function(a){return!ru()||a.cu?!0:!1};
g.lA=function(a){if(!a.bd)return null;var b=null!=a.bd.latitudeE7&&null!=a.bd.longitudeE7?a.bd.latitudeE7+","+a.bd.longitudeE7:",";return b+=","+(a.bd.clientPermissionState||0)+","+(a.bd.locationRadiusMeters||"")+","+(a.bd.locationOverrideToken||"")};
mA=function(a){if(!a.ea()){a.Af=!1;var b=a.la("web_player_raw_data_loaded_killswitch")?a.Nd:void 0;a.P("dataloaded",b)}};
fA=function(a,b,c){c&&a.ma&&a.ma.dispose();a.ma=b;g.I(a,b);nA(a)&&a.xc.push("webgl");a.ma.isLive||(a.ra=!1)};
g.oA=function(a,b){if(a.ea())return bq();a.xa=null;a.Dd=null;a.De=null;var c=a.Ra.l.c;a.la("disable_rqs")||(a.ig=/^rq/.test(a.clientPlaybackNonce)||/^r/.test(a.clientPlaybackNonce)&&/UNPLUGGED/.test(c)||a.la("html5_high_res_logging"));return Sga(a,b).then(void 0,(0,g.z)(a.LD,a)).then(void 0,(0,g.z)(a.ID,a,b)).then(void 0,(0,g.z)(a.JD,a,b)).then(void 0,(0,g.z)(a.MD,a)).then(void 0,(0,g.z)(a.KD,a)).then(function(){if(a.la("html5_probe_media_capabilities")&&a.xa)return jga(a.xa).then(a.mn,void 0,a)})};
Sga=function(a,b){if(!b&&!kA(a)){var c=!1;if(a.spacecastAdaptiveFormats)fA(a,ax(eA(a,a.spacecastAdaptiveFormats),a.Ec,a.lengthSeconds,!1,!1),!0),c=!0;else if(a.ma&&a.tn){var d=ix(a.ma,a.tn);d&&(fA(a,d,!0),c=!0)}if(c)return Ky(dA(a,!0),a.Ra.T,a.ma,a.Re).then(a.mn,void 0,a).then(a.pu,void 0,a)}return bq()};
pA=function(a){var b={cpn:a.clientPlaybackNonce,c:a.Ra.l.c,cver:a.Ra.l.cver};a.lk&&(b.ptk=a.lk,b.oid=a.dr,b.ptchn=a.ar,b.pltype=a.fr);return b};
g.qA=function(a){return Op()&&a.fairPlayCert?(a={},a.fairplay="https://youtube.com/api/drm/fps?ek=uninitialized",a):a.ua&&a.ua.Ec||null};
g.rA=function(a){var b=a.Xa&&a.Xa.paidContentOverlay&&a.Xa.paidContentOverlay.paidContentOverlayRenderer||null;return b&&b.text?g.Wz(b.text):a.mM};
g.sA=function(a){var b=a.Xa&&a.Xa.paidContentOverlay&&a.Xa.paidContentOverlay.paidContentOverlayRenderer||null;return b&&b.durationMs?wb(b.durationMs):a.By};
tA=function(a){var b="";a.ra&&(b=a.isPremiere?"lp":a.yj&&a.la("enable_vss_type_post")?"post":a.yg?"dvr":"live");return b};
g.uA=function(a,b){return g.v(a.keywords[b])?a.keywords[b]:null};
vA=function(a){return!!(a.Ud||a.adaptiveFormats||a.Ei||a.Ai||a.spacecastFormatMap||a.spacecastAdaptiveFormats||a.hlsvp)};
wA=function(a){var b=g.Ma(a.xc,"ypc");a.ypcPreview&&(b=!1);return a.ld()&&!a.Af&&(vA(a)||g.Ma(a.xc,"fresca")||g.Ma(a.xc,"heartbeat")||b)};
eA=function(a,b,c){b=tp(b);var d={};c&&(0,g.C)(c.split(","),function(a){(a=a.match(/^([0-9]+)\/([0-9]+)x([0-9]+)(\/|$)/))&&(d[a[1]]={width:a[2],height:a[3]})});
(0,g.C)(b,function(a){var b=d[a.itag];b&&(a.width=b.width,a.height=b.height)},a);
return b};
Tga=function(a){a=tp(a);var b={};(0,g.C)(a,function(a){var c=a.family;a=a.url;c&&a&&(b[c]=a)});
return b};
Kga=function(a,b){for(var c=tp(b),d=0;d<c.length;d++){var e=c[d],f=e.u;Ds(f)&&a.captionTracks.push(new g.et({is_translateable:T(!1,e.t),languageCode:e.lc,languageName:e.n,url:f,vss_id:e.v,kind:e.k,format:3}))}};
Lga=function(a,b){var c=tp(b);a.Pi=[];(0,g.C)(c,function(a){var b={};g.t(a.aid)&&(b.audioTrackId=a.aid);var c=a.i;c&&(b.captionTrackIndices=(0,g.E)(c.split(","),function(a){return(0,window.parseInt)(a,10)}));
b.hasDefaultTrack=g.t(a.d);b.hasDefaultTrack&&(b.defaultCaptionTrackIndex=(0,window.parseInt)(a.d,10)||void 0);b.hasForcedTrack=g.t(a.f);b.hasForcedTrack&&(b.forcedCaptionTrackIndex=(0,window.parseInt)(a.f,10));b.visibility=Uga[(0,window.parseInt)(a.v,10)]||"UNKNOWN";this.Pi.push(b)},a)};
Mga=function(a,b){for(var c=tp(b),d=0;d<c.length;d++){var e=c[d];a.captionTranslationLanguages.push(new g.dt({languageCode:e.lc,languageName:e.n}))}};
Vga=function(a,b){var c=b.playerAttestationRenderer.challenge;null!=c&&(a.Bg=c)};
Jga=function(a,b){a.captionTracks=[];b.captionTracks&&(0,g.C)(b.captionTracks,function(a){var b=a.baseUrl;Ds(b,!0)&&(a=new g.et({is_translateable:!!a.isTranslatable,languageCode:a.languageCode,languageName:a.name&&g.Wz(a.name),url:b,vss_id:a.vssId,kind:a.kind,format:3}),this.captionTracks.push(a))},a);
a.Pi=b.audioTracks||[];a.bo=b.defaultAudioTrackIndex||0;a.captionTranslationLanguages=b.translationLanguages?(0,g.E)(b.translationLanguages,function(a){return new g.dt({languageCode:a.languageCode,languageName:g.Wz(a.languageName)})}):[];
a.Qi=!!b.contribute&&!!b.contribute.captionsMetadataRenderer};
Wga=function(a,b,c){if(a.Zq){var d=b.heartbeatToken;d&&(a.drmSessionId=b.drmSessionId||"",a.heartbeatToken=d,a.heartbeatInterval=(0,window.parseInt)(b.intervalMilliseconds,10),a.heartbeatRetries=(0,window.parseInt)(b.maxRetries,10),a.heartbeatSoftFail=!!b.softFailOnError,a.sj=!!b.useInnertubeHeartbeatsForDrm,c.ypc_license_checker_module="1")}};
Xga=function(a,b){var c=b.playerLegacyMulticameraRenderer;c&&(c=c.metadataList)&&(a.multifeedMetadataList=c,a.zg=tp(c))};
Yga=function(a,b){if(a.Fy){var c=b.playerControlsOverlayRenderer;c&&(c=c.controlBgHtml,null!=c&&(a.dniColor=c,a.isDni=!0))}};
Zga=function(a,b,c){a.tM&&(b=b.ypcClickwrap)&&(b=b.playerLegacyDesktopYpcClickwrapRenderer)&&(a.ypcClickwrapMessage=b.durationMessage||"",c.ypc_clickwrap_module="1")};
$ga=function(a,b,c){var d=xA(b.googleRemarketingUrl);d&&(a.googleRemarketingUrl=d);if(d=xA(b.youtubeRemarketingUrl))a.youtubeRemarketingUrl=d;if(a.Gy&&(d=xA(b.ptrackingUrl))){d=yA(d);var e=d.oid;e&&(a.dr=e);if(e=d.pltype)a.fr=e;if(e=d.ptchn)a.ar=e;if(d=d.ptk)a.lk=(0,window.encodeURIComponent)(d)}a.qM&&(d=xA(b.ppvRemarketingUrl))&&(a.ppvRemarketingUrl=d);if(a.rM&&(d=xA(b.qoeUrl))){d=g.up(d);for(var f in d)e=d[f],d[f]=g.ya(e)?e.join(","):e;if(f=d.cat)a.nk=f}a.sM&&(f=xA(b.remarketingUrl))&&(a.remarketingUrl=
f,f=yA(f),f.foc_id&&(a.Qc.focEnabled=!0),f=f.data)&&(a.Qc.rmktEnabled=!0,f.engaged&&(a.Qc.engaged="1"));if(a.Hy&&(b=xA(b.videostatsPlaybackUrl))){b=yA(b);if(f=b.adformat)c.adformat=f;if(c=b.autoplay)a.oi="1"==c;if(c=b.autonav)a.Qh="1"==c;if(c=b.delay)a.ne=wb(c);if(c=b.ei)a.eventId=c;if(c=b.feature)a.ri=c;if(c=b.list)a.playlistId=c;if(c=b.of)a.Rm=c;if(c=b.osid)a.osid=c;if(c=b.plid)a.playbackId=c;if(c=b.referrer)a.referrer=c;if(c=b.sdetail)a.qk=c;if(c=b.ssrt)a.tk="1"==c;if(c=b.subscribed)a.subscribed=
"1"==c,a.Qc.subscribed=c;if(c=b.upt)a.Ak=c;if(c=b.vm)a.videoMetadata=c;if(c=b.wpid)a.ag=c}};
aha=function(a,b){if(a.Cy){var c=b.audioConfig;if(c){var d=c.loudnessDb;null!=d&&(a.relativeLoudness=d);c.audioMuted&&(a.Cg=!0);c.muteOnStart&&(a.Cg=!0)}}a.Dy&&(c=b.fairPlayConfig)&&((d=c.certificate)&&window.atob&&(a.fairPlayCert=(0,window.atob)(d)),d=(0,window.parseInt)(c.keyRotationPeriodMs,10),0<d&&(a.bj=d),c=(0,window.parseInt)(c.keyPrefetchMarginMs,10),0<c&&(a.aj=c));if(a.pM){if(c=b.playbackStartConfig){a.Jy=(0,window.parseInt)(c.startSeconds,10);if(d=c.liveUtcStartSeconds)a.liveUtcStartSeconds=
(0,window.parseInt)(d,10);if(c=c.startPosition){if(d=c.utcTimeMillis)a.liveUtcStartSeconds=.001*(0,window.parseInt)(d,10);if(c=c.streamTimeMillis)a.un=.001*(0,window.parseInt)(c,10)}}else if(c=b.skippableSegmentsConfig){if(d=c.introSkipDurationMs)a.lp=d/1E3;if(c=c.outroSkipDurationMs)a.Yq=c/1E3}if(d=b.skippableIntroConfig)c=(0,window.parseInt)(d.startMs,10),d=(0,window.parseInt)(d.endMs,10),(0,window.isNaN)(c)||(0,window.isNaN)(d)||(a.mp=c,a.kp=d)}if(a.kk){if(c=b.streamSelectionConfig)a.Qe=(0,window.parseInt)(c.maxBitrate,
10);(c=b.visualizerConfig)&&c.isVisualizerEligible&&(a.isVisualizerEligible=!0);if(c=b.vrConfig)a.xj="1"==c.partialSpherical}if(c=b.webDrmConfig)if(c.skipWidevine&&(a.Hz=!0),c=c.widevineServiceCert)a.Ck=g.Wd(c)};
cha=function(a,b){if(a.Ey){var c=b.licenseInfos;if(c&&0<c.length){for(var d={},e=g.q(c),f=e.next();!f.done;f=e.next()){var k=f.value;f=k.drmFamily;k=k.url;f&&k&&(d[bha[f]]=k)}a.Ec=d;if(c=c[0].drmParams)a.drmParams=c}}if(a.nM){if(c=b.dashManifestUrl)a.Ud=g.Ig(c,{cpn:a.clientPlaybackNonce});if(c=b.hlsManifestUrl)a.hlsvp=c;if(c=b.probeUrl)a.probeUrl=Fs(g.Ig(c,{cpn:a.clientPlaybackNonce}))}};
dha=function(a,b){var c=b.videoId;c&&(a.videoId=c);if(c=b.title)a.title=c;if(c=b.lengthSeconds)a.lengthSeconds=(0,window.parseInt)(c,10);if(c=b.keywords)a.keywords=$z(c);if(c=b.channelId)a.vh=c;if(c=b.author)a.author=c;if(c=b.isCrawlable)a.isListed=c;if(c=b.musicVideoType)a.musicVideoType=c;c=b.isLive;null!=c&&(a.ra=c,a.isPremiere=!!c&&!b.isLiveContent)};
g.zA=function(a,b){return!!a.Nd[b]};
g.AA=function(a){return a.ra&&!a.yg};
BA=function(a){return a.ra&&a.yg};
nA=function(a){return a.zf()||a.yf()||a.Rg()||a.Oe()};
eha=function(a){a.xa=a.xa.l};
g.CA=function(a){if(a.Hr)return null;var b=a.Nd.iv_endscreen_url;b||(b=a.Xa&&a.Xa.endscreen&&a.Xa.endscreen.endscreenUrlRenderer&&a.Xa.endscreen.endscreenUrlRenderer.url);return b||null};
DA=function(a){return a.adFormat&&"1_5"!=a.adFormat?"adunit":a.Ra.R};
EA=function(a){if(a.isAd()&&a.videoId!=a.Ra.ha)return a.Ra.ha};
FA=function(a){return a.oi||"detailpage"==DA(a)};
GA=function(a){return FA(a)?"detailpage"==DA(a)?a.Qh||0<a.bf:!0:!1};
HA=function(a){return a.oauthToken||a.Ra.Oa};
IA=function(a){var b=1,c=g.S(a.Ra.experiments,"html5_default_ad_gain");c&&a.isAd()&&(b=c);return Math.min(1,Math.pow(10,-a.relativeLoudness/20))||b};
cA=function(a){return!a.Ra.deviceHasDisplay||a.Yr&&a.Ra.sb};
Zz=function(a){return a&&a.annotations&&(a=a.annotations[0],a.playerAnnotationsUrlsRenderer)?a.playerAnnotationsUrlsRenderer:null};
xA=function(a){return a&&a.baseUrl||""};
yA=function(a){a=g.up(a);for(var b in a){var c=a[b];a[b]=g.ya(c)?c[0]:c}return a};
$z=function(a){var b={};(0,g.C)(a,function(a){var c=a.split("=");2==c.length?b[c[0]]=c[1]:b[a]=!0});
return b};
JA=function(a,b,c,d){this.videoData=a;this.g=b;this.reason=c;this.l=d};
KA=function(){this.endTime=this.startTime=-1;this.co="-";this.playbackRate=1;this.visibilityState=0;this.Un="";this.volume=this.connectionType=this.Rf=0;this.muted=!1};
MA=function(a){this.l=a;this.H=!1;this.g=0;this.B=-1;this.L=this.l.kd().volume;this.J=this.l.kd().muted;this.C=window.NaN;this.o=0;this.Wa=[];this.A=LA(this.l);this.F=this.G=0};
g.NA=function(a){a.A.startTime=a.o;a.A.endTime=a.g;a.Wa.length&&g.Ha(a.Wa).isEmpty()?a.Wa[a.Wa.length-1]=a.A:a.Wa.length&&a.A.isEmpty()||a.Wa.push(a.A);a.G+=a.g-a.o;a.A=LA(a.l);a.o=a.g};
OA=function(a){return a.G+a.l.l()-a.o};
PA=function(a){a.Wa.length&&a.g==a.o||g.NA(a);var b=a.Wa;a.Wa=[];return b};
QA=function(a,b,c){c-=a.C;return b==a.g&&.5<c};
fha=function(a,b,c,d,e,f,k,l,m,n,p,u,x){this.videoData=a;this.g=b;this.kd=c;this.C=d;this.l=e;this.B=f;this.J=k;this.getAudioTrack=l;this.H=m;this.F=n;this.o=p;this.G=u||function(){};
this.A=null;this.L=x||function(){}};
g.SA=function(a){return RA(a)()};
RA=function(a){if(!a.A){var b=g.Ea(function(a){var b=g.qr();a&&631152E6>=b&&(g.M(Error("invalid yt.global.now value: "+b)),b=(new Date).getTime()+2);return b},g.R(a.g.experiments,"html5_validate_yt_now"));
a.A=g.Ea(function(a){return Math.round(b()-a)/1E3},b());
a.L()}return a.A};
TA=function(a){var b=a.kd();g.Fa(b,a.videoData.kd());return b};
VA=function(a){if(window.navigator.connection&&window.navigator.connection.type)return UA[window.navigator.connection.type]||UA.other;if(g.R(a.g.experiments,"html5_tv_bearer")&&g.gy(a.g)){a=window.navigator.userAgent;if(/[Ww]ireless[)]/.test(a))return 3;if(/[Ww]ired[)]/.test(a))return 1}return 0};
LA=function(a){var b=new KA;b.co=a.kd().cc||"-";b.playbackRate=a.H();var c=a.o();0!=c&&(b.visibilityState=c);a.g.Rf&&(b.Rf=1);c=a.getAudioTrack();c.ib&&c.ib.id&&"und"!=c.ib.id&&(b.Un=c.ib.id);b.connectionType=VA(a);b.volume=a.kd().volume;b.muted=a.kd().muted;return b};
g.WA=function(a){return(a=gha[a.toString()])?a:"LICENSE"};
XA=function(){};
YA=function(a,b){a.g&&null!=b&&b.g==a.g.g||(a.g&&a.g.dispose(),a.g=b)};
g.ZA=function(a){a=void 0===a?!1:a;g.G.call(this);this.B=this.o=this.A=null;this.G=a;this.J=this.H=!1;this.F=new g.xf;g.I(this,this.F)};
$A=function(a){a=a.Ml();return 1>a.length?window.NaN:a.end(a.length-1)};
aB=function(a,b){a.A&&null!=b&&b.g==a.A.g||(a.A&&a.A.dispose(),a.A=b)};
bB=function(a){return Qt(a.Le(),a.ya())};
cB=function(a){var b=a.Le();return 0<Pt(b)&&a.ec()?Ot(b,a.ya()):0};
dB=function(a){var b=a.ec();return window.Infinity==b?1:b?cB(a)/b:0};
eB=function(a){switch(a.Ue()){case 2:return"progressive.net.retryexhausted";case 3:return"fmt.decode";case 4:return"fmt.unplayable";case 5:return"drm.unavailable";case 1E3:return"capability.changed";default:return null}};
fB=function(a,b,c){g.Ze.call(this,b,a);this.g=c||null};
hha=function(a){this.A=this.g=window.NaN;this.o=this.l=!1;this.B=void 0===a?!1:a};
gB=function(a,b){return b>a.g+(a.B?.001:0)&&b<a.g+5};
hB=function(a,b,c,d){if(d=1<d)a.o=!0;if(a.l)b!=a.g&&(a.l=!1);else if(0<b&&a.g==b)return c-a.A>(d||!a.o?1500:400);a.g=b;a.A=c;return!1};
g.iB=function(a,b){this.g=a||64;this.l=void 0===b?null:b};
jB=function(a,b){return hB(a,b.ya(),g.qr(),bB(b))};
kB=function(a,b,c){return b==a.g&&c==a.l||void 0!=b&&(b&128&&!c||b&2&&b&16)?a:new g.iB(b,c)};
lB=function(a,b){return kB(a,a.g|b)};
mB=function(a,b){return kB(a,a.g&~b)};
nB=function(a,b,c){return kB(a,(a.g|b)&~c)};
g.U=function(a,b){return!!(a.g&b)};
g.oB=function(a,b){return b.g==a.g&&b.l==a.l};
g.pB=function(a){return g.U(a,8)&&!g.U(a,512)&&!g.U(a,64)&&!g.U(a,2)};
g.qB=function(a){return g.U(a,8)&&!g.U(a,2)&&!g.U(a,1024)};
g.rB=function(a){return g.U(a,64)&&!g.U(a,8)&&!g.U(a,4)};
g.sB=function(a){return g.U(a,1)&&!g.U(a,2)};
tB=function(a){return g.U(a,128)?-1:g.U(a,2)?0:g.U(a,64)?-1:g.U(a,1)&&!g.U(a,32)?3:g.U(a,8)?1:g.U(a,4)?2:-1};
g.uB=function(a,b){this.state=a;this.g=b};
g.vB=function(a,b){return g.U(a.state,b)&&!g.U(a.g,b)?1:!g.U(a.state,b)&&g.U(a.g,b)?-1:0};
xB=function(a){g.G.call(this);var b=this;this.g=a;this.l={};this.J=1;this.X=window.NaN;this.o="N";this.C=this.ba=this.Y=this.A=0;this.O=this.ka="";this.da=0;this.oa=-1;this.ga=1;this.L=this.T=0;this.Z=this.H=!1;this.pa=[];this.F=null;this.R=this.G=!1;(a=window.navigator.getBattery?window.navigator.getBattery():null)&&a.then&&a.then(function(a){b.F=a});
g.wB(this,0,"vps",["N"])};
g.wB=function(a,b,c,d){var e=a.l[c];e||(e=[],a.l[c]=e);e.push(b.toFixed(3)+":"+d.join(":"))};
AB=function(a,b){b=0<=b?b:g.SA(a.g);var c=a.g.B();if(!(0,window.isNaN)(a.ha)&&!(0,window.isNaN)(c.o)){var d=c.o-a.ha;0<d&&g.wB(a,b,"bwm",[d,(c.B-a.wa).toFixed(3)])}a.ha=c.o;a.wa=c.B;(0,window.isNaN)(c.bandwidthEstimate)||g.wB(a,b,"bwe",[c.bandwidthEstimate.toFixed(0)]);a.g.videoData.ig&&c.g&&yB(a,"bwinfo",c.g);a.F&&g.wB(a,b,"bat",[a.F.level,a.F.charging?"1":"0"]);d=a.g.o();a.oa!=d&&(g.wB(a,b,"vis",[d]),a.oa=d);g.wB(a,b,"cmt",[a.g.l().toFixed(3)]);(d=VA(a.g))&&d!=a.da&&(g.wB(a,b,"conn",[d]),a.da=d);
zB(a,b,c);null!==a.g.videoData.Wk&&(a.l.acc=[a.g.videoData.Wk.join(":")])};
zB=function(a,b,c){if(!(0,window.isNaN)(c.l)){var d=c.l;c.A<d&&(d=c.A);g.wB(a,b,"bh",[d.toFixed(3)])}};
BB=function(a){var b=0,c;for(c in a.l)b+=c.length+Aj(a.l[c],function(a,b){return a+b.length},0);
1E3<b&&(new g.L(a.B,0,a)).start()};
CB=function(a,b,c,d){var e=a.g.l();c=[c,e.toFixed(3)];d&&c.push(d);g.wB(a,b,"error",c)};
jha=function(a,b){if(g.U(b,128))return"ER";if(g.U(b,512))return"SU";if(g.U(b,16)||g.U(b,32))return"S";var c=iha[tB(b)];g.gy(a.g.g)&&"B"==c&&3==a.g.o()&&(c="SU");"B"==c&&g.U(b,4)&&(c="PB");return c};
DB=function(a,b){var c=a.l.cat||[];c.push(b);a.l.cat=c};
yB=function(a,b,c,d){var e=a.l.ctmp||[],f=-1!=a.pa.indexOf(b);f||a.pa.push(b);d&&f||(d||(c="t."+(1E3*g.SA(a.g)).toFixed()+";"+c),e.push(b+":"+c),a.l.ctmp=e,BB(a))};
EB=function(a,b,c,d){this.Oa=b;this.segments=[];this.experimentIds=[];this.adQueryId=null;this.jg=this.da=this.isFinal=this.sc=this.O=this.autoplay=this.autonav=!1;this.ba="yt";this.l=this.B=null;this.R=!1;this.A="watchtime"==c;this.F="playback"==c;this.T="delayplay"==c;this.C="atr"==c;this.Fc="engage"==c;this.xi=!1;this.ka=g.R(this.Oa.experiments,"web_player_attestation_auth_headers");this.oa=this.C?"/api/stats/"+c:"//"+b.Of+"/api/stats/"+c;d&&(this.da=d.fs,d.rtn&&(this.l=d.rtn),this.A?(this.playerState=
d.state,0<d.rti&&(this.B=d.rti)):(this.Ia=d.mos,this.Va=d.volume,d.at&&(this.adType=d.at)),d.autonav&&(this.autonav=d.autonav),d.inview&&(this.ga=d.inview),d.size&&(this.ha=d.size));this.Ta=g.Wb(b.l);this.wa=b.pa;this.experimentIds=b.experiments.experimentIds;this.X=b.Mb;this.ba=b.Z;this.region=b.region;this.userAge=b.userAge;this.userGender=b.userGender;this.ab=Gr();this.xi=b.sa;this.G=HA(a);this.adFormat=a.adFormat;this.adQueryId=a.adQueryId;this.autoplay=GA(a);this.autonav=a.Qh||this.autonav;this.contentVideoId=
EA(a);this.clientPlaybackNonce=a.clientPlaybackNonce;this.O=a.isDni;a.vssCredentialsToken&&(this.L=a.vssCredentialsToken,this.sa=a.In);a.mdxEnvironment&&(this.mdxEnvironment=a.mdxEnvironment);this.Wf=a.Wf;this.ne=a.ne;a.ua&&(this.pa=g.ot(a.ua),a.Yb&&g.ot(a.Yb)!=this.pa&&(this.J=g.ot(a.Yb)));this.jg=a.jg;this.Oh=a.Oh;if(b=tA(a))this.Ja=b;this.Dj=a.Dj;this.Ce=a.Ce;this.playbackId=a.playbackId;this.eventId=a.eventId;this.playlistId=a.dA||a.playlistId;this.qk=a.qk;this.Ee=a.Ee;this.Fe=a.Fe;this.tk=a.tk;
this.subscribed=a.subscribed;this.videoId=a.videoId;this.videoMetadata=a.videoMetadata;this.visitorData=a.visitorData;this.osid=a.osid;this.Rm=a.Rm;this.referrer=a.referrer;this.ri=a.kr||a.ri;this.Ci=a.Ci;this.Ak=a.Ak;this.ag=a.ag;this.Ca=DA(a)};
FB=function(a,b){if(!a.ka&&a.C)return null;var c=a.G&&zp(),d=a.xi&&!!a.visitorData;if(!c&&!d)return null;var e={};c&&(e.Authorization="Bearer "+a.G);d&&(e["X-Goog-Visitor-Id"]=a.visitorData);return{headers:e,withCredentials:!0,Yc:b}};
kha=function(a,b,c,d){b.cmt=b.len;b.lact="0";d=d();d=d.toFixed(3);b.rt=(1*d).toString();a=g.Ig(a,b);c?g.Fp(a,c):g.Vp(a)};
HB=function(a){var b={ns:a.ba,el:a.Ca,cpn:a.clientPlaybackNonce,docid:a.videoId,ver:2,referrer:a.referrer,cmt:a.g(a.Wf),plid:a.playbackId,ei:a.eventId,fmt:a.pa,fs:a.da?"1":"0",rt:a.g(a.Ya),of:a.Rm,adformat:a.adFormat,content_v:a.contentVideoId,euri:a.wa,lact:a.ab,live:a.Ja,cl:"223881213",mos:a.Ia,osid:a.osid,state:a.playerState,vm:a.videoMetadata,volume:a.Va};a.adQueryId&&(b.aqi=a.adQueryId);a.subscribed&&(b.subscribed="1");g.Fa(b,a.Ta);a.autonav&&(b.autonav="1");a.autoplay&&(b.autoplay="1");a.O&&
(b.dni="1");a.isFinal&&(b["final"]="1");a.jg&&(b.splay="1");a.ne&&(b.delay=a.ne);a.X&&(b.hl=a.X);a.region&&(b.cr=a.region);g.t(a.userAge)&&a.userGender&&(b.uga=a.userGender+a.userAge);g.t(a.Y)&&(b.len=a.g(a.Y));!a.A&&0<a.experimentIds.length&&(b.fexp=a.experimentIds.toString());null!=a.l&&(b.rtn=a.g(a.l));a.ri&&(b.feature=a.ri);a.playlistId&&(b.list=a.playlistId);a.Ee&&(b.ctrl=a.Ee);a.Fe&&(b.ytr=a.Fe);a.tk&&(b.ssrt="1");a.J&&(b.afmt=a.J);a.Z&&(b.lio=a.g(a.Z));a.A?(b.idpj=a.Oh,b.ldpj=a.Dj,null!=a.B&&
(b.rti=a.g(a.B))):g.t(a.adType)&&(b.at=a.adType);a.ha&&(a.F||a.T)&&(b.size=a.ha);null!=a.ga&&(a.F||a.T)&&(b.inview=a.g(a.ga));a.A&&(b.volume=GB(a,(0,g.E)(a.segments,function(a){return a.volume})),b.muted=GB(a,(0,g.E)(a.segments,function(a){return a.muted?1:0})),b.st=GB(a,(0,g.E)(a.segments,function(a){return a.startTime})),b.et=GB(a,(0,g.E)(a.segments,function(a){return a.endTime})),(0,g.rj)(a.segments,function(a){return 1!=a.playbackRate})&&(b.rate=GB(a,(0,g.E)(a.segments,function(a){return a.playbackRate}))));
(0,g.rj)(a.segments,function(a){return 0!=a.visibilityState})&&(b.vis=GB(a,(0,g.E)(a.segments,function(a){return a.visibilityState})));
(0,g.rj)(a.segments,function(a){return 0!=a.connectionType})&&(b.conn=GB(a,(0,g.E)(a.segments,function(a){return a.connectionType})));
(0,g.rj)(a.segments,function(a){return 0!=a.Rf})&&(b.blo=GB(a,(0,g.E)(a.segments,function(a){return a.Rf})));
(0,g.rj)(a.segments,function(a){return"-"!=a.co})&&(b.cc=(0,g.E)(a.segments,function(a){return a.co}).join(","));
if((0,g.rj)(a.segments,function(a){return!!a.Un})){var c="au";
a.F&&(c="au_d");b[c]=(0,g.E)(a.segments,function(a){return a.Un}).join(",")}zp()&&a.L&&(b.ctt=a.L,b.cttype=a.sa,b.mdx_environment=a.mdxEnvironment);
a.Fc&&(b.etype=g.t(a.o)?a.o:0);a.Ci&&(b.uoo=a.Ci);a.Ak&&(b.upt=a.Ak);a.ag&&(b.wpid=a.ag);return b};
GB=function(a,b){return(0,g.E)(b,a.g).join(",")};
g.IB=function(a,b){return a.baseYtUrl+"timedtext_video?ref=player&v="+b.videoId};
JB=function(a){g.G.call(this);this.g=a;this.l=new xB(a);g.I(this,this.l);this.o=new MA(a);this.C="paused";this.F=window.NaN;this.J=[10,10,10,40];this.L=this.H=0;this.Z=this.R=this.X=this.Y=this.T=this.O=this.B=!1;this.A=window.NaN};
KB=function(a,b,c){var d=g.SA(a.g);c=(0,window.isNaN)(c)?d:c;c=Math.ceil(c);var e=a.J[a.H];a.H+1<a.J.length&&a.H++;c+=e;d=1E3*(c-d);a.F=g.op((0,g.z)(a.da,a,c,b),d);return c};
LB=function(a,b){var c=TA(a.g);g.Fa(c,{state:a.C});c=new EB(a.g.videoData,a.g.g,b,c);c.Wf=a.g.l();a.g.videoData.ra||(c.Y=a.g.C());if(a.g.videoData.ma){var d=mx(a.g.videoData.ma,c.Wf);d&&(c.Z=d-c.Wf)}c.Ya=g.SA(a.g);c.segments=[LA(a.g)];return c};
MB=function(a,b){var c=LB(a,"watchtime");c.segments=b;c.Wf=a.o.g;return c};
NB=function(a){a.o.update();return MB(a,PA(a.o))};
QB=function(a){a.g.videoData.remarketingUrl&&!a.Y&&(OB(a,a.g.videoData.remarketingUrl),a.Y=!0);a.g.videoData.youtubeRemarketingUrl&&!a.X&&(OB(a,a.g.videoData.youtubeRemarketingUrl),a.X=!0);a.g.videoData.googleRemarketingUrl&&!a.R&&(OB(a,a.g.videoData.googleRemarketingUrl),a.R=!0);a.g.videoData.ppvRemarketingUrl&&!a.Z&&(OB(a,a.g.videoData.ppvRemarketingUrl),a.Z=!0);PB(a)};
RB=function(a){a.A=g.pp((0,g.z)(a.G,a,"heartbeat"),3E4)};
PB=function(a){a.g.videoData.Qc.eventLabel=DA(a.g.videoData);a.g.videoData.Qc.playerStyle=a.g.g.playerStyle;a.g.videoData.Ym&&(a.g.videoData.Qc.feature="pyv");a.g.videoData.Qc.vid=a.g.videoData.videoId;var b=a.g.videoData.Qc;a=a.g.videoData;a=a.isAd()||!!a.Ym;b.isAd=a};
OB=function(a,b,c){a.g.g.sa&&a.g.videoData.visitorData&&yp(b)?g.Fp(b,{Yc:c,headers:{"X-Goog-Visitor-Id":a.g.videoData.visitorData}}):g.Vp(b,c)};
SB=function(a,b){Ts.call(this,a,b);this.g=!1;Us(this,"getPresentingPlayerType",this.Da);Us(this,"addInfoCardXml",this.kF);Us(this,"cueVideoByPlayerVars",this.wm);Us(this,"loadVideoByPlayerVars",this.Tj);Us(this,"preloadVideoByPlayerVars",this.xm);Us(this,"seekBy",this.zd);Us(this,"updatePlaylist",this.NF);Us(this,"updateLastActiveTime",this.MF);Us(this,"updateVideoData",this.OF);Us(this,"canPlayType",this.Ij);Us(this,"sendVideoStatsEngageEvent",this.we);Us(this,"setCardsVisible",this.Uj);Us(this,
"setAutonav",this.ow);Us(this,"setAutonavState",this.Vp);Us(this,"showControls",this.ww);Us(this,"hideControls",this.rw);Us(this,"setSafetyMode",this.FF);Us(this,"cancelPlayback",this.Xp);Us(this,"isContinuousPlayback",this.tw);Us(this,"isFastLoad",this.xF);Us(this,"isInline",this.yF);Us(this,"isPeggedToLive",this.isPeggedToLive);Us(this,"setInline",this.CF);Us(this,"getVideoAspectRatio",this.uF);Us(this,"getPreferredQuality",this.Sj);Us(this,"setPlaybackQualityRange",this.uw);Us(this,"onAdUxClicked",
this.nd);Us(this,"getPlayerResponse",this.getPlayerResponse);Us(this,"getStoryboardFormat",this.getStoryboardFormat);Us(this,"getStoryboardFrame",this.qF);Us(this,"getStoryboardFrameIndex",this.rF);Us(this,"getStoryboardLevel",this.sF);Us(this,"getNumberOfStoryboardLevels",this.pF);Us(this,"getProgressState",this.fh);Us(this,"getAudioTrack",this.getAudioTrack);Us(this,"setAudioTrack",this.Zp);Us(this,"getAvailableAudioTracks",this.getAvailableAudioTracks);Us(this,"getMaxPlaybackQuality",this.oF);
Us(this,"getUserPlaybackQualityPreference",this.tF);Us(this,"setUserEngagement",this.IF);Us(this,"getVideoContentRect",this.qw);Us(this,"updateSubtitlesUserSettings",this.ym);Us(this,"getSubtitlesUserSettings",this.gh);Us(this,"resetSubtitlesUserSettings",this.Yp);Us(this,"setMinimized",this.EF);Us(this,"getSphericalProperties",this.Tp);Us(this,"setSphericalProperties",this.Wp);Us(this,"setBlackout",this.zF);Us(this,"getVisibilityState",this.Cf);Us(this,"setFauxFullscreen",this.AF);Us(this,"toggleFullscreen",
this.Ad);Us(this,"getVideoStats",this.Lu);Us(this,"getPlayerSize",this.eh);Us(this,"isMutedByMutedAutoplay",this.sD);Us(this,"setUseFastSizingOnWatch",this.HF);Us(this,"setInternalSize",this.DF);Us(this,"getHousebrandProperties",this.nF);Us(this,"getCurrentPlaylistSequence",this.mF);Us(this,"getPlaylistSequenceForTime",this.getPlaylistSequenceForTime);Us(this,"handleGlobalKeyDown",this.vF);Us(this,"handleGlobalKeyUp",this.wF);Us(this,"setSizeStyle",this.GF);Us(this,"forceFrescaUpdate",this.lF);Us(this,
"shouldSendVisibilityState",this.JF);Us(this,"setGlobalCrop",this.BF);Us(this,"wakeUpControls",this.oN);Us(this,"updateFullerscreenEduButtonVisibility",this.LF);Us(this,"updateFullerscreenEduButtonSubtleModeState",this.KF)};
TB=function(a){a=(a=at(a.app.C))?a.g:null;return a?(a=a.Gu())?a.O:null:null};
UB=function(a,b){this.o=a;this.g=b||null;this.l=!1};
XB=function(a,b,c){var d=g.Zx(b.Ra)&&b.Ra.Lc&&FA(b);if(b.Ra.zc&&(g.Wx(b.Ra)||g.uy(b.Ra)||d)&&!a.l){a.l=!0;g.ep("TIMING_ACTION")||g.dp("TIMING_ACTION",a.o.csiPageType);a.o.Va&&g.dp("CSI_SERVICE_NAME",a.o.Va);if(a.g){b=a.g.ha;for(var e in b)(0,g.VB)(e,b[e],"");e=a.g.ba;for(var f in e)(0,g.WB)(f,e[f],"");f=a.g;f.ha={};f.ba={}}(0,g.WB)("yt_pvis",Fga(),"");(0,g.WB)("yt_pt","html5","");c&&!Oz("pbs","")&&(0,g.VB)("pbs",c,"");a=a.o;!g.uy(a)&&!g.Wx(a)&&Oz("_start","")&&Vz("")}};
g.YB=function(a,b,c){g.G.call(this);this.start=a;this.end=b;this.B=lha++;a=c||{};this.Ga=a.id||"";this.C=a.priority||7;this.active=!0;this.visible=a.visible||!1;this.style=a.style||"ytp-ad-progress";this.namespace=a.namespace||"";this.color="";if(b=a.color)b=b.toString(16),this.color="#"+Array(7-b.length).join("0")+b;this.g=null;this.tooltip=a.tooltip;this.icons=a.icons?a.icons.filter(function(a){return(0,g.em)(a.thumbnails,function(a){return g.Bs(a.url)})}):null;
this.visible=this.visible;this.style=this.style;this.start=this.start};
ZB=function(a){return-0x8000000000000==a?"BEFORE_MEDIA_START":0==a?"MEDIA_START":0x7ffffffffffff==a?"MEDIA_END":0x8000000000000==a?"AFTER_MEDIA_END":a.toString()};
mha=function(a,b){switch(a.style){case "ytp-chapter-marker":return b?8:5;case "ytp-ad-progress":return 6;case "ytp-time-marker":return Number.POSITIVE_INFINITY;default:return 0}};
g.$B=function(a,b){return a.start-b.start||a.C-b.C||a.B-b.B};
g.aC=function(a){return"crn_"+a};
g.bC=function(a,b){this.type=a||"";this.id=b||""};
g.dC=function(a,b){g.N.call(this);this.Ra=a;this.startSeconds=0;this.Lz=!1;this.Ua=0;this.title="";this.kg=0;this.Ea=[];this.Cj=this.Te=!1;this.Zc=this.iu=this.pk=null;var c=b.session_data;c&&(this.Zc=g.rp(c));this.views=0;this.OB=0!=b.fetch;this.Cd=[];this.Ua=Math.max(0,b.index||0);this.loop=!!b.loop;this.startSeconds=(0,window.parseInt)(b.startSeconds,10)||0;this.UH="1"==b.mob;this.title=b.playlist_title||"";this.description=b.playlist_description||"";this.author=b.author||b.playlist_author||"";
this.tg={};b.video_id&&(this.Ea[this.Ua]=b);if(c=b.api)"string"==typeof c&&16==c.length?b.list="PL"+c:b.playlist=c;this.im=0;if(c=b.list)switch(b.listType){case "user_uploads":this.Cj||(this.listId=new g.bC("UU","PLAYER_"+c),cC(this,"/list_ajax?style=json&action_get_user_uploads_by_user=1",{username:c}));break;case "user_favorites":this.Cj||(this.listId=new g.bC("FL","PLAYER_"+c),cC(this,"/list_ajax?style=json&action_get_favorited_by_user=1",{username:c}));break;case "search":nha(this,c);break;default:var d=
b.playlist_length;d&&(this.kg=(0,window.parseInt)(d,0));this.listId=new g.bC(c.substr(0,2),c.substr(2));(c=b.video)?(this.Ea=c.slice(0),this.Te=!0):oha(this)}else b.playlist&&(c=b.playlist.toString().split(","),0<this.Ua&&(this.Ea=[]),c.forEach(function(a){a&&this.Ea.push({video_id:a})},this),this.kg=this.Ea.length,c=this.Ea.map(function(a){return a.video_id}),cC(this,"/list_ajax?style=json&action_get_templist=1",{video_ids:c.join(",")}),this.Te=!0);
this.setShuffle(!!b.shuffle);if(c=b.suggestedQuality)this.quality=c;this.tg=kz(b,"playlist_");this.Tz=(c=b.thumbnail_ids)?c.split(","):[]};
eC=function(a){return!!(a.playlist||a.list||a.api)};
fC=function(a){var b=a.Ua+1;return b>=a.kg?0:b};
gC=function(a){var b=a.Ua-1;return 0>b?a.kg-1:b};
hC=function(a,b){a.Ua=g.Uc(b,0,a.kg-1);a.startSeconds=0};
nha=function(a,b){if(!a.Cj){a.listId=new g.bC("SR",b);var c={search_query:b};a.UH&&(c.mob="1");cC(a,"/search_ajax?style=json&embeddable=1",c)}};
oha=function(a){if(!a.Cj){var b=b||a.listId;b={list:b};var c=a.za();c&&c.videoId&&(b.v=c.videoId);cC(a,"/list_ajax?style=json&action_get_list=1",b)}};
cC=function(a,b,c){a.OB&&g.Fp(g.Ig(b,c),{format:"JSON",onSuccess:(0,g.z)(function(a,b){iC(this,b)},a),
onError:(0,g.z)(function(){this.P("error")},a)})};
iC=function(a,b){if(b.video&&b.video.length){a.title=b.title;a.description=b.description;a.views=b.views;a.author=b.author;var c=b.loop;c&&(a.loop=c);c=a.za();a.Ea=[];b.video.forEach(function(a){a&&(a.video_id=a.encrypted_id,this.Ea.push(a))},a);
a.kg=a.Ea.length;var d=b.index;d?a.Ua=d:a.cj(c);a.setShuffle(!1);a.Cj=!1;a.Te=!0;a.im++;a.pk&&a.pk()}};
g.jC=function(a){g.ZA.call(this);this.g=a;this.C={}};
kC=function(a,b,c){this.audio=a;this.video=b;this.reason=c};
lC=function(){this.g=this.l=0;this.o=[]};
nC=function(a,b,c){0==c&&(a.l=0,a.g=0,a.o.length=0);if(!((0,window.isNaN)(a.l)||8>b.length)){c=new window.DataView(b.buffer,b.byteOffset);for(var d=!1;!d;)if(a.l==a.g)a:{var e;d=a;var f=b.length;if(d.l+7>=f){for(e=d.l;e<f;e++)d.o.push(c.getUint8(e));d=!0}else{if(0<d.o.length){for(e=0;8>d.o.length;e++)d.o.push(c.getUint8(e));var k=mC(d.o,0);e=mC(d.o,4);d.o.length=0}else k=c.getUint32(d.g),e=c.getUint32(d.g+4);if(1836019558==e||1836019574==e||1718909296==e||1936286840==e||1701671783==e||1937013104==
e||1936419184==e)d.l+=k,d.g=d.l;else if(1835295092==e)d.l+=k,d.g+=8;else{d.l=window.NaN;d=!0;break a}d=d.g>=f}}else a:if(d=a,f=b.length,d.g+5>=f){for(e=d.g;e<f;e++)d.o.push(c.getUint8(e));d=!0}else{if(0<d.o.length){for(e=0;6>d.o.length;e++)d.o.push(c.getUint8(e));e=mC(d.o,0);12==e&&6==d.o[4]&&45==d.o[5]&&c.setUint8(d.g+5,63);d.g+=e+4;d.o.length=0}for(;d.g<d.l&&d.g+5<f;){e=c.getUint32(d.g);if(0>=e){d.l=window.NaN;d=!0;break a}12==e&&6==c.getUint8(d.g+4)&&45==c.getUint8(d.g+5)&&c.setUint8(d.g+5,63);
d.g+=e+4}d=d.g>=f}(0,window.isNaN)(a.l)||(a.l-=b.length,a.g-=b.length)}};
mC=function(a,b){return(a[b]<<24)+(a[b+1]<<16)+(a[b+2]<<8)+a[b+3]};
pC=function(a,b){this.R=a;this.Y=b;this.g=new oC(0,0,null);this.A=8;this.o=[];this.F=[];this.B=this.H=window.NaN;this.T=this.l=this.J=0;this.C=window.NaN;this.Z=0;this.O=!1;this.G=null;this.L=0};
qC=function(a){return{startTime:a.C/a.l,duration:a.T/a.l}};
rC=function(a){a.C=window.NaN;a.T=0;a.G=null;a.L=0};
sC=function(a){return!(0,window.isNaN)(a.B)&&a.l?a.B/a.l:a.Z};
tC=function(a,b,c){var d=b.getUint32(c);b=b.getUint32(c+4);a.g=new oC(b,d,a.g);return 8};
uC=function(a){a.l&&!(0,window.isNaN)(a.H)&&(a.B=Math.floor(a.H*a.l),a.H=window.NaN)};
vC=function(a){return 0==a.g.type||1836019574==a.g.type||1952867444==a.g.type||1936286840==a.g.type||1953653094==a.g.type||1836019558==a.g.type||1836476516==a.g.type};
wC=function(a,b,c){for(var d=c;d<b.byteLength;d++)a.o.push(b.getUint8(d));0<c&&a.F.push(new window.DataView(b.buffer,b.byteOffset,c))};
xC=function(a,b,c){return new Iu(b,c,a.g.size,a.g.type,!0)};
oC=function(a,b,c){this.type=a;this.size=b;this.parent=c;this.offset=this.version=0};
yC=function(a){for(var b=new window.Uint8Array(0),c=new window.DataView(a.buffer,a.byteOffset,a.length),d=0;d<a.length-8;){var e=c.getUint32(d);if(1>=e)break;var f=c.getUint32(d+4);if(1836019574==f)d+=8;else{if(1886614376==f){f=a.subarray(d,d+e);var k=new window.Uint8Array(b.length+f.length);k.set(b);k.set(f,b.length);b=k}d+=e}}return b};
pha=function(a){a=jv(a,1886614376);(0,g.C)(a,function(a){return!a.l});
return(0,g.E)(a,function(a){return new window.Uint8Array(a.data.buffer,a.offset+a.data.byteOffset,a.size)})};
qha=function(a){var b=Aj(a,function(a,b){return a+b.length},0),c=new window.Uint8Array(b),d=0;
(0,g.C)(a,function(a){c.set(a,d);d+=a.length});
return c};
zC=function(a){return g.Ud(a,!0).replace(/[\.]{1,2}$/,"")};
rha=function(a,b){this.l=a;this.C=this.B=!1;this.length=b?b:0;this.o=0;this.g=[];this.A=null;this.length?1!=this.l.length||this.l[0].Na||(this.l[0].Na=this.length):1==this.l.length||(0,g.em)(this.l,function(a){return!!a.range})};
sha=function(a){var b=a.length-a.o;(0,g.C)(a.g,function(a){b+=a.range.length});
return b};
tha=function(a,b){this.l=a;this.g=b};
AC=function(a,b){if(0>b)return!0;var c=a.g.rb();return b<c||b==c&&!a.l.Y||b==c&&(c=Hw(a.g))&&b==c.vb?!0:!1};
uha=function(a,b,c){if(!AC(a,b))return 0;if(!a.l.g||!(0,window.isNaN)(c)&&0<c)return 2;if(0>b)return 1;c=a.g.rb();return b<c||b==c&&(a=Hw(a.g))&&b==a.vb&&!a.g?2:1};
vha=function(a,b,c,d){if(AC(a,b))return d;b=0;a.l.g&&(b=.2);return c+1E3*(a.g.g+b)};
wha=function(a,b,c,d,e){b=uha(a,b,e);if(2==b)return d;c=b?d:c+1E3*a.g.g;a.l.g&&(c+=1E3*a.g.g);return c};
xha=function(a){this.C=a;this.A=window.NaN;this.B=[];this.o=this.g=this.l=0};
yha=function(a,b,c,d,e){this.sa=null;this.l=a;this.wa=b;this.Ca=c;this.Z=d;this.F=e;this.ba=this.g=window.NaN;this.pa=0;this.R=this.ha=this.o=this.C=window.NaN;this.ka=this.ga=this.A=!1;this.B=0;this.da=Fx(this.l);this.X=window.NaN;this.L=this.H=window.Infinity;this.O=window.NaN;this.oa=!1;this.J=this.T=window.NaN;this.G=this.Y=null};
BC=function(a){return{rt:((0,g.D)()-a.g).toFixed(),lb:a.o.toFixed(),pt:(1E3*a.X).toFixed(),pb:a.wa.toFixed(),stall:(1E3*a.B).toFixed(),elbowTime:(a.ba-a.g).toFixed(),elbowBytes:a.pa.toFixed()}};
CC=function(a){a.J||(a.J=a.sa(),3==a.J&&(a.Y=new xha(a.l)));return a.J};
GC=function(a,b,c,d){var e=(b-a.C)/1E3,f=c-a.o,k=CC(a);if(3==k&&f){var l=a.Y;l.B.push({lm:f,Ir:(0,window.isNaN)(l.A)?window.NaN:d-l.A,aR:d});l.A=d}a.A?1==k&&0<f&&(.2<e||1024>f?(a.B+=e,.2<e&&FC(a,.05,f)):FC(a,e,f),a.ka=!0):DC(a,c)&&(1==k&&(d=(b-a.g)/1E3,EC(a)||(k=a.l,k.F.l(1,d),zx(k))),a.ba=b,a.pa=c,a.A=!0);Cx(a.l,e,f);a.C=b;a.o=c};
FC=function(a,b,c){b=Math.max(b,.05);a=a.l;var d=void 0;a.g.l(void 0===d?b:d,c/b);a.o=g.qr()};
IC=function(a,b,c){c=Math.round(c/1024);a.G&&a.G.push(HC(b-a.ha,c-a.R));a.ha=b;a.R=c};
DC=function(a,b){return b?a.F&&1!=CC(a)?!0:b>=a.l.policy.A:!1};
JC=function(a){return DC(a,a.o)};
KC=function(a){a.O=a.g+1E3*a.da.delay;a.oa=!1};
LC=function(a,b){var c=a.Z.g[0].l;a.H=Math.min(a.H,vha(a.F,c,a.g,b));a.L=Math.min(a.L,wha(a.F,c,a.g,b,a.Z.o));a.H<=a.g?KC(a):(a.O=a.H,a.oa=!0)};
EC=function(a){a.F&&LC(a,(0,g.D)());return a.oa};
MC=function(a,b){b=void 0===b?(0,g.D)():b;if(a.F){LC(a,b);var c=a.J?a.F?1!=CC(a):!1:a.H!=a.L;if(c){if(c=a.L,b<c){a.T=a.L;return}}else c=a.H;c=Math.max(c,a.O)}else c=a.O;var d=a.wa-a.o;0>d&&a.l.policy.C&&(d=0);d=1E3*(d*a.da.stall+d/a.da.byterate);d=JC(a)?d+b:d+Math.max(b,c);a.T=d};
HC=function(a,b){for(var c="";4095<a;)c+=HC(4095,0),a-=4095;for(;4095<b;)c+=HC(a,4095),b-=4095,a=0;return c+("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_".charAt(a>>6&63)+"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_".charAt(a&63)+"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_".charAt(b>>6&63)+"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_".charAt(b&63))};
NC=function(){return!("function"!=typeof window.fetch||!window.ReadableStream)};
OC=function(a){if(a.Il())return!1;a=a.Bd("content-type");return"audio/mp4"==a||"video/mp4"==a};
PC=function(a,b,c,d,e,f){this.status=0;this.J=this.response=null;this.R=d;this.T=c;this.Z=e;this.C=f;this.A=[];this.o=null;this.l=this.g=0;this.Ga=zha++;this.B=null;a=new window.Request(a,{method:"GET",credentials:"include"});(0,window.fetch)(a).then(jp((0,g.z)(this.xM,this)),jp((0,g.z)(this.Aw,this)));(0,g.D)();this.O=this.F=this.G=this.H=!1;this.L="";b()};
UC=function(a,b){a.l+=b.length;var c=b.length;var d=QC(a)?1:Math.max(RC(a)/2,16384);c=c>=d;d=b.length+a.g>RC(a);a.O?((c||d)&&0!==a.g&&SC(a),c?a.A.push(b):TC(a,b)):(TC(a,b),a.l>=(QC(a)?1:16384)&&SC(a))};
SC=function(a){a.O=!0;a.A.push(a.o.subarray(0,a.g));a.g=0;a.o=a.H?null:new window.Uint8Array(RC(a))};
TC=function(a,b){if(b.length+a.g>RC(a)){var c=new window.Uint8Array(a.g+b.length);c.set(a.o,0);a.o=c}a.o.set(b,a.g);a.g+=b.length};
VC=function(a){a.B.read().then(jp((0,g.z)(a.MI,a)),jp((0,g.z)(a.Aw,a)));(0,g.D)()};
XC=function(a){if(!a.F){a.H=!0;if(WC(a)&&!a.A.length&&!a.g&&!a.G&&a.l){OC(a);if(!a.o||8>a.o.length)a.o=new window.Uint8Array(8);var b=new window.DataView(a.o.buffer,0,8);b.setUint32(0,8);b.setUint32(4,1936419184);a.g=8;a.l+=8}a.R()}};
QC=function(a){return a.C.Oa&&a.C.g&&OC(a)};
WC=function(a){return a.C.ed&&a.C.g&&OC(a)};
RC=function(a){a=a.Il()||0;return Math.max(16384,.125*a)};
YC=function(a,b,c,d,e){this.status=0;this.response=null;this.l=this.o=!1;this.g=new window.XMLHttpRequest;this.g.open("GET",a);this.g.responseType="arraybuffer";this.g.withCredentials=!0;this.g.onreadystatechange=(0,g.z)(this.RF,this);this.A=d;this.C=c;this.B=e;a=jp((0,g.z)(this.PF,this));this.g.addEventListener("load",a,!1);this.g.addEventListener("error",a,!1);this.g.send();b();this.g.addEventListener("progress",jp((0,g.z)(this.QF,this)),!1)};
ZC=function(a,b,c,d){this.o=a;this.info=b;this.timing=c;this.Z=d;this.state=1;this.g=this.Y=null;this.F=this.G=0;this.R=new g.L(this.DM,a.H,this);this.A=this.B=this.H=null;this.C=0;this.O=this.l=null;this.T=0;this.X=this.L=!1;this.J=this.o.sa&&(yw(this.info)||xw(this.info))};
Aha=function(a,b){a.H=b};
$C=function(a){return a.B?gw(a.B.g):""};
aD=function(a){var b=BC(a.timing);b.shost=$C(a);b.rn=a.G.toString();a.C&&(b.rc=a.C.toString());b.itag=""+g.ot(a.info.g[0].g.info);b.ml=""+ +a.info.g[0].g.hc();b.sq=""+a.info.g[0].l;410!=a.C&&500!=a.C&&503!=a.C||(b.fmt_unav="true");a.g&&a.g.cq()&&(b.msg=a.g.cq());return b};
bD=function(a){$C(a);return bw(a.Z,$C(a))};
dD=function(a){if("net.timeout"==a.A){var b=a.timing,c=(0,g.D)();c=c>b.g&&4E12>c?c:(0,g.D)();IC(b,c,1024*b.R);var d=(c-b.g)/1E3;if(2!=CC(b))if(JC(b))b.B+=(c-b.C)/1E3,Ax(b.l,b.o,b.B);else{if(!EC(b)){var e=b.l;e.F.l(1,d);zx(e)}b.ba=c}e=b.l;var f=b.X,k=xw(b.Z);e.C.l(d,b.o/d);e.o=g.qr();k||e.l.l(1,d-f);Cx(b.l,(c-b.C)/1E3,0)}else(0,g.D)();"net.nocontent"!=a.A&&("net.timeout"==a.A||"net.connect"==a.A?(b=bD(a),b.l+=1):(b=bD(a),b.g+=1),a.info.l.g++);cD(a,7)};
eD=function(a){if(1==a.state)return!0;a=bD(a);return 100>a.l&&6>a.g};
cD=function(a,b){a.state=b;if(5<=a.state){var c=a.timing;c.A&&(c.A=!1)}a.H&&a.H(a)};
gD=function(a,b){if(b){var c=bD(a);c.A+=1}fD(a);a.A="net.timeout";dD(a)};
hD=function(a){return(0,g.em)(a.info.g,function(a){return 3==a.type})};
fD=function(a){if(a.g){var b=a.g;a.g=null;b.abort()}a=a.timing;a.A&&(a.A=!1)};
jD=function(a){var b=a.g.Bd("content-type"),c=a.g.Il();(b=(!iD(a)||!b||-1!=b.indexOf("text/plain"))&&(!c||2048>=c))&&iD(a)&&QC(a.g);return b};
Bha=function(a,b){var c=(0,g.z)(a.fM,a),d=(0,g.z)(a.iM,a),e=(0,g.z)(a.hM,a),f=(0,g.z)(a.gM,a);return a.o.F&&(a.o.ws&&!(0,window.isNaN)(a.info.o)&&a.info.o>a.o.uv?0:NC()&&hD(a))?new PC(b,d,e,c,f,a.o):new YC(b,d,e,c,f)};
iD=function(a){return a.g?a.g.Pz():!1};
kD=function(a){return 2<=a.state&&!!a.l&&!!a.l.g.length};
lD=function(a,b){if(b||iD(a)&&!jD(a)){if(!a.l){var c;iD(a)||(c=a.g.zo());a.l=new rha(a.info.g,c)}for(;a.g.Ug();){c=a.l;for(var d=a.g.Fz(),e=b&&!a.g.Ug(),f=0,k=0,l=g.q(c.l),m=l.next();!m.done;m=l.next())if(m=m.value,m.range&&f+m.Na<=c.o)f+=m.Na;else{var n=c,p=m;if(1==p.type){n.B=!0;var u=!1}else 3==p.type||4==p.type?(p=n.B&&!n.C,n.C=!0,u=p):u=!1;n=c;var x=c.o-f,B=k;p=d;u=u||m.g.Tv();var F=p.length-B;m.range&&(F=Math.min(m.Na-x,F));x=Pv(m,m.o+x,F,m.range?m.o+x+F==m.range.length:!!e);var H=Hv(p.byteOffset,
p.length);B=Hv(p.byteOffset+B,F);n.g.push(new Sv(x,p.buffer,B,H,u));n=F;c.o+=n;k+=n;f+=m.Na;if(k==d.length)break}}}};
Cha=function(a){if(!a.o.g||!(0,window.isNaN)(a.info.o)&&0<a.info.o)return!1;if(!a.g||!a.g.rj())return!0;if(!OC(a.g))return!1;if((0,window.isNaN)(a.info.o)){var b=a.g.Bd("x-head-seqnum");if(b&&(0,window.parseInt)(b,10)>a.info.g[0].l)return!1}return!0};
mD=function(a,b,c){g.N.call(this);this.C=0;this.o=a;this.g=[];this.A=null;this.O=b;this.ba=c;this.B=this.F=window.NaN;this.R=null;this.ga=(0,g.z)(function(a){this.o.ms&&(this.P("timestamprewrite",a),this.o.ms=!1)},this);
this.L=this.l=null;this.X="constructor";this.H=window.NaN;this.da=this.J=this.Z=null;this.T=!1;this.Y=this.G=null;this.o.R&&(this.l=new pC(this.o,this.ba));this.o.zc&&this.o.Nc&&(this.Y=new lC)};
nD=function(a){return a.g.length?a.g[0]:null};
oD=function(a){return a.g.length?a.g[a.g.length-1]:null};
Eha=function(a,b,c){b=Dha(a,b,c);(0,g.C)(b,function(b){a.g.push(b)})};
rD=function(a,b){if(1==b.info.type){var c=Tv(b);qt(b.info.g.info)&&!rt(b.info.g.info)&&(uv(new mv(c)),tv(21936,c));if(!a.o.PA&&rt(b.info.g.info)&&"bt2020"==b.info.g.info.za().primaries){var d=new mv(c);ov(d,[408125543,374648427,174,224,21936,21937])&&(d=d.o+d.g,129==c.getUint8(d)&&1==c.getUint8(d+1)&&c.setUint8(d+1,9))}b.info.g.info.video&&Cw(b.info.g,c);2==b.info.g.info.containerType&&b.info.g.info.video&&vv(c);pD(a,b)&&($v(b),g.tt(b.info.g.info)&&iv(Tv(b),1701671783))}b.info.g.Rl(b);qD(a,b)};
Fha=function(a){if(!a.g.length)return 0;for(var b=a.g[0].A.length,c=1;c<a.g.length;c++)a.g[c].g!=a.g[c-1].g&&(b+=a.g[c].A.length);a.A&&(b+=a.A.A.length);return b};
sD=function(a){return(0,g.E)(a.g,function(a){return a.info})};
uD=function(a,b,c){(0,window.isNaN)(a.H)||a.H==b.G||tD(a,b,null,"Mismatch get",c);return a.L};
vD=function(a,b,c,d){(0,window.isNaN)(a.H)||a.H==b.G||tD(a,b,c,"Mismatch set",d);var e=c?c.l:null;e&&a.L&&tD(a,b,c,"Duplicated set",d);a.L=e;a.X=d;a.H=e?b.G:window.NaN;a.Z=c?c.info.range:null};
tD=function(a,b,c,d,e){a.o.Ok&&a.P("warning",b,c,d+" current emsg by "+e+"/"+b.G+"/"+(c?c.info.range.toString():"null")+"/"+(c?c.l?c.l.l:-999:window.NaN)+"; previously "+a.X+"/"+a.H+"/"+(a.Z?a.Z.toString():"null")+"/"+(a.L?a.L.l:window.NaN))};
wD=function(a,b){a.T=!1;a.G&&!a.o.Lc&&a.P("placeholderrollback",a.G);a.G=null;if(a.l){var c=(0,window.isNaN)(a.B)?b.info.g[0].range?b.info.g[0].C:(0,window.isNaN)(a.l.C)?sC(a.l):qC(a.l).startTime:a.B;a.l.reset();a.J=a.da;a.B=c}vD(a,b,null,"rollbackRequest")};
xD=function(a){return a.l?sC(a.l):a.F||0};
Dha=function(a,b,c){var d={};if(!c.verify(d)||c.info.g.qp())d=Object.assign(d,Nv(c.info)),d.verification="1",a.P("error",d||{});c.o&&c.info.g.info.video&&Cw(c.info.g,Tv(c));c.info.A&&(a.da=c.info);a.Y&&c.info.g.info.video&&g.tt(c.info.g.info)&&(d=Tv(c),nC(a.Y,new window.Uint8Array(d.buffer,d.byteOffset,d.byteLength),c.info.o));if(!a.O.Je()){2==c.info.g.info.containerType&&(d=Tv(c),c.o&&c.info.g.info.video&&vv(d));(d=uD(a,b,"get"))&&Qv(c.info,d);!a.J||(a.o.Ik?Lv(a.J,c.info,!0):Mv(a.J,c.info))||(a.l&&
a.l.reset(),a.F=window.NaN,a.C=0);a.J=c.info;if(a.l)b:{var e;(e=!(0,window.isNaN)(a.B))||(e=a.l,e=!(!(0,window.isNaN)(e.B)||!(0,window.isNaN)(e.H)));e&&(e=a.l,e.H=(0,window.isNaN)(a.B)?(0,window.isNaN)(a.F)?c.info.startTime:a.F:a.B,uC(e),a.B=window.NaN);e=Tv(c);e=a.l.process(e);if(d=c.info.A)d=a.l,d=!(0==d.g.type&&!d.o.length);d&&!a.o.Jk&&(d=Nv(c.info),d.partialbox="1",a.P("error",d||{}));var f=b.timing;d=!!c.info.o&&1936286840!=e&&!(a.o.ed&&1936419184==e);var k=c.info.A;if(3==CC(f)&&(e=f.Y,e.B.length)){f=
e.B.shift();var l=f.Ir;d||(f.lm-=Math.min(f.lm,1500),f.Ir=0);e.l+=f.lm;e.g+=f.Ir;e.o+=(0,window.isNaN)(l)?0:l;k&&(0>=e.g||(d=e.C,k=e.g/1E3,f=e.o/1E3,d.g.l(void 0===f?k:f,e.l/k),d.o=g.qr()),e.g=0,e.l=0,e.o=0)}if(a.o.Bs&&a.o.g){if(!a.l.O&&!c.info.A){c=null;break b}}else if((0,window.isNaN)(a.l.C)){c=null;break b}e=a.l;f=c.info.g.info;if(e.F.length){e.O=!1;d=0;l=g.q(e.F);for(k=l.next();!k.done;k=l.next())d+=k.value.byteLength;if(!e.G||e.G.length-e.L<d)e.G=new window.Uint8Array(Math.max(d,e.R.Sk+Math.round(f.g*
e.R.Rk))),e.L=0;l=f=e.L;var m=g.q(e.F);for(k=m.next();!k.done;k=m.next())k=k.value,e.G.set(new window.Uint8Array(k.buffer,k.byteOffset,k.byteLength),f),f+=k.byteLength;e.F.length=0;e.L=f;e=new window.DataView(e.G.buffer,l,d)}else e=null;e?(d=Hv(e.byteOffset,e.byteLength),k=Hv(0,e.buffer.byteLength),f=c.info.o+c.info.Na-a.l.o.length-e.byteLength,l=Pv(c.info,f,e.byteLength,c.info.A),c=new Sv(l,e.buffer,d,k,c.o&&!f)):c=null}else a.o.Ja?e=a.ba(Wv(c),1):e=(0,window.isNaN)(a.B)?(0,window.isNaN)(a.F)?c.info.startTime:
a.F:a.B,a.B=window.NaN,Xv(c,e)?a.F=e+Yv(c):(e=Nv(c.info),e.smst="1",a.P("error",e||{}));if(!c)return[];pD(a,c)&&($v(c),c.l&&(vD(a,b,c,"processSlice"),a.T=!!a.l,Qv(c.info,c.l),Qv(a.J,c.l)));pD(a,c)&&g.tt(c.info.g.info)&&iv(Tv(c),1701671783);-1==c.info.l&&tD(a,b,c,"ct "+c.info.g.info.containerType+"; st "+c.info.type,"noemsg");k=c;if(e=uD(a,b,"publishMediaInfo"))if(k.info.A){a.T=!1;a.G=null;a.l?(k=qC(a.l),rC(a.l),d=k.startTime,k=k.duration):(d=Wv(k),k=Yv(k));k=new Fu(e.l,d,k,e.ingestionTime,"sq/"+e.l,
void 0,void 0,!1);a.P("segmentinfo",k);if(f=e.g["Cuepoint-Type"]?new Ru(yD?(0,window.parseFloat)(e.g["Cuepoint-Playhead-Time-Sec"])||0:-((0,window.parseFloat)(e.g["Cuepoint-Playhead-Time-Sec"])||0),(0,window.parseFloat)(e.g["Cuepoint-Total-Duration-Sec"])||0,e.g["Cuepoint-Context"],e.g["Cuepoint-Identifier"]||"",Gha[e.g["Cuepoint-Event"]||""]||"unknown",(0,window.parseFloat)(e.g["Cuepoint-Playhead-Time-Sec"])||0):null)f.g+=d,a.P("cuepoint",f,e.l);e=k}else a.T&&a.l&&!(0,window.isNaN)(a.l.C)?(d=qC(a.l).startTime,
e=new Fu(e.l,d,e.G,e.ingestionTime,"sq/"+e.l,void 0,void 0,!0),a.G=e,a.P("placeholderinfo",e),a.T=!1):e=null;else e=null;d=c;if(a.o.Bl)if(e)for(Rv(d.info,e),d=g.q(b.info.g),k=d.next();!k.done;k=d.next())Rv(k.value,e);else a.G&&Rv(d.info,a.G);c.info.A&&vD(a,b,null,"isEndOfSegment");qD(a,c)}b=c;if(a.o.xs&&!a.O.Je()&&(0==b.info.o||a.A)&&g.tt(b.info.g.info)&&3==b.info.type&&!Zv(b)&&b.info.duration&&!a.o.R&&(b=c,a.C+=1E3*(Yv(b)-b.info.duration),a.R&&Math.abs(a.C-a.R.C)>=a.o.fv))return b=c,c=(a.R.C-a.C)/
1E3,e=Yv(b)+c,d=new window.DataView(b.g),d=(d=g.Yu(d,1936286840))?gv(d):window.NaN,(0,window.isNaN)(d)&&(d=b.info.g.g,k=new window.DataView(b.g),d=(k=g.Yu(k,1836476516))?Zu(k):d?$u(d):window.NaN),(d=zD(a,b,e*d))&&d.length&&(k=Nv(b.info),k.fds=e.toFixed(3),k.com=a.C.toFixed(3),a.P("timestamprewrite",k),a.F+=c,a.C+=1E3*c),d?d:AD(a,b);a.o.Oc&&a.O.Je()&&(0==c.info.o||a.A)&&g.tt(c.info.g.info)?(b=c,c=b.info.g.index.Ao(b.info.l),a=(c=zD(a,b,c))?c:AD(a,b)):a=[c];return a};
qD=function(a,b){if(a.o.X&&a.O.info.Ec)if(2==b.info.g.info.containerType){var c=new mv(Tv(b));if(ov(c,[408125543,374648427,174,28032,25152,20533,18402])){var d=rv(c,!0);c=16!=d?null:zv(c,d)}else c=null;c&&(b.info.g.G={type:"webm",key:c})}else b.info.J=pha(Tv(b)),c=qha(b.info.J),0<c.length&&(b.info.g.G={type:"cenc",key:c})};
pD=function(a,b){return!a.O.Je()&&0==b.info.o&&(g.tt(b.info.g.info)||2==b.info.g.info.containerType)};
AD=function(a,b){if(a.A&&a.A!=b){var c=[a.A,b];a.A=null;return c}return[]};
zD=function(a,b,c){if(a.A){var d=a.A;var e=new window.Uint8Array(d.range.length+b.range.length);e.set(new window.Uint8Array(d.g,d.range.start,d.range.length));e.set(new window.Uint8Array(b.g,b.range.start,b.range.length),d.range.length);d=new window.DataView(e.buffer);hv(d)}else d=Tv(b),e=hv(d),e&&e<d.byteLength||(a.A=b,d=null);if(!d)return null;c=ffa(d,c,a.ga);if(!c)return null;d=hv(d);a.A&&(d-=a.A.range.length,a.A=null);a=Vv(b,d);a[0].g=c;a[0].range=Hv(0,c.byteLength);a[0].A=Hv(0,c.byteLength);
b=a[0];c=new window.DataView(c);c=!!Wu(c,0,1836019574);b.o=c;return a};
BD=function(a,b,c){this.T=a;this.g=b;this.A=[];this.o=new mD(a,b,c);this.R=this.B=this.l=null;this.O=0;this.J=b.info.g;this.G=!1;this.L=0;this.F=b.Sh();this.C=-1;this.H=this.F?0:window.NaN};
CD=function(a,b){a.A.push(b);a.l=g.Ha(b.info.g)};
ED=function(a){for(;a.A.length&&6==a.A[0].state;){var b=a.A.shift();DD(a,b);b=b.timing;a.O=(b.C-b.g)/1E3}a.A.length&&kD(a.A[0])&&!xw(a.A[0].info)&&DD(a,a.A[0])};
DD=function(a,b){if(kD(b)){b.L=!0;var c=b.l,d=c.g;c.g=[];c.A=g.Ha(d).info;(0,g.C)(d,(0,g.z)(a.Z,a,b))}};
HD=function(a,b){a.g.hc();var c=FD(a,b);if(0<=c)return c;a.l=a.g.rf(b).g[0];GD(a)&&(a.B=null);a.L=0;return a.l.startTime};
ID=function(a,b){a.F=!0;a.C=-1;a.T.xg&&(a.B=null);HD(a,window.Infinity);a.o.B=b;a.H=b};
JD=function(a){var b=0;(0,g.C)(a.A,function(a){var c=b;a=a.l&&a.l.length?sha(a.l):Aw(a.info);b=c+a},a);
return b+=Fha(a.o)};
LD=function(a){KD(a);a.o.g=[]};
MD=function(a,b){var c;for(c=0;c<a.A.length&&b!==a.A[c];c++);if(c==a.A.length)b.L&&wD(a.o,b),b.dispose();else{for(;c<a.A.length;){var d=a.A.pop();d.L&&wD(a.o,d);d.dispose()}3==b.info.g[0].type?(b.l&&b.l.A?(c=b.l.A,c=new Jv(c.type,c.g,c.range,"getEmptyStubAfter_"+c.F,c.l,c.startTime+c.duration,0,c.o+c.Na,0,!1)):(c=b.info.g[0],c=new Jv(c.type,c.g,c.range,"getEmptyStubBefore_"+c.F,c.l,c.startTime,0,c.o,0,!1)),a.l=c):a.l=null}};
GD=function(a){return!!a.B&&a.B.G};
ND=function(a){var b=[];a.B&&b.push(a.B);b=g.Sa(b,sD(a.o));(0,g.C)(a.A,function(a){(0,g.C)(a.info.g,function(c){a.L&&(b=(0,g.Bd)(b,function(a){return!(a.g!=c.g?0:a.range&&c.range?a.range.start+a.o>=c.range.start+c.o&&a.range.start+a.o+a.Na<=c.range.start+c.o+c.Na:a.l==c.l&&a.o>=c.o&&(a.o+a.Na<=c.o+c.Na||c.A))}));
3!=c.type&&4!=c.type||b.push(c)})});
a.l&&!nfa(a.l,g.Ha(b),a.l.g.Je())&&b.push(a.l);return b};
OD=function(a,b){if(!a.length)return!1;for(var c=b+1;c<a.length;c++)if(!Mv(a[c-1],a[c]))return!1;return!0};
FD=function(a,b,c){c=void 0===c?!1:c;if(!a.l||!a.l.Na)return window.NaN;var d=ND(a);a:{var e=c;e=void 0===e?!1:e;for(var f=-1,k=0;k<d.length;++k){var l=d[k];if(l.C<=b)if(e)f=k;else if(l.startTime+l.duration>=b){b=k;break a}}b=f}return 0>b||!OD(d,a.T.Xs||c?b:0)?window.NaN:d[b].startTime};
PD=function(a){return(0,g.rj)(a.A,function(a){return 4<=a.state})};
QD=function(a){return!(!a.l||a.l.g==a.g)};
RD=function(a){return QD(a)&&a.g.hc()&&a.l.g.info.g<a.g.info.g};
SD=function(a,b,c){return(a=oD(a.o)?oD(a.o).info:a.B)&&!a.G?a.B>b&&a.B<b+c:!1};
KD=function(a){(0,g.C)(a.A,function(a){a.L&&wD(this.o,a);a.dispose()},a);
a.A=[];a.l=null};
TD=function(a){return!!a.l&&-1!=a.l.l&&a.l.l<a.g.index.pe()};
UD=function(a){var b=a.l;if(b&&-1==b.l){var c=oD(a.o);c&&3==c.info.type?(a=c.info.l,b.F="updateLastSliceRequested",b.l=a):a.F||a.o.P("warning",null,c,"noupdtsgnm")}};
VD=function(a){return(0,g.rj)(a.A,function(a){return a.J})};
Hha=function(a,b){this.l=a;this.g=b;this.o=1};
Iha=function(a,b){var c=Math.min(2.5,Bx(a.l)),d=WD(a);return b-c*d};
YD=function(a,b,c,d,e){e=void 0===e?!1:e;d/=a.o;var f=1/g.Ex(a.l);var k=.9*(d-a.g.Ia);k=Math.max(k,Bx(a.l)+a.l.policy.A*f);c=k/f*a.g.ts/(b+c);a.g.Of&&(d-=a.g.Ia);c=Math.min(c,d);a.g.ob&&e&&(c=Math.max(c,a.g.ob));return XD(a,c,b)};
XD=function(a,b,c){return Math.ceil(Math.max(Math.max(65536,a.g.rs*c),Math.min(Math.min(a.g.O,a.g.Fc*c),Math.ceil(b*c))))};
Jha=function(a,b){var c=XD(a,b.video?a.g.Ys:a.g.ie,b.g);return a.g.Qd&&b.video?Math.max(c,a.g.Qd):c};
WD=function(a){var b=g.Ex(a.l);if(a.g.Qk)return b;var c=a.g.qs,d=1E-9+Bx(a.l);b*=Math.min(1,c/(b*d));a.g.Fd&&(c=((yx(a.l.l,.98)||0)-1)/2,c=Math.max(0,Math.min(1,c)),b*=1-a.g.Fd*c);return b};
ZD=function(a){return WD(a)/a.o};
Kha=function(a,b,c,d){this.Z=a;this.F=b;this.C=c;this.G=d;this.l=Bu;this.A=this.O=null;this.T=-1;this.o=this.B=null;this.g=[];this.R={};this.H=0;this.L=this.X=!1;this.Y=0;this.J=Bu;this.da=1};
dE=function(a,b){if(yu(a.l,b))return null;if("m"==b.reason&&b.isLocked())return a.J=Bu,$D(a,b),a.H=a.g.length-1,aE(a),bE(a),a.L=a.L||a.A!=a.o,a.A=a.o,new kC(a.B,a.A,b.reason);"r"==b.reason&&(a.T=-1);$D(a,b);bE(a);if("r"==b.reason&&a.o==a.A)return new kC(a.B,a.o,b.reason);if(a.A&&a.o&&cE(a,a.A.info)<cE(a,a.o.info)){var c=a.l.reason;a.X=a.X||"r"==c||"u"==c||"v"==c}return null};
Lha=function(a,b){if(b.info.video){if(a.A!=b)return a.A=b,eE(a)}else a.O=b;return null};
fE=function(a,b){b.L=g.qr();a.T=-1;$D(a,a.l)};
gE=function(a){for(var b=g.qr()-6E4,c=g.q(a.G.videoInfos),d=c.next();!d.done;d=c.next())if(a.C.g[d.value.id].L>b)return!0;return!1};
hE=function(a){return a.l.isLocked()};
eE=function(a){a.T=g.qr();a.X=!1;return new kC(a.O,a.A,a.l.reason)};
$D=function(a,b){a.l=b;var c=a.G.videoInfos;if(!hE(a)){var d=g.qr()-6E4;c=(0,g.Bd)(c,function(a){if(a.g>this.F.G)return!1;a=this.C.g[a.id];return a.L>d?!1:4<a.A.g||4<a.J||a.B?!1:!0},a);
if(gE(a)){var e=(0,g.Bd)(c,function(a){a=g.ot(a);return"140"==a||"134"==a||"243"==a});
e.length&&(c=e)}}c.length||(c=a.G.videoInfos);e=(0,g.Bd)(c,b.A,b);e.length||(e=[c[0]]);e.sort((0,g.z)(function(a,b){return cE(this,a)-cE(this,b)},a));
for(c=1;c<e.length;c++){var f=e[c-1],k=e[c];f.video.width>k.video.width?(g.Pa(e,c),c--):cE(a,f)*a.F.l>cE(a,k)&&(g.Pa(e,c-1),c--)}c=e[e.length-1];a.g=e;pfa(a.F,c)};
Mha=function(a,b){if(b)a.B=a.C.g[b];else{var c=g.Ja(a.G.g,function(a){return!!a.ib&&a.ib.isDefault});
c=c||a.G.g[0];a.B=a.C.g[c.id]}aE(a)};
aE=function(a){if(!a.B.info.ib&&(a.B=a.C.g[a.G.g[0].id],1<a.G.g.length)){if(a.F.preferLowQualityAudio)var b=!0;else if(a.l.isLocked())b=240>a.l.g;else{for(b=0;b+1<a.g.length&&"tiny"==a.g[b].video.quality;)b++;var c=ZD(a.Z)/a.F.l;b=cE(a,a.B.info)+cE(a,a.g[b])>c}b&&(a.B=a.C.g[a.G.g[1].id])}};
bE=function(a){if(hE(a))a.o=a.C.g[a.g[a.g.length-1].id];else{for(var b=Math.min(a.H,a.g.length-1),c=ZD(a.Z),d=cE(a,a.B.info),e=c/a.F.A-d;0<b&&!(cE(a,a.g[b])<=e);b--);for(c=c/a.F.l-d;b<a.g.length-1&&!(cE(a,a.g[b+1])>=c);b++);a.o=a.C.g[a.g[b].id];a.H=b}};
Nha=function(a){var b=a.F.A,c=ZD(a.Z)/b-cE(a,a.B.info);b=g.Ka(a.g,function(a){return cE(this,a)<c},a);
0>b&&(b=0);a.H=b;a.o=a.C.g[a.g[b].id]};
cE=function(a,b){if(!a.R[b.id]){var c=a.C.g[b.id].index.Du(a.Y,15);c=b.A&&a.A&&a.A.index.Ob()?c||b.A:c||b.g;a.R[b.id]=c}return a.R[b.id]};
Oha=function(a,b){var c=Pb(a.C.g,function(a){return g.ot(a.info)==b});
if(!c)throw Error("Itag "+b+" from server not known.");return c};
Pha=function(a){var b=[];if("s"==a.l.reason||"m"==a.l.reason)return b;var c=!1;if(Hfa(a.C)){for(var d=Math.max(0,a.H-2);d<a.H;d++){var e=g.ot(a.g[d]);lt(a.g[d].video)||(c=!0);b.push(e)}b.reverse();if(!c&&a.F.Sz)for(d=Math.max(0,a.H-3);0<=d&&!c;d--)lt(a.g[d].video)||(c=!0,b.push(g.ot(a.g[d])))}return b};
iE=function(a,b,c,d){this.l=a;this.C=b;this.B=d;this.A=c;this.g=0};
jE=function(a,b,c,d){g.N.call(this);this.g=a;this.R=b;this.T=c;this.L=d;this.O=window.NaN;this.o=this.H=this.B=null;this.l=this.F=this.G=this.C=window.NaN;this.A=!1;this.J=window.NaN};
Qha=function(a,b,c,d){return a.da&&a.g&&a.F&&NC()&&a.wa?new jE(a,b,c,d):null};
kE=function(a,b){if(a.g.Es){var c=b.info.g;if(0>=c)a.J=window.NaN;else{var d=g.Ex(a.R),e=b.index.g;c=Math.max(1,d/c);a.J=Math.round(1E3*Math.max(((c-1)*e+a.g.J)/c,e-a.g.Ya))}}};
Rha=function(a,b){var c=(0,g.D)()/1E3,d=c-a.C,e=c-a.G,f=e>=a.g.fd,k=!1;if(f){var l=0;!(0,window.isNaN)(b)&&b>a.F&&(l=b-a.F,a.F=b);l/e<a.g.Gs&&(k=!0);a.G=c}c=d>=a.g.Ya&&!a.A;if(!f&&!c&&lE(a,b))return window.NaN;c&&(a.A=!0);a:{d=k;c=(0,g.D)()/1E3-(a.T.g()||0)-a.H.o-a.g.J;f=a.o.startTime;c=f+c;if(d){if((0,window.isNaN)(b)){mE(a,window.NaN,"n",b);f=window.NaN;break a}d=b-a.g.Va;d<c&&(c=d)}else a.A&&(d=c+a.g.J-a.O+a.g.Hs,(0,window.isNaN)(b)||(d=Math.max(d,Math.min(c,b-a.g.Va))),c=d);f=c=Math.max(c,f)}a.l=
f;if((0,window.isNaN)(a.l))return nE(a),window.NaN;if(!k&&lE(a,b))return oE(a,b),window.NaN;if(a.l<=a.o.startTime)return mE(a,window.NaN,"y",b),nE(a),window.NaN;if(!a.L(a.l,!1))return!oE(a,b)&&k&&(mE(a,window.NaN,"t",b),nE(a)),window.NaN;k=a.l;mE(a,k,"s",b);nE(a);return k};
oE=function(a,b){return a.L(a.l,!0)?!1:(mE(a,window.NaN,"ns",b),nE(a),!0)};
lE=function(a,b){return(0,window.isNaN)(b)?!0:(0,window.isNaN)(a.l)?!1:b<a.l+(a.A?a.g.Va:a.g.Fs)};
nE=function(a){a.B=null;a.H=null;a.o=null;a.C=window.NaN;a.G=window.NaN;a.F=window.NaN;a.l=window.NaN;a.A=!1};
mE=function(a,b,c,d){var e=aD(a.B);e.ssr_sk=(1E3*b).toFixed(0);e.ssr_t=(1E3*a.l).toFixed(0);e.ssr_r=c;e.ssr_st=(1E3*a.C).toFixed(0);e.ssr_n=(0,g.D)().toFixed(0);e.ssr_f=(1E3*a.H.o).toFixed(0);e.ssr_fa=a.A?"1":"0";e.ssr_o=(1E3*a.T.g()||0).toFixed(0);e.ssr_v=(1E3*d).toFixed(0);b=a.o.g.index;Gw(b,a.o.l,!0)&&(e.ssr_ist=(1E3*b.od(a.o.l)).toFixed(0),e.ssr_id=(1E3*b.Df(a.o.l)).toFixed(0));e=Py(e);a.P("ctmp","ssr",e,!1)};
Sha=function(){this.g=[];this.l=g.$B};
Tha=function(a,b,c){var d=[];for(b=pE(a,b);b<a.g.length;++b){var e=a.g[b];(e.end<=c||e.contains(c))&&d.push(e);if(e.start>c)break}return d};
qE=function(a,b){for(var c=[],d=g.q(a.g),e=d.next();!e.done&&!(e=e.value,e.contains(b)&&c.push(e),e.start>b);e=d.next());return c};
Uha=function(a){return a.g.slice(pE(a,0x7ffffffffffff),a.g.length)};
pE=function(a,b){var c=$a(a.g,function(a){return b-a.start||1});
return 0>c?-(c+1):c};
rE=function(a,b){for(var c=window.NaN,d=g.q(a.g),e=d.next();!e.done;e=d.next())if(e=e.value,e.contains(b)&&((0,window.isNaN)(c)||e.end<c)&&(c=e.end),e.start>b&&((0,window.isNaN)(c)||e.start<c)){c=e.start;break}return c};
sE=function(a,b){if(1<b.length&&b.length>a.g.length)a.g=a.g.concat(b),a.g.sort(a.l);else for(var c=g.q(b),d=c.next();!d.done;d=c.next())d=d.value,!a.g.length||0<a.l(d,a.g[a.g.length-1])?a.g.push(d):g.db(a.g,d,a.l)};
tE=function(a,b,c,d,e){g.G.call(this);this.B=window.NaN;this.G=this.H=this.C=!1;this.R=a;this.T=b;this.J=c;this.L=d;this.Z=e;this.O=new g.L(this.l,250,this);g.I(this,this.O);this.F=new g.L(this.l,0,this);g.I(this,this.F);this.o=[];this.g=new Sha};
uE=function(a){return a.ea()?[]:a.g.g};
Vha=function(a,b){var c=(0,g.Bd)(uE(a),function(a){return a.namespace==b});
a.A.apply(a,c);return c};
vE=function(a,b){var c=[];if(!b.length)return c;for(var d=0;d<b.length;d++){var e=b[d];e.active&&-1==a.o.indexOf(e)&&(a.o.push(e),c.push([1,e]))}return c};
wE=function(a,b){var c=[];if(!b.length)return c;b.sort(g.$B);for(var d=0;d<b.length;d++){var e=b[d];a.o.splice(a.o.indexOf(e),1);c.push([2,e])}return c};
Yha=function(a){if(a.C&&!a.ea()){a.F.stop();var b=a.J();g.U(b,32)&&a.O.start();for(var c=Wha(a),d=g.U(b,2),e=[],f=[],k=0;k<a.o.length;k++){var l=a.o[k];l.active&&(d?0x8000000000000>l.end:!l.contains(c))&&f.push(l)}e=e.concat(wE(a,f));var m;if(d){b=qE(a.g,0x7ffffffffffff);g.R(a.Z.experiments,"web_player_new_cue_range_manager_end_state_behavior")&&(m=b.filter(function(a){return 0x8000000000000>a.end}));
var n=Uha(a.g)}else b=a.B<=c&&g.pB(b)&&!g.U(b,16)&&!g.U(b,32)?Tha(a.g,a.B,c):qE(a.g,c);e=e.concat(vE(a,b));m&&(e=e.concat(wE(a,m)));n&&(e=e.concat(vE(a,n)));a.B=c;Xha(a,e)}};
Xha=function(a,b){for(var c=g.q(b),d=c.next();!d.done;d=c.next()){d=d.value;var e=d[1];1==d[0]?(e.g&&e.g.P("onEnter",e),a.L(g.aC(e.namespace),e)):(e.g&&e.g.P("onExit",e),a.L("crx_"+e.namespace,e))}};
Wha=function(a){return g.U(a.J(),2)?0x8000000000000:1E3*a.R()};
xE=function(){var a=this;this.g=this.l=eaa;this.o=new g.Pf(function(b,c){a.l=b;a.g=c})};
zE=function(a,b,c,d,e){g.N.call(this,b.Ts);var f=this;this.O=a;this.l=b;this.C=c;this.ob=e||null;this.g=this.o=null;this.H=new Hha(a,b);this.A=null;this.F=new Kha(this.H,b,this.C,d);this.da=new g.L(this.Ld,0,this);g.I(this,this.da);this.pa=new g.L(this.Ld,1E3,this);g.I(this,this.pa);this.Mb=new g.L(this.Ld,void 0,this);g.I(this,this.Mb);this.Ya=new g.L(this.Ld,1E4,this);g.I(this,this.Ya);this.B=window.NaN;this.T=!1;this.J=window.NaN;this.ab=0;this.Z=this.Ca=this.Y=!1;this.Wb={};this.oa="";this.Ja=
this.Ta=0;this.yb=b.zc&&!b.Nc?new lC:null;this.sa=new vx(5);this.ba={};this.Va="";this.Oa=window.NaN;this.Ia=this.L=!1;(this.G=Qha(this.l,this.O,this.sa,function(a,b){if(f.g&&f.o&&f.g.g.hc()&&f.o.g.hc()&&f.A&&f.A.l&&f.A.g)if(b&&f.C.l&&(-1==f.g.C||-1==f.o.C))var c=!0;else c=yE(f.g,a,f.A.l,b),(0,window.isNaN)(c)?c=!1:(c=yE(f.o,f.l.wa?a:c,f.A.g,b),c=(0,window.isNaN)(c)?!1:!0);else c=!1;return c}))&&this.G.subscribe("ctmp",this.Wc,this);
this.Cb=window.NaN;this.ga=this.nb=null;this.R=window.NaN;this.X=0};
AE=function(a,b){b=b||a.g&&a.g.l&&a.g.l.startTime||a.B;var c=a.g;var d=a.F;var e=d.o&&d.o.index.sf(b)||0;d.Y!=e&&(d.R={},d.Y=e,$D(d,d.l));e=!hE(d)&&-1<d.T&&g.qr()-d.T<1E3*d.F.Zy;var f=3*cE(d,d.o.info)<ZD(d.Z);if(!e||f)aE(d),bE(d),d.L=d.L||d.o!=d.A;d.o.index.Ob()||(d.Y=-1);d=d.o;c.g!=d&&(c.g=d);c=a.o;d=a.F.B;c.g!=d&&(c.g=d)};
BE=function(a,b){a.Y=!0;a.Ca=b};
g.CE=function(a,b){if(!b.g&&!b.l)if(a.l.Ws){var c=a.g.g.info.mimeType,d=a.l.Cx;b.g=new Tt(new St(Xt(b,a.o.g.info.mimeType)),d,window.Infinity);b.l=new Tt(new St(Xt(b,c)),d,window.Infinity)}else c=a.g.g.info.mimeType,b.g=new St(Xt(b,a.o.g.info.mimeType)),b.l=new St(Xt(b,c));a.A=b;a.o.G=!1;a.g.G=!1;a.o.B=null;a.g.B=null;a.resume();au(b)&&(b.g.addEventListener("updateend",(0,g.z)(a.Ld,a)),b.l.addEventListener("updateend",(0,g.z)(a.Ld,a)),b.g.addEventListener("error",(0,g.z)(a.Nm,a,!0)),b.l.addEventListener("error",
(0,g.z)(a.Nm,a,!1)));a.yc("msa");Pz("msa");Kz.measure&&Kz.getEntriesByName("mark_vta").length&&Kz.measure("measure_vta_to_msa","mark_vta");a.wa&&a.ka&&(c=g.y("yt.scheduler.instance.enablePriorityThreshold"))&&c(1);a.l.fl&&a.Wc("toff",""+b.g.supports(1),!0);a.Ld()};
EE=function(a){a.A&&a.A.g&&a.A.l&&a.A.g.supports(3)&&(a.A.g.removeEventListener("updateend",(0,g.z)(a.Ld,a)),a.A.l.removeEventListener("updateend",(0,g.z)(a.Ld,a)),a.A.g.removeEventListener("error",(0,g.z)(a.Nm,a,!0)),a.A.l.removeEventListener("error",(0,g.z)(a.Nm,a,!1)));a.A=null;BE(a,!1);DE(a)};
FE=function(a){a.A&&Yt(a.A)&&EE(a)};
HE=function(a,b,c){if(a.Y&&(!Gx(a.O)||a.Ca))return!1;if(a.C.l){if((a.l.uu||1<a.l.yb)&&0<b.A.length&&b.l&&-1==b.l.l||b.A.length>=a.l.yb&&!a.l.Ta||!a.l.iA&&0<b.A.length&&!a.l.g)return!1;if(b.F)return!a.C.isLive||!(0,window.isNaN)(a.Oa)}if(VD(b))return!1;if(!(b.l||a.C.l&&a.l.Ta&&b.F)){if(!b.g.hc())return!1;HD(b,a.B)}var d=b.A.length+c.A.length;(PD(b)||PD(c)||a.C.isLive&&(!a.l.Ta||!b.A.length))&&--d;if(d+1>=a.l.vv)return!1;d=b.l;if(!d)return!0;if(!tw(d.g.A))return!1;4==d.type&&d.g.hc()&&(b.l=g.Ha(d.g.fn(d)),
d=b.l);!d.G&&!d.g.Bf(d)||d.g.info.audio&&4==d.type?a=!1:RD(b)&&!a.l.Z?a=!0:(!(c=d.G||JD(b)&&JD(b)+JD(c)>a.l.ga||!!(c.l&&!c.l.G&&c.l.B<d.B)&&(!a.C.l||c.l&&c.l.B&&d.B)&&!a.L)&&(c=3==d.type)&&(d=d.B,b=GE(a,b,!0),!hE(a.F)&&0<a.l.nb&&(c=(g.qr()-a.ab)/1E3,b=Math.min(b,a.l.nb+a.l.ab*c)),b=a.B+b,a.l.Mc?(c=Math.min(b,Zha(a)+a.l.Mc),c!=b&&a.Wc("mrl","ori."+b+";mod."+c,!0),a=c):a=b,c=d>a),a=c?!1:!0);return a};
IE=function(a,b,c){if((!a.A||Wt(a.A)||au(a.A))&&!a.T&&a.F.X){var d=a.B;a=a.H;c=YD(a,b.g.info.g,c.g.info.g,0);var e=Bx(a.l)+c/g.Ex(a.l);d+=Math.max(e,e+a.g.Wb-c/b.g.info.g);a:{if(b.A.length){if(b.A[0].info.g[0].startTime<=d)break a;KD(b)}a=b.o;for(c=a.g.length-1;0<=c;c--)a.g[c].info.startTime>d&&a.g.pop();b.A.length?b.l=g.Ha(g.Ha(b.A).info.g):b.o.g.length?b.l=oD(b.o).info:b.l=b.B;b.l&&d<b.l.startTime&&(b.L=0,b.l=b.g.rf(d,!0).g[0])}}};
LE=function(a,b,c){HE(a,b,c);if(b.F){if(a.C.isLive){var d=b.g.rf(window.Infinity);d.o=a.Oa}else d=b.g.Vj(0,!0);a.G?(c=a.G,0==d.o&&(d.B=c.J)):d.B=a.Cb;CD(b,JE(a,d))}else if(d=b.l,d.g.hc()){!RD(b)||a.l.Z||a.C.l||(IE(a,b,c),b.l||HD(b,a.B));d=b.l;var e=d.B-a.B,f=!d.range||0==d.Na&&0==d.o?0:d.range.length-(d.o+d.Na),k=d.g;if(QD(b)&&b.g.hc()){var l=Math.min(15,.5*GE(a,b,!0));l=RD(b)||e<=l}else l=!1;l&&0==f&&(a.C.l?k=b.g:(k=d.startTime+KE,d.Na&&(k+=d.duration),HD(b,k),d=b.l,k=d.g));k.Je()?(f=a.F,e=YD(a.H,
k.info.g,c.g.info.g,e,0<f.g.length&&0==f.H&&a.Z),c=a.l.ge?QD(b):QD(b)&&b.g.hc(),e=d.g.Yg(d,e),e.range&&1<e.g.length&&(c||e.l.g?e=d.g.Yg(d,e.g[0].Na):(c=e.g[e.g.length-1],k=c.Na/e.range.length,!c.A&&.4>k&&(e=d.g.Yg(d,e.range.length-c.Na)))),d=e):(0>d.l&&a.Wc("nosq",d.F+";"+Py(Nv(d))),d=k.Yh(d));CD(b,JE(a,d))}else d.g.Je()?(c=YD(a.H,b.g.info.g,c.g.info.g,0),d=d.g.Yg(d,c)):d=d.g.Yh(d),CD(b,JE(a,d))};
JE=function(a,b){3==b.g[b.g.length-1].type&&ME(a,Lha(a.F,b.g[0].g));var c=Aw(b);c=new yha(a.O,c,Iha(a.H,c),b,a.nb);a.l.Uk&&(c.G=[]);var d=new ZC(a.l,b,c,a.ba);c.sa=function(){return Cha(d)?d.o.Pk&&window.performance&&window.performance.now&&d.g&&d.g.rj()&&iD(d)&&QC(d.g)?d.info.g[0].g.info.video?3:4:2:1};
Aha(d,(0,g.z)(a.cL,a));3==b.g.length&&1==b.g[0].type&&2==b.g[1].type&&4==b.g[2].type&&b.g[0].g.info.video&&(d.Y=Pha(a.F));d.start(Math.max(0,b.g[0].C-a.B));b.g[0].g.info.video&&(c=$C(d))&&(a.Va=c.substr(0,c.indexOf(".")));return d};
ME=function(a,b){b&&a.P("videoformatchange",b)};
aia=function(a,b){var c=b.info.g[0].g,d=c.info.video?a.g:a.o;$ha(a,d,b);xw(b.info)&&!ww(b.info)&&((0,g.C)(b.l.g,function(a){rD(d.o,a)}),a.l.Mk||a.P("metadata",c))};
$ha=function(a,b,c){if(a.C.l&&b&&(b.F=!1,c.T&&a.sa.l(1,c.T),b=c.g?(0,window.parseInt)(c.g.Bd("X-Head-Seqnum"),10):null)){a=a.C;for(var d in a.g)c=a.g[d].index,c.l&&(c.o=Math.max(c.o,b))}};
NE=function(a,b,c){a:{b=b.info;var d=a.l.AA,e=null,f=b.g[0];if(b.range)e=Hv(b.range.start,Math.min(4096,b.range.length));else if(d){if(b.A&&0<=b.A.indexOf("/range/")){c=null;break a}e=Hv(0,4096)}else if(f.g.info.video){c=null;break a}b=new Jv(5,f.g,e,"createProbeRequestInfo_"+f.F,f.l);b=new vw([b]);b.C=c;c=b}c&&JE(a,c)};
cia=function(a){var b=-1!=a.g.C,c=-1!=a.o.C;if(!b||!c)if(b=!b&&nD(a.g.o),c=!c&&nD(a.o.o),b||c){c=b?a.g:a.o;b=b?a.o:a.g;var d=nD(c.o).info.l;if(a.l.Lk||-1==b.C||b.C==d){if(c.C=d,c.H=window.NaN,-1!=b.C){var e=Math.max(b.g.index.od(b.C),c.g.index.od(c.C));a.ga&&(a.ga.resolve(e+.1),a.ga=null);g.Jf(function(){return OE(a,e)})}}else nx(a.C,d,c==a.g),bia(c,b.C),PE(a,!1,"qoe.avsync",{start:"1",
target:String(b.C),actual:String(d)})}};
bia=function(a,b){LD(a);HD(a,window.Infinity);var c=a.H;a.o.B=c;a.H=c;c=a.l;c.F="correctTrack_";c.l=b-1};
dia=function(a){if(a.l.Cc)return!1;var b;if(!(b=VD(a.g))&&(b=a.T)){b=a.H;var c=a.g,d=a.o;if(0==c.A.length&&0==d.A.length)b=!0;else{var e=0,f=sD(c.o).concat(sD(d.o));f=g.q(f);for(var k=f.next();!k.done;k=f.next())e+=k.value.Na;c=c.g.info.g+d.g.info.g;e/=c;b=10<e?!0:10>c*(10-e)/ZD(b)}(b=!b)||(b=a.g,b=0<b.A.length&&1==b.o.g.length&&nD(b.o).info.H<b.O)}if(b)return!0;if(!a.Z||!a.l.oa||10>a.B||360<a.g.g.info.za().g)return!1;b=SD(a.g,a.B,a.l.oa)||SD(a.o,a.B,a.l.oa);return(0<a.g.A.length||0<a.o.A.length||
HE(a,a.g,a.o)||HE(a,a.o,a.g))&&b};
TE=function(a,b,c,d){if(c.Hf())return!0;var e=nD(b.o);if(!e||!c.ao())return!1;var f=e.info;!b.B||b.B.A||Lv(b.B,f)||(b.B=null,Wt(a.A)&&c.abort(),c.qh(null));c.Rr(f.g.info.containerType,f.g.info.mimeType);f=a.C.isLive&&Zv(e);var k;if(k=a.l.sc&&a.C.o&&0==e.info.o&&(g.tt(e.info.g.info)||a.l.ct)){if(null==c.pf()){if(!(k=null==b.B||b.B.g!=e.info.g)){a:{k=b.B.J;var l=e.info.J;if(k.length!=l.length)k=!1;else{for(var m=0;m<k.length;m++)if(!g.cb(k[m],l[m])){k=!1;break a}k=!0}}k=!k}}else k=c.pf()!=e.info.g.g;
k=!k}k&&(g.tt(e.info.g.info)?(iv(Tv(e),1836019574),iv(Tv(e),1718909296)):(k=new mv(Tv(e)),Ev(k),qv(k,524531317,!0),e.range=new g.Fv(k.o+k.g,e.range.end)),e.o=!1);if(!a.C.o||0==e.info.o)if(f||a.C.l||e.o)c.qh(null);else if(QE(a,c,e))return!0;f=GE(a,b,!1);f=a.B+f;null!==d&&0<=d&&(f=Math.min(f,d));d=f;if(a.G)a:if(a.G.B&&b.g.info.audio){if((f=nD(b.o))&&(f=f.l)&&null!=f.A){f=f.A-1;break a}f=-1}else f=window.Infinity;else f=window.Infinity;k=b.o;if(!k.g.length||k.g[0].info.C>=d)d=null;else if(l=k.g[0].o?
0:k.g[0].range.start,l>f)d=null;else{for(m=1;m<k.g.length;m++){var n=k.g[m].range.start>f,p=k.g[m].g!=k.g[m-1].g;if(k.g[m].info.C>d||n||p||k.o.Oc)break}m--;d=new g.Fv(l,Math.min(k.g[m].range.end,f))}if(!d)return!1;k=new window.Uint8Array(e.g,d.start,d.length);a.yb&&e.info.g.info.video&&g.tt(e.info.g.info)&&nC(a.yb,k,e.info.o);f=!1;3!=e.info.type||!g.tt(e.info.g.info)&&2!=e.info.g.info.containerType||(f=g.tt(e.info.g.info)&&a.l.HB&&!b.G&&0==e.info.o&&0<e.info.startTime)&&Xv(e,0);a:{l=g.q(b.o.g);for(m=
l.next();!m.done;m=l.next()){m=m.value;if(d.end==m.range.end){l=m.info.A;break a}if(d.end<m.range.end)break}l=!1}a:if(k=RE(a,c,k,l),"s"==k)k=!0;else{if("i"==k||"x"==k)SE(a,"checked",k,e.info);else{if("q"==k&&(e.info.g.info.video?(k=a.l,k.B=Math.floor(.8*k.B),k.L=Math.floor(.8*k.L),k.o=Math.floor(.8*k.o)):(k=a.l,k.C=Math.floor(.8*k.C),k.ka=Math.floor(.8*k.ka),k.o=Math.floor(.8*k.o)),c.supports(2)&&!c.Hf())){k=!1;l=c.Nb().length;for(m=0;!k&&m<l;m++)c.Nb().start(m)>e.info.B&&(c.remove(c.Nb().start(m),
c.Nb().end(l-1)),k=!0);l=Math.max(0,Math.min(a.B,e.info.startTime)-5);!k&&l&&c.remove(0,l);k=!1;break a}a.P("reattachrequired")}k=!1}if(!k)return!1;b.G=!0;if(f)Xv(e,e.info.startTime),c.abort(),c.qh(null);else{f=b.o;for(k=[];f.g.length&&(f.g[0].range.end>d.end?(m=Vv(f.g[0],d.end-f.g[0].range.start+1),l=m[0],f.g[0]=m[1]):l=f.g.shift(),k.push(l),l.range.end!=d.end););k.length&&(0,g.C)(k,b.Y,b)}e.o&&(e.info.g.g&&(c.qh(e.info.g.g),a.l.X||a.P("initsegment",c.pf())),(b=e.info.g.G)&&a.P("newDrmInfo",b.type,
b.key));return!0};
SE=function(a,b,c,d){var e="fmt.unplayable";"i"==c&&(e="html5.invalidstate");if("x"==c||"m"==c)e="fmt.unparseable",d.g.B=e,d.g.info.video&&!gE(a.F)&&fE(a.F,d.g);d=Nv(d);d.mrs=a.A.o.readyState;d.origin=b;d.reason=c;PE(a,"i"!=c,e,d)};
UE=function(a,b,c){Ufa(a.C,b,c)&&c&&g.Jf(function(){if(a.Ia)a.Ia=!1,OE(a,b.startTime);else{var c=b.startTime,e=b.duration;if(!a.ea()&&a.l.T&&a.L&&-1!=a.g.C&&-1!=a.o.C){var f=a.l.ys?0:.1;a.B<c||a.B>c+e+f?3>a.X?(a.X++,a.seek(a.B)):(a.Wc("iterativeSeeking","incomplete;count="+a.X,!1),a.X=0,a.L=!1,a.P("seekplayerrequired",c+.1,!0)):(a.Wc("iterativeSeeking","done;count="+a.X,!1),a.X=0,a.L=!1)}}})};
OE=function(a,b){!a.ea()&&a.l.T&&a.L&&-1!=a.g.C&&-1!=a.o.C&&(a.L=!1,a.P("seekplayerrequired",b+.1,!0))};
QE=function(a,b,c){c.info.g.hc();var d=c.info.g.g;if(null==d||b.pf()==d)return!1;var e=RE(a,b,d,!0);if("s"!=e)return SE(a,"sepInit",e,c.info),!0;b.qh(d);a.l.X?(c=c.info.g.G)&&a.P("newDrmInfo",c.type,c.key):a.P("initsegment",b.pf());return b.Hf()};
RE=function(a,b,c,d){try{b.nq(c,d)}catch(e){if(11==e.code)return"i";if(12==e.code)return"x";if(22!=e.code&&0!=e.message.indexOf("Not enough storage"))return g.M(e),"u";a.l.Vk&&a.Wc("quex","br."+Mt(b.Nb()).replace(/,/g,"_"));return"q"}return Yt(a.A)?"m":"s"};
VE=function(a,b){b.o.subscribe("warning",a.VJ,a);b.o.subscribe("error",a.QJ,a);b.o.subscribe("timestamprewrite",a.UJ,a);var c=(0,g.z)(a.RJ,a,b);b.o.subscribe("placeholderinfo",c,void 0);c=(0,g.z)(a.SJ,a,b);b.o.subscribe("placeholderrollback",c,void 0);c=(0,g.z)(a.TJ,a,b);b.o.subscribe("segmentinfo",c,void 0);b==a.g&&b.o.subscribe("cuepoint",a.PJ,a)};
GE=function(a,b,c){if(a.Y)return 1;var d=b.g.info.audio?a.l.C:a.l.B;!a.l.Z&&hE(a.F)&&(d=Math.max(d,b.g.info.audio?a.l.ka:a.l.L));c&&(d+=a.l.ga);var e=hE(a.F)?b.l?b.l.g.info.g:b.g.info.g:b.J;d/=e;0<a.l.pa&&a.A&&Wt(a.A)&&(b=b.g.info.video?a.A.l:a.A.g)&&!b.Hf()&&(e=Nt(b.Nb(),a.B),0<=e&&(b=a.B-b.Nb().start(e),d+=Math.max(0,Math.min(b-a.l.pa,a.l.Fx))));0<a.l.o&&(d=Math.min(d,a.l.o));a.l.Mb&&c&&!hE(a.F)&&(c=a.F,c=cE(c,g.Ha(c.g))+cE(c,c.G.g[0]),c=a.l.Mb*(c/WD(a.H)),c<d&&15>c&&a.Wc("bwcapped","1",!0),c=Math.max(c,
15),d=Math.min(d,c));return d};
Zha=function(a){if(!a.ob)return window.Infinity;var b=(0,g.Bd)(uE(a.ob),function(a){return"ad"==a.namespace});
b=g.q(b);for(var c=b.next();!c.done;c=b.next())if(c=c.value,c.start/1E3>a.B)return c.start/1E3;return window.Infinity};
WE=function(a,b,c){if(a.g.hc())if(c){var d=yE(a,b,c);if(!(0,window.isNaN)(d))return d;LD(a);c=Ot(c.Nb(),b);if((0,window.isNaN)(c))return HD(a,b);HD(a,c+KE)}else{c=FD(a,b);if(0<=c)return c;LD(a);HD(a,b)}else 0!=b&&KD(a);return b};
yE=function(a,b,c,d){d=void 0===d?!1:d;var e=Ot(c.Nb(),b),f=window.NaN,k=a.B;k&&(f=Ot(c.Nb(),k.g.index.od(k.l)));if(e==f&&a.l&&a.l.Na&&OD(ND(a),0))return b;a=FD(a,b,d);return 0<=a?a:window.NaN};
XE=function(a,b,c,d){c.hc()||c.C||!tw(c.A)||(d=c.Ih(d?Jha(a.H,c.info):0),(0,g.C)(d,function(a){if("f"!=a.g[0].g.info.l){var c=JE(this,a);ww(a)&&CD(b,c)}},a),c.C=!0)};
PE=function(a,b,c,d){a.ea()||(c=new g.Oy(c,b,d),Py(c.details),a.P("error",c),b&&a.dispose())};
YE=function(a){var b={lct:a.B.toFixed(3),lsk:a.T,lmf:hE(a.F),lbw:Dx(a.O).toFixed(3),lhd:Bx(a.O).toFixed(3),lst:(1E9*(a.O.A.g()||0)).toFixed(3),laa:a.o&&a.o.B?Ov(a.o.B):"",lva:a.g&&a.g.B?Ov(a.g.B):"",lar:a.o&&a.o.l?Ov(a.o.l):"",lvr:a.g&&a.g.l?Ov(a.g.l):"",lvh:a.Va};a.A&&!Yt(a.A)&&a.A.g&&a.A.l&&(b.lab=Mt(a.A.g.Nb()),b.lvb=Mt(a.A.l.Nb()));return b};
DE=function(a){a.o&&a.g&&(LD(a.o),LD(a.g))};
eia=function(a,b){var c=b.info.video?a.g:a.o;null!=c&&XE(a,c,b,!1)};
fia=function(a,b,c){this.url=a;this.interval=b;this.g=c};
ZE=function(a){g.N.apply(this,arguments)};
$E=function(a,b,c){this.initData=a;this.contentType=(void 0===b?"":b)||null;this.isPrefetch=void 0===c?!1:c;this.g=this.cryptoPeriodIndex=window.NaN;this.l=!1;this.o=[]};
aF=function(a,b,c,d){ZE.call(this);var e=this;this.o=-1;this.g={};this.A=new g.L(this.B,0,this);g.I(this,this.A);this.l=new g.L(function(){e.ea()||(e.A.start(Math.random()*c),e.l.start(b))},a,this);
g.I(this,this.l);d.subscribe("fairplay_next_need_key_info",this.C,this)};
gia=function(a,b,c){a=g.wg(a);for(var d=[],e=g.q(a[6].split("&")),f=e.next();!f.done;f=e.next())f=f.value,0==f.indexOf("cpi=")?d.push("cpi="+b):0==f.indexOf("ek=")?d.push("ek="+g.jb(c)):d.push(f);a[6]="?"+d.join("&");b="skd://"+a.slice(2).join("");a=2*b.length;c=new window.Uint8Array(a+4);c[0]=a%256;c[1]=(a-c[0])/256;for(a=0;a<b.length;++a)c[2*a+4]=b.charCodeAt(a);return c};
bF=function(a,b){this.statusCode=a;this.errorMessage=null;this.message=b;this.o=this.l=this.g=this.heartbeatParams=null};
cF=function(a){var b=lv(a.subarray(0,16384)),c=b.indexOf("\r\n\r\n");if(-1==c)return null;var d=b.indexOf("\r\n"),e=b.slice(0,d).match(/^GLS\/1.\d ([0-9]{1,3}) (\w+)$/);if(null==e)return null;e=e[1];(0,window.isFinite)(e)&&(e=String(e));e=g.v(e)?/^\s*-?0x/i.test(e)?(0,window.parseInt)(e,16):(0,window.parseInt)(e,10):window.NaN;b=Vu(b.slice(d+2));if(null==b)return null;a=new bF(e,a.subarray(c+4));0!=a.statusCode&&(a.errorMessage=g.WA(a.statusCode));if(c=b["Heartbeat-Url"])a.heartbeatParams=new fia(c,
(0,window.parseInt)(b["Heartbeat-Interval-Secs"],10)||60,(0,window.parseInt)(b["Heartbeat-Num-Retries"],10)||4);if(c=b["Authorized-Format-Types"])a.g=c.split(",");if(c=b["Key-Ids"])a.l=hia(c);a.o=b["Next-Key-Id"];return a};
hia=function(a){if(!a)return{};var b={};(0,g.C)(a.split(";"),function(a){a=a.split(",");2==a.length&&(b[a[1]]=a[0])});
return b};
dF=function(a,b,c,d){g.G.call(this);this.message=a;this.number=b;this.o=c;this.g=d;this.l=new g.ao(5E3,2E4,.2)};
eF=function(a,b,c,d,e){g.G.call(this);this.C=a;this.J=b;this.H=c;this.g=d;this.l=e;this.sessionId="";this.G=this.F=this.A=this.B=null;this.ca=new g.Pq(this);g.I(this,this.ca);this.g?(this.ca.M(this.g,"message",this.XF),this.ca.M(this.g,"keystatuseschange",this.YF),this.g.closed&&this.g.closed.then(jp((0,g.z)(this.WF,this)),null)):this.l&&(Qq(this.ca,this.l,["mskeymessage","webkitkeymessage"],this.jy),Qq(this.ca,this.l,["mskeyerror","webkitkeyerror"],this.iy),Qq(this.ca,this.l,["mskeyadded","webkitkeyadded"],
this.hy))};
fF=function(a,b){g.G.call(this);this.l=a;this.g=b;this.C={};this.A=null;this.ca=new g.Pq(this);g.I(this,this.ca);this.o=this.B=null};
gF=function(a){if(a.g.l)return a.g.l.createMediaKeys().then(jp(function(b){a.ea()||(a.B=b,a.l.setMediaKeys(b))}));
yy(a.g)?a.o=new (wy())(a.g.g):By(a.g)?(a.o=new (wy())(a.g.g),a.l.webkitSetMediaKeys(a.o)):iia(a);return null};
iia=function(a){Qq(a.ca,a.l,["keymessage","webkitkeymessage"],a.cG);Qq(a.ca,a.l,["keyerror","webkitkeyerror"],a.bG);Qq(a.ca,a.l,["keyadded","webkitkeyadded"],a.aG)};
jia=function(a){return"widevine"==a.g.flavor&&a.g.Ck&&a.B.setServerCertificate?a.B.setServerCertificate(a.g.Ck):null};
hF=function(a,b){var c=b.subarray(4);c=String.fromCharCode.apply(null,new window.Uint16Array(c.buffer,c.byteOffset,c.byteLength/2)).match(/ek=([0-9a-f]+)/)[1];for(var d="",e=0;e<c.length;e+=2)d+=String.fromCharCode((0,window.parseInt)(c.substr(e,2),16));c=kv(a.g.fairPlayCert);e=new window.ArrayBuffer(2*d.length);for(var f=new window.Uint16Array(e),k=0;k<d.length;k++)f[k]=d.charCodeAt(k);d=new window.Uint8Array(e);e=0;k=new window.ArrayBuffer(b.byteLength+4+d.byteLength+4+c.byteLength);f=new window.Uint8Array(k);
k=new window.DataView(k);f.set(b);e+=b.byteLength;k.setUint32(e,d.length,!0);e+=4;f.set(d,e);e+=d.length;k.setUint32(e,c.byteLength,!0);f.set(c,e+4);return f};
iF=function(a,b){var c=a.C[b.sessionId];!c&&a.A&&(c=a.A,a.A=null,c.sessionId=b.sessionId,a.C[b.sessionId]=c);return c};
kF=function(a,b,c,d,e,f){g.G.call(this);this.C=a;this.l=a.Re;this.o=e;this.A=b;this.cryptoPeriodIndex=d.cryptoPeriodIndex||window.NaN;this.Y=f;this.G=kia(this);this.G.session_id=f;this.J=!0;"playready"==this.l.flavor&&(a=(0,window.parseInt)(g.zt(b.experiments,"playready_first_play_expiration"),10),!(0,window.isNaN)(a)&&0<=a&&(this.G.mfpe=""+a),g.R(b.experiments,"html5_playready_keystatuses_killswitch")||(this.J=!1));"fairplay"==this.l.flavor?(a=d.initData.subarray(4),a=String.fromCharCode.apply(null,
new window.Uint16Array(a.buffer,a.byteOffset,a.byteLength/2)).replace("skd://","https://")):a=this.l.A;e=a=this.L=a;var k=void 0===k?!1:k;vs(lia.test(e),e,k,"Drm Licensor URL")||jF(this,"drm.net",!0,"t.x");for(var l in this.G)k=l,e=this.G[l],a=Jg(g.Ng(a,k),k,e);this.X=a;this.Z=g.R(b.experiments,"html5_use_drm_retry");this.R=0;this.H=this.O=!1;(0,g.VB)("drm_gk_s");try{var m=c.createSession(d)}catch(n){b="t.g",n instanceof window.DOMException&&(b+=";c."+n.code),this.o.P("licenseerror","drm.unavailable",
!0,b,"HTML5_NO_AVAILABLE_FORMATS_FALLBACK"),m=null}if(this.B=m)b=this.B,c=this.TF,l=this.SF,m=this.VF,b.B=this.UF,b.A=c,b.F=l,b.G=m,b.o=this,g.I(this,this.B);this.da=d.o;this.F=[];this.g={};this.T=window.NaN};
kia=function(a){var b={};g.Zb(b,a.A.l);b.cpn=a.C.clientPlaybackNonce;var c=["23763106","23775802"].filter(function(b){return a.A.experiments.experiments[b]});
0<c.length&&(b.fexp=c.join());a.C.df&&(b.vvt=a.C.df,a.C.mdxEnvironment&&(b.mdx_environment=a.C.mdxEnvironment));a.A.Dc&&(b.authuser=a.A.Dc);a.A.pageId&&(b.pageid=a.A.pageId);(0,window.isNaN)(a.cryptoPeriodIndex)||(b.cpi=a.cryptoPeriodIndex);return b};
mia=function(a){var b={};g.Zb(b,a.G);return b};
lF=function(a){for(var b="",c=0;c<a.length;c+=2)b+=String.fromCharCode(a[c]);a=(new window.DOMParser).parseFromString(b,"text/xml");return a?(a=a.querySelector("Challenge"))&&a.childNodes&&0!==a.childNodes.length?new window.Uint8Array(Oaa(a.childNodes[0].data)):null:null};
nia=function(a,b){if("widevine"!=a.l.flavor)jF(a,"drm.provision",!0,"e.flavor;f."+a.l.flavor+";l."+b.byteLength);else{var c={cpn:a.C.clientPlaybackNonce};g.Zb(c,a.A.l);c=g.Ig("https://www.googleapis.com/certificateprovisioning/v1/devicecertificates/create?key=AIzaSyB-5OLKTx2iU5mko18DfdwK5611JIjbUhE",c);var d={format:"RAW",headers:{"content-type":"application/json"},method:"POST",postBody:Lda({signedRequest:lv(b)}),responseType:"arraybuffer"};g.$p(c,d,3,500).then(jp(function(b){if(!a.ea()){b=new window.Uint8Array(b.response);
var c=lv(b);try{var d=g.Tn(c)}catch(l){}d&&d.signedResponse?(a.o.P("ctmp","provisioning",""),a.B&&a.B.update(b)):(d=d&&d.error&&d.error.message,b="e.parse",d&&(b+=";m."+d),jF(a,"drm.provision",!0,b))}}),jp(function(b){a.ea()||jF(a,"drm.provision",!0,"e."+b.errorCode+";c."+(b.Wg&&b.Wg.status))}))}};
mF=function(a){var b;if(b=a.J&&null!=a.B)a=a.B,b=!(!a.g||!a.g.keyStatuses);return b};
nF=function(a,b){(0,g.VB)("drm_net_s");if(g.R(a.A.experiments,"use_innertube_drm_service_optin")){var c=new g.Mr(a.A.yb),d={context:g.rr(c.g)};d.drmSystem=oia[a.l.flavor];d.videoId=a.C.videoId;d.cpn=a.C.clientPlaybackNonce;d.sessionId=a.Y;d.licenseRequest=g.Ud(b.message);d.drmParams=a.C.drmParams;(0,window.isNaN)(a.cryptoPeriodIndex)||(d.isKeyRotated=!0,d.cryptoPeriodIndex=a.cryptoPeriodIndex);var e={onSuccess:(0,g.z)(b.F,b),onError:(0,g.z)(b.C,b)};g.vr(c,"player/get_drm_license",d,e)}else c=a.X,
d=a.C.oauthToken,e={format:"RAW",method:"POST",postBody:b.message,responseType:"arraybuffer",withCredentials:!0,timeout:3E4,onSuccess:(0,g.z)(b.B,b),onError:(0,g.z)(b.A,b)},d&&(c=Jg(g.Ng(c,"access_token"),"access_token",d)),g.Fp(c,e)};
jF=function(a,b,c,d,e){a.ea()||a.o.P("licenseerror",b,c,d,e);c&&a.dispose()};
pia=function(a,b){var c=b.l.getValue();c=new g.L(function(){return nF(a,b)},c);
g.I(a,c);c.start();g.bo(b.l)};
oF=function(a){return g.Ma(a,"UHD2")?"highres":g.Ma(a,"UHD1")?"hd2160":g.Ma(a,"HD")?"hd1080":g.Ma(a,"HD720")?"hd720":"large"};
pF=function(a,b){if(!mF(a)&&Ay(a.l)&&!b)return"large";var c=[],d=!0;if(mF(a))for(var e in a.g)"usable"==a.g[e].status&&c.push(a.g[e].type),"unknown"!=a.g[e].status&&(d=!1);if(!mF(a)||d)c=a.F;return oF(c)};
qF=function(a){var b=a[0];a[0]=a[3];a[3]=b;b=a[1];a[1]=a[2];a[2]=b;b=a[4];a[4]=a[5];a[5]=b;b=a[6];a[6]=a[7];a[7]=b};
qia=function(a){if(mF(a)){var b=[],c;for(c in a.g)b.push.apply(b,[c,a.g[c].type,a.g[c].status]);a=b.join(";")}else a=a.F.join(";");return a};
ria=function(a,b,c,d){a=new window.Uint8Array(a);if(a=lF(a))a={format:"RAW",method:"POST",postBody:a,responseType:"arraybuffer",withCredentials:!0,timeout:3E4},c=hba(c,d),g.$p(c,a,3,500).then(function(a){a=new window.Uint8Array(a.response);(a=cF(a))&&a.message&&b.update(a.message)})};
rF=function(a,b){var c=sia(void 0===b?"auto":b),d;for(d in a.g)if("output-restricted"==a.g[d].status){var e=a.g[d].type;if(""==c||"AUDIO"==e||c==e)return!0}return!1};
sia=function(a){switch(a){case "highres":case "hd2880":return"UHD2";case "hd2160":case "hd1440":return"UHD1";case "hd1080":case "hd720":return"HD";case "large":case "medium":case "small":case "light":case "tiny":return"SD";default:return""}};
sF=function(a,b){for(var c in a.g)if("usable"==a.g[c].status&&a.g[c].type==b)return!0;return!1};
tF=function(){this.keys=[];this.values=[]};
uF=function(a,b,c){ZE.call(this);var d=this;this.A=a;this.o=b;this.g=[];this.l=new g.L(function(){var a=d.g.shift().info;a:{var b=a.cryptoPeriodIndex;if((0,window.isNaN)(b)&&0<d.o.values.length)b=!0;else{for(var c=g.q(d.o.values),l=c.next();!l.done;l=c.next())if(l.value.cryptoPeriodIndex==b){b=!0;break a}b=!1}}b||d.P("rotated_need_key_info_ready",a);0<d.g.length&&(a=d.g[0].time-(0,g.D)(),d.l.start(Math.max(0,a)))},0);
g.I(this,this.l);c.subscribe("widevine_set_need_key_info",this.B,this)};
wF=function(a,b,c,d){g.N.call(this);a&&(a.addKey||a.webkitAddKey)||wy()||Cy(c.experiments);this.G=a;this.pa=b;this.g=b.Re;this.A=c;this.subscribe("newlicense",this.mK,this);this.subscribe("newsession",this.nK,this);this.subscribe("sessionready",this.rL,this);this.subscribe("keystatuseschange",this.dG,this);this.subscribe("hdentitled",this.uJ,this);this.oa=b.drmSessionId||g.es();this.l=new tF;this.B=this.H=null;this.o=[];this.J="fairplay"==this.g.flavor?Bu:g.R(this.A.experiments,"html5_drm_start_from_null_constraint")?
Bu:vF;this.T=null;this.L=new fF(a,this.g);g.I(this,this.L);this.F=null;yy(this.g)&&(this.F=new fF(a,this.g),g.I(this,this.F));this.ba=2;this.ca=new g.Pq(this);g.I(this,this.ca);this.ga=this.X=!1;this.da=null;this.R=!1;a=this.G;this.g.l?this.ca.M(a,"encrypted",this.kJ):Qq(this.ca,a,yy(this.g)?["msneedkey"]:["needkey","webkitneedkey"],this.jK);(a=gF(this.L))?a.then(jp((0,g.z)(this.OJ,this)),jp((0,g.z)(this.vI,this))):this.R=!0;this.F&&gF(this.F);this.ka=d;this.O=this.Y=this.Z=!1;a:{d=this.g;a=this.A.experiments;
b=this.l;switch(d.flavor){case "fairplay":g.R(a,"html5_enable_fairplay_key_rotation")&&Op()?(a=d.bj,d=d.aj,d>=a&&(d=.75*a),b=.5*(a-d),d=new aF(b,a,a-b-d,this)):d=null;break a;case "widevine":d=g.R(a,"html5_enable_widevine_key_rotation")?new uF(g.R(a,"disable_license_delay"),b,this):null;break a}d=null}if(this.C=d)g.I(this,this.C),this.C.subscribe("rotated_need_key_info_ready",this.Rn,this)};
zF=function(a,b,c){a.ga=!0;g.R(a.A.experiments,"html5_playbackmanager_enable_notify_new_drm_info")?0==a.o.length?xF(a,new $E(b,c)):yF(a):yy(a.g)||xF(a,new $E(b,c))};
uia=function(a,b){if(yy(a.g)&&!a.Z){var c=yC(b);if(0!=c.length){var d=new $E(c);a.Z=!0;window.navigator.requestMediaKeySystemAccess("com.microsoft.playready",[{initDataTypes:["keyids","cenc"],audioCapabilities:[{contentType:'audio/mp4; codecs="mp4a"'}],videoCapabilities:[{contentType:'video/mp4; codecs="avc1"'}]}]).then(function(b){b.createMediaKeys().then(function(b){tia(a,b,d)})},null)}}};
tia=function(a,b,c){var d=b.createSession(),e=a.l.values[0],f=mia(e);d.addEventListener("message",function(b){ria(b.message,d,a.g.A,f)});
d.addEventListener("keystatuseschange",function(){d.keyStatuses.forEach(function(b,c){"usable"==c&&(a.Y=!0,AF(a,pF(e,a.Y)))})});
d.generateRequest("cenc",c.initData)};
xF=function(a,b){a.ea()||a.X&&a.ka||(a.X=!0,"widevine"==a.g.flavor&&a.C?a.P("widevine_set_need_key_info",b):a.Rn(b))};
BF=function(a){a.ea()||(a.R=!0,yF(a))};
yF=function(a){if((!g.R(a.A.experiments,"html5_playbackmanager_enable_notify_new_drm_info")||a.ga)&&a.R&&!a.O){for(;a.o.length;){var b=a.o[0];if(g.cb(a.H,b.initData))a.o.shift();else{if(a.l.get(b.initData))if("fairplay"==a.g.flavor)a.l.remove(b.initData);else{a.o.shift();continue}a:{var c=b.initData;try{for(var d=0,e=new window.DataView(c.buffer);d<e.byteLength-8;){var f=e.getUint32(d);if(1>=f)break;if(1886614376==e.getUint32(d+4)){var k=32;if(0<e.getUint8(d+8)){var l=e.getUint32(d+28);k+=16*l+4}var m=
e.getUint32(d+k-4);try{var n=new ie(c.subarray(d+k,d+k+m)),p=new ap;for(k=n;je(k)&&4!=k.l;)switch(k.o){case 2:var u=ne(k),x=u;Ke(p,2).push(x);break;case 4:u=ne(k);Le(p,4,u);break;case 7:u=he(k.g);Le(p,7,u);break;case 9:u=he(k.g);Le(p,9,u);break;case 10:u=he(k.g);Le(p,10,u);break;case 11:u=le(k);Le(p,11,u);break;case 12:u=he(k.g);Le(p,12,u);break;case 13:x=u=ne(k);Ke(p,13).push(x);break;case 14:u=new bp;x=k;var B=u,F=hea,H=x.g.o,Q=he(x.g),O=x.g.g+Q;x.g.o=O;F(B,x);x.g.g=O;x.g.o=H;x=p;B=u;F=bp;Oe(x,
F,14);var ab=x.g[14];ab||(ab=x.g[14]=[]);var Cb=B?B:new F,de=Ke(x,14);ab.push(Cb);de.push(Qe(Cb));break;case 1:u=le(k);Le(p,1,u);break;case 3:u=me(k);Le(p,3,u);break;case 5:u=me(k);Le(p,5,u);break;case 6:u=me(k);Le(p,6,u);break;case 8:u=ne(k);Le(p,8,u);break;default:ke(k)}var ng=p;if(null!=ng){var Ub=ng;break a}}catch(ve){}}d+=f}Ub=null}catch(ve){Ub=null}}if(null!=Ub)for(c=Je(Ub,7),null!=c&&(b.cryptoPeriodIndex=c),c=Je(Ub,10),null!=c&&0<c&&(b.g=c),c=Ke(Ub,2),c=!c.length||c[0]instanceof window.Uint8Array?
c:(0,g.E)(c,Paa),c=g.q(c),d=c.next();!d.done;d=c.next())b.o.push(zC(d.value));if("widevine"==a.g.flavor&&!a.C){a:if(c=a,(0,window.isNaN)(b.cryptoPeriodIndex)&&0<c.l.values.length)c=!0;else{c=g.q(c.l.values);for(d=c.next();!d.done;d=c.next())if(d.value.cryptoPeriodIndex==b.cryptoPeriodIndex){c=!0;break a}c=!1}if(c&&!g.R(a.A.experiments,"html5_dedup_by_cryptoperiod_killswitch")){a.o.shift();continue}else{a:{c=a;if(!(g.R(c.A.experiments,"disable_license_delay")||"widevine"!=c.g.flavor||b.l||(0,window.isNaN)(b.cryptoPeriodIndex)))for(c=
g.q(c.l.values),d=c.next();!d.done;d=c.next())if(1>=Math.abs(d.value.cryptoPeriodIndex-b.cryptoPeriodIndex)){c=!0;break a}c=!1}if(c){via(a,b);a.o.shift();continue}}}break}}a.o.length&&(b=a.o[0],a.l.get(b.initData),a.O=!0,Ub=new kF(a.pa,a.A,a.L,b,a,a.oa),a.l.set(b.initData,Ub))}};
via=function(a,b){a.B&&a.B.dispose();a.H=b.initData;a.B=new g.L(function(){a.H=null;a.B=null;b.l=!0;a.Rn(b)},wia(b.g));
a.B.start()};
wia=function(a){return 1E3*Math.max(0,Math.random()*(((0,window.isNaN)(a)?120:a)-30))};
AF=function(a,b){var c=zu("auto",b,!1,"l");if(g.R(a.A.experiments,"html5_drm_start_from_null_constraint")){if(yu(a.J,c))return}else if(Eu(a.J,b))return;a.J=c;a.P("qualitychange")};
xia=function(a,b){this.videoData=a;this.xa=b};
yia=function(a,b){return g.oA(a,b).then(function(){return new xia(a,a.xa)},function(){var b=a.ra&&!g.tu()?"html5.unsupportedlive":"fmt.noneavailable",d={buildRej:"1",
a:""+ +!!a.adaptiveFormats,d:""+ +!!a.Ud,f18:""+ +(0<=a.Ei.indexOf("itag=18")),c18:""+ +Bt('video/mp4; codecs="avc1.42001E, mp4a.40.2"'),f43:""+ +(0<=a.Ei.indexOf("itag=43")),c43:""+ +Bt('video/webm; codecs="vp8.0, vorbis"')};a.ma&&(d.f133=""+ +!!a.ma.g["133"],d.f140=""+ +!!a.ma.g["140"]);return new g.Oy(b,!0,d)})};
CF=function(a,b){this.g=a;this.A=b;this.o=this.l=0};
GF=function(a,b,c,d){var e=zu("auto",sx(),!1,"s"),f=g.R(a.g.experiments,"html5_break_sticky")&&/^i/.test(b.videoData.clientPlaybackNonce);if(Au(e)||f){e=Cu(DF(a,b),EF(a,b));f=0;!a.g.o||g.Zx(a.g)||Tp()||g.R(a.g.experiments,"mweb_uniplayer_auto_quality")||g.R(a.g.experiments,"hls_for_vod")||(f=g.jt.medium);var k=g.S(a.g.experiments,"html5_default_quality_cap");if(k){var l=!!b.xa.g&&!b.videoData.Ee,m=g.S(a.g.experiments,"html5_quality_cap_min_age_secs");l&&m&&(l=a.g.schedule.G,l=g.qr()-l>1E3*m);l&&(f=
f?Math.min(f,k):k)}if(m=k=g.S(a.g.experiments,"html5_hfr_quality_cap"))a:{m=b.xa;if(m.g)for(m=g.q(m.videoInfos),l=m.next();!l.done;l=m.next())if(32<l.value.za().fps){m=!0;break a}m=!1}m&&(f=f?Math.min(f,k):k);g.S(a.g.experiments,"tvhtml5_yongle_quality_cap");f=new xu(0,f,!1,"d");e=Cu(e,f);f=g.S(a.g.experiments,"html5_background_quality_cap");k=g.S(a.g.experiments,"html5_background_cap_idle_secs");d=!f||"auto"!=sx()||Gr()/1E3<k?Bu:d?new xu(0,f,!1,"v"):Bu;d=Cu(e,d);e=(e=g.S(a.g.experiments,"html5_autonav_quality_cap"))&&
b.videoData.Qh?new xu(0,e,!1,"e"):Bu;e=Cu(Cu(Cu(d,e),FF(a,b)),b.videoData.sA)}g.R(a.g.experiments,"html5_ignore_sticky_for_medcap")&&(e=Cu(e,EF(a,b)));return Cu(Cu(Cu(b.videoData.En,e),b.videoData.Yn),c)};
HF=function(a,b,c){g.gy(a.g)&&(c=Cu(c,DF(a,b)));return c};
DF=function(a,b){if(g.gy(a.g)&&fu(a.g.T,ju))var c=b.xa.videoInfos[0].za().g;else{var d=!!b.xa.g;g.Yx(a.g)&&(c=window.screen&&window.screen.width?new g.ad(window.screen.width,window.screen.height):null);c||(c=a.g.Nf?a.g.Nf.clone():a.A.Ha());if(Sx||IF||d){d=c;var e=g.oy(),f=g.ta(void 0)?void 0:e;d.width*=e;d.height*=f}var k=b.xa.videoInfos;if(k.length){d=.85;e=k[0].za();4!=e.projectionType&&2!=e.projectionType&&3!=e.projectionType||Xx||(d=.45);e=k[0];f=e.za();k=g.q(k);for(var l=k.next();!l.done&&!(e=
f=l.value,f=f.za(),null===c||f.width*d<c.width&&f.height*d<c.height);l=k.next());c=zu("auto","93"==g.ot(e)?it(f.width,f.height):f.quality,!1,"r")}else c=Bu;c=c.g}c&&(c=Math.max(c,360));return new xu(0,c,!1,"r")};
EF=function(a,b){var c=JF(b.xa);(g.Kp("armv7")||g.Kp("android"))&&!g.gy(a.g)&&qt(b.xa.videoInfos[0])&&(c=Math.min(c,g.jt.large));return new xu(0,c,!1,"o")};
JF=function(a){if(!a||!a.videoInfos.length||null==a.videoInfos[0].o)return 0;for(var b=g.q(a.videoInfos),c=b.next();!c.done;c=b.next())if(c=c.value,c.o)return c.za().height;return a.videoInfos[0].za().height};
FF=function(a,b){if(a.la("html5_restore_perf_cap")){var c=tx(b.xa.videoInfos[0].l);return new xu(0,c,!1,"b")}return a.g.Fd};
KF=function(a,b){b=void 0===b?null:b;var c={};this.o=(c.c1a=(0,g.z)(this.C,this),c.c3a=(0,g.z)(this.F,this),c.c6a=(0,g.z)(this.B,this),c);this.g=a;this.A=b;this.g&&this.g.Bg?this.l=g.sp(this.g.Bg):this.l=[]};
g.LF=function(a,b,c){g.ZA.call(this);this.l=a;this.g=b;this.C=c};
MF=function(a){this.l=window.Float32Array?new window.Float32Array(a):Array(a);this.o=this.g=a-1};
NF=function(a){return a.l[a.g]||0};
zia=function(a){this.A=new MF(50);this.g=null;this.o=this.l=0;this.B=a};
PF=function(a,b,c){g.N.call(this);var d=new Aia;"ULTRALOW"==a.latencyClass&&(d.A=!1);a.wj?d.o=3:g.AA(a)&&(d.o=2);g.R(b,"html5_adaptive_seek_to_head_killswitch")||"NORMAL"!=a.latencyClass||(d.C=!0);var e=21530001==hA(a),f=g.R(b,"html5_live_no_streaming_impedance_mismatch")||"ULTRALOW"==a.latencyClass&&g.R(b,"html5_ull_no_streaming_impedance_mismatch")||e;d.B=f&&gA(a)&&(a.hasSubfragmentedFmp4&&(!jA(a)||!NC())||a.defraggedFromSubfragments);d.B&&(d.J++,e&&(d.F=g.S(b,"html5_jumbo_ull_nonstreaming_mffa_ms")||
window.NaN));Lp()&&(e=g.S(b,"html5_platform_minimum_readahead_seconds")||3,d.l=Math.max(d.l,e));g.S(b,"html5_minimum_readahead_seconds")&&(d.l=g.S(b,"html5_minimum_readahead_seconds"));g.S(b,"html5_maximum_readahead_seconds")&&(d.G=g.S(b,"html5_maximum_readahead_seconds"));g.R(b,"html5_force_adaptive_readahead")&&(d.A=!0);g.S(b,"html5_allowable_liveness_drift_chunks")&&(d.g=g.S(b,"html5_allowable_liveness_drift_chunks"));g.S(b,"html5_readahead_ratelimit")&&(d.H=g.S(b,"html5_readahead_ratelimit"));
switch(hA(a)){case 21530001:d.g=(d.g+1)/5,"LOW"==a.latencyClass&&(d.g*=2)}this.g=d;this.A=a;this.H=c;this.o=[];this.B=0;this.C=1!=this.g.o;this.F=!1;this.G=0;b=(0,window.isNaN)(a.liveChunkReadahead)?3:a.liveChunkReadahead;a.wj&&b--;a.isLowLatencyLiveStream&&"NORMAL"!=a.latencyClass||b++;switch(hA(a)){case 21530001:b=1;break;case 2153E4:b=2}this.g.B&&b++;this.l=OF(this,b)};
RF=function(a){return QF(a)*a.l};
TF=function(a,b){var c=SF(a);var d=a.g.g;a.F||(d=Math.max(d-1,0));d*=QF(a);return b>=c-d};
SF=function(a){return Math.max(a.H()-RF(a),a.A.zb())};
UF=function(a,b,c){3==a.g.o&&((b=TF(a,b),c||b)?b&&(a.C=!0):a.C=!1)};
VF=function(a,b){var c=TF(a,b);a.F!=c&&a.P("livestatusshift",c);a.F=c};
QF=function(a){return a.A.ma?lx(a.A.ma)||5:5};
OF=function(a,b){b=Math.max(Math.max(a.g.J,Math.ceil(a.g.l/QF(a))),b);return Math.min(Math.min(8,Math.floor(a.g.G/QF(a))),b)};
Aia=function(){this.J=1;this.l=0;this.G=window.Infinity;this.H=0;this.A=!0;this.g=2;this.o=1;this.B=!1;this.F=window.NaN;this.C=!1};
YF=function(a,b){g.N.call(this);var c=this;this.da=b;var d={};this.Z=(d.seekelementrequired=this.JM,d.seekplayerrequired=this.IM,d.videoformatchange=this.EG,d);this.la("html5_unrewrite_timestamps")&&(this.Z.timestamp=this.SM);this.g=a;this.ba=null;this.oa=new Bia(b);this.Y=new g.Pq;g.I(this,this.Y);this.H=this.B=this.C=this.l=null;this.o=window.NaN;this.F=0;this.G=null;this.X=window.NaN;this.L=this.J=null;this.R=this.O=!1;this.ga=new g.L(function(){var a={tgt:c.o};c.C&&g.Fa(a,YE(c.C));c.l&&g.Fa(a,
c.l.Zh());(0,window.isFinite)(0<c.o)&&0<c.o&&c.l&&WF(c)&&!c.l.ya()&&(c.l.Ab(c.o-c.A),a.elem="1");c.P("ctmp","seektimeout",Py(a))},1E4);
g.I(this,this.ga);this.T=new g.L(function(){c.O=!0;XF(c)});
g.I(this,this.T);this.A=0;this.ka=!0};
Cia=function(a,b){a.ba=b;a.g.ra&&(a.H=new zia(function(){a:{if(a.ba&&a.ba.xa.g){if(gA(a.g)&&a.C){var b=a.C.sa.g()||0;break a}if(a.g.ma){b=a.g.ma.G;break a}}b=0}return b}),a.B=new PF(a.g,a.da.experiments,function(){return a.Gc(!0)}));
a.g.startSeconds&&(0,window.isFinite)(a.g.startSeconds)&&1E9<a.g.startSeconds||(a.F=a.F||a.g.startSeconds||0)};
$F=function(a,b){g.Rq(a.Y);(a.l=b)?Dia(a):ZF(a)};
bG=function(a,b){a.C&&Tq(a.C,a.Z,a);(a.C=b)?(Sq(b,a.Z,a),aG(a,!0)):ZF(a)};
cG=function(a){return!(0,window.isNaN)(a.o)&&(0,window.isFinite)(a.o)?a.o:a.l&&WF(a)?a.l.ya()+a.A:a.F||0};
dG=function(a,b){if(!a.B)return!1;void 0==b&&(b=cG(a));return TF(a.B,b)};
gG=function(a,b,c,d,e){c=void 0===c?!0:c;d=void 0===d?!1:d;e=void 0===e?0:e;if(b!=a.o||!a.O){a.O&&ZF(a);a.L||(a.L=new xE);b&&!(0,window.isFinite)(b)&&aG(a,!1);var f=b;eG(a)&&!(a.l&&0<a.l.ae()&&0<$A(a.l))||!(0,window.isFinite)(f)&&gA(a.g)||(b=fG(a,b,d));b&&!(0,window.isFinite)(b)&&aG(a,!1);a.la("html5_seek_resumetime_killswitch")||(a.F=b);a.o=b;a.B&&(d=a.B,f=b,UF(d,f,!1),VF(d,f));a.P("seekto",b,c);if(a.L||a.la("html5_seek_removed_el_killswitch"))c?(a.O=!0,XF(a)):e&&a.T.start(e)}};
aG=function(a,b){if(a.B&&a.C){var c=!1;if(b)c=!0;else if(a.g.isLowLatencyLiveStream||"LOW"==a.g.latencyClass||"ULTRALOW"==a.g.latencyClass)if(c=a.B,c.o.length){var d=c.l;b:{if(c.o.length){if(1<Math.min.apply(null,c.o)){var e=OF(c,c.l-1);break b}if(c.g.A){e=OF(c,c.l+1);break b}}e=c.l}c.l=e;if(d=d!=c.l)c.o=[],c.B=0;c=d}else c=!1;c&&a.P("livereadaheadchanged",RF(a.B));c=a.C;d=a.B.l;e=a.B;e=(e.l-1+e.g.g)*QF(e);var f=a.B.g.F;c.Oa=Math.max(d-1,0);c.G&&(c.G.O=e);c.Cb=f}};
hG=function(a){a.L||!(0<a.F)||a.l&&0<a.l.ya()||gG(a,a.F)};
eG=function(a){return a.g.ra&&!!a.g.xa&&!a.g.xa.g};
XF=function(a){Eia(a).then(void 0,function(){ZF(a)});
Fia(a).then(function(b){a.L&&(a.L.resolve(b),a.P("seekend"));ZF(a)},function(){ZF(a)});
a.ga.start();a.P("seekstart")};
Eia=function(a){if(!a.J)if(a.C)if((0,window.isFinite)(a.o))a.J=a.C.seek(a.o-a.A);else{var b=a.C;DE(b);b.G&&kE(b.G,b.g.g);var c=Math.max(xD(b.g.o),xD(b.o.o));ID(b.g,c);ID(b.o,c);var d=b.C,e;for(e in d.g)Hu(d.g[e].index,window.Infinity);b.l.T&&(b.L=!0,b.Ia=!0);b.B=c;b.T=!0;g.In(b.da);b.ga=new xE;a.J=b.ga;a.o=a.C.B+a.A}else a.J=Tf(a.o-a.A);return a.J};
Fia=function(a){a.G||(a.G=new xE,iG(a));return a.G};
fG=function(a,b,c){return(0,window.isNaN)(b)?window.NaN:g.Uc(b,a.zb(),a.Gc(c))};
iG=function(a){if(a.G&&(!a.la("html5_nondash_live_seek_killswitch")&&eG(a)&&a.l&&0<a.l.ae()&&0<$A(a.l)&&(a.o=fG(a,a.o,!1)),a.l&&WF(a)&&!(0,window.isNaN)(a.o)&&(0,window.isFinite)(a.o)&&a.X!=a.o-a.A))if(!a.g.ra&&a.o>=a.Gc()-.1)a.o=a.Gc(),a.G.resolve(a.Gc()),a.P("ended");else try{a.l.Ab(a.o-a.A),a.X=a.o-a.A,a.F=a.o}catch(b){}};
WF=function(a){if(!a.l||0==a.l.ae()||a.oa.g&&0<a.l.Ue())return!1;var b=0<a.l.ya();if(0<=a.o){var c=a.l.Ml();if(c.length||!b)return 0<=Nt(c,a.o-a.A)}return b};
ZF=function(a){a.o=window.NaN;a.X=window.NaN;a.G=null;a.J=null;a.L=null;a.O=!1;a.R=!1;a.ga.stop();a.T.stop()};
Dia=function(a){if(a.l)for(var b=g.q(["loadedmetadata","progress","seeked","seeking"]),c=b.next();!c.done;c=b.next())a.Y.M(a.l,c.value,function(b){switch(b.type){case "seeking":b=a.l.ya()+a.A;if(!a.G||a.R&&b!=a.o)a.G=new xE,gG(a,b,!0),a.R=!0;break;case "seeked":a.G&&a.G.resolve(a.l.ya());break;case "loadedmetadata":b=Gia(a),a.la("html5_nondash_live_seek_killswitch")&&!b&&eG(a)&&(a.o=(0,window.isFinite)(a.o)?g.Uc(a.o,a.zb(),a.Gc()):a.Gc());case "progress":iG(a)}})};
Gia=function(a){if(!a.ka)return!1;if((BA(a.g)||a.g.liveUtcStartSeconds)&&(a.g.liveUtcStartSeconds||a.g.startSeconds&&(0,window.isFinite)(a.g.startSeconds)&&1E9<a.g.startSeconds)&&a.g.ma){var b=a.g.liveUtcStartSeconds||a.g.wf;b=a.Gc()-mx(a.g.ma,a.Gc())+b;gG(a,b);return!0}return a.g.ma&&a.g.ma.l&&a.g.wf&&0!=a.g.wf?(gG(a,a.g.wf+a.A),!0):a.la("html5_unrewrite_timestamps")&&a.g.un?(gG(a,a.g.un),!0):!1};
Hia=function(a){if(!a.l)return 0;if(BA(a.g)){var b=a.l,c=b.Le();b=(0<Pt(c)&&b.ec()?c.end(c.length-1):0)+a.A-a.zb();a=a.Gc()-a.zb();return Math.max(0,Math.min(1,b/a))}return dB(a.l)};
Bia=function(a){this.g=!g.R(a.experiments,"html5_element_ready_error_check_killswitch")};
jG=function(){var a=void 0===a?window.Infinity:a;this.g=0;this.l=a};
kG=function(){var a=qq();return!(!a||"visible"==a)};
mG=function(a){var b=lG();b&&window.document.addEventListener(b,a,!1)};
nG=function(a){var b=lG();b&&window.document.removeEventListener(b,a,!1)};
lG=function(){if(window.document.visibilityState)var a="visibilitychange";else{if(!window.document[pq+"VisibilityState"])return"";a=pq+"visibilitychange"}return a};
oG=function(){g.N.call(this);this.o=0;this.C=this.l=this.g=this.A=!1;this.F=(0,g.z)(this.B,this);mG(this.F);var a=this.isFullscreen();this.G=this.l?4:kG()?3:a?2:this.g?1:this.A?5:this.C?7:0};
pG=function(a,b){a.C!=b&&(a.C=b,a.B())};
qG=function(){g.G.call(this);this.o={};this.g={};this.l=new g.L(this.A,250,this);g.I(this,this.l)};
sG=function(a,b,c,d){a.o[b]=c;a.g[b]=new rG(!!d)};
tG=function(a,b){if(a.g[b]){var c=a.g[b].g;for(var d=[];c.o!=c.g;)c.o=(c.o+1)%c.l.length,d.push(c.l[c.o]);c=d}else c=[];return c};
uG=function(a,b){return a.g[b]?NF(a.g[b].g):0};
rG=function(a){this.o=a;this.g=new MF(100);this.l=window.NaN};
vG=function(){this.g=this.l=!1};
xG=function(a,b,c,d,e,f,k,l){g.N.call(this);var m=this;this.C=a;this.Ia=new hha(this.la("html5_min_has_advanced"));this.R=c;this.ab=d;this.ie=f;this.L=l;this.xh=k;c=(0,g.z)(function(a,b){a!=g.aC("endcr")||g.U(this.o,32)||wG(this);e(a,b)},this);
this.H=new tE((0,g.z)(this.tb,this),(0,g.z)(this.Sv,this),(0,g.z)(this.aE,this),c,a);g.I(this,this.H);this.G=null;this.ob=[];this.T=null;this.sa=new CF(a,this.ab);this.zc=!0;this.J=this.B=null;this.Z=[];this.Y=new vG;this.O=this.nb=null;this.X=new vG;this.yb=null;this.Fd=this.Nc=this.Nf=this.ga=!1;this.Cb=window.NaN;this.o=new g.iB;this.Mb=[];this.Ya=b;this.Ca=new g.Pq;g.I(this,this.Ca);this.g=new g.Xz(a);this.l=null;this.oa=new g.L((0,g.z)(this.HJ,this),15E3);g.I(this,this.oa);this.A=null;this.ed=
this.Ja=!1;this.wa=window.NaN;this.Cc=this.Ta=this.Oa=!1;this.Lc=window.NaN;this.da=new qG;g.I(this,this.da);sG(this.da,"bufferhealth",function(){var a=m.F;return a.l?bB(a.l):0});
sG(this.da,"bandwidth",(0,g.z)(this.qC,this));sG(this.da,"networkactivity",(0,g.z)(this.tC,this),!0);sG(this.da,"livelatency",(0,g.z)(this.Cu,this));sG(this.da,"rawlivelatency",(0,g.z)(this.Eu,this));this.da.start();this.fd=!1;this.Wb=!0;this.cd=window.NaN;this.dd=!1;this.pa=1;this.Va=(0,g.z)(this.fE,this);mG(this.Va);this.L.subscribe("visibilitystatechange",this.Va);this.Of=this.he=this.ge=0;Iia(this);this.ka=null;this.Qd=!1;this.Oc=[];this.Mc=this.xg=0;this.ba=new jG};
yG=function(a){g.zr()?g.Ar(a.wa):g.qp(a.wa)};
JG=function(a,b,c,d){d=void 0===d?!0:d;a.Z.length=0;a.nb=null;a.Y.reset();a.X.reset();a.Ja=!1;a.cd=window.NaN;a.zc=!0;a.l&&a.l.Kc();zG(a);AG(a);BG(a);yG(a);a.da.clear();a.ba.isActive()&&CG(a,0,window.Infinity);g.Xe(a.g);if(2==a.Ya||a.C.Qk)b.rv=!0;var e=a.C.g;var f=a.C.sb,k;(k=b.ir)||(k=(k=b.Wr)&&Mb(DG,k)&&Mb(EG,k)?EG[k]+"_"+DG[k]:void 0);if(k){var l=k.match(FG);if(l&&5==l.length){if(l=k.match(FG)){var m=(0,window.parseInt)(l[3],10),n=[7,8,10,5,6];l=!(1==(0,window.parseInt)(l[1],10)&&8==m)&&0<=n.indexOf(m)}else l=
!1;e=e||f||l?k:null}else e=null}else e=null;e&&(b.adFormat=e);2==a.Ya&&(b.oi=!0);if(a.L.isFullscreen()||a.C.g)e=g.ps("yt-player-autonavstate"),b.autonavState=e||(a.C.g?2:a.g.autonavState);a.Wb=d;a.g=b;a.g.subscribe("dataupdated",a.UL,a);a.g.subscribe("dataloaded",a.ko,a);a.g.subscribe("dataloaderror",a.Gj,a);a.g.subscribe("onStatusFail",a.TL,a);GG(a,b);Jia(a,c);a.Oa=!1;HG(a,"newdata");IG(a,new g.iB);b=a.F;a=a.g;ZF(b);b.g=a;b.B=null;b.H=null;b.A=0;b.F=0;b.ka=!0};
Jia=function(a,b){AG(a);if(!a.g.Ai){var c=new fha(a.g,a.C,b,(0,g.z)(a.Xg,a),(0,g.z)(a.tb,a),(0,g.z)(a.uC,a),(0,g.z)(a.ab.Ha,a.ab),(0,g.z)(a.getAudioTrack,a),(0,g.z)(a.Sv,a),(0,g.z)(a.Ko,a),a.ie,(0,g.z)(a.FC,a),function(){(0,g.VB)("qoes",void 0,"")});
a.A=new JB(c)}};
AG=function(a){if(a.A){var b=a.A;if(!b.ea()&&b.B){b.C="paused";var c=NB(b);c.isFinal=!0;c.send();c=b.l;"PL"==c.o&&(c.o="N");var d=g.SA(c.g);g.wB(c,d,"vps",[c.o]);c.B(d);g.qp(b.A);b.dispose()}g.Xe(a.A);a.A=null}};
KG=function(a){return a.l&&a.l.hg()?a.l.ia():null};
MG=function(a){if(a.g.ld())return!0;g.LG(a,"api.invalidparam",void 0,"invalidVideodata.1");return!1};
PG=function(a,b){a.ga=void 0===b?!1:b;if(!MG(a)||a.Y.l)NG(a)&&a.Y.l&&!a.Y.g&&!a.ga&&a.ko();else{a.Y.start();if(a.A){var c=a.A.l;g.SA(c.g);c.g.videoData.nk&&DB(c,c.g.videoData.nk);c.g.videoData.mh?DB(c,"prefetch"):(c.l.user_intent=["0"],c.G=!0);c.g.videoData.bf&&(yB(c,"reload",c.g.videoData.reloadReason),yB(c,"reloadcount",c.g.videoData.bf.toString()));c.g.videoData.wj&&DB(c,"monitor");c.g.videoData.ra&&DB(c,"live");c.g.videoData.Ee&&yB(c,"ctrl",c.g.videoData.Ee,!0);c.g.videoData.Fe&&yB(c,"ytp",c.g.videoData.Fe,
!0);if(c.g.videoData.dz){var d=c.g.videoData.dz.replace(/,/g,".");yB(c,"ytrexp",d,!0)}c.g.videoData.chapterMarkers.length&&DB(c,"chaptermarkers");if(!g.R(c.g.g.experiments,"html5_disable_gpu_reporting")){var e=c.g.g.experiments;d=c.g.videoData;e=g.R(e,"enable_white_noise")||g.R(e,"enable_webgl_noop")||g.R(e,"enable_gpu_logging");var f=d.Rg()||d.yf()||d.zf()||d.Oe(),k=d.xa&&"1"==g.Ha(d.xa.videoInfos).l&&/^g/.test(d.clientPlaybackNonce);d=/^gp/.test(d.clientPlaybackNonce);(e||f||d||k)&&(d=(0,g.OG)())&&
(c.l.gpu=[d])}c.X=g.pp((0,g.z)(c.B,c),1E4)}a.ko()}};
NG=function(a){return g.R(a.C.experiments,"tvhtml5_disable_live_prefetch")&&g.gy(a.C)&&a.g.ra};
Kia=function(a){g.U(a.o,128)||(a.g.Ob(),a.Wb=!0,4!=a.Ya&&(a.Z=g.Ta(a.g.xc)),vA(a.g)?(QG(a).then(function(){if(!a.ea()&&(a.ga&&RG(a),GG(a,a.g),a.Y.g=!0,HG(a,"dataloaded"),a.X.l?UG(a):a.ga&&IG(a,lB(lB(a.o,512),1)),a.la("html5_log_media_capabilities")&&window.navigator.mediaCapabilities)){var b=JF(a.g.xa);a.Za("mediacapabilities","bestHeight."+VG(a).g+";bestSmoothHeight."+b+";updateConstraint."+(b<VG(a).g))}}),a.Za("loudness",""+a.g.relativeLoudness.toFixed(3),!0),a.g.wf&&a.Za("startSeconds",""+a.g.wf)):
HG(a,"dataloaded"))};
QG=function(a){a.la("html5_updatePlaybackData_loader_fix_killswitch")||BG(a);var b=yia(a.g,a.L.l);a.nb=b;a.nb.then((0,g.z)(a.yK,a),(0,g.z)(a.zK,a));return b};
WG=function(a){a.l&&a.l.gf();PG(a);MG(a)&&!g.U(a.o,128)&&(a.X.l||(a.X.start(),IG(a,lB(lB(a.o,8),1))),UG(a))};
UG=function(a){if(!a.X.g&&a.Y.g&&!g.U(a.o,128)&&!a.Z.length){if(!a.H.C){var b=a.H;b.C=!0;b.l()}if(!XG(a)){a.B&&(b=a.B,a.Nf=!!b.ka&&!!b.wa);a.X.g||(a.X.g=!0);!a.g.ra||0<a.g.wf&&!gA(a.g)||(YG(a,window.Infinity,!0),ZG(a,"readying"),a.L.isBackground()&&(a.ed=!0));if(a.A&&(b=a.A,b.g.videoData.enableCardio&&b.g.videoData.enableCardioBeforePlayback&&(b.G("connected"),RB(b)),b.g.videoData.ra)){b=b.l;var c=b.g.videoData.ma;gA(b.g.videoData)&&DB(b,"manifestless");c&&lx(c)&&DB(b,"live-segment-"+lx(c).toFixed(1))}a.P("playbackready",
a);Oz("pbr","")||((0,g.VB)("pbr",void 0,""),Pz("pbr"))}}};
wG=function(a,b,c){b=void 0===b?!0:b;(void 0===c||c)&&a.l&&a.l.pause();b=b?new g.iB(14):new g.iB;IG(a,b)};
GG=function(a,b){if(b.endSeconds&&b.endSeconds>b.startSeconds){var c=b.endSeconds;a.T&&(a.H.A(a.T),a.T=null);a.T=new g.YB(1E3*c,0x7ffffffffffff);a.T.namespace="endcr";$G(a,a.T)}};
cH=function(a,b,c,d){a.g.ua=c;d&&aH(a,b,d);if(a.A){var e=g.bH(a);d=a.A.l;e=new JA(a.g,c,b,e?g.ot(e):"");c=g.SA(d.g);g.wB(d,c,"vfs",[e.g.id,e.l,d.ka,e.reason]);d.ka=e.g.id;e=d.g.J();if(0<e.width&&0<e.height){e=[Math.round(e.width),Math.round(e.height)];var f=g.oy();1<f&&e.push(f);g.wB(d,c,"view",e)}!d.R&&d.g.videoData.ig&&DB(d,"rqs");d.R=!0;g.wB(d,c,"vps",[d.o]);d.B(c)}a.sa.l=0;a.P("internalvideoformatchange",a.g,"m"==b)};
g.bH=function(a){if(!a.O||!bA(a.g))return null;var b=GF(a.sa,a.O,dH(a),a.L.isBackground());return g.Ja(a.g.xa.videoInfos,(0,g.z)(b.A,b))};
aH=function(a,b,c){if(c!=a.g.Yb){var d=!a.g.Yb;a.g.Yb=c;"m"!=b&&(b=d?"i":"a");if(a.A){var e=a.A.l;c=new JA(a.g,c,b,"");var f=g.SA(e.g);c.g.id!=e.O&&(g.wB(e,f,"afs",[c.g.id,e.O,c.reason]),e.O=c.g.id)}d||a.P("internalaudioformatchange",a.g,"m"==b)}};
g.LG=function(a,b,c,d,e){var f,k;g.Nb(Lia,c)?f=c:c?k=c:f="GENERIC_WITHOUT_LINK";b={errorCode:b,errorDetail:d,message:k||g.eH[f]||"",messageKey:f,subreason:e||""};HG(a,"dataloaderror");IG(a,kB(a.o,128,b));yG(a);BG(a);g.fH(a)};
Mia=function(a,b){a.Z=a.Z.filter(function(a){return b!=a});
a.X.l&&UG(a)};
XG=function(a){var b;(b=!!a.Z.length)||(a=a.H.g.g[0],b=!!a&&-0x8000000000000>=a.start);return b};
CG=function(a,b,c){var d=a.ba;d.g=b;d.l=c;b=a.l&&a.l.ue()?a.l.l:a.l;c=a.J;b&&gH(a,b);c&&hH(a,a.l.bi());hG(a.F)};
iH=function(a){return a.ba.isActive()};
jH=function(a){return iH(a)||!!a.l&&a.l.ue()};
gH=function(a,b){b&&iH(a)&&(b=new g.LF(b,a.ba.g,a.ba.l));if(a.la("html5_new_queueing")&&a.l&&b.ia()==a.l.ia()&&(b.ue()||a.l.ue())){if(b.ue()||!a.l.ue())g.Rq(a.Ca),a.l=b,kH(a),$F(a.F,a.l)}else{a.l&&lH(a);if(!a.o.isError()){var c=mB(a.o,512);g.U(c,8)&&!g.U(c,2)&&(c=lB(c,1));IG(a,c)}a.l=b;a.l.rm(a.dd);a.l.be(a.pa);kH(a);mH(a);$F(a.F,a.l)}};
mH=function(a){if(g.R(a.C.experiments,"html5_prewarm_mse")&&ru()&&$t())try{a.l.Xm()}catch(b){}};
lH=function(a,b){b=void 0===b?!1:b;if(a.l){var c=a.tb();0<c&&(a.F.F=c);$F(a.F,null);nH(a);a.B&&(g.In(a.B.da),BE(a.B,!1));a.oa.stop();if(a.l){!a.X.l||a.o.isError()||g.U(a.o,2)||IG(a,lB(a.o,512));g.Rq(a.Ca);if(b||!iH(a)&&!a.l.ue())a.l.Kc(),zG(a);a.l=null}}};
qH=function(a){if(!g.U(a.o,128))if(a.fd)a.fd=!1,oH(a);else if(WG(a),g.U(a.o,64)&&IG(a,lB(a.o,8)),a.X.g&&a.l)if(a.g.xa)if(a.L.l&&a.g.xa.g)QG(a);else{if(a.g.ra){var b=a.tb()<a.zb()-15;var c=g.AA(a.g)&&g.U(a.o,4);if(b||c)c?(YG(a,window.Infinity,!0),ZG(a,"unpauseLiveOnly")):(YG(a,a.zb(),!0),ZG(a,"outOfWindow"));!pH(a,void 0,!0)&&a.isPeggedToLive()&&(YG(a,window.Infinity,!0),ZG(a,"peggedToLive"));if(b=g.U(a.o,256)&&a.g.Gd)b=a.F,b=b.O&&!(0,window.isFinite)(b.o);if(b){IG(a,nB(a.o,8,4));return}}RG(a)?a.C.Tk?
g.op((0,g.z)(a.Tm,a),0):a.Tm():a.Tm()}else b=a.g.ra&&!g.tu()?"html5.unsupportedlive":a.g.Ec?"fmt.unplayable":"fmt.noneavailable",g.LG(a,b,"HTML5_NO_AVAILABLE_FORMATS_FALLBACK","selectableFormats.1")};
rH=function(a){if(!a.O)return[];var b=HF(a.sa,a.O,dH(a,!0));b=b||Bu;a=(0,g.Bd)(a.O.xa.videoInfos,(0,g.z)(b.A,b));b=[];for(var c={},d=0;d<a.length;d++){var e=a[d].za();c[e.quality]||(b.push(e),c[e.quality]=!0)}return b};
VG=function(a){return a.O?GF(a.sa,a.O,dH(a),a.L.isBackground()):Bu};
dH=function(a,b){if(a.G){var c=a.G;var d=void 0===b?!1:b;d=void 0===d?!1:d;c=!g.R(c.A.experiments,"html5_drm_entitled_qualitycap_on_edge_killswitch")&&d&&c.T?c.T:c.J}else c=bA(a.g)&&a.g.xa.g&&Yw(a.g.ma)?g.R(a.C.experiments,"html5_drm_start_from_null_constraint")?Bu:vF:Bu;return c};
sH=function(a){if(!a.ea()&&!g.U(a.o,128)&&bA(a.g)){var b=VG(a);if(a.g.xa.g){if(a.B){var c=a.B;if(!c.ea()&&!yu(c.F.l,b)&&c.g){ME(c,dE(c.F,b));AE(c);var d=hE(c.F)&&"m"==b.reason&&c.F.L,e=c.l.xh&&"l"==b.reason&&QD(c.g);b="b"==b.reason;d||e||b?c.P("reattachrequired"):(RD(c.g)&&IE(c,c.g,c.o),g.In(c.da))}}}else{c=a.g;a:if(d=a.g.De,b.g){e=g.q(d);for(var f=e.next();!f.done;f=e.next()){f=f.value;var k=f.Me(),l=g.jt[k.za().quality];if((!b.o||"auto"!=k.za().quality)&&l<=b.g){d=f;break a}}d=d[d.length-1]}else d=
d[0];c.Dd=d;cH(a,b.reason,a.g.Dd.Me())}g.pB(a.o)&&(a.F.ka=!1,qH(a))}};
g.tH=function(a){Tfa(a.g.ma,{cpn:a.g.clientPlaybackNonce,c:a.C.l.c,cver:a.C.l.cver});var b=a.C,c=a.g,d=new g.aw;d.ys=g.R(b.experiments,"html5_seek_accuracy_allowance_killswitch");d.Ks=g.R(b.experiments,"html5_unrewrite_timestamps");g.R(b.experiments,"html5_streaming_xhr")&&(d.F=!0);g.R(b.experiments,"html5_streaming_debug")&&(d.F=!0,d.R=!0);g.S(b.experiments,"html5_max_av_sync_drift")&&(d.fv=g.S(b.experiments,"html5_max_av_sync_drift"));var e=b.schedule;e.g.g()==e.policy.o&&(d.nb=10);g.S(b.experiments,
"html5_min_secs_between_format_selections")&&(d.Zy=g.S(b.experiments,"html5_min_secs_between_format_selections"));d.Ta=g.R(b.experiments,"html5_stop_overlapping_requests");d.pa=g.S(b.experiments,"html5_min_readbehind_secs");d.Fx=g.S(b.experiments,"html5_min_readbehind_cap_secs");g.gy(b)&&(d.pa=g.S(b.experiments,"tvhtml5_min_readbehind_secs"));d.he=g.R(b.experiments,"html5_append_init_while_paused");d.Mb=g.S(b.experiments,"html5_max_readahead_bandwidth_cap");d.az=g.R(b.experiments,"html5_disable_audio_append_cap");
d.Ik=g.R(b.experiments,"html5_disable_non_contiguous");d.Mc=g.S(b.experiments,"html5_post_interrupt_readahead");d.Vk=g.R(b.experiments,"html5_log_quota_exceeded");d.J=g.S(b.experiments,"html5_subsegment_readahead_target_buffer_health_secs");d.Ya=g.S(b.experiments,"html5_subsegment_readahead_timeout_secs");d.Fs=g.S(b.experiments,"html5_subsegment_readahead_min_buffer_health_secs");d.Va=g.S(b.experiments,"html5_subsegment_readahead_min_buffer_health_secs_on_timeout");d.Gs=g.S(b.experiments,"html5_subsegment_readahead_min_load_speed");
d.fd=g.S(b.experiments,"html5_subsegment_readahead_load_speed_check_interval");d.Hs=g.S(b.experiments,"html5_subsegment_readahead_seek_latency_fudge");d.Oa=g.R(b.experiments,"html5_streaming_xhr_optimize_lengthless_mp4");d.sa=g.R(b.experiments,"html5_peak_shave");d.Sz=g.R(b.experiments,"html5_peak_shave_always_include_sd");d.ws=g.R(b.experiments,"html5_restrict_streaming_xhr_on_sqless_requests");d.uv=g.S(b.experiments,"html5_max_headm_for_streaming_xhr");d.iA=g.R(b.experiments,"html5_pipeline_manifestless_allow_nonstreaming");
d.yA=g.R(b.experiments,"html5_prefer_server_bwe3");d.Qd=1024*g.S(b.experiments,"html5_video_tbd_min_kb");d.AA=g.R(b.experiments,"html5_probe_live_using_range");d.Bs=g.R(b.experiments,"html5_streaming_xhr_buffer_mdat");d.ed=g.R(b.experiments,"html5_streaming_xhr_no_mp4_holdback_chunk");d.Tk=g.R(b.experiments,"html5_last_slice_transition");d.Jk=g.R(b.experiments,"html5_disable_incomplete_incremental_parse_error");d.As=g.R(b.experiments,"html5_store_xhr_headers_readable");d.Rk=g.S(b.experiments,"html5_incremental_parser_buffer_duration_secs");
d.Sk=g.S(b.experiments,"html5_incremental_parser_buffer_extra_bytes");d.Cs=g.R(b.experiments,"html5_streaming_xhr_progress_includes_latest");d.Pk=g.R(b.experiments,"html5_enable_packet_train_response_rate");if(e=g.S(b.experiments,"html5_probe_secondary_during_timeout_miss_count"))d.cd=e,d.Is=1;d.Ca=g.S(b.experiments,"html5_probe_primary_delay_base_ms")||d.Ca;g.R(b.experiments,"html5_drm_start_from_null_constraint")&&(d.xh=!0);d.Lc=g.R(b.experiments,"html5_no_placeholder_rollbacks");d.Es=g.R(b.experiments,
"html5_subsegment_readahead_enable_mffa");d.wa=g.R(b.experiments,"html5_platform_whitelisted_for_frame_accurate_seeks");d.dd=g.R(b.experiments,"html5_reattach_on_stuck");d.ha=g.R(b.experiments,"html5_manifestless_request_prediction");d.ct=g.R(b.experiments,"html5_webm_init_skipping");d.ge=g.R(b.experiments,"html5_adaptation_fix");d.Ia=g.S(b.experiments,"html5_request_size_padding_secs")||d.Ia;d.Of=g.R(b.experiments,"html5_clamp_with_padding");d.fl=g.R(b.experiments,"html5_log_timestamp_offset");d.Ws=
g.R(b.experiments,"html5_use_media_source_view");d.Cx=g.S(b.experiments,"html5_view_offset");d.X=g.R(b.experiments,"html5_playbackmanager_enable_notify_new_drm_info");d.Nk=g.R(b.experiments,"html5_disable_new_live_flags");d.Ts=g.R(b.experiments,"html5_loader_use_async");d.ab=g.S(b.experiments,"html5_dynamic_readahead_growth_rate")||d.ab;d.Kk=g.R(b.experiments,"html5_disable_incremental_traf_timescale");d.Ok=!g.R(b.experiments,"html5_loader_logging_wrongful_set_current_emsg_killswitch");d.xg=g.R(b.experiments,
"html5_loader_clear_last_slice_appended_when_seek_to_head");d.Xs=g.R(b.experiments,"html5_loader_use_partial_timeline_check_contiguous");d.Nc=g.R(b.experiments,"html5_remove_fpa_sei_mediastream");d.Lk=g.R(b.experiments,"html5_disable_manifestless_sqless_sync");d.uu=!g.R(b.experiments,"html5_manifestless_singleton_headm_killswitch");Sp()&&(d.Oc=!0);Lp()&&(d.o=240);g.jh&&(d.L=41943040);d.Z=!$t();g.gy(b)||!$t()?(d.B=8388608,d.C=524288,d.ie=5,d.ga=2097152,d.O=1048576,d.rs=1.5,d.Fc=15,d.mz=!1,d.G=4587520,
Pp()&&(d.G=786432),d.l*=1.1,d.A*=1.1,d.sc=!0,d.L=d.B,d.ka=d.C):b.o&&(d.l*=1.3,d.A*=1.3);g.Ct&&g.Kp("crkey")&&(e="CHROMECAST/ANCHOVY"==b.l.cmodel,d.B=20971520,d.C=1572864,e&&(d.G=812500,d.H=1E3,d.Ys=5,d.O=2097152));!g.R(b.experiments,"html5_disable_firefox_init_skipping")&&g.hu&&(d.sc=!0);d.zc=!g.R(b.experiments,"disable_fpa_sei_removal")&&g.Kp("windows nt")&&(c.Rg()||c.Oe());if(gA(c)){d.Qk=!0;d.xs=!1;d.Ja=g.R(b.experiments,"html5_shrink_live_timestamps");d.T=d.Ja||g.R(b.experiments,"html5_manifestless_synchronized");
if("ULTRALOW"==c.latencyClass||"LOW"==c.latencyClass&&!g.R(b.experiments,"html5_disable_low_pipeline"))d.yb=2,d.vv=4;d.g=c.hasSubfragmentedFmp4;d.Y=c.defraggedFromSubfragments}c.isAd()&&(d.oa=0,d.ob=0);iA(c)&&(d.R=!0);jA(c)&&(d.R=!0,d.F=!0);d.da=g.R(b.experiments,"html5_enable_subsegment_readahead_v3")||g.R(b.experiments,"html5_ultra_low_latency_subsegment_readahead")&&"ULTRALOW"==c.latencyClass;d.Bl=gA(c);d.ba=c.ig;d.Uk=d.ba&&(/^rq[a-f]/.test(c.clientPlaybackNonce)||g.R(b.experiments,"html5_high_res_logging"));
/^pp/.test(c.clientPlaybackNonce)&&(d.IB=!0,d.os=!0);Up()&&/(K\d{3}|KS\d{3}|KU\d{3})/.test(b.l.cmodel)&&!g.R(b.experiments,"html5_disable_move_pssh_to_moov")&&Yw(c.ma)&&(d.sc=!1);Yw(c.ma)&&(d.dd=!1);if(c.ra){e=lx(c.ma);var f=g.S(b.experiments,"html5_live_abr_head_miss_fraction"),k=g.S(b.experiments,"html5_live_abr_repredict_fraction");f&&e&&(d.Cb=Math.min(e*f,d.Cb));k&&e&&(d.H=Math.min(1E3*e*k,d.H))}f=0;g.R(b.experiments,"html5_live_use_alternate_bandwidth_window_sizes")&&(f=b.schedule.policy.g,c.ra&&
(f=g.S(b.experiments,"ULTRALOW"==c.latencyClass?"html5_live_ultra_low_latency_bandwidth_window":c.isLowLatencyLiveStream?"html5_live_low_latency_bandwidth_window":"html5_live_normal_latency_bandwidth_window")||f));e=b.schedule;e.policy.B=gA(c)?.5:0;if(!e.policy.l&&f&&(e=e.g,f=Math.round(f*e.L),f!=e.o)){k=Array(f);var l=Math.min(f,e.C?e.o:e.A),m=e.A-l;0>m&&(m+=e.o);for(var n=0;n<l;++n)k[n]=e.B[(m+n)%e.o];for(;n<f;++n)k[n]=window.Infinity;e.o=f;e.B=k;e.A=l%f;e.C=l==f;e.G=!0;e.J=wx(e)}d.Cc=g.R(b.experiments,
"html5_disable_new_live_flags")?c.ma.o:c.ra;switch(hA(c)){case 21530001:d.Oa=!0;d.ha=!0;d.da=!0;"LOW"==c.latencyClass?d.J=g.S(b.experiments,"html5_jumbo_mobile_subsegment_readahead_target"):"ULTRALOW"==c.latencyClass&&(d.J=g.S(b.experiments,"html5_jumbo_ull_subsegment_readahead_target"));d.Lc=!0;break;case 2153E4:d.Oa=!0,d.ha=!0,d.da=!1}d.preferLowQualityAudio=c.preferLowQualityAudio;d.zs=c.zj;c.xa&&c.xa.videoInfos&&32<c.xa.videoInfos[0].za().fps&&g.gy(b)&&(d.Nf=!1);c=g.S(b.experiments,"html5_deadzone_multiplier")||
1;(e=g.S(b.experiments,"html5_sticky_reduces_discount_by"))&&"auto"!=sx()&&(c-=e);d.l*=c;d.A*=c;if(c=g.S(b.experiments,"html5_request_sizing_multiplier"))d.ts=c;d.o=g.S(b.experiments,"html5_max_buffer_duration")||d.o;d.Wb=g.S(b.experiments,"html5_min_upgrade_health")||d.Wb;fu(b.T,lu)&&(d.G=window.NaN);d.Fc=g.S(b.experiments,"html5_request_size_max_secs")||d.Fc;d.Mk=g.R(b.experiments,"killswitch_metadata_events");"auto"!=sx()&&(d.Fd=0);d.PA=g.R(b.experiments,"html5_rec_2020_matrix_correction_killswitch");
d.Cc=g.R(b.experiments,"html5_never_pause_appends");a.B=new zE(a.C.schedule,d,a.g.ma,a.g.xa,a.H);a.B.subscribe("initsegment",a.wJ,a);a.B.subscribe("newDrmInfo",a.lK,a);a.B.subscribe("videoformatchange",a.dE,a);a.B.subscribe("audioformatchange",a.JJ,a);a.B.subscribe("error",a.Gj,a);a.B.subscribe("ctmp",a.Za,a);a.B.subscribe("reattachrequired",a.FM,a);a.B.subscribe("metadata",a.ey,a);a.B.subscribe("constraint",a.SL,a);a.B.subscribe("timestamp",a.HD,a);b=g.Ma(a.Z,"spacecast")||a.ga&&!g.R(a.C.experiments,
"html5_preload_media")||a.ga&&NG(a);d=a.getAudioTrack();d=d.ib.isDefault?void 0:d;c=a.la("html5_stop_start_seconds")?a.tb():a.g.startSeconds;a.B.initialize(c,VG(a),b,d);a.g.probeUrl&&(a.B.oa=a.g.probeUrl);(a.Z.length||a.ga)&&BE(a.B,!1);bG(a.F,a.B);a.ob=[]};
Iia=function(a){a.F=new YF(a.g,a.C);a.F.subscribe("seekto",function(b,c){a.la("html5_stop_start_seconds")?a.F.F=b:a.g.startSeconds=b;var d=a.Ia;d.g=b;d.l=!0;c||uH(a);a.T&&b>a.g.endSeconds&&(0,window.isFinite)(b)&&(a.H.A(a.T),a.T=null);b<vH(a)-.01&&IG(a,mB(a.o,2));a.P("seekto",a,b)});
a.F.subscribe("seekstart",function(){return wH(a)});
a.F.subscribe("seekend",function(){return a.P("seekcomplete")});
a.F.subscribe("ended",function(){return wG(a)});
a.F.subscribe("pausemediaelement",function(){return xH(a,!0)});
a.F.subscribe("resumemediaelement",function(){g.U(a.o,8)&&a.Tm()});
a.F.subscribe("ctmp",a.Za,a);a.F.subscribe("livereadaheadchanged",function(b){var c;if(c=a.A)c=a.A.l,g.wB(c,g.SA(c.g),"lra",[b]),yB(c,"live-readahead-seconds",b.toString()),c=void 0;return c})};
BG=function(a){a.B&&(a.B.dispose(),a.B=null,bG(a.F,null));nH(a)};
nH=function(a){a.J&&(a.J.dispose(),a.J=null)};
zH=function(a){if(a.J)return a.J.Fj;a.la("html5_disable_loader_reorder")&&yH(a);Nia(a);return a.J?a.J.Fj:null};
Nia=function(a){if(a.la("html5_application_media_source"))a.P("requestmediasource",a);else{try{var b=a.l.bi()}catch(c){if(AH(a,"html5.missingapi",{updateMs:"1"}))return;g.M(c,"WARNING");c.message="window.URL object overwritten by external code";window.setTimeout(function(){throw c;},0);
g.LG(a,"html5.missingapi","HTML5_NO_AVAILABLE_FORMATS_FALLBACK","updateMs.1")}hH(a,b)}};
hH=function(a,b){iH(a)&&(b=bu(b,a.ba.g,a.ba.l));a.la("html5_disable_loader_reorder")||yH(a);a.J=b;Xea(a.J,function(b){try{if(a.J&&(!b||a.J==b))if(a.Fd)a.Nc=!0;else{var c=a.Xg();!c&&gA(a.g)&&(c=3600);if(!iH(a)&&!a.J.C)a.J.o.duration=c;else if(!a.la("html5_gapless_set_mse_duration_killswitch")){var e=a.ba.g+c;e>a.J.o.duration&&(a.J.o.duration=e)}g.CE(a.B,a.J);a.P("mediasourceattached")}}catch(f){g.M(f,"WARNING"),a.Gj(new g.Oy("fmt.unplayable",!0,{msi:"1",ename:f.name}))}})};
yH=function(a){a.B?a.B.seek(a.tb()):g.tH(a)};
Oia=function(a){return 403==a.details.rc?(a=a.errorCode,"net.badstatus"==a||"manifest.net.retryexhausted"==a):!1};
BH=function(a){return a.Ta||"yt"!=a.C.Z?!1:a.g.Gd?10>a.g.bf:!a.g.bf};
oH=function(a){a.Ta||(a.Ta=!0,a.P("signatureexpired"))};
CH=function(a){return"net.retryexhausted"==a.errorCode||"net.badstatus"==a.errorCode&&!!a.details.fmt_unav};
Pia=function(a,b){if(a.l&&("fmt.unplayable"==b.errorCode||"html5.invalidstate"==b.errorCode)){var c=a.l.Ue();b.details.merr=c?c.toString():"0";b.details.msg=a.l.Jj()}};
AH=function(a,b,c){if(a.cd+3E4>(0,g.D)())return a.la("html5_exile_broken_instances")&&!a.g.Gd&&(a.C.Y+=1,10<a.C.Y)?(c.exiled=""+a.C.Y,a.A.onError("qoe.start15s",Py(c)),a.P("playbackstalledatstart"),!0):!1;a.cd=(0,g.D)();var d=a.g;d=d.Dd?(d.la("inline_hls_expire_killswitch")?+g.up(d.Dd.hi().g).expire:d.Dd.Au())<Date.now()/1E3+1800:!1;a.A&&(c.e=b,a.J&&(c.msopened=""+ +!!a.J.g),d&&(c.staleprog="1"),a.A.onError("qoe.restart",Py(c)));if(d&&BH(a))return oH(a),!0;g.Kp("philips")&&DH(a);a.B?(b=a.B,b.g&&(c=
(c=b.g.B||b.g.l)?c.g:b.g.g,c.J+=1,fE(b.F,c))):a.la("html5_progressive_fallback")&&a.g.Dd&&a.g.Dd.ur();EH(a);return!0};
EH=function(a){BG(a);CG(a,0,window.Infinity);a.P("newelementrequired");g.U(a.o,8)&&qH(a)};
DH=function(a){if("GAME_CONSOLE"!=a.C.l.cplatform)try{window.close()}catch(b){}};
xH=function(a,b){b=void 0===b?!1:b;if((g.U(a.o,64)||g.U(a.o,2))&&!b)if(g.U(a.o,8))IG(a,nB(a.o,4,8));else return;if(a.l||g.R(a.C.experiments,"html5_pause_video_fix"))g.U(a.o,128)||(b?IG(a,lB(a.o,256)):IG(a,nB(a.o,4,8))),a.l&&a.l.pause(),g.AA(a.g)&&a.B&&BE(a.B,!1)};
FH=function(a){xH(a);a.B&&(BE(a.B,!1),DE(a.B))};
g.fH=function(a,b){b=void 0===b?!1:b;a.l&&(a.la("html5_release_mediakey_after_load")?(a.l.Kc(),zG(a),BG(a)):(zG(a),BG(a),a.l.Kc()),mH(a),g.U(a.o,128)||(b?IG(a,nB(a.o,4,8)):IG(a,kB(a.o))),a.C.G.remove(a.g.videoId))};
YG=function(a,b,c,d){b=void 0===b?0:b;c=void 0===c?!1:c;var e=void 0===e?!1:e;g.U(a.o,2)&&RG(a);gG(a.F,b,c,e,d)};
uH=function(a){g.U(a.o,32)||(IG(a,lB(a.o,32)),g.U(a.o,8)&&xH(a,!0),a.P("beginseeking",a));GH(a)};
wH=function(a){g.U(a.o,32)?(IG(a,nB(a.o,16,32)),a.P("endseeking",a)):a.la("html5_sync_seeking_state")&&!g.U(a.o,2)&&IG(a,lB(a.o,16))};
HH=function(a){if(a.g.ma)return mx(a.g.ma,a.tb()-(a.F?a.F.A:0));if((!a.la("html5_disable_limit_ingestion_tvos")||Op())&&a.l&&a.l.Lj()){var b=a.l.Lj().getTime();if(!(0,window.isNaN)(b))return b/1E3+a.tb()}return window.NaN};
IH=function(a,b){var c={};if(void 0===b?0:b){a.A?g.Fa(c,HB(LB(a.A,"playback"))):a.g&&(c.cpn=a.g.clientPlaybackNonce);a.l&&(g.Fa(c,a.l.Zh()),g.Fa(c,a.Ko()));a.B&&g.Fa(c,YE(a.B));if(a.G){var d=a.G,e=d.g;e={systemInfo:{flavor:e.flavor,keySystem:e.g},sessions:[]};d=g.q(d.l.values);for(var f=d.next();!f.done;f=d.next()){f=f.value;var k={requestedKeyIds:f.da,cryptoPeriodIndex:f.cryptoPeriodIndex};f.B&&(k.keyStatuses=f.g);e.sessions.push(k)}c.drm=e}c.state=a.o.g.toString(16);g.U(a.o,128)&&(c.debug_error=
a.o.l);XG(a)&&(c.prerolls=a.Z.join(","));a.g.Qe&&(c.ismb=a.g.Qe);"UNKNOWN"!=a.g.latencyClass&&(c.latency_class=a.g.latencyClass);a.g.isLowLatencyLiveStream&&(c.lowlatency="1");a.g.ra&&(a.g.ma&&lx(a.g.ma)&&(c.segduration=lx(a.g.ma)),e=a.F,c.lat=e.H?NF(e.H.A):0);c.relative_loudness=a.g.relativeLoudness.toFixed(3);if(e=g.bH(a))c.optimal_format=e.video.qualityLabel;c.user_qual=sx()}c.debug_videoId=a.g.videoId;return c};
$G=function(a,b){var c=a.H,d=[b];c.l();sE(c.g,d);c.B=window.NaN;c.l()};
HG=function(a,b){a.P("internalvideodatachange",void 0===b?"dataupdated":b,a,a.g)};
kH=function(a){(0,g.C)("loadstart loadeddata loadedmetadata play playing progress pause ended suspend seeking seeked timeupdate durationchange ratechange error waiting resize".split(" "),function(a){this.Ca.M(this.l,a,this.eE,this)},a);
a.C.Qd&&a.l.hg()&&(a.Ca.M(a.l,"webkitplaybacktargetavailabilitychanged",a.mI,a),a.Ca.M(a.l,"webkitcurrentplaybacktargetiswirelesschanged",a.nI,a))};
KH=function(a){window.clearInterval(a.Cb);a.oa.stop();a.g.Gd=!0;a.C.Gd=!0;a.C.Y=0;JH(a);g.U(a.o,8)&&IG(a,mB(a.o,65));if(a.A){var b=a.A;if(!b.B){g.R(b.g.g.experiments,"disable_embedpage_playback_logging")||16623!=b.g.videoData.rootVeType||g.kp(Error("Playback for EmbedPage"));var c=LB(b,"playback");b.J=[10+b.g.videoData.Oh,10,10,40+b.g.videoData.Dj-b.g.videoData.Oh,40];var d=b.o;window.clearInterval(d.F);d.F=window.NaN;d.F=g.pp((0,g.z)(d.update,d),100);d.C=g.SA(d.l);d.A=LA(d.l);c.l=KB(b,!0);c.send();
b.g.videoData.lk&&(c=b.g.g,d=b.g.videoData,d={html5:"1",video_id:d.videoId,cpn:d.clientPlaybackNonce,plid:d.playbackId,ei:d.eventId,ptk:d.lk,oid:d.dr,ptchn:d.ar,pltype:d.fr,content_v:EA(d)},c=g.Ig(c.baseYtUrl+"ptracking",d),OB(b,c));b.g.videoData.enableCardio&&(b.G("playback"),b.A||RB(b));b.g.videoData.ne||QB(b);b.B=!0;b=b.o;b.g=b.l.l();b.C=g.SA(b.l);!(0==b.o&&5>b.g)&&2<b.g-b.o&&(b.o=b.g);b.H=!0}g.op((0,g.z)(a.vr,a),4500)}a.P("playbackstarted");g.zr()&&((a=g.y("yt.scheduler.instance.clearPriorityThreshold"))?
a():Br(0))};
JH=function(a){var b=a.tb(),c=a.g;!Oz("pbs","")&&Kz.measure&&Kz.getEntriesByName&&(Kz.getEntriesByName("mark_nr")[0]?Nz("mark_nr"):Nz());c.videoId&&a.R.info("docid",c.videoId);c.eventId&&a.R.info("ei",c.eventId);c.clientPlaybackNonce&&a.R.info("cpn",c.clientPlaybackNonce);0<c.startSeconds&&a.R.info("start",c.startSeconds.toString());a.l&&a.l.ah()&&a.R.info("paused",1);c.ua?a.R.info("fmt",g.ot(c.ua)):a.R.info("fmt","-1");c.mh&&a.R.info("yt_pre",a.Nf?"2":"1");a.L.isFullscreen()&&a.R.info("yt_fs","1");
a.R.info("cmt",b.toFixed(3));if(a.B){a=a.B;window&&window.performance&&window.performance.getEntriesByName&&(b=window.performance.getEntriesByName(a.wa),b.length&&(b=b[0],a.yc("vri",b.fetchStart),a.yc("vdns",b.domainLookupEnd),a.yc("vreq",b.requestStart),a.yc("fvb",b.responseStart),a.yc("vrc",b.responseEnd)),b=window.performance.getEntriesByName(a.ka),b.length&&(b=b[0],a.yc("ari",b.fetchStart),a.yc("adns",b.domainLookupEnd),a.yc("areq",b.requestStart),a.yc("avb",b.responseStart),a.yc("arc",b.responseEnd)));
a=a.Wb;for(var d in a)(0,g.VB)(d,a[d],"")}};
GH=function(a,b){b=void 0===b?!1:b;if(a.l&&a.g){var c=a.F,d=g.pB(a.o),e=cG(c),f=dG(c,e);if(c.H&&f){var k=c.H;if(k.g&&!(e>=k.l&&e<k.o)){var l=k.g.sf(e);-1!=l&&(k.l=k.g.od(l),k.o=k.l+k.g.Df(l),l=(0,g.D)()/1E3-k.g.bq(l),l-=k.B(),k.A.add(l))}}c.B&&(f&&(f=c.B,k=c.l?bB(c.l):0,f.B++,3>f.B||(0,g.D)()-f.G<f.g.H||(f.G=(0,g.D)(),f.o.push(k),50<f.o.length&&f.o.shift())),f=c.B,UF(f,e,void 0===d?!0:d),VF(f,e),d&&(d=c.B,!TF(d,e)&&d.isPeggedToLive()?(d.g.C&&(d.g.g=Math.max(d.g.g+1,10)),e=window.Infinity):e=e<d.A.zb()?
Math.min(d.A.zb()+10,SF(d)):window.NaN,(0,window.isNaN)(e)||gG(c,e,!0)));c=a.tb();!a.B||g.U(a.o,4)&&g.AA(a.g)||(e=a.B,d=c,e.A&&(d-=!(0,window.isNaN)(e.R)&&e.l.Ks?e.R:0,e.B!=d&&e.resume(),e.T&&!Yt(e.A)&&(f=e.B<=d&&d<e.B+10,k=0<=Nt(e.A.l.Nb(),e.B+KE),f&&k&&(e.T=!1)),e.T||(e.B=d),g.In(e.pa)));5<c&&(a.F.F=c);(e=g.zr())?g.Ar(a.wa):g.qp(a.wa);!g.sB(a.o)&&a.l.ah()||g.U(a.o,128)||(d=(0,g.z)(a.QC,a),0==a.l.hj().length?a.wa=e?g.xr(d,100):g.op(d,100):a.wa=e?g.xr(d,500):g.op(d,500));a.g.Wf=c;if(!b&&g.pB(a.o)&&
(a.A&&(c=a.A,c.o.update(),c.g.videoData.Ob()&&c.g.videoData.ne&&!c.T&&OA(c.o)>=c.g.videoData.ne&&(c.B&&c.g.videoData.ne&&(e=LB(c,"delayplay"),e.sc=!0,e.send(),c.T=!0),QB(c)),a.g.ra&&(0,g.D)()>a.Of+6283&&(!pH(a)||a.g.ma&&jx(a.g.ma)||(c=a.A.l,d=c.g.B(),e=g.SA(c.g),zB(c,e,d),d=d.C,(0,window.isNaN)(d)||g.wB(c,e,"e2el",[d.toFixed(3)])),!a.la("html5_report_raw_latency_killswitch")&&g.py(a.C)&&a.Za("rawlat","l."+uG(a.da,"rawlivelatency").toFixed(3)),a.Of=(0,g.D)())),a.g.ua&&ut(a.g.ua)&&(c=KG(a))&&c.videoHeight!=
a.Mc&&(a.Mc=c.videoHeight,a.la("html5_log_hls_video_height_change_as_format_change")&&a.g.Dd&&"auto"==a.g.Dd.nf.za().quality&&a.g.De)))for(c=g.q(a.g.De),e=c.next();!e.done;e=c.next())if(e=e.value,e.getHeight()==a.Mc&&"auto"!=e.nf.za().quality){cH(a,"a",e.Me());break}a.P("progresssync",a,b)}};
IG=function(a,b){if(!g.oB(a.o,b)){var c=new g.uB(b,a.o);a.o=b;var d=!a.Mb.length;a.Mb.push(c);var e=a.l&&a.l.dm();if(0<g.vB(c,1)&&!g.U(c.g,16)&&!e&&g.U(a.o,8)&&!g.U(a.o,64)&&a.B&&(a.B.Z=!0,LH(a),a.l&&5<=bB(a.l))){e=a.sa;var f=a.O;6E4<(0,g.D)()-e.o&&(e.l=0);e.l++;e.o=(0,g.D)();f=f.videoData.ua;var k=f.za().g;if(4!=e.l)e=!1;else{var l=e.g.o?240:360;"1"==f.l&&(l=0);if(k>l){f=f.l;--k;if(!e.la("html5_save_perf_cap_killswitch")){l=k;var m=g.ps("yt-player-performance-cap")||{};0<+m[f]&&(l=Math.min(+m[f],
l));m[f]=l;g.os("yt-player-performance-cap",m,604800)}e.g.Fd=new xu(0,k,!1,"b");e=!0}else e=!1}e&&(a.g.ua&&"1"==a.g.ua.l?QG(a):sH(a))}(0>g.vB(c,8)||0<g.vB(c,1024))&&a.oa.stop();!(0<g.vB(c,8))||a.g.Gd||g.U(c.state,1024)||a.oa.start();g.U(c.state,8)&&0>g.vB(c,16)&&!g.U(c.state,32)&&!g.U(c.state,2)&&qH(a);g.U(c.state,2)&&BA(a.g)&&(e=a.tb(),a.g.lengthSeconds!=e&&(a.g.lengthSeconds=e,HG(a)),GH(a,!0));0<g.vB(c,2)&&(a.vr(),LH(a));a.g.ma&&a.g.ra&&(0>g.vB(c,8)?(e=a.g.ma,e.A&&e.A.stop()):0<g.vB(c,8)&&a.g.ma.resume());
if(a.A&&(e=a.A,!e.ea())){g.U(c.state,2)?(e.C="paused",0<g.vB(c,2)&&e.B&&NB(e).send()):g.U(c.state,8)?(e.C="playing",e.B&&(0,window.isNaN)(e.F)&&KB(e,!1)):e.C="paused";f=e.l;k=c.state;l=g.SA(f.g);m=jha(f,c.state);if(m!=f.o){if(!(l<f.A)){if("PL"==f.o)f.L+=l-f.A;else if("B"==f.o&&f.H){f.H=!1;var n=g.S(f.g.g.experiments,"html5_disable_last_state_change")?f.A:f.Y;f.T+=l-n;!f.Z&&10<=f.T&&180>=f.L&&(f.g.G(),f.l.qoealert=["1"],f.Z=!0)}"B"!=m||"PL"!=f.o&&"PB"!=f.o||(f.H=!0);f.A=l}"B"==m&&"PL"==f.o||f.g.videoData.ig?
AB(f,l):g.wB(f,l,"cmt",[f.g.l().toFixed(3)]);g.wB(f,l,"vps",[m]);f.o=m;f.Y=l;f.A=l}m=k.l;g.U(k,128)&&m&&CB(f,l,m.errorCode,m.errorDetail);(g.U(k,2)||g.U(k,128))&&f.B(l);g.U(k,8)&&f.g.videoData.mh&&!f.G&&(f.l.user_intent=[g.SA(f.g).toString()],f.G=!0);BB(f);e.A&&g.U(c.state,128)&&(e.G("error-100"),g.qp(e.A))}if(d&&!a.ea())try{for(var p=g.q(a.Mb),u=p.next();!u.done;u=p.next()){var x=u.value,B=a.H;c=x;if(B.C&&(B.l(),g.U(c.g,16))){c=B;var F=rE(c.g,Math.max(c.B-2E3,0));!(0,window.isNaN)(F)&&0x7ffffffffffff>
F&&c.F.start()}a.P("statechange",x)}}finally{a.Mb.length=0}}};
MH=function(a,b){g.U(a.o,128)||(IG(a,nB(a.o,1028,9)),a.Za("dompaused",b),a.P("onDompaused"))};
RG=function(a){if(!a.l||!a.g.xa)return!1;var b=null;a.g.xa.g?(b=zH(a),a.B.resume()):(BG(a),a.g.Dd&&(b=a.g.Dd.hi()));var c=a.l.qm(),d=!1;c&&null!=b&&b.g==c.g||((0,g.VB)("vta",void 0,""),Pz("vta"),0<a.tb()&&(c=a.tb(),a.F.F=c),a.l.gf(b),a.J&&Br(4),!a.g.Gd&&g.qB(a.o)&&a.oa.start(),d=!0);g.U(a.o,2)||hG(a.F);Qia(a,d);return d};
Qia=function(a,b){if(g.qA(a.g)&&a.l){var c=a.g.Re;if(c&&a.l.hg()){var d=a.l.ia();if(a.G){if(a.la("html5_drm_check_element_killswitch")||d==a.G.ia())if(!a.la("html5_keep_safari_drm_killswitch")&&!b||"fairplay"!=c.flavor||Op())return;zG(a)}a.G=new wF(d,a.g,a.C,"widevine"==c.flavor&&!a.g.ra&&!a.g.sj);a.G.subscribe("licenseerror",a.AJ,a);a.G.subscribe("qualitychange",a.CJ,a);a.G.subscribe("heartbeatparams",a.bE,a);a.G.subscribe("keystatuseschange",a.cE,a);a.G.subscribe("hdproberequired",a.BJ,a);a.G.subscribe("ctmp",
a.Za,a);(0,g.C)(a.ob,function(b){xF(a.G,new $E(b.info,b.type))});
a.ob=[]}else g.LG(a,"fmt.unplayable","HTML5_NO_AVAILABLE_FORMATS_FALLBACK","drm.1")}};
zG=function(a){a.G&&(a.G.dispose(),a.G=null)};
NH=function(a,b){b=void 0===b?!1:b;return a.g.ra&&(pH(a)||a.isPeggedToLive()||g.AA(a.g))?a.tb():vH(a,b)};
vH=function(a,b){return a.F.Gc(void 0===b?!1:b)};
OH=function(a,b){a.pa=b;a.l&&a.l.be(b)};
pH=function(a,b,c){return a.g.ra&&(a.zc||(void 0===c?0:c))?dG(a.F,b):!1};
g.PH=function(a,b){(a.zc=b)||a.oa.stop();if(a.g.ma)if(b)a.g.ma.resume();else{var c=a.g.ma;c.A&&c.A.stop()}g.R(a.C.experiments,"html5_suspend_loader")&&a.B&&(b?a.B.resume():BE(a.B,!0));g.R(a.C.experiments,"html5_fludd_suspend")&&(g.U(a.o,2)||b?g.U(a.o,512)&&b&&IG(a,mB(a.o,512)):IG(a,lB(a.o,512)));a.A&&(c=a.A.l,g.wB(c,g.SA(c.g),"stream",[b?"A":"I"]))};
g.QH=function(a){return a.l?a.l.nm():a.dd};
RH=function(a,b){g.R(a.C.experiments,"html5_log_rebuffer_reason")&&a.Za("bufreason","r."+b+";lact."+Gr())};
SH=function(a,b){if(a.g.ig){var c=g.S(a.C.experiments,"html5_log_rebuffer_events");if(c&&a.A&&a.l){var d=a.l.Zh();d.rt=g.SA(a.A.g).toFixed(3);d.e=b.substr(0,3);a.Oc[a.xg++%c]=Py(d)}}};
LH=function(a){if(a.g.ig){for(var b=g.q(a.Oc),c=b.next();!c.done;c=b.next())a.Za("vpe",c.value);a.Oc=[];a.xg=0}};
ZG=function(a,b){a.Za("seekreason",b)};
g.TH=function(a,b){SB.call(this,a,b);this.G=null};
g.UH=function(a){return a.app.C};
g.VH=function(a){a=g.UH(a).J;return!!a&&a.Wv()};
g.WH=function(a,b){3==a.Da()?a.P("mdxautoplaycancel"):a.P("autonavcancel",b)};
g.V=function(a){return a.app.g};
g.YH=function(a,b){return XH(a.app,b||a.playerType)};
g.ZH=function(a){return a.app.G};
g.aI=function(a){var b=g.$H(g.UH(a));return a.app.X&&!a.isFullscreen()||3==a.Da()&&b&&b.hasNext()&&b.Pe()||!!a.Ve()};
g.bI=function(a,b){var c=a.playerType;(c=g.W(a.app,void 0===c?1:c))&&wG(c,b)};
g.cI=function(a){var b={};a=rH(g.W(a.app));a=g.q(a);for(var c=a.next();!c.done;c=a.next())c=c.value,b[c.quality]=c;return b};
g.dI=function(a){return(a=g.UH(a).B)?a.CE():{}};
g.eI=function(a,b,c,d){var e=g.W(a.app);c.event=b;a.isFullscreen()&&(c.fs=1);c.ux=1;e.logEvent(c,d)};
g.fI=function(a){a=g.UH(a).o;return!!a&&a.Hj()};
g.gI=function(a){a=g.UH(a).o;return!!a&&a.Vv()};
g.hI=function(a,b){var c=g.bt(a);if(c)return c.hq(b);c=a.app.G.Ha();return new g.Tg(0,0,c.width,c.height)};
g.iI=function(a){a=g.UH(a).L;return!!a&&a.uE()};
g.kI=function(a,b,c){jI(a.app,b,c||a.playerType)};
g.nI=function(a,b,c){var d=a.app;a=c||a.playerType;if(c=g.W(d,a))c.H.A.apply(c.H,b),a&&lI(d)!=a||mI(d,"cuerangesremoved",b)};
g.oI=function(a,b,c){var d=a.app;a=c||a.playerType;if(c=g.W(d,a))b=Vha(c.H,b),a&&lI(d)!=a||mI(d,"cuerangesremoved",b)};
g.pI=function(a,b,c){c=void 0===c?a.playerType:c;(a=g.W(a.app,c))&&Mia(a,b)};
g.qI=function(a){a=(a=a.getVideoData())&&a.ua;return!!a&&!(!a.audio||!a.video)&&"application/x-mpegURL"!=a.mimeType};
g.rI=function(a){a=a.getVideoData();return!!a&&!!(a.adaptiveFormats||a.hlsFormats||a.Ud)};
g.sI=function(a,b,c){a=g.ZH(a).element;var d=$a(a.children,function(a){a=(0,window.parseInt)(a.getAttribute("data-layer"),10);return c-a||1});
0>d&&(d=-(d+1));zd(a,b,d);b.setAttribute("data-layer",c)};
g.tI=function(a){return(a=g.W(a.app,void 0))?a.F?a.F.A:0:0};
g.uI=function(a){var b=g.V(a);if(!b.Ja)return!1;var c=a.getVideoData();if(!c||3==a.Da())return!1;var d=!c.isLiveDefaultBroadcast||g.R(b.experiments,"allow_poltergust_autoplay");b=c.ra&&(!g.R(b.experiments,"allow_live_autoplay")||!d);return!c.ypcPreview&&!b&&!g.Ma(c.xc,"ypc")&&!a.Ve()};
g.vI=function(a,b){g.V(a).C&&a.app.L.click(b)};
g.xI=function(a,b,c){if(g.V(a).C){a=a.app.L;var d=b.getAttribute("data-visual-id");g.Ma(a.g,b);c?(g.Oa(a.o,d),g.Oa(a.A,b)):(g.Qa(a.o,d),g.Qa(a.A,b));c&&!g.Ma(a.C,d)&&(a.l?(c=g.js())&&b.visualElement&&g.Tr(c,b.visualElement):g.wI(a,"onLogVesShown",{ids:[d]}),g.Oa(a.C,d))}};
yI=function(a,b){return g.V(a).C?g.Ma(a.app.L.g,b):!1};
g.BI=function(a,b){if(lI(a.app)==b){var c=a.app,d=g.W(c,b);d&&(d!=c.A?zI(c,c.A):AI(c))}};
Ria=function(a,b,c,d){CI(a.app,b,c,void 0===d?0:d)};
DI=function(a){return a.isTimeout?"NO_BID":"ERR_BID"};
Sia=function(){var a=null;kq().then(function(b){return a=b},function(b){return a=DI(b)});
return a};
Tia=function(){var a=lg(1E3,"NO_BID");return $f(g.bg(Xf([kq(),a]),DI),function(){return a.cancel()})};
EI=function(a){this.g=a;this.o=g.S(g.V(a).experiments,"bulleit_get_midroll_info_timeout_ms")||8E3;this.A=this.l=1};
FI=function(a,b,c,d){c=void 0===c?{}:c;var e=c.WB,f=c.hd,k=void 0===c.Vz?0:c.Vz;d=void 0===d?"":d;c=a.g.getVideoData(1);var l={AD_BLOCK:a.l++,AD_BREAK_LENGTH:e?e.durationSecs:0,AUTONAV_STATE:g.V(a.g).Ja?aga()?3:2:1,CA_TYPE:"image",CPN:c.clientPlaybackNonce,LACT:Gr(),LIVE_INDEX:e?a.A++:1,LIVE_TARGETING_CONTEXT:e&&e.context?e.context:"",MIDROLL_POS:f?Math.round(f.start/1E3):0,MIDROLL_POS_MS:f?Math.round(f.start):0,VIS:a.g.Cf(),TSLA:k,P_H:g.ZH(a.g).Ha().height,P_W:g.ZH(a.g).Ha().width},m=ip();Object.keys(m).forEach(function(a){null!=
m[a]&&(l[a.toUpperCase()]=m[a].toString())});
""!==d&&(l.BISCOTTI_ID=d);d={abv:"45"};(e=g.V(a.g).forcedExperiments)&&Ap(b)&&(d.forced_experiments=e);b=g.xp(g.Lm(b,l),d);d=b.split("?");if(2!=d.length)return Uf(Error("Invalid AdBreakInfo URL"));e=g.q(d);d=e.next().value;f=e.next().value;e={};c.oauthToken&&zp()&&(e.Authorization="Bearer "+c.oauthToken);if(f=(c=g.sp(f))&&c.post_data)k=g.sp(c.post_data),Object.assign(c,k),delete c.post_data;return f?Zp(d,{lu:!0,format:"RAW",headers:e,method:"POST",qb:c,timeout:a.o,withCredentials:!0}):Zp(b,{lu:!0,
format:"RAW",headers:e,method:"GET",timeout:a.o,withCredentials:!0})};
g.GI=function(a){g.N.call(this);this.player=a;this.loaded=!1};
HI=function(a,b,c){this.A=a;this.g=null;this.o=b;this.l=0;this.livestream=void 0===c?!1:c;this.visible=!0};
II=function(a,b,c,d){g.YB.call(this,b.start,b.end,{id:d,namespace:"ad",priority:2,visible:c});this.o=a.kind||"AD_PLACEMENT_KIND_UNKNOWN";this.l=!1;this.A=null};
JI=function(a){return"AD_PLACEMENT_KIND_START"==a.o};
KI=function(a){return"AD_PLACEMENT_KIND_MILLISECONDS"==a.o};
LI=function(a){return a.end-a.start};
MI=function(a,b,c){c=void 0===c?!1:c;switch(a.kind){case "AD_PLACEMENT_KIND_START":return new g.Ai(-0x8000000000000,-0x8000000000000);case "AD_PLACEMENT_KIND_END":return c?new g.Ai(Math.max(0,b.A-b.l),0x7ffffffffffff):new g.Ai(0x7ffffffffffff,0x8000000000000);case "AD_PLACEMENT_KIND_MILLISECONDS":var d=a.adTimeOffset;a=(0,window.parseInt)(d.offsetStartMilliseconds,10);d=(0,window.parseInt)(d.offsetEndMilliseconds,10);-1===d&&(d=b.A);if(c&&(d=a,a=Math.max(0,a-b.l),a==d))break;return new g.Ai(a,d);
case "AD_PLACEMENT_KIND_CUE_POINT_TRIGGERED":return a=b.g,d=1E3*a.g,c?d<b.o?new g.Ai(d-4E3,d):new g.Ai(Math.floor(b.o+Math.random()*Math.max(0,d-b.o-1E4)),d):new g.Ai(d,d+(0<a.durationSecs?1E3*a.durationSecs:5E3))}return null};
NI=function(a,b,c){b=void 0===b?null:b;c=void 0===c?{}:c;this.id=X(a);this.componentType=a;this.macros=c;this.renderer=b};
X=function(a){return a+g.Mn(g.Ln.getInstance())};
OI=function(a,b,c){this.id=c;this.content=a;this.actionType=b};
PI=function(a){this.o=a};
QI=function(a){this.o=a};
RI=function(a,b){this.g=a;this.Y=b||{};this.G=String(Math.floor(1E9*Math.random()));this.F={};this.L=0};
Uia=function(a){this.o=a;this.l={};this.g=Oh()?500:g.gy(g.V(a))?1E3:2500};
Wia=function(a,b){if(!b.length)return null;var c=b.filter(function(b){if(!b.mimeType)return!1;b.mimeType in a.l||(a.l[b.mimeType]=a.o.Ij(b.mimeType));return a.l[b.mimeType]?!!b.mimeType&&"application/x-mpegurl"==b.mimeType.toLowerCase()||!!b.mimeType&&"application/dash+xml"==b.mimeType.toLowerCase()||"PROGRESSIVE"==b.delivery:!1});
return Via(a,c)};
Via=function(a,b){for(var c=null,d=g.q(b),e=d.next();!e.done;e=d.next()){e=e.value;var f=e.minBitrate,k=e.maxBitrate;f>a.g||k<a.g||c&&!(f<c.minBitrate)||(c=e)}if(!c)for(c=null,d=g.q(b),e=d.next();!e.done;e=d.next())e=e.value,f=e.maxBitrate,k=e.minBitrate,f>a.g||(!c||f>c.maxBitrate?c=e:c&&f==c.maxBitrate&&k<c.minBitrate&&(c=e));if(!c)for(c=null,d=g.q(b),e=d.next();!e.done;e=d.next())e=e.value,f=e.minBitrate,k=e.maxBitrate,f<a.g||(!c||f<c.minBitrate?c=e:c&&f==c.minBitrate&&k>c.maxBitrate&&(c=e));return c};
SI=function(a,b){this.g=a;this.l=b.length;this.adBreakLengthSeconds=b.reduce(function(a,b){return a+b},0);
for(var c=0,d=a+1;d<b.length;d++)c+=b[d];this.adBreakRemainingLengthSeconds=c};
TI=function(a,b){var c;if(c=a.pings){var d={};d.impression=c.impressionPings||[];d.error=c.errorPings||[];d.mute=c.mutePings||[];d.unmute=c.unmutePings||[];d.pause=c.pausePings||[];d.rewind=c.rewindPings||[];d.resume=c.resumePings||[];d.skip=c.skipPings||[];d.close=c.closePings||[];d.progress=c.progressPings||[];d.clickthrough=c.clickthroughPings||[];d.fullscreen=c.fullscreenPings||[];d.active_view_viewable=c.activeViewViewablePings||[];d.active_view_measurable=c.activeViewMeasurablePings||[];d.active_view_fully_viewable_audible_half_duration=
c.activeViewFullyViewableAudibleHalfDurationPings||[];d.end_fullscreen=c.endFullscreenPings||[];d.channel_clickthrough=c.channelClickthroughPings||[];d.abandon=c.abandonPings||[];d.start=c.startPings||[];d.first_quartile=c.firstQuartilePings||[];d.midpoint=c.secondQuartilePings||[];d.third_quartile=c.thirdQuartilePings||[];d.complete=c.completePings||[];c=d}else c={};RI.call(this,a,c);this.A=new SI(0,[]);this.C=this.R=null;this.X=b;this.T=[];this.o={};this.Z=null;this.l=0;this.H=this.J=this.B=null;
c=this.g.skipOffsetMilliseconds||0;0<c&&(this.Z=c);this.o=g.sp(this.g.playerVars||"");if(c=this.g.external)this.T=c.mediaFiles||[],c=c.durationMilliseconds,g.ta(c)&&(this.l=c/1E3,this.o.length_seconds=this.l.toString()),(c=Wia(this.X,this.T))?(this.J=c.uri,c=c.mimeType,this.o.url_encoded_third_party_media="url="+(0,window.encodeURIComponent)(this.J)+"&type="+(0,window.encodeURIComponent)(c)):this.H=Error("Nonplayable third party ad media file.");else if(this.B=this.o.video_id,this.R=this.o.ucid||
null,this.l=Ix(this.l,this.o.length_seconds),this.o.cta_conversion_urls)try{this.o.cta_conversion_urls=JSON.parse(this.o.cta_conversion_urls)}catch(e){g.M(e)}this.C=this.g.clickthroughEndpoint||null;this.A=new SI(0,[this.l])};
UI=function(a){var b=a.o||{};1<a.A.l&&(b.slot_pos=a.A.g);b.autoplay="1";return b};
VI=function(a){return 0<a.l&&7.05>=a.l};
WI=function(a){RI.apply(this,arguments)};
XI=function(a){RI.apply(this,arguments)};
YI=function(){this.g=[];this.l=null;this.A=!0;this.o=0};
ZI=function(a,b){b&&a.g.push(b)};
$I=function(a){var b=a.impressionUrls,c={};b&&(c.impression=b);RI.call(this,a,c)};
Xia=function(){this.url=null;this.height=this.width=0;this.adInfoRenderer=this.impressionTrackingUrls=this.clickTrackingUrls=null};
aJ=function(){this.contentVideoId=null;this.macros={};this.imageCompanionAdRenderer=this.iframeCompanionRenderer=null};
bJ=function(a){RI.apply(this,arguments)};
cJ=function(a,b,c){g.P.call(this,a);this.o=b;this.A=c;this.B=Yia(this)};
Yia=function(a){var b=a.o;if(b){a=function(a){return{toString:function(){return a()}}};
var c={};c.AD_MT=a(function(){return Math.round(Math.max(0,1E3*b.ya(2))).toString()});
c.MT=a(function(){return Math.round(Math.max(0,1E3*b.ya(1))).toString()});
c.P_H=a(function(){return b.eh().height.toString()});
c.PV_H=c.P_H;c.P_W=a(function(){return b.eh().width.toString()});
c.PV_W=c.P_W;c.CONN="0";c.WT=a(function(){return(0,g.D)().toString()});
c.LACT=a(function(){return Gr().toString()});
c.VIS=a(function(){return b.Cf().toString()});
c.VOL=a(function(){return b.Jb().toString()});
return c}return{}};
dJ=function(a){g.G.call(this);this.G=a};
eJ=function(a){dJ.call(this,!0);this.g=a};
fJ=function(a,b){function c(a){return{toString:a}}
var d={},e=a.getVideoData();d.CPN=c(function(){return e&&e.clientPlaybackNonce||null});
d.ASR=c(function(){return e&&e.adSafetyReason||null});
d.EI=c(function(){return e&&e.eventId||null});
d.AD_CPN=c(function(){return b.X});
d.AD_MT=c(function(){return Math.round(Math.max(0,1E3*a.ya(2))).toString()});
d.MT=c(function(){return Math.round(Math.max(0,1E3*a.ya(1))).toString()});
d.P_H=c(function(){return a.eh().height.toString()});
d.PV_H=d.P_H;d.P_W=c(function(){return a.eh().width.toString()});
d.PV_W=d.P_W;d.CONN="0";d.WT=c(function(){return Date.now().toString()});
d.LACT=c(function(){return Gr().toString()});
d.VIS=c(function(){return a.Cf().toString()});
d.VOL=c(function(){return a.Jb().toString()});
return d};
gJ=function(a,b){g.G.call(this);var c=this;this.o=[];this.F=!1;this.l=0;this.B=this.C=this.A=!1;this.J=null;var d=(0,g.z)(a,b);this.g=new g.L(function(){return d(c.J)},300);
g.I(this,this.g);this.H=this.G=window.Infinity};
hJ=function(a,b){if(!b)return!1;for(var c=0;c<b.length;c++){var d=b.item(c);if(d&&a.o.includes(d.identifier))return!0}return!1};
Y=function(a,b,c,d,e){e=void 0===e?null:e;g.Ns.call(this,c);this.api=a;this.l=b;this.macros={};this.componentType=d;this.G=null;this.sa=e;this.ga=null;this.Ia=new eJ(this.element);g.I(this,this.Ia);this.pa=this.M(this.element,"click",this.onClick);this.T=[];this.O=new gJ(this.onClick,this);g.I(this,this.O);this.Oa=!1;this.L=null};
iJ=function(a,b){a=void 0===a?null:a;b=void 0===b?null:b;if(null==a)return g.M(Error("Got null or undefined adText object"),"WARNING"),"";var c=g.qb(a.text);if(!a.isTemplated)return c;if(null==b)return g.M(Error("Missing required parameters for a templated message"),"WARNING"),c;for(var d=g.q(Object.entries(b)),e=d.next();!e.done;e=d.next()){var f=g.q(e.value);e=f.next().value;f=f.next().value;c=c.replace("{"+e+"}",f)}return c};
jJ=function(a){a=void 0===a?null:a;return null!=a&&(a=a.thumbnail,null!=a&&null!=a.thumbnails&&0!=a.thumbnails.length&&null!=a.thumbnails[0].url)?g.qb(a.thumbnails[0].url):""};
Zia=function(a){a=void 0===a?null:a;return null!=a&&(a=a.thumbnail,null!=a&&null!=a.thumbnails&&0!=a.thumbnails.length&&null!=a.thumbnails[0].width&&null!=a.thumbnails[0].height)?new g.ad(a.thumbnails[0].width||0,a.thumbnails[0].height||0):new g.ad(0,0)};
mJ=function(a,b,c){var d=a.api;g.V(d).C&&g.kJ(d.app.L,b,a);a=a.api;g.V(a).C&&g.lJ(a.app.L,b,c)};
nJ=function(a,b,c){yI(a.api,b)&&g.xI(a.api,b,c)};
oJ=function(a,b){b=void 0===b?null:b;var c=g.V(a.api);!(0<a.T.length)&&c.o&&g.R(g.V(a.api).experiments,"use_touch_events_for_bulleit_mweb")&&"ontouchstart"in window.document.documentElement&&(Oh()||Nh())&&(a.Pa(a.pa),b&&a.Pa(b),a.T=[a.M(a.element,"touchstart",a.MH,a),a.M(a.element,"touchmove",a.LH,a),a.M(a.element,"touchend",a.KH,a)])};
pJ=function(){g.G.call(this);var a=this;this.g=new window.Map;this.l=g.Lq(window.document.body,"click",function(b){if(b.target&&(b=a.g.get(b.target))&&b)for(var c=0;c<b.length;c++)g.Vp(b[c],void 0,void 0)},"ytp-ad-has-logging-urls")};
rJ=function(){null==qJ&&(qJ=new pJ);return qJ};
tJ=function(a,b){if(a.simpleText){a:{var c=a.simpleText;if(b){var d=sJ(c);if(d){c=g.ud("SPAN",null,d);break a}}c=g.wd(c)}return c}c=[];if(a.runs)for(d=0;d<a.runs.length;d++){var e=a.runs[d];e.text&&c.push($ia(e,b))}return 1==c.length?c[0]:g.ud("SPAN",null,c)};
$ia=function(a,b){var c=null,d=a.text;b&&(d=sJ(d)||d);a.bold&&(c=g.ud("B",null,c||d));a.italics&&(c=g.ud("I",null,c||d));a.strikethrough&&(c=g.ud("STRIKE",null,c||d));if(a.navigationEndpoint&&a.navigationEndpoint.urlEndpoint){var e=a.navigationEndpoint.urlEndpoint;c=g.ud("A",null,c||d);g.Qc(c,e.url);"TARGET_NEW_WINDOW"==e.target&&(c.target="_blank");if(e=a.navigationEndpoint.loggingUrls)e=e.map(function(a){return a.baseUrl}),rJ().register(c,e),g.J(c,"ytp-ad-has-logging-urls")}return c||g.ud("SPAN",
null,d)};
sJ=function(a){a=a.split(/(?:\r\n|\r|\n)/g);if(1<a.length){for(var b=[a[0]],c=1;c<a.length;c++)b.push(g.ud("BR")),b.push(a[c]);return b}return null};
uJ=function(a){dJ.call(this,a);this.C=new g.N;g.I(this,this.C)};
vJ=function(a,b,c){g.G.call(this);this.Bb=a;this.Ii=b;this.view=c();g.I(this,this.view);this.o=null;this.l=[];this.macros={};this.A=!1;this.hide()};
wJ=function(a){for(var b={},c=g.q(Object.entries(fJ(a.Bb,a.Ii))),d=c.next();!d.done;d=c.next()){var e=g.q(d.value);d=e.next().value;e=e.next().value;b[d]=e.toString()}Object.assign(b,a.macros);return b};
xJ=function(a){g.N.call(this);this.A=a;this.l=new g.P({D:"div",I:"ytp-ad-info-dialog-confirm-container",K:[{D:"button",I:"ytp-ad-info-dialog-confirm-button",V:"{{content}}"}]});g.I(this,this.l);this.l.hide();this.o=new g.P({D:"div",I:"ytp-ad-info-dialog-title",V:"{{content}}"});g.I(this,this.o);this.o.hide();this.g=new g.P({D:"div",I:"ytp-ad-info-dialog-relative-container",K:[{D:"div",I:"ytp-ad-info-dialog-form",K:[this.o,{D:"ul",I:"ytp-ad-info-dialog-ad-reasons"},{D:"div",I:"ytp-ad-info-dialog-message",
V:"{{content}}"},this.l]}]});g.I(this,this.g);this.g.hide();this.ca=new g.Pq(this);g.I(this,this.ca)};
yJ=function(a){return a.g.g["ytp-ad-info-dialog-ad-reasons"]};
zJ=function(a){return a?tJ(a):null};
AJ=function(a){uJ.call(this,!1);var b=this;this.g=new xJ(a.ia());g.I(this,this.g);a={};for(var c=g.q(Object.values(aja)),d=c.next();!d.done;a={Ek:a.Ek},d=c.next())a.Ek=d.value,this.g.subscribe(a.Ek,function(a){return function(){return b.dispatchEvent({type:a.Ek})}}(a))};
BJ=function(a,b,c){vJ.call(this,a,b,function(){return new bja.TA(c)});
this.ca=new g.Pq(this);g.I(this,this.ca);this.g=null;this.gd()};
CJ=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-out-of-player-ad-info",K:[{D:"div",I:"ytp-out-of-player-hover-container"},{D:"div",I:"ytp-out-of-player-ad-info-button-container",K:[{D:"button",W:["ytp-out-of-player-ad-info-button"],K:[{D:"span",I:"ad-info-icon"}]}]}]},"watch-ad-info-hover-button");this.o=this.g["ytp-out-of-player-hover-container"];this.C=this.g["ytp-out-of-player-ad-info-button-container"];this.F=this.g["ytp-out-of-player-ad-info-button"];this.je=new BJ(this.api,this.l,new eJ(this.C));
g.I(this,this.je);this.A=new g.Pq(this);g.I(this,this.A);this.B();this.je.Ah(new eJ(this.element));this.A.M(this.F,"mouseenter",this.J);this.A.M(this.F,"mouseleave",this.B);this.A.M(this.C,"click",this.H);this.hide()};
DJ=function(a,b,c,d){d=cja(c,d);var e={D:"div"};d&&(e={D:"div",I:"image-companion",K:[{D:"img",N:{src:d.url,border:"0",style:"cursor:pointer;"}}]});cJ.call(this,e,a,b);this.l=c;this.qc=new CJ(a,b);g.I(this,this.qc);this.qc.aa(this.element,0);this.l.adInfoRenderer&&this.l.adInfoRenderer.adHoverTextButtonRenderer?this.qc.init(X("watch-ad-info-hover-button"),this.l.adInfoRenderer.adHoverTextButtonRenderer,{}):g.M(Error("ImageCompanionAdRenderer has no ad info renderer."));if(a=this.g["image-companion"])void 0!==
d.width&&void 0!==d.height&&g.Ah(a,d.width,d.height),this.fa("click",this.C,this),this.lf(c.impressionCommands)};
cja=function(a,b){if(!a.image||!a.image.thumbnail)return null;var c=a.image.thumbnail;return null==c.thumbnails?null:g.Ja(c.thumbnails||[],function(a){return a.width==b.width&&a.height==b.height})};
EJ=function(a){bJ.call(this,a);this.C=(0,g.E)((a.image&&a.image.thumbnail?a.image.thumbnail.thumbnails:null)||[],function(a){return new g.ad(a.width,a.height)})};
FJ=function(a){RI.apply(this,arguments)};
GJ=function(a,b,c){cJ.call(this,{D:"div",I:"videowall-companion-container",K:[{D:"iframe",I:"videowall-companion",N:{marginwidth:"0",marginheight:"0",hspace:"0",vspace:"0",frameborder:"0",scrolling:"no",src:c.iframeUrl}}]},a,b);var d=this;this.l=c;var e=this.g["videowall-companion"];g.Ah(e,c.iframeWidth||300,c.iframeHeight||250);this.qc=new CJ(a,b);g.I(this,this.qc);this.qc.aa(this.element,0);this.l.adInfoRenderer&&this.l.adInfoRenderer.adHoverTextButtonRenderer?this.qc.init(X("watch-ad-info-hover-button"),
this.l.adInfoRenderer.adHoverTextButtonRenderer,{}):g.M(Error("VideowallIframeCompanionAdRenderer has no ad info renderer."));e&&this.M(e,"load",function(){d.lf(c.impressionCommands);var a=dja(e);a&&d.M(a,"click",function(a){g.Fd(d.qc.element,a.target)||(d.lf(d.l.onClickCommands),d.o.nd("videowall-companion"))})})};
dja=function(a){try{var b=a.contentDocument||a.contentWindow.document;return b&&b.body}catch(c){return g.M(c),null}};
HJ=function(a){bJ.apply(this,arguments)};
IJ=function(a){return a.length?(0,g.E)(a[0].loggingUrls||[],function(a){return a.baseUrl}):[]};
JJ=function(a,b){YI.call(this);if(a.renderers){for(var c=[],d=g.q(a.renderers),e=d.next();!e.done;e=d.next()){var f=e.value;f.instreamVideoAdRenderer?(e=new TI(f.instreamVideoAdRenderer,b),ZI(this,[e]),c.push(e.l)):f.simultaneousAdsRenderer&&(e=eja(f.simultaneousAdsRenderer.inPlayerFormat,b),f=fja(f.simultaneousAdsRenderer.aboveFeedFormat),ZI(this,[e,f]),c.push(e.l))}this.g.forEach(function(a,b){for(var d=g.q(a),e=d.next();!e.done;e=d.next())if(e=e.value,e instanceof TI){var f=new SI(b,c);e.A=f}})}};
eja=function(a,b){return null==a?null:a.instreamVideoAdRenderer?new TI(a.instreamVideoAdRenderer,b):null};
fja=function(a){return null==a?null:a.imageCompanionAdRenderer?new EJ(a.imageCompanionAdRenderer):a.videowallIframeCompanionAdRenderer?new HJ(a.videowallIframeCompanionAdRenderer):a.shoppingCompanionCarouselRenderer?new FJ(a.shoppingCompanionCarouselRenderer):a.actionCompanionAdRenderer?new WI(a.actionCompanionAdRenderer):null};
KJ=function(a){RI.apply(this,arguments)};
LJ=function(a){RI.apply(this,arguments)};
MJ=function(a){if(!a)return[];var b=[];a=g.q(a);for(var c=a.next();!c.done;c=a.next())if(c=c.value,c.loggingUrls){c=g.q(c.loggingUrls);for(var d=c.next();!d.done;d=c.next())b.push({baseUrl:d.value.baseUrl})}return b};
gja=function(a){var b={};b.abandon=a.abandonCommands&&MJ(a.abandonCommands.commands)||[];return b};
NJ=function(a){RI.call(this,a,gja(a))};
OJ=function(a){RI.apply(this,arguments)};
PJ=function(a){RI.apply(this,arguments)};
QJ=function(a){RI.apply(this,arguments)};
RJ=function(a){if(!a)return[];var b=[];a.forEach(function(a){a.command.loggingUrls.forEach(function(c){b.push({baseUrl:c.baseUrl,offsetMilliseconds:a.adVideoOffset.milliseconds})})});
return b};
SJ=function(a){return a&&a.adVideoOffset&&a.adVideoOffset.percent||0};
TJ=function(a){return"AD_VIDEO_PROGRESS_KIND_PERCENT"==a.adVideoOffset.kind};
hja=function(a){a=a.playbackCommands;if(!a)return{};var b={};b.impression=MJ(a.impressionCommands)||[];b.error=MJ(a.errorCommands)||[];b.mute=MJ(a.muteCommands)||[];b.unmute=MJ(a.unmuteCommands)||[];b.pause=MJ(a.pauseCommands)||[];b.rewind=MJ(a.rewindCommands)||[];b.resume=MJ(a.resumeCommands)||[];b.skip=MJ(a.skipCommands)||[];b.close=MJ(a.closeCommands)||[];b.clickthrough=MJ(a.clickthroughCommands)||[];b.fullscreen=MJ(a.fullscreenCommands)||[];b.active_view_viewable=MJ(a.activeViewViewableCommands)||
[];b.active_view_measurable=MJ(a.activeViewMeasurableCommands)||[];b.active_view_fully_viewable_audible_half_duration=MJ(a.activeViewFullyViewableAudibleHalfDurationCommands)||[];b.end_fullscreen=MJ(a.endFullscreenCommands)||[];b.channel_clickthrough=MJ(a.channelClickthroughCommands)||[];b.abandon=MJ(a.abandonCommands)||[];b.progress=RJ(a.progressCommands.filter(function(a){return"AD_VIDEO_PROGRESS_KIND_MILLISECONDS"==a.adVideoOffset.kind}));
b.start=RJ(a.progressCommands.filter(function(a){return TJ(a)&&1E-6>=Math.abs(SJ(a)-0)}));
b.first_quartile=RJ(a.progressCommands.filter(function(a){return TJ(a)&&1E-6>=Math.abs(SJ(a)-.25)}));
b.midpoint=RJ(a.progressCommands.filter(function(a){return TJ(a)&&1E-6>=Math.abs(SJ(a)-.5)}));
b.third_quartile=RJ(a.progressCommands.filter(function(a){return TJ(a)&&1E-6>=Math.abs(SJ(a)-.75)}));
b.complete=RJ(a.progressCommands.filter(function(a){return TJ(a)&&1E-6>=Math.abs(SJ(a)-1)}));
return b};
UJ=function(a,b){b=void 0===b?!0:b;RI.call(this,a,hja(a));this.A=b;this.o=a.questions?a.questions.reduce(function(a,b){var c=b.instreamSurveyAdSingleSelectQuestionRenderer||b.instreamSurveyAdMultiSelectQuestionRenderer;return c?a+(c.surveyAdQuestionCommon.durationMilliseconds||0)/1E3:a},0):0};
VJ=function(a){RI.apply(this,arguments)};
WJ=function(a){RI.apply(this,arguments)};
XJ=function(a,b){YI.call(this);var c=a.persistingOverlay;var d=a.adVideoStart;c&&c.persistingAdOverlayRenderer?c=new QJ(c.persistingAdOverlayRenderer):d&&d.surveyTextInterstitialRenderer?(this.A=!1,c=new VJ(d.surveyTextInterstitialRenderer)):c=null;this.l=c;c=a.adVideoStart;null==c?c=null:c.adActionInterstitialRenderer?(this.o=1,c=[new NJ(c.adActionInterstitialRenderer)]):c=c.adTextInterstitialRenderer?[new WJ(c.adTextInterstitialRenderer)]:c.adChoiceInterstitialRenderer?[new OJ(c.adChoiceInterstitialRenderer)]:
c.adMessageRenderer?[new PJ(c.adMessageRenderer)]:null;ZI(this,c);a:{if(d=a.linearAd){if(d.instreamVideoAdRenderer){c=[new TI(d.instreamVideoAdRenderer,b)];break a}if(d.instreamSurveyAdRenderer){c=[new UJ(d.instreamSurveyAdRenderer,!(this.l instanceof VJ))];break a}if(d.parallelChoiceAdPlacementRenderer){c=[];d=g.q(d.parallelChoiceAdPlacementRenderer.adPlacementRendererChoices);for(var e=d.next();!e.done;e=d.next())e=e.value,e.instreamVideoAdRenderer?c.push(new TI(e.instreamVideoAdRenderer,b)):e.instreamSurveyAdRenderer&&
c.push(new UJ(e.instreamSurveyAdRenderer));break a}}c=null}ZI(this,c);(c=a.adVideoEnd)?c.adActionInterstitialRenderer?(this.o=1,c=[new NJ(c.adActionInterstitialRenderer)]):c=null:c=null;ZI(this,c)};
YJ=function(a,b,c,d){this.id=b;this.G=a.placementStartPings||[];this.F=a.placementEndPings||[];this.A=d.g;b=a.config&&a.config.adPlacementConfig;if(!b)throw Error("Malformed AdPlacementRenderer: missing AdPlacementConfig");var e=a.renderer&&a.renderer.adBreakServiceRenderer&&a.renderer.adBreakServiceRenderer||{};this.l=e.getAdBreakUrl||"";d.l=(0,window.parseInt)(e.prefetchMilliseconds,10)||0;d.visible=!b.hideCueRangeMarker;var f=MI(b,d);if(null==f)d=new II(b,new g.Ai(-1,-1),!1,"adcuerange:invalid"),
d.l=!0,d=[null,d];else{e=g.Mn(g.Ln.getInstance());var k=d.livestream||d.g;f=new II(b,f,d.visible&&!k,"adcuerange:"+e);k=null;if(d.g||0<d.l)if(d=MI(b,d,!0))k=new II(b,d,!1,"prefetch:"+e),f.A=k,k.A=f;d=[k,f]}this.J=d[0];this.H=d[1];if(a.renderer){var l=a.renderer;a=l.instreamVideoAdRenderer;d=l.clientForecastingAdRenderer;b=l.invideoOverlayAdRenderer;e=l.videowallIframeCompanionAdRenderer;f=l.imageCompanionAdRenderer;k=l.instreamSurveyAdRenderer;var m=l.plaShelfRenderer,n=l.sandwichedLinearAdRenderer,
p=l.shoppingCompanionCarouselRenderer,u=l.backfillMpuCompanionAdRenderer,x=l.actionCompanionAdRenderer;l=l.multipleInstreamVideoAdRenderer;c=null!=a&&a.playerVars?new TI(a,c):null!=d?new $I(d):null!=b?new KJ(b):null!=e?new HJ(e):null!=f?new EJ(f):null!=k?new UJ(k):null!=n?new XJ(n,c):null!=l?new JJ(l,c):null!=m?new LJ(m):null!=p?new FJ(p):null!=u?new XI(u):null!=x?new WI(x):null}else c=null;this.g=c;this.B=!1;this.o={};this.C={}};
ZJ=function(a){return"AD_PLACEMENT_KIND_MILLISECONDS"==a.wb().o||"AD_PLACEMENT_KIND_CUE_POINT_TRIGGERED"==a.wb().o};
$J=function(a){return"AD_PLACEMENT_KIND_START"==a.wb().o};
aK=function(a,b,c,d){var e=null;try{e=new YJ(a,b,c,d)}catch(f){g.M(f)}return e};
cK=function(a){var b={};ija(a,b);jja(b);b.LACT=bK(function(){return Gr().toString()});
b.VIS=bK(function(){return a.Cf().toString()});
b.SDKV="h.3.0";b.VOL=bK(function(){return Math.round(a.Jb()).toString()});
b.VED="";return b};
dK=function(a,b){var c=b&&-1!=b.indexOf("load_timeout")?"402":"400",d={};return d.YT_ERROR_CODE=a.toString(),d.ERRORCODE=c,d.ERROR_MSG=b,d};
bK=function(a){return{toString:function(){return a()}}};
eK=function(a){for(var b={},c=g.q(kja),d=c.next();!d.done;d=c.next()){d=d.value;var e=a[d];e&&(b[d]=e.toString())}return b};
fK=function(a){for(var b=[],c=0;c<arguments.length;++c)b[c-0]=arguments[c];c={};Object.assign.apply(Object,[c].concat(g.ea(b)));return c};
lja=function(a,b,c){function d(a,c){var d=b[c];d&&(f[a]=d)}
function e(a,c){var d=b[c];d&&(f[a]=k(d))}
if(!b||g.Qb(b))return a;var f=Object.assign({},a),k=c?window.encodeURIComponent:function(a){return a};
e("DV_VIEWABILITY","doubleVerifyViewability");e("IAS_VIEWABILITY","integralAdsViewability");e("MOAT_INIT","moatInit");e("MOAT_VIEWABILITY","moatViewability");d("GOOGLE_VIEWABILITY","googleViewability");d("VIEWABILITY","viewability");return f};
ija=function(a,b){b.CPN=bK(function(){var b;(b=a.getVideoData(1))?b=b.clientPlaybackNonce:(g.M(Error("Video data is null."),"WARNING"),b=null);return b});
b.AD_MT=bK(function(){return gK(a,2)});
b.MT=bK(function(){return gK(a,1)});
b.P_H=bK(function(){return g.ZH(a).Ha().height.toString()});
b.P_W=bK(function(){return g.ZH(a).Ha().width.toString()});
b.PV_H=bK(function(){return g.hK(g.ZH(a)).height.toString()});
b.PV_W=bK(function(){return g.hK(g.ZH(a)).width.toString()})};
gK=function(a,b){var c=1E3*a.ya(b);return Math.round(Math.max(0,c)).toString()};
jja=function(a){a.CONN=bK(lc("0"));a.WT=bK(function(){return Date.now().toString()})};
iK=function(a){this.l=a;this.o=zp();if(this.g=g.R(g.V(this.l).experiments,"use_legacy_ping_service_for_bulleit_living_room")){Pm.A=!0;a=Pm;var b=!g.Np();a.l=b}};
jK=function(a){this.o=a};
kK=function(a){this.o=a};
lK=function(){};
nK=function(){g.G.call(this);var a=this;this.g={};mK(this,"commandExecutorCommand",function(b,c,d){b.commands&&a.lf(b.commands,c,d)});
mK(this,"clickTrackingParams",function(){})};
oK=function(a,b){return mK(a,b.g(),function(a,d,e){b.l(a,d,e)})};
mK=function(a,b,c){if(a.g[b])return g.M(Error("Extension name "+b+" already registered")),function(){};
a.g[b]=c;return function(){delete a.g[b]}};
pK=function(a,b,c,d,e){e=void 0===e?{}:e;if(a=a.g[b])try{a(c[b],d,e)}catch(f){g.M(f)}else g.M(Error("Unhandled field "+b))};
qK=function(a,b){var c=g.ep("VALID_SESSION_TEMPDATA_DOMAINS",[]),d=g.yg(window.location.href);d&&c.push(d);d=g.yg(a);if(g.Ma(c,d)||!d&&g.fb(a,"/"))if(g.lp("autoescape_tempdata_url")&&(c=window.document.createElement("a"),g.Qc(c,a),a=c.href),a&&(c=g.wg(a),c=g.vg(null,null,null,null,c[5],c[6],c[7]),d=c.indexOf("#"),c=0>d?c:c.substr(0,d))){if(b.itct||b.ved)b.csn=b.csn||g.js();if(e){var e=(0,window.parseInt)(e,10);(0,window.isFinite)(e)&&0<e&&(c="ST-"+g.vb(c).toString(36),d=b?g.Gg(b):"",g.Jr(c,d,e||5))}else e=
"ST-"+g.vb(c).toString(36),c=b?g.Gg(b):"",g.Jr(e,c,5)}};
g.rK=function(a){var b=void 0===b?{}:b;var c=void 0===c?"":c;var d=void 0===d?window:d;d=d.location;a=g.Ig(a,b)+c;a=a instanceof g.yc?a:Dc(a);d.href=g.zc(a)};
g.sK=function(a,b,c){b=void 0===b?{}:b;c=void 0===c?!1:c;var d=g.ep("EVENT_ID");d&&(b.ei||(b.ei=d));b&&qK(a,b);c||((window.ytspf||{}).enabled?window.spf.navigate(a):g.rK(a))};
g.tK=function(a,b,c){c&&qK(a,c);c=g.Cc(a);c=g.zc(c);a!=c&&g.kp(Error("Unsafe window.open URL: "+a));a=c;window.open(a,b||g.vb(a).toString(36))};
uK=function(){};
vK=function(){this.g=null};
mja=function(a){return wK(a).then(function(){return new g.Pf(function(a,c){var b=xK();(b=b?yK(b):null)&&"adSizes"in b[0]?a((0,g.E)(b[0].adSizes,function(a){return new g.ad(a.adWidth,a.adHeight)})):c(Error("No slots registered with GPT services"))})})};
nja=function(a){!zK()&&a.g?a.g.cancel():wK(a).then(function(){return AK(null,300,60)})};
wK=function(a){if(null==a.g){var b=function(a){if(!zK()){if(0>=a)throw Error("Timed out while waiting for GPT services");return lg(200).then(function(){return b(a-1)})}};
a.g=Tf().then(function(){return b(150)})}return a.g};
AK=function(a,b,c){var d=lg(5E3).then(function(){throw Error("Timed out while waiting for GPT set companion");}),e=new g.Pf(function(d,e){var f=xK();
if(f){var k=yK(f);if(k&&0!=k.length){var n={};n.slotId=k[0].slotId;n.adContent="<div></div>";n.adWidth=b;n.adHeight=c;n.friendlyIframeRendering=!1;n.onAdContentSet=function(b){var c=g.Dd(b);c||(c=g.vd("div"),b.appendChild(c));a&&c.appendChild(a);d()};
(f=f.googleSetCompanionAdContents)?f([n]):e(Error("Missing googleSetCompanionAdContents API"))}else e(Error("No slots registered with GPT services"))}else e(Error("Failed to find GPT services"))});
return Xf([e,d])};
zK=function(){var a=xK();if(!a)return!1;a=yK(a);return g.ya(a)&&0!=a.length?null!=g.gd("google_companion_ad_div"):!1};
xK=function(){var a=sd();return g.y("googletag.cmd",a)?a:null};
yK=function(a){a=void 0!==a.googleGetCompanionAdSlots?jp(a.googleGetCompanionAdSlots)():void 0;return void 0!==a&&0<a.length?a:null};
BK=function(a,b){this.l=a;this.g=b};
oja=function(a){return a.g?mja(a.g):Uf("GPT is not enalbed")};
CK=function(a){a=void 0===a?null:a;g.N.call(this,!0);this.g=a;this.l=-window.Infinity};
pja=function(a,b){switch(b.event){case "start":case "continue":case "predictStart":case "stop":break;case "unknown":return;default:return}var c=b.g+b.l/1E3;if(!(c<a.l)){a.l=c;if(a.g){if(c<a.g.end)switch(b.event){case "start":case "continue":case "stop":c=b.g+b.durationSecs;c>=a.g.end||(a.g.end=c,a.P("Shortened the latest cuerange",c,b));return;case "predictStart":return;default:return}a.g=null}switch(b.event){case "start":case "continue":a.g=new g.Ai(b.g,b.g+b.durationSecs),a.P("Identified a new cuerange",
b)}}};
DK=function(a){g.G.call(this);this.g=[];var b=a.subscribe("Shortened the latest cuerange",this.l,this);g.We(this,function(){return a.Ac(b)})};
EK=function(a){g.G.call(this);this.l=a;this.g=null};
FK=function(){g.N.call(this);this.g=new window.Map};
HK=function(){null==GK&&(GK=new FK,gm.getInstance().l="b",hm());return GK};
qja=function(a){switch(a){case "fully_viewable_audible_half_duration_impression":return"h";case "measurable_impression":return"c";case "overlay_unmeasurable_impression":return"i";case "overlay_unviewable_impression":return"j";case "overlay_viewable_end_of_session_impression":return"k";case "overlay_viewable_immediate_impression":return"l";case "viewable_impression":return"q";default:return null}};
JK=function(a){return IK(a)&&1==a.Kd(2)};
IK=function(a){a=a.xb();return void 0!==a&&2==a.getPlayerType()};
KK=function(a){a=g.V(a);return ey(a)&&!g.py(a)&&"desktop-polymer"==a.playerStyle};
MK=function(a,b){var c=g.V(a);g.Yx(c)||"3"!=c.A||(c=g.ZH(a),g.Yx(c.app.g),c.C=!b,g.LK(c))};
NK=function(a){g.G.call(this);this.g=a;var b=gm.getInstance();a=a.tw();b.A!==a&&((b.A=a)||Tca(b))};
rja=function(a){switch(a){case "abandon":return"abandon";case "active_view_fully_viewable_audible_half_duration":return"fully_viewable_audible_half_duration_impression";case "active_view_measurable":return"measurable_impression";case "active_view_viewable":return"viewable_impression";case "complete":return"complete";case "end_fullscreen":return"exitfullscreen";case "first_quartile":return"firstquartile";case "fullscreen":return"fullscreen";case "impression":return"impression";case "midpoint":return"midpoint";
case "mute":return"mute";case "pause":return"pause";case "progress":return"progress";case "resume":return"resume";case "skip":return"skip";case "start":return"start";case "third_quartile":return"thirdquartile";case "unmute":return"unmute"}return null};
OK=function(a,b,c,d,e,f){f=void 0===f?new iK(d):f;g.G.call(this);this.l=a;this.G=b;g.I(this,this.G);this.o=c;this.g=d;this.H=e;this.C=f;this.F=Array.from(this.l.Y.progress||[]);this.F.sort(function(a,b){return a.offsetMilliseconds-b.offsetMilliseconds});
this.A={us:.25,Ls:.5,Us:.75};this.B=null};
UK=function(a,b,c){!PK(a)&&0<c&&(QK(a,b),RK(a)?SK(a,b,c):TK(a,b,c))};
YK=function(a){if(RK(a)){var b=a.g.ya(2,!1);VK(a,"impression",b,0)}else WK(a,"impression");WK(a,"start");PK(a)||a.g.isFullscreen()&&XK(a,"fullscreen")};
ZK=function(a,b){PK(a)||(RK(a)?(QK(a,0,!0),SK(a,b,b)):(QK(a,0,!0),TK(a,0,0,!0)),WK(a,"complete"))};
sja=function(a,b){b&&b.forEach(function(b){b.baseUrl&&a.C.send(b.baseUrl,$K(a),{})})};
QK=function(a,b,c){for(c=void 0===c?!1:c;a.l.L<a.F.length;){var d=aL(a,"progress"),e=a.F[a.l.L];if(e.offsetMilliseconds<=1E3*b||c)(e=e.baseUrl)&&a.C.send(e,$K(a),d),a.l.L++;else break}};
TK=function(a,b,c,d){d=void 0===d?!1:d;(b>=c*a.A.us||d)&&WK(a,"first_quartile");(b>=c*a.A.Ls||d)&&WK(a,"midpoint");(b>=c*a.A.Us||d)&&WK(a,"third_quartile")};
VK=function(a,b,c,d){if(null==a.B){if(c<d||.25<c-d)return}else if(a.B>d||d>c)return;WK(a,b)};
SK=function(a,b,c){if(0<c&&0<b){var d=g.YH(a.g,a.g.Da());g.U(d,16)||g.U(d,32)||(VK(a,"first_quartile",b,c*a.A.us),VK(a,"midpoint",b,c*a.A.Ls),VK(a,"third_quartile",b,c*a.A.Us))}a.B=b};
XK=function(a,b){for(var c=aL(a,b),d=g.q(a.l.Y[b]||[]),e=d.next();!e.done;e=d.next())(e=e.value.baseUrl)&&a.C.send(e,$K(a),c);a.l.F[b]=!0};
WK=function(a,b){a.l.F.hasOwnProperty(b)||XK(a,b)};
bL=function(a,b){return a.l.F.hasOwnProperty(b)};
$K=function(a){for(var b={},c=cK(a.g),d=g.q(Object.keys(c)),e=d.next();!e.done;e=d.next())e=e.value,b[e]=c[e].toString();return Object.assign(b,a.o)};
aL=function(a,b){var c=a.G;var d=a.l;if(d.vj()){var e=rja(b);if(null==e)d={};else{var f;(f=d.O()())||(f=(f=c.g)&&f.xb?(f=f.xb())&&2==f.getPlayerType()?KG(f):null:null);f?(c={opt_adElement:f,opt_fullscreen:c.g.isFullscreen()},d=nm(e,d.G,c)):d={}}}else d={};return d?Object.assign({},d):{}};
cL=function(a,b){if(!g.R(g.V(a.g).experiments,"disable_vss2_engage_for_bulleit"))switch(b){case "action-companion":case "shopping-companion":case "image-companion":case "videowall-companion":if(2==a.g.Da())a.g.we(1,void 0,2);else if(a.H){var c=a.H.g;c&&c()}else g.M(Error("trackCompanionEngagement is called butcompanionEngagementHandler is null"),"ERROR")}};
RK=function(a){if(g.R(g.V(a.g).experiments,"html5_bulleit_dai_logging_policy_upg_livestream_killswitch"))return!1;var b=a.g.getVideoData(1);return b?b.xf()&&g.py(g.V(a.g))&&a.l.Rh():!1};
PK=function(a){return RK(a)&&!bL(a,"impression")};
dL=function(a){return RK(a)&&bL(a,"seek")};
eL=function(a,b,c,d,e){d=void 0===d?0:d;g.N.call(this);this.g=a;this.l=new OK(b,new NK(this.g),c,this.g,e);g.I(this,this.l);this.A=HK();this.A.g.set(b.G,this);this.A.subscribe("c",this.Sy,this);this.A.subscribe("h",this.Ty,this);this.A.subscribe("i",this.Uy,this);this.A.subscribe("j",this.Vy,this);this.A.subscribe("k",this.Wy,this);this.A.subscribe("l",this.Xy,this);this.A.subscribe("q",this.Yy,this);this.C=b;this.L=[];this.macros=c;this.F=!1;if(!(a=0==d)){if(d=1==d)d=g.V(this.g),d=g.py(d)||d.o||
g.gy(d)||!g.ry;a=d}a?d=!0:(d=g.jd("video-ads"),d=null!=d&&"none"!=g.mh(d,"display"));this.T=!d};
fL=function(a){a.T?a.Rb("ui_unstable"):a.Vb()};
hL=function(a,b){Ua(a.L,b);gL(a,b,1)};
tja=function(a,b){var c=[];(0,g.C)(b,function(a){0<=g.Ia(this.L,function(b){return b.componentType==a.componentType})?c.push(a):g.M(Error("Cannot find UX Component "+a.componentType+" to modify"),"WARNING")},a);
gL(a,c,2)};
iL=function(a){gL(a,a.L,3);a.L=[]};
jL=function(a){a=a.l;a.o=fK(a.o,dK(0,"No playable media files can be selected"));WK(a,"error")};
gL=function(a,b,c){0!=b.length&&(b=(0,g.E)(b,function(a){return new OI(a,c,a.id)}),a.P("onAdUxUpdate",b))};
kL=function(a){return(a=a.g.getVideoData(2))&&a.clientPlaybackNonce||""};
lL=function(a,b){NI.call(this,"action-companion",a,b)};
uja=function(a){var b=a.renderer;var c=a.renderer;c=c.navigationEndpoint&&c.navigationEndpoint.urlEndpoint&&c.navigationEndpoint.urlEndpoint.url||"";var d=mL(b.bannerImage),e=mL(b.iconImage),f=b.headline&&b.headline.text||"",k=b.description&&b.description.text||"";a=a.renderer;a=(a=a.actionButton&&a.actionButton.buttonRenderer&&a.actionButton.buttonRenderer.text)?g.Wz(a):"";return{target:c,bannerImageUrl:d,iconImageUrl:e,headline:f,descriptionText:k,actionTitle:a,impressionEndpoints:b.impressionCommands,
adInfoRenderer:b.adInfoRenderer,trackingParams:b.trackingParams}};
mL=function(a){return a&&a.thumbnail&&a.thumbnail.thumbnails&&a.thumbnail.thumbnails.length?a.thumbnail.thumbnails[0].url||"":""};
nL=function(a,b,c,d){eL.call(this,a,b,c,void 0,d);this.o=null};
oL=function(a,b){var c=b.renderer;return c&&c.adVideoId==a.videoId};
pL=function(a,b,c){if(c.renderer.actionButton||b.isListed){var d=c.renderer,e=d.iconImage&&d.iconImage.thumbnail&&d.iconImage.thumbnail.thumbnails||null;e&&e.length&&g.ib(g.qb(e[0].url))&&(e[0].url=b.profilePicture);(e=d.bannerImage&&d.bannerImage.thumbnail&&d.bannerImage.thumbnail.thumbnails||null)&&e.length&&g.ib(g.qb(e[0].url))&&(e[0].url=b.channelBanner);e=d.headline;null!=e&&g.ib(g.qb(e.text))&&(e.text=b.author);c.renderer.actionButton||(d.description&&(d.description.text=b.videoCountText),d.navigationEndpoint&&
d.navigationEndpoint.urlEndpoint&&(d.navigationEndpoint.urlEndpoint.url=b.channelPath));hL(a,[c])}};
qL=function(a,b){NI.call(this,"ad-action-interstitial",a,b)};
rL=function(a,b,c,d){eL.call(this,a,b,c,1);this.B=b;this.o=b.g.durationMilliseconds||0;this.Fa=null;this.G=d};
sL=function(a,b){NI.call(this,"ad-choice-interstitial",a,b)};
tL=function(a,b,c){eL.call(this,a,b,c,1);this.o=b};
uL=function(a){NI.call(this,"ad-message",a)};
vL=function(a,b,c){eL.call(this,a,b,c);var d=this;this.J=b;this.G=b.g.durationMs||0;this.B=this.o=0;this.H=function(){var a=d.g.fh().current;a<d.o?d.Tc():a>d.B&&d.yd()}};
wL=function(a,b){b.SLOT_POS="1";NI.call(this,"backfill-mpu-companion",a,b)};
xL=function(a,b,c,d){eL.call(this,a,b,c,void 0,d)};
yL=function(a,b,c){eL.call(this,a,b,c)};
zL=function(a,b){NI.call(this,"invideo-overlay",a,b)};
AL=function(a,b,c){eL.call(this,a,b,c);this.o=b};
BL=function(a,b){NI.call(this,"persisting-overlay",a,b)};
CL=function(a,b,c){eL.call(this,a,b,c);this.o=b};
DL=function(a,b){NI.call(this,"pla-shelf",a,b)};
EL=function(a,b,c){eL.call(this,a,b,fK(c,{TRIGGER_TYPE:"YOUTUBE_SHELF_SHOW"}));this.o=b};
FL=function(a,b){NI.call(this,"shopping-companion",a,b)};
GL=function(a,b,c,d){eL.call(this,a,b,c,void 0,d)};
HL=function(a){NI.call(this,"survey",a);this.g=!1};
IL=function(a,b,c,d){eL.call(this,a,b,c,2);this.B=b;this.o=null;this.G=d};
JL=function(a,b){NI.call(this,"survey-interstitial",a,b)};
KL=function(a,b,c){eL.call(this,a,b,c,2);this.o=b};
LL=function(a){NI.call(this,"ad-text-interstitial",a)};
ML=function(a,b,c,d){eL.call(this,a,b,c);this.B=b;this.o=b.g.durationMilliseconds||0;this.Fa=null;this.G=d};
NL=function(a){return a?g.Wz(a):null};
OL=function(a){if(!a||!a.loggingUrls)return[];a=a.loggingUrls.map(function(a){return a.baseUrl});
return 0===a.length?[]:a};
vja=function(a){return a.cancelRenderer&&a.cancelRenderer.buttonRenderer?(a=a.cancelRenderer.buttonRenderer.serviceEndpoint)&&a.muteAdEndpoint?a:null:null};
PL=function(a){var b={};b.baseUrl=a;return{loggingUrls:[b],pingingEndpoint:{hack:!0}}};
wja=function(a,b,c,d){this.l=a;this.o=b;this.g=c;this.A=d};
xja=function(a,b,c){b.isSkippable=!0;b.skipTime=c.skipOffsetMilliseconds?Math.floor(c.skipOffsetMilliseconds/1E3):0;if(c.skippableRenderer)switch(Object.keys(c.skippableRenderer)[0]){case "skipButtonRenderer":var d=c.skippableRenderer.skipButtonRenderer;b.skip=function(){a.A.Ng()};
b.skipShown=function(){QL(a,d.impressionCommands)}}};
yja=function(a,b,c){var d=NL(c.confirmLabel)||"",e=NL(c.title)||"",f=c.adReasons?c.adReasons.map(function(a){return NL(a)||""}):[];
b.whyThisAdInfo={closeButton:d,menuTitle:"",targetingReasonHeader:e,targetingReasons:f,adSettingsLink:null,cancelButton:null,continueButton:null,controlText:null};b.whyThisAdClicked=function(){QL(a,c.impressionEndpoints)};
b.whyThisAdClosed=function(){QL(a,c.confirmServiceEndpoint)}};
Aja=function(a,b,c){if(c.navigationEndpoint&&c.navigationEndpoint.adFeedbackEndpoint&&c.navigationEndpoint.adFeedbackEndpoint.content){var d=c.navigationEndpoint.adFeedbackEndpoint.content.adFeedbackRenderer;if(d){var e={goneText:"",questionText:"",undoText:"",hoverText:NL(c.text)||"",surveyOptions:[]};b.muteAdInfo=e;c=OL(c.navigationEndpoint);var f=PL(c[1]),k=[PL(c[0])];(c=vja(d))&&k.push(c);var l=!1;b.muteAdClicked=function(){l=!0;QL(a,f)};
b.muteAd=function(){l||QL(a,f);l=!1;QL(a,k)};
zja(b,d)}}};
zja=function(a,b){a.muteAdInfo.goneText=NL(b.title)||"";a.muteAdInfo.questionText=NL(b.reasonsTitle)||"";b.undoRenderer&&(a.muteAdInfo.undoText=NL(b.undoRenderer.buttonRenderer.text)||"");for(var c=a.muteAdInfo.surveyOptions,d=g.q(b.reasons||[]),e=d.next();!e.done;e=d.next()){var f=e.value;e=NL(f.reason)||"";f=OL(f.endpoint);c.push({label:e,url:f[0]})}};
QL=function(a,b){b&&(g.ya(b)?b.forEach(function(b){return a.l.Ka(b,a.o)}):a.l.Ka(b,a.o))};
Bja=function(){return{adSystem:0,attributionInfo:null,clickThroughUrl:"",isBumper:!1,isSkippable:!1,muteAdInfo:null,skipTime:5,videoId:"",videoUrl:"",whyThisAdInfo:null,muteAd:function(){},
muteAdClicked:function(){},
sendAdsPing:function(){},
skip:function(){},
skipShown:function(){},
whyThisAdClicked:function(){},
whyThisAdClosed:function(){}}};
RL=function(a,b){g.G.call(this);this.A=Math.max(0,a);this.o=this.l=0;this.B=b;this.g=null};
SL=function(a){a.g&&(a.g.stop(),a.g.dispose(),a.g=null)};
TL=function(){NI.call(this,"ad-attribution-bar");this.adPodPositionInfoString=null;this.adPodPosition=0;this.adPodLength=1;this.adBreakLengthSeconds=0;this.adBadgeText=null;this.adBreakRemainingLengthSeconds=0;this.adVideoId=null};
UL=function(a){a=void 0===a?null:a;NI.call(this,"ad-channel-thumbnail");this.channelIconThumbnailUrl=a};
VL=function(a){a=void 0===a?null:a;NI.call(this,"ad-title");this.videoTitle=a};
WL=function(a){a=void 0===a?null:a;NI.call(this,"advertiser-name");this.channelName=a};
XL=function(a){NI.call(this,"player-overlay",a)};
YL=function(a){NI.call(this,"skip-button",a)};
ZL=function(a){NI.call(this,"visit-advertiser",a);var b={};var c=a.text;a=a.navigationEndpoint;null!=c&&null!=c.runs&&null!=a?(b.runs=[g.Wb(c.runs[0])],b.runs[0].navigationEndpoint=a):(b={text:"Visit advertiser's site"},a&&(b.navigationEndpoint=a),b={runs:[b]});this.visitAdvertiserLabel=b};
g.$L=function(a,b){var c={},d;for(d in b)c.Jn=b[d],a=a.replace(new RegExp("\\$"+d,"gi"),function(a){return function(){return a.Jn}}(c)),c={Jn:c.Jn};
return a};
aM=function(a,b,c,d,e){eL.call(this,a,b,c,1,d);var f=this;this.o=b;this.H=e;this.da=g.R(g.V(a).experiments,"bulleit_use_video_end_cuerange_for_completion");this.R=g.R(g.V(a).experiments,"bulleit_publish_external_playback_events");this.O=new g.Pq(this);g.I(this,this.O);this.G=new g.L(function(){f.Rb("load_timeout")},g.R(g.V(a).experiments,"use_variable_load_timeout")?g.S(g.V(a).experiments,"variable_load_timeout_ms"):1E4);
g.I(this,this.G);this.B=null;g.R(g.V(a).experiments,"enable_bulleit_buffer_timer")&&(this.B=new RL(g.R(g.V(a).experiments,"use_variable_buffer_timeout")?g.S(g.V(a).experiments,"variable_buffer_timeout_ms"):15E3,function(){f.Rb("buffer_timeout")}),g.I(this,this.B));
this.X=!g.R(g.V(a).experiments,"bulleit_unstarted_event_killswitch");this.J=!1;this.Y=new wja(e,c,b,this);this.Z=d};
bM=function(a){var b=new TL;b.adBadgeText="Ad";var c=a.o.A;1<c.l&&(b.adPodPositionInfoString=g.$L("$AD_INDEX of $ADS_COUNT",{AD_INDEX:String(c.g+1),ADS_COUNT:String(c.l)}));b.adBreakLengthSeconds=c.adBreakLengthSeconds;b.adBreakRemainingLengthSeconds=c.adBreakRemainingLengthSeconds;b.adPodPosition=c.g+1;b.adPodLength=c.l;if(a=a.o.B)b.adVideoId=a;return b};
eM=function(a){var b=a.o.g,c=b.playerOverlay&&b.playerOverlay.instreamAdPlayerOverlayRenderer;c||(c={});var d=g.V(a.g);if(g.py(d)&&!c.skipOrPreviewRenderer){var e=a.g.ec(2);(0,window.isFinite)(e)&&33<e&&!a.o.isSkippable()&&!g.py(d)&&g.M(Error("Instream ad is skippable by length, but was was marked "+("nonskippable. adLengthSecs:"+e+", IVAR: "+JSON.stringify(b))),"ERROR");d={};a.o.isSkippable()&&!VI(a.o)?d.skipAdRenderer=cM(a):d.adPreviewRenderer=dM(a,!1,VI(a.o));c.skipOrPreviewRenderer=d}c.skipOrPreviewRenderer&&
g.Qb(c.skipOrPreviewRenderer)&&g.M(Error("IAPOR.skipOrPreview was filled, but empty. IVAR: "+JSON.stringify(b)),"ERROR");return c};
cM=function(a){var b={preskipRenderer:{}};b.preskipRenderer.adPreviewRenderer=dM(a,!0,!1);b.skippableRenderer={};a=b.skippableRenderer;var c={message:{}};c.message.text="Skip Ad";a.skipButtonRenderer=c;return b};
dM=function(a,b,c){var d=a.g.getVideoData(1),e={};if(b||c){var f={},k={};c=c?g.$L("Your video will begin in $TIME_REMAINING",{NEW_LINE:"\n",TIME_REMAINING:"{TIME_REMAINING}"}):g.$L("You can skip to video in $TIME_REMAINING",{NEW_LINE:"\n",TIME_REMAINING:"{TIME_REMAINING}"});k.text=c;k.isTemplated=!0;f.templatedAdText=k;e.templatedCountdown=f}else f={},k=g.$L("Video will play after ad",{NEW_LINE:"\n"}),f.text=k,f.isTemplated=!1,e.staticPreview=f;b&&(e.durationMilliseconds=5E3);e.thumbnail={};b=e.thumbnail;
f={};f.url=g.my(g.V(a.g),d.videoId,"mqdefault.jpg");f.width=320;f.height=180;b.thumbnail={thumbnails:[f]};return e};
fM=function(a){return g.R(a.experiments,"tv_html5_bulleit_unify_adinfo")?qy(a)||g.gy(a):qy(a)||g.gy(a)&&!g.py(a)};
gM=function(a,b,c,d,e){var f=Object.assign({},{});f.FINAL=bK(lc("1"));f.SLOT_POS=bK(lc("0"));c=fK(c,eK(f));return b instanceof TI?(f={},f.SLOT_POS=bK(lc(b.A.g.toString())),c=fK(c,eK(f)),new aM(a,b,c,d,e)):b instanceof KJ?new AL(a,b,c):b instanceof $I?new yL(a,b,c):b instanceof FJ?new GL(a,b,c,d):b instanceof UJ?new IL(a,b,c,e):b instanceof LJ?new EL(a,b,c):b instanceof XI?new xL(a,b,c,d):b instanceof NJ?new rL(a,b,c,e):b instanceof QJ?new CL(a,b,c):b instanceof WI?new nL(a,b,c,d):b instanceof WJ?
new ML(a,b,c,e):b instanceof VJ?new KL(a,b,c):b instanceof OJ?new tL(a,b,c):b instanceof PJ?new vL(a,b,c,e):null};
Cja=function(a,b){this.l=a;this.g=b;this.o=a.ya()};
Eja=function(a,b){var c=void 0===c?Date.now():c;if(hM(a.g))for(var d=iM(a),e=g.q(b),f=e.next();!f.done;f=e.next()){f=f.value;var k=c;jM({cuepointTrigger:{type:"CUEPOINT_TYPE_AD",event:Dja(f.event),cuepointId:f.identifier,totalCueDurationMs:1E3*f.durationSecs,playheadTimeMs:f.l,cueStartTimeMs:1E3*f.g,cuepointReceivedTimeMs:k,contentCpn:d}});"unknown"===f.event&&kM("DAI_ERROR_TYPE_CUEPOINT_WITH_INVALID_EVENT",d);f=f.g+f.l/1E3;f>a.o&&a.l.ya()>f&&kM("DAI_ERROR_TYPE_LATE_CUEPOINT",d)}};
lM=function(a,b,c){hM(a.g)&&jM({daiStateTrigger:{totalCueDurationMs:b,filledAdsDurationMs:c,contentCpn:iM(a)}})};
iM=function(a){return(a=a.l.getVideoData(1))&&a.clientPlaybackNonce||void 0};
kM=function(a,b){jM({daiStateTrigger:{errorType:a,contentCpn:b}})};
jM=function(a){Nr("adsClientStateChange",a)};
Dja=function(a){switch(a){case "unknown":return"CUEPOINT_EVENT_UNKNOWN";case "start":return"CUEPOINT_EVENT_START";case "continue":return"CUEPOINT_EVENT_CONTINUE";case "stop":return"CUEPOINT_EVENT_STOP";case "predictStart":return"CUEPOINT_EVENT_PREDICT_START"}};
mM=function(a){this.l=a;this.Z=(a=!g.R(g.V(this.l).experiments,"html5_ad_csi_tracker_initialization_killswitch"))?g.V(this.l).l.c:g.ep("INNERTUBE_CLIENT_NAME",void 0);this.Y=a?g.V(this.l).l.cver:g.ep("INNERTUBE_CLIENT_VERSION",void 0);this.T=a?g.V(this.l).l.cbrand:"";this.R=a?g.V(this.l).l.cmodel:"";this.H="AD_PLACEMENT_KIND_UNKNOWN";this.A=this.G=this.C=this.B=null;this.g="unknown_type";this.J=!0;this.L=this.o=this.F=!1;this.O="vod"};
nM=function(a){a.B=null;a.C=null;a.G=null;a.A=null;a.H="AD_PLACEMENT_KIND_UNKNOWN";a.g="unknown_type";a.F=!1;a.o=!1};
Fja=function(a){switch(a){case "AD_PLACEMENT_KIND_START":return"1";case "AD_PLACEMENT_KIND_MILLISECONDS":case "AD_PLACEMENT_KIND_CUE_POINT_TRIGGERED":return"2";case "AD_PLACEMENT_KIND_END":return"3";default:return"unknown"}};
qM=function(a,b){var c=oM(a);pM(c,b)};
oM=function(a){a=[a,a.A].filter(function(a){return null!=a});
for(var b=g.q(a),c=b.next();!c.done;c=b.next())c.value.l=!0;return a};
pM=function(a,b){g.Jf(function(){g.nI(b.g,a,1);for(var c=g.q(a),d=c.next();!d.done;d=c.next())d=d.value,b.C["delete"](d),b.A["delete"](d)})};
rM=function(a,b,c,d,e,f,k,l){g.N.call(this);this.o=a;this.g=b;a=Object.assign({},{});a.MIDROLL_POS=ZJ(d)?bK(lc(Math.round(d.wb().start/1E3).toString())):bK(lc("0"));this.macros=fK(e,eK(a));this.ba=g.R(g.V(b).experiments,"bulleit_terminate_ad_when_ending_with_commands");this.A=d;this.C=this.A.g instanceof RI?this.A.g:null;this.l=null;this.Y=!1;this.J=c;this.Z=(c=b.getVideoData(1))&&c.ra||!1;this.da=0;this.ga=!1;this.ka=g.R(g.V(b).experiments,"abort_ad_on_browser_autoplay_blocked");this.L=f;this.R=
k;this.H=l;this.X=!1};
sM=function(a){hM(a.o);if(IK(a.g)){var b=a.g.getVideoData(2);(b=a.A.C[b.qd]||null)?(!a.l||a.l&&a.l.C!==b)&&a.Vb(b):a.Zj()}else 1===a.g.Da()&&a.l&&a.Zj()};
tM=function(a){(a=a.baseUrl)&&g.Vp(a,void 0,Ym.up(a))};
uM=function(a,b){var c=a.J,d=a.A.wb().o,e=a.vu(),f=a.xu();var k=a.isLiveStream()?"live":"vod";nM(c);var l=c.l.getVideoData(1),m=c.l.getVideoData(2);l&&(c.B=l.clientPlaybackNonce,c.G=l.videoId);m&&(c.C=m.clientPlaybackNonce,c.A=m.videoId);c.H=d;0>=f?nM(c):(c.g=c.J?b?"unknown_type":"video_to_ad":b?"ad_to_video":"ad_to_ad",c.O=k,c.L=e+1==f,c.F=!0,c.F&&((0,g.WB)("c",c.Z,c.g),(0,g.WB)("cver",c.Y,c.g),g.R(g.V(c.l).experiments,"html5_ad_csi_tracker_initialization_killswitch")||((0,g.WB)("cbrand",c.T,c.g),
(0,g.WB)("cmodel",c.R,c.g)),(0,g.WB)("yt_pt","html5",c.g),(0,g.WB)("yt_pre","2",c.g),(0,g.WB)("yt_abt",Fja(c.H),c.g),c.B&&(0,g.WB)("cpn",c.B,c.g),c.G&&(0,g.WB)("docid",c.G,c.g),c.C&&(0,g.WB)("ad_cpn",c.C,c.g),c.A&&(0,g.WB)("ad_docid",c.A,c.g),(0,g.WB)("yt_vst",c.O,c.g)))};
wM=function(a){vM(a.o,a.A.wb(),a);hM(a.o)&&!a.A.B&&(a.ku(),a.A.B=!0)};
xM=function(a,b,c,d){if(c>a.wb().end)return!1;var e=gM(a.g,b,a.macros,a.H,a.o);var f=a.R;var k=g.Za(f.g,c);0<=k?f=c:(k=-k-1,f=k>=f.g.length||f.g[k]>d?null:f.g[k]);f=Math.min(d,a.wb().end,null===f?window.Infinity:f);c=e.ju(c,f);if(!c)return!1;a.A.C[c]=b;return f===d};
Gja=function(a){if(a.ga)return function(a){a.Ab(window.Infinity,!0)};
var b=Math.floor((0,g.D)()/1E3)-a.da;return function(a){a.Ab(a.ya()+b,!0)}};
yM=function(a,b,c,d,e,f){eL.call(this,b,d.g,e,void 0,f);this.O=c;this.H=d;this.o=d.g;this.J=a;this.B=this.G=null;a=this.H.wb();a.visible=!1;vM(this.J,a,this)};
Hja=function(a){return zM(a.renderer&&a.renderer.adBreakServiceRenderer&&a.renderer.adBreakServiceRenderer.getAdBreakUrl||"")};
zM=function(a){if(!a)return!1;a=Mg(a,"post_data");if(!a)return!1;try{var b=(0,window.decodeURIComponent)(a)}catch(c){return g.M(c),!1}return b?b.split("&").some(function(a){a=a.split("=");return 1<a.length&&"pat"==a[0]}):!1};
Ija=function(a){return a&&a.renderer&&a.renderer.invideoOverlayAdRenderer?!0:!1};
Jja=function(a){if(a&&a.config&&a.config.adPlacementConfig&&a.renderer){var b=a.config.adPlacementConfig;a=a.renderer.backfillMpuCompanionAdRenderer;return!(!("AD_PLACEMENT_KIND_START"==b.kind||"AD_PLACEMENT_KIND_MILLISECONDS"==b.kind&&b.adTimeOffset&&"0"==b.adTimeOffset.offsetStartMilliseconds)||!a)}return!1};
AM=function(a,b,c,d,e){g.N.call(this);this.l=a;this.C=b;this.F=g.R(g.V(b).experiments,"bulleit_gmi_assume_empty_is_throttled");this.B=c;this.g=d;this.o=!1;this.A=e;Kja(this)};
Lja=function(a,b){var c=null,d={isEmpty:!0,qv:!1,Qn:[]};try{c=JSON.parse(b.response)}catch(f){return b.response&&g.M(f),d}if(!c)return d;if(c&&c.adThrottled)return d.qv=!0,d;c=c.playerAds;if(!c||!c.length)return d;c=c.map(function(a){return a.adPlacementRenderer}).filter(function(a){return a&&null!=a.renderer});
if(0==c.length)return d;if(0<a.g.wb().end){var e=a.g.wb().end.toString();c.forEach(function(a){(a=a.config&&a.config.adPlacementConfig)&&"AD_PLACEMENT_KIND_MILLISECONDS"==a.kind&&"-1"==a.adTimeOffset.offsetEndMilliseconds&&a.adTimeOffset.offsetEndMilliseconds!=e&&(a.adTimeOffset.offsetEndMilliseconds=e)})}d.Qn=c;
d.isEmpty=!1;return d};
Kja=function(a){[a.g.J,a.g.wb()].filter(function(a){return null!=a}).forEach(function(b){vM(a.l,b,a)})};
CM=function(a,b,c,d,e,f,k,l){rM.call(this,a,b,c,d,e,f,k,l);this.F=d.g;this.G=-1;this.T=this.B=null;this.O=BM(this.Go())};
DM=function(a){var b=a.F.l;b&&(a.B=gM(a.g,b,a.macros,a.H,a.o),a.B.subscribe("onAdUxUpdate",a.Mw,a),fL(a.B))};
FM=function(a,b){a.G++;var c=EM(a);c.length&&c[0].length?a.Vb(c[0][void 0===b?0:b]):a.kf()};
BM=function(a){return a?Mja.some(function(b){return a instanceof b}):!1};
EM=function(a){return 0>=a.G?a.F.g:a.F.g.slice(a.G)};
GM=function(a){g.G.call(this);var b=this;this.l=a;this.g=null;g.We(this,function(){return b.g=null});
var c=g.wq(a);if(c){var d=function(){b.g&&b.g(!!g.uq())};
this.l.addEventListener(c,d);g.We(this,function(){b.l.removeEventListener(c,d)})}};
HM=function(a){g.G.call(this);this.g=a};
Nja=function(a){var b=window.document;return g.py(g.V(a))?new GM(b):new HM(a)};
Oja=function(a){this.A=a;a=g.V(a).experiments;this.o=g.R(a,"enable_html5_midroll_tsla_update")||g.R(a,"enable_html5_midroll_tsla_update_for_living_room");this.l=!1;this.g=-1};
IM=function(a){a.g=(0,g.D)()/1E3;if(!a.l||a.o)g.Vp(g.V(a.A).baseYtUrl+"mac_204?action_fcts=1"),a.l=!0};
Pja=function(a){return 0<a.g?Math.ceil((0,g.D)()/1E3-a.g):0};
KM=function(a){JM=a&&a.data};
MM=function(a){LM=a&&a.data};
NM=function(){JM=null};
OM=function(a,b){g.N.call(this);var c=this;this.g=a;this.X=null;this.Ca=b;this.oa=new BK(a,KK(a)?null:new vK);this.o=null;this.O=zaa(function(){c.g.ea()||g.pI(c.g,"ad")});
this.l=null;this.A=new window.Map;this.ka=new EK(a);g.I(this,this.ka);this.C=new window.Set;this.T=-1;this.F=[];this.G=null;this.da=new Oja(a);this.J=new window.Set;this.Ja=new Uia(a);this.ca=new g.Pq(this);g.I(this,this.ca);this.B=new g.Pq(this);g.I(this,this.B);this.Z=this.ga=this.Y=!1;this.R=null;this.L=g.py(g.V(a));var d=new nK;g.I(this,d);[new PI(this),new QI(this),new jK(new iK(a)),new lK,new uK].forEach(function(a){return oK(d,a)});
g.R(g.V(a).experiments,"enable_mute_ad_endpoint_resolution_on_bulleit")?oK(d,new kK(this)):mK(d,"muteAdEndpoint",function(){});
["adInfoDialogEndpoint","adFeedbackEndpoint"].forEach(function(a){return mK(d,a,function(){})});
this.sa=d;this.pa=new Cja(this.g,this);this.H=new CK;g.I(this,this.H);this.H.subscribe("Identified a new cuerange",this.kK,this);this.H.subscribe("Shortened the latest cuerange",this.zJ,this);this.wa=new DK(this.H);this.ba=Nja(this.g);g.I(this,this.ba);this.Ia=g.uy(g.V(this.g))?g.R(g.V(a).experiments,"align_ad_to_video_player_lifecycle_for_bulleit_living_room"):g.R(g.V(a).experiments,"align_ad_to_video_player_lifecycle_for_bulleit")};
Qja=function(a){return a&&a.adPlacements?a.adPlacements.map(function(a){return a.adPlacementRenderer}).filter(function(a){return a&&null!=a.renderer}):[]};
Rja=function(a,b){return b.filter(function(b){return"AD_PLACEMENT_KIND_CUE_POINT_TRIGGERED"==(b.config&&b.config.adPlacementConfig&&b.config.adPlacementConfig.kind||null)?(a.G=b,!1):!0})};
Sja=function(a,b){return b.every(function(b){b=a.A.get(b);return null==b?(g.M(Error("AdCueRange without a corresponding AdPlacement.")),!0):b instanceof AM?!1:b instanceof rM?!b.Ye():!0})};
PM=function(a){var b=Tja(a);0<b.length?(Sja(a,b)&&a.O(),g.Jf(function(){if(!a.ea())for(var c=g.q(b),d=c.next();!d.done;d=c.next())a.Gm(d.value)})):a.O()};
Uja=function(a,b){if(!b)return{};var c=!!a.l&&a.l||null;c?(c=c.l,c=c.C.vj()?aL(c.l,b):{}):c={};return c};
Tja=function(a){for(var b=[],c=g.q(a.C),d=c.next();!d.done;d=c.next())d=d.value,JI(d)&&b.push(d);c=g.q(b);for(d=c.next();!d.done;d=c.next())a.C["delete"](d.value);return b};
QM=function(a,b,c){c=void 0===c?null:c;if(b.some(Hja)){var d=b.findIndex(Jja);var e=null;-1!=d&&(e=b[d],b.splice(d,1));d=e}else d=null;a.R=d;var f=c;f=void 0===f?null:f;c=a.Ja;d=1E3*a.g.ec(1);e=a.g.getVideoData(1).ra||!1;d=new HI(d,1E3*a.g.ya()||0,e);e=a.F.length;var k=f;e=void 0===e?0:e;k=void 0===k?null:k;f=[];var l=0;if(k){k=g.q(k);for(var m=k.next();!m.done;m=k.next()){m=m.value;var n=d,p=new HI(n.A,n.o,n.livestream),u=n.g;u&&(p.g=new Ru(u.g,u.durationSecs,u.context,u.identifier,u.event,u.l));
n.l&&(p.l=n.l);p.visible=n.visible;n=p;n.g=m;f.push(aK(b[0],e+l,c,n));l++}}else for(b=g.q(b),k=b.next();!k.done;k=b.next())f.push(aK(k.value,e+l,c,d)),l++;a.F=a.F.concat(f);if(0!=f.length)for(b=eK(cK(a.g)),c=g.q(f),f=c.next();!f.done;f=c.next())d=a,e=a.g,m=a.Ca,n=a.oa,p=f.value,k=a.pa,l=a.wa,f=a.ka,p.g instanceof YI?(m=p,d=new CM(d,e,new mM(e),m,b,k,l,f),wM(d)):p.g instanceof bJ?new yM(d,e,n,p,b,f):""==p.l?(m=p,d=new rM(d,e,new mM(e),m,b,k,l,f),wM(d)):new AM(d,e,m,p,k)};
UM=function(a,b){b.Xl()?(g.Xe(a.o),a.o=b):((b.Aj()||b.C instanceof UJ)&&a.o&&a.o.wb().start<b.wb().start&&RM(a),b.ov()&&(a.l&&SM(a,hM(a)),a.l=b,b.Ye()&&TM(a)))};
RM=function(a){var b=a.oa;if(b.g)b.g&&nja(b.g);else{var c=b.l.getVideoData(1);b.l.na("updateKevlarOrC3Companion",{contentVideoId:c&&c.videoId})}g.Xe(a.o);a.o=null};
TM=function(a){a.Y||(a.B.M(a.g,"presentingplayerstatechange",a.IG),a.B.M(a.g,"internalAbandon",a.ZH),a.B.M(a.g,"progresssync",a.XL),a.B.M(a.g,"onVolumeChange",a.KG),a.B.M(a.ba,"fullscreentoggled",a.HG),a.Y=!0);g.xn(a.g.getRootNode(),["ad-showing","ad-interrupting"]);hM(a)||g.VM(a.g.app,2)};
SM=function(a,b,c){var d=!!a.l&&a.l||null,e=d&&d.Ye()&&(IK(a.g)||hM(a));d=b&&d&&d.reset()||null;a.l&&WM(a,a.l);a.l=null;a.T=-1;e&&XM(a,c);a.Z||a.O();b&&d&&(d.wb().l=!1,wM(d))};
XM=function(a,b){g.Rq(a.B);a.Y=!1;g.zn(a.g.getRootNode(),["ad-showing","ad-interrupting"]);hM(a)||(a.Ia?(a.Z||a.O(),YM(a),a.g.wm({},2)):(a.g.wm({},2),YM(a)));b&&b(a.g)};
YM=function(a){if(a.ga)!a.L&&g.gy(g.V(a.g))&&g.R(g.V(a.g).experiments,"release_player_on_abandon_for_bulleit_living_room")&&g.BI(a.g,2);else if(g.BI(a.g,2),!a.L){var b=g.YH(a.g);g.U(b,4)&&!g.U(b,2)&&a.g.Kb()}};
vM=function(a,b,c){if(b instanceof II){if(a.L&&KI(b)&&g.U(g.YH(a.g),64)){var d=1E3*a.g.ya()||0;d!=b.start&&b.contains(d)&&(b.l=!0)}a.A.has(b)?g.M(Error(b.toString()+" has already been seen")):(a.C.add(b),a.A.set(b,c),JI(b)||g.kI(a.g,[b],1))}else g.M(Error("Should use AdCueRange instead of CueRange"))};
WM=function(a,b){for(var c=a.A,d=g.q(c),e=d.next();!e.done;e=d.next()){e=g.q(e.value);var f=e.next().value;if(e.next().value==b){c["delete"](f);break}}g.Xe(b)};
aN=function(a,b){var c=a.g.app;1==b&&((0,g.VB)("vr",void 0,""),c.wa||(c.wa=vz(c.Rx,c)),JH(c.o),XB(c.pa,c.o.getVideoData(),ZM(c)));var d=c.g;(g.uy(d)&&d.sb||g.hy(d))&&($M(c)||c.l.na("onAdStateChange",b));switch(b){case 1:a.T=1;break;case 0:a.T=0}};
bN=function(a){return IK(a.g)&&a.l.Aj()};
hM=function(a){if(!g.py(g.V(a.g))||!a.g.getVideoData(1).xf()||0===a.F.length)return!1;a=g.q(a.F);for(var b=a.next();!b.done;b=a.next())if(b=b.value.g,null!=b&&!b.Rh())return!1;return!0};
cN=function(a){return a&&a.thumbnails&&0!=(a.thumbnails||null).length&&a.thumbnails[0].url?g.qb(a.thumbnails[0].url):""};
dN=function(a,b,c,d){d=void 0===d?!1:d;Y.call(this,a,b,{D:"img",I:"ytp-ad-image"},"ad-image",void 0===c?null:c);this.o=d;this.hide()};
g.fN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-cast-desktop-on"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,N:{d:"M7,24 L7,27 L10,27 C10,25.34 8.66,24 7,24 L7,24 Z M7,20 L7,22 C9.76,22 12,24.24 12,27 L14,27 C14,23.13 10.87,20 7,20 L7,20 Z M25,13 L11,13 L11,14.63 C14.96,15.91 18.09,19.04 19.37,23 L25,23 L25,13 L25,13 Z M7,16 L7,18 C11.97,18 16,22.03 16,27 L18,27 C18,20.92 13.07,16 7,16 L7,16 Z M27,9 L9,9 C7.9,9 7,9.9 7,11 L7,14 L9,14 L9,11 L27,11 L27,25 L20,25 L20,27 L27,27 C28.1,27 29,26.1 29,25 L29,11 C29,9.9 28.1,9 27,9 L27,9 Z",
fill:"#fff"}}]}};
g.gN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-chevron-back"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 32 32",width:"100%"},K:[{D:"path",N:{d:"M 19.41,20.09 14.83,15.5 19.41,10.91 18,9.5 l -6,6 6,6 z",fill:"#fff"}}]}};
g.hN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-chevron-forward"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 32 32",width:"100%"},K:[{D:"path",N:{d:"m 12.59,20.34 4.58,-4.59 -4.58,-4.59 1.41,-1.41 6,6 -6,6 z",fill:"#fff"}}]}};
iN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-clip-clear"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 14 14",width:"100%"},K:[{D:"path",N:{d:"M14,14 L14,0 L0,0 L0,14 L14,14 Z"}},{D:"path",N:{d:"M7.15,8.35 L9.25,10.45 L10.65,9.05 L8.55,6.95 L10.7,4.8 L9.3,3.4 L7.15,5.55 L5,3.4 L3.6,4.8 L5.75,6.95 L3.65,9.05 L5.05,10.45 L7.15,8.35 Z",fill:"#fff"}}]}};
jN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-clip-end"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 14 14",width:"100%"},K:[{D:"path",La:!0,N:{d:"M2,14 L5,11 L5,3 L2,0 L9,0 L9,14 L2,14 L2,14 Z",fill:"#eaeaea"}}]}};
kN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-clip-start"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 14 14",width:"100%"},K:[{D:"path",La:!0,N:{d:"M12,14 L9,11 L9,3 L12,0 L5,0 L5,14 L12,14 Z",fill:"#eaeaea"}}]}};
g.lN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-close"]}:{D:"svg",N:{height:"100%",viewBox:"0 0 24 24",width:"100%"},K:[{D:"path",N:{d:"M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",fill:"#fff"}}]}};
g.mN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-dislike"]}:{D:"svg",N:{viewBox:"0 0 24 24"},K:[{D:"path",N:{d:"M0 0h24v24H0z",fill:"none"}},{D:"path",N:{d:"M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v1.91l.01.01L1 14c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z",fill:"#fff"}}]}};
g.nN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-like"]}:{D:"svg",N:{viewBox:"0 0 24 24"},K:[{D:"path",N:{d:"M0 0h24v24H0z",fill:"none"}},{D:"path",N:{d:"M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-1.91l-.01-.01L23 10z",fill:"#fff"}}]}};
g.oN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-next"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,I:"ytp-svg-fill",N:{d:"M 12,24 20.5,18 12,12 V 24 z M 22,12 v 12 h 2 V 12 h -2 z"}}]}};
g.pN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-notifications-active"]}:{D:"svg",N:{fill:"#fff",height:"24px",viewBox:"0 0 24 24",width:"24px"},K:[{D:"path",N:{d:"M7.58 4.08L6.15 2.65C3.75 4.48 2.17 7.3 2.03 10.5h2c.15-2.65 1.51-4.97 3.55-6.42zm12.39 6.42h2c-.15-3.2-1.73-6.02-4.12-7.85l-1.42 1.43c2.02 1.45 3.39 3.77 3.54 6.42zM18 11c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2v-5zm-6 11c.14 0 .27-.01.4-.04.65-.14 1.18-.58 1.44-1.18.1-.24.15-.5.15-.78h-4c.01 1.1.9 2 2.01 2z"}}]}};
g.qN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-pause"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,I:"ytp-svg-fill",N:{d:"M 12,26 16,26 16,10 12,10 z M 21,26 25,26 25,10 21,10 z"}}]}};
g.rN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-play"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,I:"ytp-svg-fill",N:{d:"M 12,26 18.5,22 18.5,14 12,10 z M 18.5,22 25,18 25,18 18.5,14 z"}}]}};
g.sN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-prev"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,I:"ytp-svg-fill",N:{d:"m 12,12 h 2 v 12 h -2 z m 3.5,6 8.5,6 V 12 z"}}]}};
g.tN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-replay"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,I:"ytp-svg-fill",N:{d:"M 18,11 V 7 l -5,5 5,5 v -4 c 3.3,0 6,2.7 6,6 0,3.3 -2.7,6 -6,6 -3.3,0 -6,-2.7 -6,-6 h -2 c 0,4.4 3.6,8 8,8 4.4,0 8,-3.6 8,-8 0,-4.4 -3.6,-8 -8,-8 z"}}]}};
g.uN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-settings"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,N:{d:"m 23.94,18.78 c .03,-0.25 .05,-0.51 .05,-0.78 0,-0.27 -0.02,-0.52 -0.05,-0.78 l 1.68,-1.32 c .15,-0.12 .19,-0.33 .09,-0.51 l -1.6,-2.76 c -0.09,-0.17 -0.31,-0.24 -0.48,-0.17 l -1.99,.8 c -0.41,-0.32 -0.86,-0.58 -1.35,-0.78 l -0.30,-2.12 c -0.02,-0.19 -0.19,-0.33 -0.39,-0.33 l -3.2,0 c -0.2,0 -0.36,.14 -0.39,.33 l -0.30,2.12 c -0.48,.2 -0.93,.47 -1.35,.78 l -1.99,-0.8 c -0.18,-0.07 -0.39,0 -0.48,.17 l -1.6,2.76 c -0.10,.17 -0.05,.39 .09,.51 l 1.68,1.32 c -0.03,.25 -0.05,.52 -0.05,.78 0,.26 .02,.52 .05,.78 l -1.68,1.32 c -0.15,.12 -0.19,.33 -0.09,.51 l 1.6,2.76 c .09,.17 .31,.24 .48,.17 l 1.99,-0.8 c .41,.32 .86,.58 1.35,.78 l .30,2.12 c .02,.19 .19,.33 .39,.33 l 3.2,0 c .2,0 .36,-0.14 .39,-0.33 l .30,-2.12 c .48,-0.2 .93,-0.47 1.35,-0.78 l 1.99,.8 c .18,.07 .39,0 .48,-0.17 l 1.6,-2.76 c .09,-0.17 .05,-0.39 -0.09,-0.51 l -1.68,-1.32 0,0 z m -5.94,2.01 c -1.54,0 -2.8,-1.25 -2.8,-2.8 0,-1.54 1.25,-2.8 2.8,-2.8 1.54,0 2.8,1.25 2.8,2.8 0,1.54 -1.25,2.8 -2.8,2.8 l 0,0 z",
fill:"#fff"}}]}};
g.vN=function(){return g.eN?{D:"div",W:["ytp-icon","ytp-icon-stop"]}:{D:"svg",N:{height:"100%",version:"1.1",viewBox:"0 0 36 36",width:"100%"},K:[{D:"path",La:!0,I:"ytp-svg-fill",N:{d:"M 12,25 19,25 19,11 12,11 z M 19,25 26,25 26,11 19,11 z"}}]}};
wN=function(a){if(!a)return null;switch(a.iconType){case "OPEN_IN_NEW":return{D:"svg",N:{fill:"#fff",height:"100%",version:"1.1",viewBox:"0 0 48 48",width:"100%"},K:[{D:"path",N:{d:"M0 0h48v48H0z",fill:"none"}},{D:"path",N:{d:"M38 38H10V10h14V6H10c-2.21 0-4 1.79-4 4v28c0 2.21 1.79 4 4 4h28c2.21 0 4-1.79 4-4V24h-4v14zM28 6v4h7.17L15.51 29.66l2.83 2.83L38 12.83V20h4V6H28z"}}]};case "CHECK_BOX":return g.eN?{D:"div",W:["ytp-icon","ytp-icon-check-box"]}:{D:"svg",N:{height:"100%",viewBox:"0 0 24 24",width:"100%"},
K:[{D:"path",N:{d:"M0 0h24v24H0z",fill:"none"}},{D:"path",N:{d:"M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z",fill:"#d4d4d4"}}]};case "CHECK_BOX_OUTLINE_BLANK":return g.eN?{D:"div",W:["ytp-icon","ytp-icon-check-box-outline-blank"]}:{D:"svg",N:{height:"100%",viewBox:"0 0 24 24",width:"100%"},K:[{D:"path",N:{d:"M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z",fill:"#d4d4d4"}},
{D:"path",N:{d:"M0 0h24v24H0z",fill:"none"}}]};case "CLOSE":return g.lN();case "INFO_OUTLINE":return{D:"svg",N:{fill:"#fff",height:"100%",version:"1.1",viewBox:"0 0 48 48",width:"100%"},K:[{D:"path",N:{d:"M0 0h48v48H0z",fill:"none"}},{D:"path",N:{d:"M22 34h4V22h-4v12zm2-30C12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20S35.05 4 24 4zm0 36c-8.82 0-16-7.18-16-16S15.18 8 24 8s16 7.18 16 16-7.18 16-16 16zm-2-22h4v-4h-4v4z"}}]};case "REMOVE_CIRCLE":return{D:"svg",N:{fill:"#fff",height:"100%",version:"1.1",
viewBox:"0 0 24 24",width:"100%"},K:[{D:"path",N:{d:"M0 0h24v24H0z",fill:"none"}},{D:"path",N:{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z",fill:"#757575"}}]};case "SKIP_NEXT":return g.oN();case "LIKE":return g.nN();case "DISLIKE":return g.mN();default:return g.M(Error("Unexpected icon "+a),"WARNING"),null}};
xN=function(a,b,c,d,e){c=void 0===c?[]:c;e=void 0===e?!1:e;Y.call(this,a,b,{D:"button",W:["ytp-ad-button"].concat(c)},void 0===d?"button":d);this.A=this.o=this.C=null;this.F=e;this.hide()};
Vja=function(a){var b=null;null!=a.A&&(b=[a.A.serviceEndpoint,a.A.navigationEndpoint].filter(function(a){return null!=a}));
return b||[]};
yN=function(a,b,c,d,e){Y.call(this,a,b,c,d);this.o=e;g.I(this,this.o);this.ha=this.F=-1};
zN=function(a){a.o&&-1===a.F&&(a.F=a.o.subscribe("s",a.nh,a),a.ha=a.o.subscribe("r",a.pi,a),a.nh())};
AN=function(a){null!=a.o&&-1!==a.F&&(a.o.Ac(a.F),a.o.Ac(a.ha),a.ha=-1,a.F=-1)};
BN=function(a,b,c){yN.call(this,a,b,{D:"div",I:"ytp-ad-timed-pie-countdown-container",K:[{D:"svg",I:"ytp-ad-timed-pie-countdown",N:{viewBox:"0 0 20 20"},K:[{D:"circle",I:"ytp-ad-timed-pie-countdown-inner",N:{r:"5",cx:"10",cy:"10"}},{D:"circle",I:"ytp-ad-timed-pie-countdown-outer",N:{r:"10",cx:"10",cy:"10"}}]}]},"timed-pie-countdown",c);this.B=this.g["ytp-ad-timed-pie-countdown-inner"];this.A=Math.ceil(10*3.14);this.hide()};
CN=function(a,b,c,d){Y.call(this,a,b,{D:"div",I:"ytp-ad-text"},void 0===d?"ad-text":d,void 0===c?null:c);this.o=null;this.hide()};
DN=function(a,b){b&&g.Gd(a.element,iJ(a.o,b))};
g.EN=function(a,b,c,d,e,f){e=void 0===e?null:e;f=void 0===f?null:f;g.G.call(this);this.o=a;c||a.hide();this.C=b;this.F=null==d?b:d;this.A=f;this.B=e;this.g=null;this.l=new g.L(this.An,0,this);g.I(this,this.l)};
FN=function(a,b){var c=a.o.element;b?c.setAttribute("aria-hidden",!0):c.removeAttribute("aria-hidden")};
GN=function(a,b,c,d){yN.call(this,a,b,{D:"div",I:"ytp-ad-preview-slot"},"ad-preview",c);var e=this;this.ba=-1;this.A=new g.Ns({D:"span",I:"ytp-ad-preview-container"});g.I(this,this.A);this.B=new CN(this.api,this.l,"ytp-ad-preview-text");g.I(this,this.B);this.B.aa(this.A.element);this.R=new g.Ns({D:"span",I:"ytp-ad-preview-image"});g.I(this,this.R);this.C=new dN(this.api,this.l);g.I(this,this.C);this.C.aa(this.R.element);this.R.aa(this.A.element);this.A.aa(this.element);this.H=new g.EN(this.A,400,
!1,100,function(){return e.hide()});
g.I(this,this.H);this.J=0;this.X=!1;this.ka=d;this.hide()};
HN=function(a,b,c){c=void 0===c?!0:c;g.N.call(this);this.B=b;this.C=new g.Pq(this);g.I(this,this.C);this.l=a;this.Fa=new g.jg(100);g.I(this,this.Fa);this.C.M(this.Fa,"tick",this.IH);this.A={seekableStart:0,seekableEnd:a/1E3,current:0};this.o=!1;this.g=0;c&&this.start()};
IN=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-action-interstitial",K:[{D:"div",I:"ytp-ad-action-interstitial-background-container"},{D:"div",I:"ytp-ad-action-interstitial-slot",K:[{D:"div",I:"ytp-ad-action-interstitial-card",K:[{D:"div",I:"ytp-ad-action-interstitial-image-container"},{D:"div",I:"ytp-ad-action-interstitial-headline-container"},{D:"div",I:"ytp-ad-action-interstitial-description-container"},{D:"div",I:"ytp-ad-action-interstitial-action-button-container"}]}]}]},"ad-action-interstitial");
this.ha=this.g["ytp-ad-action-interstitial-image-container"];this.C=new dN(this.api,this.l,"ytp-ad-action-interstitial-image");g.I(this,this.C);this.C.aa(this.ha);this.ba=this.g["ytp-ad-action-interstitial-headline-container"];this.J=new CN(this.api,this.l,"ytp-ad-action-interstitial-headline");g.I(this,this.J);this.J.aa(this.ba);this.X=this.g["ytp-ad-action-interstitial-description-container"];this.H=new CN(this.api,this.l,"ytp-ad-action-interstitial-description");g.I(this,this.H);this.H.aa(this.X);
this.oa=this.g["ytp-ad-action-interstitial-background-container"];this.F=new dN(this.api,this.l,"ytp-ad-action-interstitial-background",!0);g.I(this,this.F);this.F.aa(this.oa);this.ka=this.g["ytp-ad-action-interstitial-action-button-container"];this.B=this.A=this.o=null;this.ca=new g.Pq;g.I(this,this.ca);this.R=null;this.hide()};
JN=function(a){var b=g.jd("html5-video-player");b&&g.K(b,"ytp-ad-display-override",a)};
KN=function(a,b,c){c=void 0===c?!1:c;Y.call(this,a,b,{D:"span",I:"ytp-ad-simple-ad-badge"},"simple-ad-badge");this.o=c;this.hide()};
LN=function(a,b,c){Y.call(this,a,b,{D:"div",I:"ytp-ad-image-button-container",K:[{D:"div",I:"ytp-ad-image-button-thumbnail"},{D:"div",I:"ytp-ad-image-button-text"}]},"ad-image-button",void 0===c?null:c);this.o=null;this.hide()};
g.MN=function(a){var b=Math.abs(Math.floor(a)),c=Math.floor(b/86400),d=Math.floor(b%86400/3600),e=Math.floor(b%3600/60);b=Math.floor(b%60);var f="";0<c&&(f+=c+":",10>d&&(f+="0"));if(0<c||0<d)f+=d+":",10>e&&(f+="0");f+=e+":";10>b&&(f+="0");f+=b;return 0<=a?f:"-"+f};
g.NN=function(a){return(!g.ta(a.button)||0==a.button)&&!a.shiftKey&&!a.altKey&&!a.metaKey&&!a.ctrlKey};
ON=function(a,b,c){yN.call(this,a,b,{D:"span",I:"ytp-ad-duration-remaining"},"ad-duration-remaining",c);this.A=null;this.hide()};
PN=function(a,b,c,d,e,f){d=void 0===d?!1:d;e=void 0===e?[]:e;Y.call(this,a,b,{D:"span",W:["ytp-ad-hover-text-button"].concat(e)},void 0===f?"ad-hover-text-button":f);this.button=this.A=null;this.F=d;this.C=c;this.hide()};
QN=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-feedback-dialog-background",K:[{D:"div",I:"ytp-ad-feedback-dialog-container",K:[{D:"div",I:"ytp-ad-feedback-dialog-form",K:[{D:"div",I:"ytp-ad-feedback-dialog-title",K:[{D:"span",V:"{{title}}"}]},{D:"span",I:"ytp-ad-info-dialog-feedback-options-title",V:"{{reasonsTitle}}"},{D:"div",I:"ytp-ad-info-dialog-feedback-options"},{D:"div",I:"ytp-ad-feedback-dialog-confirm-container",K:[{D:"button",I:"ytp-ad-feedback-dialog-cancel-button",V:"{{cancelLabel}}"},
{D:"button",I:"ytp-ad-feedback-dialog-confirm-button",V:"{{confirmLabel}}"}]}]}]}]},"ad-info-dialog");this.B=[];this.o=null;this.C=this.g["ytp-ad-feedback-dialog-cancel-button"];this.F=this.g["ytp-ad-feedback-dialog-confirm-button"];this.H=this.g["ytp-ad-info-dialog-feedback-options"];this.J=this.g["ytp-ad-feedback-dialog-title"];this.A=null;this.hide()};
Zja=function(a,b){var c=b.cancelRenderer&&b.cancelRenderer.buttonRenderer||null;c&&(a.o=new xN(a.api,a.l,["ytp-ad-feedback-dialog-close-button"],"button"),g.I(a,a.o),a.o.init(X("button"),c,a.macros),a.o.fa("click",a.rx,a),a.o.aa(a.element));b.title&&(c=g.Wz(b.title),a.updateValue("title",c));b.reasonsTitle&&(c=g.Wz(b.reasonsTitle),a.updateValue("reasonsTitle",c));b.reasons&&Wja(a,b.reasons);b.cancelLabel&&(c=g.Wz(b.cancelLabel),a.updateValue("cancelLabel",c),g.Cq(a.C,"click",function(){return a.rx()}));
b.confirmLabel&&(c=g.Wz(b.confirmLabel),a.updateValue("confirmLabel",c),g.Cq(a.F,"click",function(){return Xja(a)}));
b.undoRenderer&&Yja(a,b.undoRenderer)};
Wja=function(a,b){for(var c=g.q(b),d=c.next();!d.done;d=c.next()){var e=d.value;d=e.reason;null==d?g.M(Error("AdFeedbackReason.reason was not set."),"WARNING"):(e=e.endpoint,null==e?g.M(Error("AdFeedbackReason.endpoint was not set."),"WARNING"):(d=new RN(d,e),g.I(a,d),a.H.appendChild(d.ia()),a.B.push(d)))}};
Yja=function(a,b){var c=b&&b.buttonRenderer||null;c&&(c.serviceEndpoint?(a.A=new xN(a.api,a.l,["ytp-ad-feedback-dialog-undo-mute-button"],"ad-feedback-undo-mute-button"),g.I(a,a.A),a.A.init(X("ad-feedback-undo-mute-button"),c,a.macros),a.A.fa("click",a.PL,a),a.A.aa(a.J)):g.M(Error("AdFeedbackRenderer.undoRenderer.undoButtonRenderer was specified but did not contain a service endpoint."),"WARNING"))};
Xja=function(a){var b=a.B.filter(function(a){return a.o.checked});
0!==b.length&&(a.l.Ka(b[0].l,a.macros),a.api.nd("ad-feedback-dialog-confirm-button"),a.P("u"),a.hide())};
RN=function(a,b){this.l=b;this.g=new g.Ns({D:"label",I:"ytp-ad-feedback-dialog-reason-label",K:[{D:"input",I:"ytp-ad-feedback-dialog-reason-input",N:{type:"radio",name:"feedback-reason-group"}},{D:"span",I:"ytp-ad-feedback-dialog-reason-text",V:g.Wz(a)}]});this.o=this.g.g["ytp-ad-feedback-dialog-reason-input"]};
SN=function(a,b,c,d){c=void 0===c?[]:c;d=void 0===d?"confirm-dialog":d;Y.call(this,a,b,{D:"div",W:["ytp-ad-confirm-dialog-background"],K:[{D:"div",I:"ytp-ad-confirm-dialog-container",K:[{D:"div",W:["ytp-ad-confirm-dialog"].concat(c),K:[{D:"div",I:"ytp-ad-confirm-dialog-title",V:"{{title}}"},{D:"div",I:"ytp-ad-confirm-dialog-messages"},{D:"div",I:"ytp-ad-confirm-dialog-confirm-container",K:[{D:"button",I:"ytp-ad-confirm-dialog-cancel-button",V:"{{cancelLabel}}"},{D:"button",I:"ytp-ad-confirm-dialog-confirm-button",
V:"{{confirmLabel}}"}]}]}]},{D:"button",W:["ytp-ad-confirm-dialog-close-overlay-button","ytp-ad-button","ytp-ad-button-link"],K:[{D:"span",I:"ytp-ad-button-icon",K:[g.lN()]}]}]},d);this.A=this.g["ytp-ad-confirm-dialog-close-overlay-button"];this.B=this.g["ytp-ad-confirm-dialog-cancel-button"];this.F=this.g["ytp-ad-confirm-dialog-confirm-button"];this.C=this.g["ytp-ad-confirm-dialog-messages"];this.ca=new g.Pq;g.I(this,this.ca);this.o=null;this.hide()};
$ja=function(a,b){if(b.title){var c=g.Wz(b.title);a.updateValue("title",c)}if(b.dialogMessages){c=g.q(b.dialogMessages);for(var d=c.next();!d.done;d=c.next())d=tJ(d.value),a.C.appendChild(d)}b.cancelLabel&&(c=g.Wz(b.cancelLabel),a.updateValue("cancelLabel",c),a.ca.M(a.B,"click",function(b){return a.Rq(b)}));
b.confirmLabel&&(c=g.Wz(b.confirmLabel),a.updateValue("confirmLabel",c),a.ca.M(a.F,"click",function(b){return a.Tq(b)}));
a.ca.M(a.A,"click",function(b){return a.Sq(b)})};
TN=function(a,b){SN.call(this,a,b,[],"ad-mute-confirm-dialog")};
UN=function(a,b,c){Y.call(this,a,b,{D:"div",I:"ytp-ad-info-dialog-background",K:[{D:"div",I:"ytp-ad-info-dialog-container",K:[{D:"div",I:"ytp-ad-info-dialog-form",K:[{D:"div",I:"ytp-ad-info-dialog-title",V:"{{title}}"},{D:"ul",I:"ytp-ad-info-dialog-ad-reasons"},{D:"div",I:"ytp-ad-info-dialog-message"},{D:"div",I:"ytp-ad-info-dialog-mute-container"},{D:"div",I:"ytp-ad-info-dialog-confirm-container",K:[{D:"button",I:"ytp-ad-info-dialog-confirm-button",V:"{{confirmLabel}}"}]}]}]}]},"ad-info-dialog");
this.o=this.A=null;this.R=this.g["ytp-ad-info-dialog-confirm-button"];this.ha=this.g["ytp-ad-info-dialog-mute-container"];this.ba=this.g["ytp-ad-info-dialog-message"];this.H=this.g["ytp-ad-info-dialog-ad-reasons"];this.C=this.B=null;this.X=c;this.F=null;this.J=!1;this.hide()};
aka=function(a){(a.F&&a.F.impressionEndpoints||[]).forEach(function(b){return a.l.Ka(b,a.macros)})};
bka=function(a,b){var c=b.content&&b.content.adFeedbackRenderer||null;c&&(a.A=new QN(a.api,a.l),g.I(a,a.A),a.A.init(X("ad-feedback-dialog"),c,a.macros),a.A.aa(a.X),a.A.subscribe("u",function(){return a.P("w")}))};
cka=function(a,b){var c=b.content&&b.content.confirmDialogRenderer||null;c&&(a.C=new TN(a.api,a.l),g.I(a,a.C),a.C.init(X("ad-mute-confirm-dialog"),c,a.macros),a.C.aa(a.X),a.C.subscribe("v",function(){return a.P("w")}))};
dka=function(a){a.o&&a.o.fa("click",a.tx,a);g.Cq(a.R,"click",function(){return a.tx()})};
VN=function(a,b,c,d){PN.call(this,a,b,void 0===d?!0:d,!0,["ytp-ad-info-hover-text-button"],"ad-info-hover-text-button");this.o=null;this.B=c;this.hide()};
eka=function(a,b,c){b=b.dialog&&b.dialog.adInfoDialogRenderer||null;null==b?g.M(Error("AdInfoDialogEndpoint did not contain an AdInfoDialogRenderer.")):(a.o=new UN(a.api,a.l,a.B),g.I(a,a.o),a.o.init(X("ad-info-dialog"),b,c),a.o.aa(a.B),a.o.subscribe("x",function(){return a.P("z")}),a.o.subscribe("w",function(){return a.P("y")}))};
fka=function(a,b,c){null==a.button?g.M(Error("AdInfoHoverTextButton.button was expected but it was not created.")):(b=b&&b.serviceEndpoint&&b.serviceEndpoint.adInfoDialogEndpoint||null,null==b?a.A&&g.J(a.A.element,"ytp-ad-info-hover-text-long"):(eka(a,b,c),a.A&&g.J(a.A.element,"ytp-ad-info-hover-text-short"),a.button.fa("click",function(){a.o&&!a.o.Ma()&&(a.o.show(),a.api.nd("ad-info-icon-button"))})))};
WN=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-choice-interstitial",K:[{D:"div",I:"ytp-ad-choice-interstitial-head-title"},{D:"div",I:"ytp-ad-choice-interstitial-button-container",K:[{D:"div",I:"ytp-ad-choice-interstitial-left-button"},{D:"div",I:"ytp-ad-choice-interstitial-right-button"}]},{D:"div",I:"ytp-ad-choice-interstitial-countdown-text"}]},"ad-choice-interstitial");this.o=this.C=this.A=this.B=null;this.F=new g.EN(this,0,!1,0);g.I(this,this.F);this.hide()};
XN=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-text-interstitial"},"ad-text-interstitial");this.A=this.g["ytp-ad-text-interstitial"];this.o=new CN(this.api,this.l,"ytp-ad-text-interstitial-message");g.I(this,this.o);this.o.aa(this.A);this.hide()};
YN=function(a){var b=g.jd("html5-video-player");b&&g.K(b,"ytp-ad-display-override",a)};
ZN=function(a,b,c,d,e){e=void 0===e?0:e;g.G.call(this);this.o=a;this.l=!1;this.G=d;this.B=!1;this.g=null;0<b&&(this.g=new g.L(this.ot,b,this),g.I(this,this.g));this.A=new g.L(this.ot,c,this);g.I(this,this.A);this.F=En(this.o,e,1,d);g.I(this,this.F);this.C=En(this.o,0,d,1);g.I(this,this.C);this.ca=new g.Pq;g.I(this,this.ca)};
$N=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-overlay-slot",K:[{D:"div",I:"ytp-ad-overlay-container"}]},"invideo-overlay");this.J=[];this.C=this.ka=null;this.wa=g.R(g.V(this.api).experiments,"enable_text_ad_overlay_link_fix");var c=this.g["ytp-ad-overlay-container"];this.ba=new ZN(c,45E3,6E3,.3,.4);g.I(this,this.ba);this.X=new g.L(this.clear,45E3,this);g.I(this,this.X);this.B=gka(this);g.I(this,this.B);this.B.aa(c);this.A=hka(this);g.I(this,this.A);this.A.aa(c);this.o=ika(this);g.I(this,this.o);
this.o.aa(c);this.oa=this.R=null;this.ha=!1;this.F=null;this.H=0;this.Ca=g.R(g.V(this.api).experiments,"bulleit_check_overlay_container_before_show");this.Ja=g.R(g.V(this.api).experiments,"bulleit_use_video_ad_div_as_overlay_container");this.hide()};
gka=function(a){var b=new g.Ns({D:"div",I:"ytp-ad-text-overlay",K:[{D:"div",I:"ytp-ad-overlay-ad-info-button-container"},{D:"div",I:"ytp-ad-overlay-close-container",K:[{D:"button",I:"ytp-ad-overlay-close-button",K:[wN(aO)]}]},{D:"div",I:"ytp-ad-overlay-title",V:"{{title}}"},{D:"div",I:"ytp-ad-overlay-desc",V:"{{description}}"},{D:"div",W:a.wa?["ytp-ad-overlay-link-inline-block","ytp-ad-overlay-link"]:["ytp-ad-overlay-link"],V:"{{displayUrl}}"}]});a.M(b.g["ytp-ad-overlay-title"],"click",function(c){return bO(a,
b.element,c)});
a.M(b.g["ytp-ad-overlay-link"],"click",function(c){return bO(a,b.element,c)});
a.M(b.g["ytp-ad-overlay-close-container"],"click",a.Gq);b.hide();return b};
hka=function(a){var b=new g.Ns({D:"div",W:["ytp-ad-text-overlay","ytp-ad-enhanced-overlay"],K:[{D:"div",I:"ytp-ad-overlay-ad-info-button-container"},{D:"div",I:"ytp-ad-overlay-close-container",K:[{D:"button",I:"ytp-ad-overlay-close-button",K:[wN(aO)]}]},{D:"div",I:"ytp-ad-overlay-text-image",K:[{D:"img",N:{src:"{{imageUrl}}"}}]},{D:"div",I:"ytp-ad-overlay-title",V:"{{title}}"},{D:"div",I:"ytp-ad-overlay-desc",V:"{{description}}"},{D:"div",W:a.wa?["ytp-ad-overlay-link-inline-block","ytp-ad-overlay-link"]:
["ytp-ad-overlay-link"],V:"{{displayUrl}}"}]});a.M(b.g["ytp-ad-overlay-title"],"click",function(c){return bO(a,b.element,c)});
a.M(b.g["ytp-ad-overlay-link"],"click",function(c){return bO(a,b.element,c)});
a.M(b.g["ytp-ad-overlay-close-container"],"click",a.Gq);a.M(b.g["ytp-ad-overlay-text-image"],"click",a.FL);b.hide();return b};
ika=function(a){var b=new g.Ns({D:"div",I:"ytp-ad-image-overlay",K:[{D:"div",I:"ytp-ad-overlay-ad-info-button-container"},{D:"div",I:"ytp-ad-overlay-close-container",K:[{D:"button",I:"ytp-ad-overlay-close-button",K:[wN(aO)]}]},{D:"div",I:"ytp-ad-overlay-image",K:[{D:"img",N:{src:"{{imageUrl}}",width:"{{width}}",height:"{{height}}"}}]}]});a.M(b.g["ytp-ad-overlay-image"],"click",function(c){return bO(a,b.element,c)});
a.M(b.g["ytp-ad-overlay-close-container"],"click",a.Gq);b.hide();return b};
cO=function(a,b){if(b){var c=b.adHoverTextButtonRenderer||null;if(null==c)g.M(Error("AdInfoRenderer did not contain an AdHoverTextButtonRenderer."));else{var d=g.jd("video-ads ytp-ad-module")||null;null==d?g.M(Error("Could not locate the root ads container element to attach the ad info dialog.")):(a.R=new g.Ns({D:"div",I:"ytp-ad-overlay-ad-info-dialog-container"}),g.I(a,a.R),a.R.aa(d),d=new VN(a.api,a.l,a.R.element,!1),g.I(a,d),d.init(X("ad-info-hover-text-button"),c,a.macros),a.F?(d.aa(a.F,0),d.subscribe("z",
a.cI,a),d.subscribe("y",a.hK,a),a.M(a.F,"click",a.dI),c=g.jd("ytp-ad-button",d.element),a.M(c,"click",a.NH),a.oa=d):g.M(Error("Ad info button container within overlay ad was not present.")))}}else g.kp(Error("AdInfoRenderer was not present within InvideoOverlayAdRenderer."))};
jka=function(a){return a.C&&a.C.closeButton&&a.C.closeButton.buttonRenderer&&(a=a.C.closeButton.buttonRenderer,a.serviceEndpoint)?[a.serviceEndpoint]:[]};
kka=function(a,b){var c=iJ(b.title),d=iJ(b.description);if(g.ib(c)||g.ib(d))return!1;mJ(a,a.B.element,b.trackingParams||null);a.B.updateValue("title",iJ(b.title));a.B.updateValue("description",iJ(b.description));a.B.updateValue("displayUrl",iJ(b.displayUrl));b.navigationEndpoint&&Ua(a.J,b.navigationEndpoint);a.B.show();a.ba.start();nJ(a,a.B.element,!0);a.M(a.B.element,"mouseover",function(){a.H++});
return!0};
lka=function(a,b){var c=iJ(b.title),d=iJ(b.description);if(g.ib(c)||g.ib(d))return!1;mJ(a,a.A.element,b.trackingParams||null);a.A.updateValue("title",iJ(b.title));a.A.updateValue("description",iJ(b.description));a.A.updateValue("displayUrl",iJ(b.displayUrl));a.A.updateValue("imageUrl",jJ(b.image));b.navigationEndpoint&&Ua(a.J,b.navigationEndpoint);a.ka=b.imageNavigationEndpoint||null;a.A.show();a.ba.start();nJ(a,a.A.element,!0);a.M(a.A.element,"mouseover",function(){a.H++});
return!0};
mka=function(a,b){var c=Zia(b.image);if(0==c.width||0==c.height||a.Ca&&dO(a,c))return!1;mJ(a,a.o.element,b.trackingParams||null);a.o.updateValue("imageUrl",jJ(b.image));a.o.updateValue("width",c.width);a.o.updateValue("height",c.height);b.navigationEndpoint&&Ua(a.J,b.navigationEndpoint);g.hh(a.o.g["ytp-ad-image-overlay"],"max-width",c.width+"px");a.o.show();nJ(a,a.o.element,!0);a.X.start();a.M(a.api,"resize",function(){return a.Gb(c)});
g.R(g.V(a.api).experiments,"enable_overlay_hide_timer_fix")?(a.M(a.o.element,"mouseover",function(){a.H++;a.X.stop()}),a.M(a.o.element,"mouseout",function(){a.X.start()})):a.M(a.o.element,"mouseover",function(){a.H++});
return!0};
dO=function(a,b){if(a.Ja)var c=g.ZH(a.api).Ha();else{c=a.element;var d=g.dd(c),e=g.pd&&c.currentStyle;e&&g.md(g.fd(d).g)&&"auto"!=e.width&&"auto"!=e.height&&!e.boxSizing?(d=g.Dh(c,e.width,"width","pixelWidth"),c=g.Dh(c,e.height,"height","pixelHeight"),c=new g.ad(d,c)):(e=new g.ad(c.offsetWidth,c.offsetHeight),d=g.Fh(c),c=g.Ih(c),c=new g.ad(e.width-c.left-d.left-d.right-c.right,e.height-c.top-d.top-d.bottom-c.bottom))}return b.width>c.width||b.height>c.height};
bO=function(a,b,c){var d=g.Wb(a.macros),e=g.Bh(b);d.AW={toString:function(){return e.width.toString()}};
d.AH={toString:function(){return e.height.toString()}};
var f=g.yh(c,b).floor();d.I_X={toString:function(){return f.x.toString()}};
d.NX={toString:function(){return f.x.toString()}};
d.I_Y={toString:function(){return f.y.toString()}};
d.NY={toString:function(){return f.y.toString()}};
d.NM={toString:function(){return a.H.toString()}};
a.J.forEach(function(b){return a.l.Ka(b,d)});
a.api.Lb()};
eO=function(a,b){var c=a.api.getRootNode();g.K(c,"ytp-ad-overlay-open",b);g.K(c,"ytp-ad-overlay-closed",!b)};
fO=function(a,b,c){yN.call(this,a,b,{D:"div",I:"ytp-ad-message-overlay",K:[{D:"div",I:"ytp-ad-message-slot"}]},"ad-message",c);var d=this;this.R=-1;this.X=this.g["ytp-ad-message-slot"];this.B=new g.Ns({D:"span",I:"ytp-ad-message-container"});this.B.aa(this.X);g.I(this,this.B);this.A=new CN(this.api,this.l,"ytp-ad-message-text");g.I(this,this.A);this.A.aa(this.B.element);this.H=new g.EN(this.B,400,!1,100,function(){return d.hide()});
g.I(this,this.H);this.C=0;this.J=!1;this.hide()};
gO=function(a,b){var c=a.api.getRootNode();g.K(c,"ytp-ad-overlay-open",b);g.K(c,"ytp-ad-overlay-closed",!b)};
nka=function(){hO||(hO=new Po,hO.A=Number(g.lp("client_streamz_web_flush_count")||0),hO.flushInterval=Number(g.lp("client_streamz_web_flush_interval_seconds")||0));this.g=hO;this.g.C("/client_streamz/youtube/video_ads/visibility_error",{nu:3,mu:"element_name"},{nu:3,mu:"error_reason"})};
oka=function(a){this.g=a};
qka=function(a,b,c,d){d=void 0===d?0:d;var e=!1;Oda({measure:function(){if(!e){var f=[];b.hidden&&f.push("hidden");"none"===g.mh(b,"display")&&f.push("display:none");var k=g.mh(b,"visibility");"hidden"!==k&&"collapse"!==k||f.push("visibility:"+k);k=b.getBoundingClientRect();k.width||k.height||f.push("boundingClientRect:0");k=0;for(var l=b;l;){if("0"===g.mh(l,"opacity")){f.push("opacity:0@level"+k);break}if(g.wn(l,"video-ads")||g.wn(l,"ytp-ad-module"))break;k+=1;l=l.parentElement}if(0<f.length&&(k=
d,f=f.join(","),a.g().g.G("/client_streamz/youtube/video_ads/visibility_error",c,f),0<k&&Math.random()<k)){k=["id","class","style","hidden","aria-hidden"];l=[];for(var m=b;m;){for(var n={tagName:m.tagName},p={},u=g.q(k),x=u.next();!x.done;x=u.next())x=x.value,m.hasAttribute(x)&&(p[x]=m.getAttribute(x));g.Qb(p)||(n.attributes=p);l.push(n);m=m.parentElement}k=pka(l);g.M(Error("vis_check_error_reason: "+f+", dump: "+k))}}}})();
return function(){return e=!0}};
pka=function(a){return JSON.stringify(a.map(function(a){var b=[a.tagName];a.attributes&&b.push(a.attributes);return b}))};
iO=function(a,b,c){c=void 0===c?0:c;return qka(rka(),a,b,c)};
jO=function(a,b,c){yN.call(this,a,b,{D:"div",I:"ytp-ad-skip-button-slot"},"skip-button",c);var d=this;this.A=null;this.wa=this.Ca=!1;this.C=new g.Ns({D:"span",W:["ytp-ad-skip-button-container"]});g.I(this,this.C);this.C.aa(this.element);this.B=this.H=null;this.R=new g.EN(this.C,500,!1,100,function(){return d.hide()});
g.I(this,this.R);this.ka=null;this.ba=!1;this.X=new ZN(this.C.element,15E3,5E3,.5,.5);g.I(this,this.X);this.Ja=(g.R(g.V(this.api).experiments,"mweb_undim_skip_button_on_ad_pause"),null);this.oa=new g.L(function(){var a=g.V(d.api).experiments;g.R(a,"enable_visibility_check_for_skip_button_in_bulleit")&&(d.J=iO(d.B.element,"skip-button-ad-text",g.S(a,"visibility_error_html_dump_sample_rate")))},3E3);
g.I(this,this.oa);this.J=null;this.hide()};
kO=function(a){a.oa.stop();a.J&&(a.J(),a.J=null)};
ska=function(a){var b=a.A&&a.A.adRendererCommands;return(b?b.clickCommand&&b.clickCommand.commandExecutorCommand&&b.clickCommand.commandExecutorCommand.commands||[]:a.A&&a.A.onClickCommands||[]).some(function(a){return a.adLifecycleCommand||a.adPlayerControlsCommand})};
lO=function(a,b,c,d){d=void 0===d?!1:d;Y.call(this,a,b,{D:"div",I:"ytp-ad-seek-ad-slot"},"seek-ad");this.J=null;this.R=0;this.B=this.C=this.o=this.A=null;this.F=c;g.I(this,this.F);this.H=null;this.X=!1;this.ba=d;this.hide()};
mO=function(a,b,c){yN.call(this,a,b,{D:"div",I:"ytp-ad-skip-ad-slot"},"skip-ad",c);this.H=!1;this.C=0;this.B=this.A=null;this.hide()};
nO=function(a,b){a.H||(a.H=!0,a.A&&(b?a.A.H.hide():a.A.hide()),b?a.B.af():a.B.show())};
oO=function(a,b,c){Y.call(this,a,b,{D:"div",I:"ytp-ad-persisting-overlay",K:[{D:"div",I:"ytp-ad-persisting-overlay-skip"}]},"persisting-overlay");this.A=this.g["ytp-ad-persisting-overlay-skip"];this.o=c;g.I(this,this.o);this.hide()};
pO=function(a,b,c,d){c=void 0===c?[]:c;d=void 0===d?"toggle-button":d;var e=X("ytp-ad-toggle-button-input");Y.call(this,a,b,{D:"div",W:["ytp-ad-toggle-button"].concat(c),K:[{D:"label",I:"ytp-ad-toggle-button-label",N:{"for":e},K:[{D:"span",I:"ytp-ad-toggle-button-icon",K:[{D:"span",I:"ytp-ad-toggle-button-untoggled-icon",V:"{{untoggledIconTemplateSpec}}"},{D:"span",I:"ytp-ad-toggle-button-toggled-icon",V:"{{toggledIconTemplateSpec}}"}]},{D:"input",I:"ytp-ad-toggle-button-input",N:{id:e,type:"checkbox"}},
{D:"span",I:"ytp-ad-toggle-button-text",V:"{{buttonText}}"},{D:"span",I:"ytp-ad-toggle-button-tooltip",V:"{{tooltipText}}"}]}]},d);this.B=this.g["ytp-ad-toggle-button"];this.o=this.g["ytp-ad-toggle-button-input"];this.X=this.g["ytp-ad-toggle-button-icon"];this.F=this.g["ytp-ad-toggle-button-untoggled-icon"];this.C=this.g["ytp-ad-toggle-button-toggled-icon"];this.R=this.g["ytp-ad-toggle-button-text"];this.A=null;this.H=!1;this.J=null;this.hide()};
qO=function(a){a.H&&(a.isToggled()?(g.Ch(a.F,!1),g.Ch(a.C,!0)):(g.Ch(a.F,!0),g.Ch(a.C,!1)))};
tka=function(a,b){var c=null;a.A&&(c=(b?[a.A.defaultServiceEndpoint,a.A.defaultNavigationEndpoint]:[a.A.toggledServiceEndpoint]).filter(function(a){return null!=a}));
return c||[]};
rO=function(a,b,c){Y.call(this,a,b,{D:"div",I:"ytp-ad-instream-user-sentiment-container"},"instream-user-sentiment",void 0===c?null:c);var d=this;this.o=null;this.B=new pO(this.api,this.l,["ytp-ad-instream-user-sentiment-like-button"]);g.I(this,this.B);this.B.aa(this.element);this.A=new pO(this.api,this.l,["ytp-ad-instream-user-sentiment-dislike-button"]);g.I(this,this.A);this.A.aa(this.element);this.C=new g.EN(this,400,!1,500,function(){return d.hide()});
g.I(this,this.C);this.F=null;this.hide()};
uka=function(a,b){a.B.init(X("toggle-button"),a.o.likeButton.toggleButtonRenderer,b);a.A.init(X("toggle-button"),a.o.dislikeButton.toggleButtonRenderer,b);a.F=a.M(a.element,"change",a.qx)};
sO=function(a,b){xN.call(this,a,b,["ytp-ad-visit-advertiser-button"],"visit-advertiser");this.B=null};
tO=function(a,b){this.l=a;this.g=b};
uO=function(a,b){return a.l+b*a.getLength()};
vO=function(a,b,c){if(!a.getLength())return null!=c?c:window.Infinity;a=(b-a.l)/a.getLength();return g.Uc(a,0,1)};
g.wO=function(a,b){g.Ns.call(this,{D:"div",I:"ytp-ad-persistent-progress-bar-container",K:[{D:"div",I:"ytp-ad-persistent-progress-bar"}]});this.A=a;this.o=b;g.I(this,this.o);this.F=this.g["ytp-ad-persistent-progress-bar"];this.l=-1;this.M(a,"presentingplayerstatechange",this.C);this.hide();this.C()};
xO=function(a,b,c){Y.call(this,a,b,{D:"div",I:"ytp-ad-player-overlay",K:[{D:"div",I:"ytp-ad-player-overlay-instream-info"},{D:"div",I:"ytp-ad-player-overlay-skip-or-preview"},{D:"div",I:"ytp-ad-player-overlay-progress-bar"},{D:"div",I:"ytp-ad-player-overlay-instream-user-sentiment"}]},"player-overlay");this.A=this.g["ytp-ad-player-overlay-instream-info"];this.B=this.g["ytp-ad-player-overlay-skip-or-preview"];this.F=this.g["ytp-ad-player-overlay-progress-bar"];this.C=this.g["ytp-ad-player-overlay-instream-user-sentiment"];
this.o=c;g.I(this,this.o);this.hide()};
yO=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-survey-answer"},"survey-answer");this.A=this.g["ytp-ad-survey-answer"];this.o=null;this.B="";this.hide()};
zO=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-survey-none-of-the-above"},"survey-none-of-the-above");this.A=this.g["ytp-ad-survey-none-of-the-above"];this.o=null;this.hide()};
AO=function(a,b){xN.call(this,a,b,["ytp-ad-survey-submit-button"],"survey-submit")};
BO=function(a,b,c){Y.call(this,a,b,{D:"div",I:"ytp-ad-survey-player-overlay",K:[{D:"div",I:"ytp-ad-survey-player-overlay-instream-info"},{D:"div",I:"ytp-ad-survey-player-overlay-skip-preview-submit",K:[{D:"div",I:"ytp-ad-survey-player-overlay-skip-or-preview"},{D:"div",I:"ytp-ad-survey-player-overlay-submit"}]},{D:"div",I:"ytp-ad-survey-player-overlay-instream-user-sentiment"}]},"survey-player-overlay");this.F=this.g["ytp-ad-survey-player-overlay-instream-info"];this.A={};this.H=this.g["ytp-ad-survey-player-overlay-skip-or-preview"];
this.o=null;this.R=this.g["ytp-ad-survey-player-overlay-submit"];this.B=null;this.J=this.g["ytp-ad-survey-player-overlay-instream-user-sentiment"];this.C=c;g.I(this,this.C);this.hide()};
CO=function(a,b,c,d){Y.call(this,a,b,{D:"div",I:"ytp-ad-survey-question",K:[{D:"div",W:["ytp-ad-survey-question-text","ytp-ad-survey-question-foreground"]},{D:"div",W:["ytp-ad-survey-answers","ytp-ad-survey-question-foreground"]},{D:"div",W:["ytp-ad-survey-question-player-overlay","ytp-ad-survey-question-foreground"]},{D:"div",I:"ytp-ad-survey-question-background"}]},c);this.question=this.g["ytp-ad-survey-question"];this.ha=this.g["ytp-ad-survey-question-background"];this.R=this.g["ytp-ad-survey-question-text"];
this.answers=this.g["ytp-ad-survey-answers"];this.J=this.g["ytp-ad-survey-question-player-overlay"];this.F=null;this.B=[];this.o=null;this.C=(0,g.D)();this.ba=d};
DO=function(a,b,c){var d=new yO(a.api,a.l);d.aa(a.answers);d.init(X("survey-answer"),b,c);a.B.push(d)};
EO=function(a,b){if(b){var c=b.background;c&&c.instreamSurveyAdBackgroundImageRenderer&&(c=(c=c.instreamSurveyAdBackgroundImageRenderer.image)&&cN(c)||"",g.ib(c)?g.M(Error("Found ThumbnailDetails without valid image URL"),"WARNING"):g.hh(a.ha,"backgroundImage","url("+c+")"));vka(a,b)}else g.M(Error("addCommonComponents() needs to be called before starting countdown."))};
vka=function(a,b){if(null==b.durationMilliseconds||void 0==b.durationMilliseconds||0==b.durationMilliseconds)g.M(Error("durationMilliseconds unset or 0 for SurveyAdQuestionCommon: "+JSON.stringify(b)));else{a.C=(0,g.D)();a.o=new HN(b.durationMilliseconds,a.l,a.ba);g.I(a,a.o);if(b.timeoutCommands){var c=b.timeoutCommands;a.o.subscribe("r",function(){c.forEach(function(b){return a.l.Ka(b,a.macros)})})}if(a.o&&b.instreamAdPlayerOverlay&&b.instreamAdPlayerOverlay.instreamSurveyAdPlayerOverlayRenderer)try{var d=
new BO(a.api,a.l,a.o);
d.aa(a.J);d.init(X("survey-player-overlay"),b.instreamAdPlayerOverlay.instreamSurveyAdPlayerOverlayRenderer,a.macros);a.F=d;g.I(a,d);a.cz()}catch(e){g.M(Error("ISAPOR had an error when initializing. Error: "+(e+" SurveyAdQuestionCommon: "+JSON.stringify(b))))}else g.M(Error("ISAPOR was not present in renderer. SurveyAdQuestionCommon: "+JSON.stringify(b)));a.o&&b.durationMilliseconds&&0<b.durationMilliseconds?(d=new g.wO(a.api,a.o),d.aa(a.J),g.I(a,d)):g.M(Error("Survey progress bar was not added. SurveyAdQuestionCommon: "+
JSON.stringify(b)))}};
wka=function(a){function b(a){return{toString:function(){return a()}}}
a.macros.SURVEY_LOCAL_TIME_EPOCH_S=b(function(){var a=new Date;return Math.round(a.valueOf()/1E3)+-60*a.getTimezoneOffset()});
a.macros.SURVEY_ELAPSED_MS=b(function(){return(0,g.D)()-a.C})};
FO=function(a,b,c){CO.call(this,a,b,"survey-question-multi-select",c);this.A=null;this.X=[];this.H=null;this.hide()};
xka=function(a,b,c){a.A=new zO(a.api,a.l);a.A.aa(a.answers);a.A.init(X("survey-none-of-the-above"),b,c)};
yka=function(a){a.B.forEach(function(a){a.o.toggleButton(!1)});
GO(a,!0)};
GO=function(a,b){var c=a.F,d=zka(a),e=b;e=void 0===e?!1:e;c.o&&(d?c.o.hide():c.o.show(),e&&c.o instanceof mO&&!c.o.H&&nO(c.o,!1));c.B&&(d?c.B.show():c.B.hide())};
zka=function(a){return a.B.some(function(a){return a.o.isToggled()})||a.A.o.isToggled()};
HO=function(a,b,c){CO.call(this,a,b,"survey-question-single-select",c);this.hide()};
IO=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-survey",K:[{D:"div",I:"ytp-ad-survey-title"},{D:"div",I:"ytp-ad-survey-questions"}]},"survey");this.B=this.g["ytp-ad-survey-title"];this.A=this.g["ytp-ad-survey-questions"];this.o=[];this.hide()};
JO=function(a,b){Y.call(this,a,b,{D:"div",I:"ytp-ad-survey-interstitial",K:[{D:"div",I:"ytp-ad-survey-interstitial-modal",K:[{D:"div",I:"ytp-ad-survey-interstitial-contents",K:[{D:"div",I:"ytp-ad-survey-interstitial-text"},{D:"div",I:"ytp-ad-survey-interstitial-logo",K:[{D:"div",I:"ytp-ad-survey-interstitial-logo-image"}]}]},{D:"div",I:"ytp-ad-survey-interstitial-action"}]}]},"survey-interstitial");this.C=this.g["ytp-ad-survey-interstitial-action"];this.J=this.g["ytp-ad-survey-interstitial"];this.o=
null;this.H=this.g["ytp-ad-survey-interstitial-modal"];this.R=this.g["ytp-ad-survey-interstitial-text"];this.F=this.g["ytp-ad-survey-interstitial-logo-image"];this.B=null;this.A=new g.EN(this,500,!1,300);g.I(this,this.A)};
Aka=function(a,b,c){var d={adPlayerControlsCommand:{action:"AD_PLAYER_CONTROLS_ACTION_RESUME"}},e=[d];c.dismissCommands&&c.dismissCommands.length&&(e=c.dismissCommands);c=b.target==a.J;b=a.o.element.contains(b.target);if(c||b)a.A.hide(),c?e.forEach(function(b){return a.l.Ka(b,a.macros)}):b&&a.l.Ka(d,a.macros)};
KO=function(a,b){var c=b&&cN(b)||"";g.ib(c)?g.kp(Error("Found ThumbnailDetails without valid image URL")):a.style.cssText+='background-image: url("'+c+'");'};
LO=function(a,b){Y.call(this,a,b,{D:"div",I:"iv-website-companion",K:[{D:"div",I:"iv-website-companion-block",K:[{D:"div",I:"iv-website-companion-icon"},{D:"div",I:"iv-website-companion-text",K:[{D:"div",I:"iv-website-companion-desc",K:[{D:"span",W:["yt-badge","yt-badge-ad"],V:"{{adBadgeText}}"}]}]}]}]},"action-companion");this.J=this.g["iv-website-companion"];this.B=new dN(this.api,this.l,"iv-website-companion-banner");g.I(this,this.B);this.B.aa(this.J,0);this.R=new dN(this.api,this.l);g.I(this,
this.B);this.R.aa(this.g["iv-website-companion-icon"]);this.F=new CN(this.api,this.l,"iv-website-companion-header");g.I(this,this.F);this.F.aa(this.g["iv-website-companion-text"],0);this.C=new CN(this.api,this.l,"iv-website-companion-domain");g.I(this,this.C);this.C.aa(this.g["iv-website-companion-desc"]);this.A=new xN(this.api,this.l,["iv-website-companion-action","yt-uix-button-size-default","yt-uix-button-primary"]);g.I(this,this.A);this.A.aa(this.g["iv-website-companion-block"]);this.qc=new CJ(this.api,
this.l);g.I(this,this.qc);this.qc.aa(this.J,0);this.H=null;this.X=[];this.ca=new g.Pq;g.I(this,this.ca);this.ba=new vK;this.o=null;this.hide()};
MO=function(){g.G.call(this);this.A=this.l=this.B=this.g=this.C=this.o=null};
Bka=function(a,b){return NO(a).then(function(a){a&&g.Aa(a.promotionShelfShow)&&a.promotionShelfShow(b)})};
Cka=function(a){NO(a).then(function(a){a&&g.Aa(a.promotionShelfClear)&&a.promotionShelfClear()})};
Eka=function(a){window.google_ad_output="html";window.google_ad_height="250";window.google_ad_format="300x250_as";window.google_container_id="google_companion_ad_div";return NO(a).then(function(b){return Dka(a,b)}).then(function(b){b();
return OO(a)})};
Fka=function(a){return NO(a).then(function(b){b.loadAfc();return OO(a)})};
PO=function(){return g.y("yt.www.watch.ads")};
QO=function(){return g.y("window.google_show_companion_ad")};
NO=function(a){if(a.ea())throw Error("Object is disposed");if(!a.o){var b=PO();a.o=b?Tf(b):(new g.Pf(function(b){a.C=g.fr("watchAdsInit",b)})).then(PO)}return a.o};
Dka=function(a,b){if(a.ea())throw Error("Object is disposed");if(!a.g){var c=QO();Gka(c,b.getGlobals)?a.g=Tf(c):a.g=(new g.Pf(function(b){a.B=g.fr("showCompanionAdLoaded",b)})).then(QO)}return a.g};
OO=function(a){if(a.ea())throw Error("Object is disposed");a.l||(RO()?Tf():a.l=new g.Pf(function(b,c){a.A=new g.L(function(){RO()?b():c()},2E3,a);
a.A.start()}));
return a.l};
Gka=function(a,b){if(!g.Aa(a)||!g.Aa(b))return!1;var c=b();return!(!c||!c.length)};
RO=function(){var a=g.gd("google_companion_ad_div");return a?(a=g.Dd(a))&&"IFRAME"==a.tagName?-1!=a.src.indexOf("youtube.com%2Fad_frame"):!1:!1};
SO=function(a,b){Y.call(this,a,b,{D:"div"},"backfill-mpu-companion");this.A=new MO;g.I(this,this.A);this.o=null};
Hka=function(a,b){(b.noAdEndpoints||[]).forEach(function(b){return a.l.Ka(b,a.macros)})};
TO=function(){g.P.call(this,{D:"div",I:"ad-carousel",K:[{D:"div",I:"ad-carousel-clip",K:[{D:"ul",W:["ad-carousel-list","ad-carousel-list-animation"]}]}]});var a=this.g["ad-carousel"];this.A=new g.P({D:"button",W:["ad-carousel-nav-button","ad-carousel-nav-prev"],N:{type:"button",onclick:"return false;"},K:[{D:"span",W:["ad-carousel-prev-icon","yt-uix-tooltip","yt-sprite"],N:{"data-tooltip-text":"Prev",title:"Prev"}}]});g.I(this,this.A);this.A.fa("click",this.F,this);this.A.aa(a);this.o=new g.P({D:"button",
W:["ad-carousel-nav-button","ad-carousel-nav-next"],N:{type:"button",onclick:"return false;"},K:[{D:"span",W:["ad-carousel-next-icon","yt-uix-tooltip","yt-sprite"],N:{"data-tooltip-text":"Next",title:"Next"}}]});g.I(this,this.o);this.o.fa("click",this.C,this);this.o.aa(a);this.B=this.g["ad-carousel-list"];this.l=0;this.Ea=[]};
VO=function(a){a.B&&g.hh(a.B,"left",(2>a.Ea.length?0:-a.l*a.Ea[1].element.clientWidth)+"px");g.Ms(a.A,0<a.l);g.Ms(a.o,a.l<a.Ea.length-UO(a))};
UO=function(a){return 2>a.Ea.length?1:Math.round((a.element.clientWidth-a.Ea[0].element.clientWidth)/a.Ea[1].element.clientWidth)+1};
WO=function(){uJ.call(this,!0);this.td=new TO};
XO=function(){uJ.call(this,!1);this.l=new g.P({D:"div",I:"iv-btp-card",K:[{D:"a",I:"iv-btp-card-content",K:[{D:"div",V:"{{cards}}"}]}]});g.I(this,this.l);var a={D:"div",I:"iv-btp-card-merchant",K:[{D:"span",I:"iv-btp-card-merchant-text",V:"{{merchant}}"}]};this.A=new g.Is({D:"div",W:["iv-btp-small-card","yt-uix-hovercard-target"],N:{"data-position":"bottomright","data-orientation":"vertical"},K:[{D:"div",W:["iv-btp-card-image","yt-uix-hovercard-anchor"],V:"{{image}}"},{D:"div",I:"iv-btp-card-info",
K:[{D:"span",I:"iv-btp-card-action",V:"{{price}}"},a]},{D:"div",W:["yt-uix-hovercard-content","iv-btp-hovercard"],V:"{{hovercard}}"}]});g.I(this,this.A);this.g=new g.Is({D:"div",I:"iv-btp-large-card",K:[{D:"div",I:"iv-btp-card-image",K:[{D:"span"},{D:"div",I:"iv-btp-card-image-aligned",V:"{{image}}"}]},{D:"div",I:"iv-btp-card-info",K:[{D:"div",I:"iv-btp-card-text-box",K:[{D:"div",I:"iv-btp-card-text-valign",K:[{D:"div",W:["yt-ui-ellipsis","yt-ui-ellipsis-4","iv-btp-card-headline"],V:"{{headline}}"}]}]},
{D:"span",I:"iv-btp-card-action",V:"{{price}}"},a,{D:"div",V:"{{review}}"}]}]});g.I(this,this.g);this.o=new g.Is({D:"div",I:"iv-btp-hovercard-text-box",K:[{D:"a",K:[{D:"div",W:["yt-ui-ellipsis","yt-ui-ellipsis-4","iv-btp-hovercard-headline"],V:"{{headline}}"}]},{D:"div",I:"iv-btp-hovercard-info",K:[{D:"span",I:"iv-btp-hovercard-action",V:"{{price}}"},a]},{D:"div",V:"{{review}}"}]});g.I(this,this.o);this.B=new g.Is({D:"div",I:"iv-btp-card-review",K:[{D:"div",I:"iv-btp-card-rating",K:[{D:"span",I:"iv-btp-card-rating-bg",
K:[{D:"span",I:"iv-btp-card-rating-fg"}]}]},{D:"span",I:"iv-btp-card-reviews",V:"{{reviewText}}"}]});g.I(this,this.B);this.A.updateValue("hovercard",this.o);this.l.updateValue("cards",[this.A,this.g]);this.gd()};
YO=function(a,b,c){c=c?tJ(c):null;a.updateValue(b,c)};
ZO=function(a,b){vJ.call(this,a,b,function(){return new Ika.On});
this.g=null;this.gd()};
$O=function(){uJ.call(this,!0);this.g=new g.P({D:"div",I:"iv-btp-companion",K:[{D:"div",I:"iv-btp-block-clicks"},{D:"div",I:"iv-btp-attribution",K:[{D:"span",I:"iv-btp-title",V:"{{shopText}}"},{D:"div",I:"ad-info-container",K:[{D:"span",I:"iv-btp-sponsored",V:"{{sponsoredText}}"},{D:"button",I:"ad-info-icon"}]}]}]});g.I(this,this.g);this.o=this.g.g["iv-btp-block-clicks"];this.l=new MO;g.I(this,this.l);this.A=Bka(this.l,this.g.element);this.gd()};
bP=function(a,b){vJ.call(this,a,b,function(){return new aP.CB});
this.ca=new g.Pq(this);g.I(this,this.ca);this.jh=[];this.Td=null;this.td=new aP.Kn;g.I(this,this.td);this.view.append(this.td);this.je=new aP.SA(a,b,new eJ(this.Hc().g.g["ad-info-icon"]));g.I(this,this.je);this.je.Ah(this.view);this.gd()};
Jka=function(a){var b=a.Hc();g.Ch(b.o,!0);Xf([a.Td,lg(1E3)]).then(function(){g.Ch(b.o,!1)})};
cP=function(){uJ.call(this,!0);var a=this;this.A=this.l=0;this.g=new g.P({D:"div",I:"iv-cards-slider",K:[{D:"div",I:"iv-cards-slider-body",K:[{D:"ul",I:"iv-cards-slider-list"}]},{D:"button",W:["iv-cards-slider-button","iv-cards-slider-prev"],N:{type:"button",onclick:";return false;"},K:[{D:"span",W:["iv-cards-slider-prev-icon","yt-sprite"]}]},{D:"button",W:["iv-cards-slider-button","iv-cards-slider-next"],N:{type:"button",onclick:";return false;"},K:[{D:"span",W:["iv-cards-slider-next-icon","yt-sprite"]}]}]});
this.F=g.jd("iv-cards-slider-list",this.g.element);if(this.o=g.jd("iv-cards-slider-prev",this.g.element))this.g.M(this.o,"click",function(){a.dispatchEvent({type:"prevbuttonclick"})}),g.Ch(this.o,!1);
(this.B=g.jd("iv-cards-slider-next",this.g.element))&&this.g.M(this.B,"click",function(){a.dispatchEvent({type:"nextbuttonclick"})});
g.I(this,this.g)};
dP=function(a){a.F.style.left=125*-a.l+"px";a.o&&g.Ch(a.o,0<a.l);a.B&&g.Ch(a.B,a.l<a.A-3)};
eP=function(){uJ.call(this,!0);this.g=new g.P({D:"div",I:"iv-cards-companion",K:[{D:"div",I:"iv-cards-attribution",K:[{D:"span",W:["yt-badge","yt-badge-ad"],V:"{{adBadgeText}}"},{D:"a",I:"ad-companion-clickthrough",N:{target:"_blank"},V:"{{shopText}}"}]},{D:"div",V:"{{content}}"}]});g.I(this,this.g);this.l=new vK;this.o=this.l.showCompanion(this.g.element,300,250);this.gd()};
fP=function(){uJ.call(this,!1);this.g=new g.P({D:"li",I:"iv-cards-slider-item",K:[{D:"div",I:"iv-cards-slider-unit",K:[{D:"a",K:[{D:"div",I:"iv-cards-slider-image",V:"{{image}}"},{D:"span",W:["yt-ui-ellipsis","yt-ui-ellipsis-4","iv-cards-slider-text"],V:"{{headline}}"},{D:"span",I:"iv-cards-slider-action",V:"{{price}}"}]}]}]});g.I(this,this.g);this.gd()};
gP=function(a,b){vJ.call(this,a,b,function(){return new Kka.On});
var c=this;this.g=null;this.Hc().addEventListener("offerclick",function(){return c.onClick()})};
iP=function(a,b){vJ.call(this,a,b,function(){return new hP.YA});
this.ca=new g.Pq(this);g.I(this,this.ca);this.Mt=[];this.Mq=null;this.jh=[];this.Td=null;this.Uf=new hP.Kn;g.I(this,this.Uf);this.view.append(this.Uf);this.qc=new CJ(a,b);g.I(this,this.qc);zd(this.view.ia(),this.qc.element,0);this.gd()};
g.jP=function(a,b){b=void 0===b?2:b;g.N.call(this);this.g=a;this.l=new g.Pq(this);g.I(this,this.l);this.B=Lka;this.o=null;this.l.M(this.g,"presentingplayerstatechange",this.JH);this.o=this.l.M(this.g,"progresssync",this.nx);this.A=b;1===this.A&&this.nx()};
kP=function(a,b,c){switch(a){case "invideo-overlay":return new $N(b,c);case "persisting-overlay":return new oO(b,c,new g.jP(b));case "player-overlay":return new xO(b,c,new g.jP(b));case "pla-shelf":return new bP(b,c);case "shopping-companion":return new iP(b,c);case "survey":return new IO(b,c);case "backfill-mpu-companion":return new SO(b,c);case "ad-action-interstitial":return new IN(b,c);case "action-companion":return new LO(b,c);case "ad-text-interstitial":return new XN(b,c);case "survey-interstitial":return new JO(b,
c);case "ad-choice-interstitial":return new WN(b,c);case "ad-message":return new fO(b,c,new g.jP(b,1));default:return null}};
lP=function(a){g.Pq.call(this);this.Bb=a;this.M(this.Bb,"onAdUxUpdate",this.C)};
mP=function(a,b){lP.call(this,a);this.o=b;this.g=new window.Map;g.I(this,rJ())};
nP=function(a,b){lP.call(this,a);this.g=b};
oP=function(a,b,c){(b=b.adRendererCommands&&b.adRendererCommands.impressionCommand)&&a.Ka(b,c)};
pP=function(a,b){lP.call(this,a);this.o=a;this.B=b;this.g={};var c=new g.P({D:"div",W:["video-ads","ytp-ad-module"]});g.I(this,c);this.A=new eJ(c.element);g.I(this,this.A);g.sI(this.o,c.element,4);g.I(this,rJ())};
qP=function(a,b){var c=Tb(a.g,b.id,null);null!=c||g.M(Error("Component not found for element id: "+b.id),"WARNING");return c||null};
rP=function(a){g.GI.call(this,a);var b=this;this.g=null;this.created=!1;var c=g.V(a);ey(c)&&!g.hy(c)&&(c=function(){return b.g},g.I(this,new pP(a,c)),g.I(this,KK(a)?new nP(a,c):new mP(a,c)))};
sP=function(a,b){if(null===a.g)g.M(Error("AdService should not be null when handling controls"));else{var c=a.g;switch(b){case "control_play":bN(c)&&qH(c.g.xb());break;case "control_pause":bN(c)&&(g.U(g.YH(c.g,2),64)||xH(c.g.xb()))}}};
g.tP=function(a,b,c,d){if((void 0===c||!c)&&g.NN(a))return g.Iq(a),!0;b.Lb();a=a.currentTarget.getAttribute("href");g.sK(a,d,!0);return!1};
uP=function(a,b,c){g.G.call(this);this.oa=b;this.pa=c;this.R=this.H=this.G=this.L=this.F=this.o=this.Z=this.X=this.T=this.B=this.J=this.l=null;this.ba={};this.ha={};this.ka=null;this.g=a;this.Y=this.da=this.C=this.O=this.A=null;this.ga=g.R(g.V(a).experiments,"web_player_defer_modules")};
g.vP=function(a){var b=g.V(a.g);if(g.uy(b)||b.Sb||!b.Ca&&!b.Ia)return!1;var c=a.g.Da();if(2==c)return!1;if(3==c)return g.R(b.experiments,"desktop_enable_autoplay");a=a.g.getVideoData();if(!a)return!1;c=!a.isLiveDefaultBroadcast||g.R(b.experiments,"allow_poltergust_autoplay");return!(a.ra&&(!g.R(b.experiments,"allow_live_autoplay")||!c))};
wP=function(a){a.ga&&(a.po(),a.no(),a.oo())};
Mka=function(a){var b=a.g.getVideoData(),c=g.V(a.g).experiments,d=g.Rp(),e=g.R(c,"enable_spherical_kabuki");a=g.sy(g.V(a.g));if(b.Oe())return d||e||a||g.R(c,"html5_enable_spherical");if(b.yf())return a||d||e||g.R(c,"html5_enable_spherical");if(b.zf())return a||d||g.R(c,"html5_enable_spherical3d");if(b.Rg())return a||g.R(c,"html5_enable_anaglyph3d")||!1;d=b.ua&&b.ua.video&&mt(b.ua.video);return a&&!g.qA(b)&&!b.isVisualizerEligible&&!d&&(g.R(c,"enable_webgl_noop")||g.R(c,"html5_enable_bicubicsharp")||
g.R(c,"html5_enable_raisr"))};
xP=function(a){g.R(g.V(a.g).experiments,"web_player_ux_module_wait")&&a.H&&g.pI(a.g,"ux")};
yP=function(a){if(a=a.g.getVideoData(1).getPlayerResponse())if(a=a.adPlacements)for(var b=0;b<a.length;b++)if(a[b].adPlacementRenderer)return!0;return!1};
BP=function(a,b,c,d){try{if(d){var e=g.zP[b];if(e)return new e(a.g);"creatorendscreen"==b?AP(a,"annotations_module",c):AP(a,b,c)}else g.pI(a.g,b)}catch(f){g.pI(a.g,b),g.M(f)}return null};
CP=function(a,b,c){a.l&&(c||a.l.Xb(b))&&(g.Xe(a.l),a.l=null);a.J&&(c||a.J.Xb(b))&&(g.Xe(a.J),a.J=null);a.B&&(c||a.B.Xb(b))&&(g.Xe(a.B),a.B=null);a.T&&(c||a.T.Xb(b))&&(g.Xe(a.T),a.T=null);a.X&&(c||a.X.Xb(b))&&(g.Xe(a.X),a.X=null);a.Z&&(c||a.Z.Xb(b))&&(g.Xe(a.Z),a.Z=null);a.o&&(c||a.o.Xb(b))&&(g.Xe(a.o),a.o=null);a.F&&(c||a.F.Xb(b))&&(g.Xe(a.F),a.F=null);a.L&&(c||a.L.Xb(b))&&(g.Xe(a.L),a.L=null);a.G&&(c||a.G.Xb(b))&&(g.Xe(a.G),a.G=null);a.O&&(c||a.O.Xb(b))&&(g.Xe(a.O),a.O=null);a.Y&&(c||a.Y.Xb(b))&&
(g.Xe(a.Y),a.Y=null);a.C&&(c||a.C.Xb(b))&&(g.Xe(a.C),a.C=null);a.A&&(c||a.A.Xb(b))&&(g.Xe(a.A),a.A=null);a.H&&(c||a.H.Xb(b))&&(g.Xe(a.H),a.H=null);a.R&&(c||a.R.Xb(b))&&(g.Xe(a.R),a.R=null)};
g.$H=function(a){return g.V(a.g).ab?a.O:null};
at=function(a){return g.V(a.g).wa?a.H:null};
AP=function(a,b,c){if(a.oa){for(var d=a.oa+b+".js",e=window.document.getElementsByTagName("SCRIPT"),f=!1,k,l=0;l<e.length;l++){var m=e[l];m.src==d&&(k=m)}k||(k=g.vd("SCRIPT"),f=!0);var n=function(){a.ea()||c.call(a)},p=function(){a.ea()||g.pI(a.g,b)};
k.onload=g.Ea(function(a){Df(n);a&&a()},k.onload);
k.onerror=g.Ea(function(a){g.M(Error("Unable to load player module "+b+".js from "+d+" on "+(window.document.location&&window.document.location.origin)+"."));Df(p);a&&a()},k.onerror);
k.onreadystatechange=g.Ea(function(a){switch(k.readyState){case "loaded":case "complete":Df(n,this)}a&&a()},k.onreadystatechange);
f&&((e=g.V(a.g).Ik)&&k.setAttribute("nonce",e),g.Sc(k,g.Od(d)),e=window.document.getElementsByTagName("HEAD")[0]||window.document.body,e.insertBefore(k,e.firstChild),g.We(a,function(){k.parentNode&&k.parentNode.removeChild(k);g.zP[b]=null;"annotations_module"==b&&(g.zP.creatorendscreen=null)}))}};
g.DP=function(a,b){return eC(b)?(b.fetch=0,new g.dC(a,b)):new g.Xz(a,b)};
g.EP=function(a,b,c,d,e){var f=b.Hq/b.rows,k=Math.min(c/(b.Iq/b.columns),d/f),l=b.Iq*k,m=b.Hq*k;l=Math.floor(l/b.columns)*b.columns;m=Math.floor(m/b.rows)*b.rows;var n=l/b.columns,p=m/b.rows,u=-b.column*n,x=-b.row*p;e&&45>=f&&(p-=1/k);n-=2/k;a=a.style;a.width=n+"px";a.height=p+"px";e||(d=(d-p)/2,c=(c-n)/2,a.marginTop=Math.floor(d)+"px",a.marginBottom=Math.ceil(d)+"px",a.marginLeft=Math.floor(c)+"px",a.marginRight=Math.ceil(c)+"px");a.background="url("+b.url+") "+u+"px "+x+"px/"+l+"px "+m+"px"};
g.FP=function(a,b,c,d){d=void 0===d?!1:d;g.Ns.call(this,b);this.R=a;this.ba=d;this.J=null;this.H=new g.Pq(this);g.I(this,this.H);this.L=new g.EN(this,c,!0,void 0,null,(0,g.z)(this.nC,this));g.I(this,this.L);this.l=null};
GP=function(a){a.l&&(window.document.activeElement&&g.Fd(a.element,window.document.activeElement)&&(g.Jd(a.l),a.l.focus()),a.l.removeAttribute("aria-expanded"),a.l=null);g.Rq(a.H);a.J=null};
g.HP=function(a){return a.Ma()&&4!=a.L.g};
g.IP=function(){g.G.call(this);this.B=null;this.A=this.g=0;this.o=new g.Fn(this.l,null,this);g.I(this,this.o)};
JP=function(a,b){if("path"==b.D)return b.N.d;if(b.K)for(var c=0;c<b.K.length;c++){var d=b.K[c];if(d&&!g.v(d)&&(d=JP(a,d)))return d}};
g.NP=function(a,b,c){c=JP(a,c);var d=b.getElementsByTagName("path")[0],e=d.getAttribute("d");if(d.getAttribute("id")){var f=g.Gs();b=b.getElementsByTagName("use");for(var k=0;k<b.length;k++)b[k].setAttributeNS("http://www.w3.org/1999/xlink","href","#"+f);d.setAttribute("id",f)}var l=KP(e),m=KP(c);g.LP(a,function(a){d.setAttribute("d",g.MP(l,m,a))},200)};
g.LP=function(a,b,c){a.B=b;a.A=g.qr();a.g=c;a.l()};
KP=function(a){var b=[];a=a.match(Nka);for(var c=0;c<a.length;c++){var d=(0,window.parseFloat)(a[c]);b.push((0,window.isNaN)(d)?a[c]:d)}return b};
g.MP=function(a,b,c){for(var d="",e=0;e<a.length;e++){var f=a[e];d=g.ta(f)?d+(f+(b[e]-f)*c):d+f}return d};
g.PP=function(a,b){g.P.call(this,{D:"button",W:["ytp-play-button","ytp-button"],N:{title:"{{title}}","aria-label":"{{label}}"},V:"{{icon}}"});this.o=a;this.A=null;this.B=b.kb();this.l=null;this.C=new g.IP;g.I(this,this.C);this.M(a,"fullscreentoggled",this.F);this.M(a,"presentingplayerstatechange",this.G);this.M(a,"videodatachange",this.F);OP(this,g.YH(a));this.fa("click",this.H,this)};
QP=function(a){switch(a){case 1:return g.rN();case 2:return g.qN();case 3:return g.tN();case 4:return g.vN();default:return null}};
OP=function(a,b){var c=g.AA(a.o.getVideoData()),d=!1;if(g.qB(b))var e=c?4:2;else g.U(b,2)?(e=3,d=c):e=1;a.element.disabled=d;if(a.A!=e){c=null;switch(e){case 2:c="Pause";break;case 3:c="Replay";break;case 1:c="Play";break;case 4:c="Stop live playback"}3==e?(a.l||(a.l=g.RP(a.B,a.element)),a.update({title:c,label:null,icon:QP(e)})):(a.l&&(a.l(),a.l=null),a.update({title:null,label:c}),(c=QP(e))&&a.A&&3!=a.A&&!g.V(a.o).J?g.NP(a.C,a.element,c):a.updateValue("icon",c));g.SP(a.B);a.A=e}};
g.UP=function(a,b,c){if(c){var d="ytp-next-button";var e=g.oN()}else d="ytp-prev-button",e=g.sN();g.P.call(this,{D:"a",W:[d,"ytp-button"],N:{title:"{{title}}",href:"{{url}}","data-preview":"{{preview}}","data-tooltip-text":"{{text}}","data-duration":"{{duration}}","aria-disabled":"{{disabled}}","data-next":"{{next}}","data-prev":"{{prev}}"},K:[e]});this.l=a;this.L=b.kb();this.o=c;this.A=this.F=null;this.J=!1;this.G=this.H=this.B=null;this.C=!1;this.M(a,"fullscreentoggled",this.mi);this.M(a,"videodatachange",
this.mi);this.M(a,"onPlaylistUpdate",this.mi);this.o||this.M(a,"appresize",this.kc);this.M(a,"mdxpreviousnextchange",function(){TP(this);this.kc()});
this.mi()};
VP=function(a){a.A&&a.A.unsubscribe("shuffle",a.mi,a)};
WP=function(a){return!!a.A&&!a.o&&!!a.F&&!a.F.ra&&3<=a.l.ya()&&2!=a.l.Da()};
XP=function(a){var b=g.$H(g.UH(a.l));return b?a.o?b.hasNext():b.Pe():!1};
TP=function(a){var b={duration:null,preview:null,text:null,title:null,url:null},c=g.V(a.l),d=g.aI(a.l),e=a.o&&g.uI(a.l),f=XP(a),k=a.o&&5==a.l.Da();if(k)b.title="Start video";else if(a.C)b.title="Replay";else if(d){var l=null;a.A&&(l=a.A.za(a.o?fC(a.A):gC(a.A)));if(l){if(l.videoId){var m=a.A.listId;b.url=c.getVideoUrl(l.videoId,m?m.toString():void 0)}b.text=l.title;b.duration=l.lengthSeconds?g.MN(l.lengthSeconds):null;b.preview=l.tc("mqdefault.jpg")}b.title=a.o?"Next":"Previous"}else e&&(a.F.suggestions&&
a.F.suggestions.length&&(c=g.DP(c,a.F.suggestions[0]),b.url=c.kj(),b.text=c.title,b.duration=c instanceof g.Xz?g.MN(c.lengthSeconds):null,b.preview=c.tc("mqdefault.jpg")),b.title="Next");b.disabled=!e&&!d&&!f&&!k;a.update(b);a.J=!!b.url;e||d||a.C||f||k?a.B||(a.B=g.RP(a.L,a.element),a.H=a.fa("click",a.jH,a)):a.B&&(a.B(),a.B=null,a.Pa(a.H),a.H=null);g.SP(a.L)};
YP=function(){this.l=this.position=this.A=this.g=this.B=this.o=this.width=window.NaN};
g.$P=function(a,b){g.Ns.call(this,{D:"div",I:"ytp-progress-bar-container",N:{"aria-disabled":"true"},K:[{D:"div",W:["ytp-progress-bar",g.V(a).o?"ytp-mobile":""],N:{tabindex:"0",role:"slider","aria-label":"Seek slider","aria-valuemin":"{{ariamin}}","aria-valuemax":"{{ariamax}}","aria-valuenow":"{{arianow}}","aria-valuetext":"{{arianowtext}}"},K:[{D:"div",I:"ytp-progress-bar-padding"},{D:"div",I:"ytp-progress-list",K:[{D:"div",W:["ytp-play-progress","ytp-swatch-background-color"]},{D:"div",I:"ytp-load-progress"},
{D:"div",I:"ytp-hover-progress"},{D:"div",I:"ytp-clip-start-exclude"},{D:"div",I:"ytp-clip-end-exclude"},{D:"div",I:"ytp-ad-progress-list"},{D:"div",I:"ytp-marker-crenellation-list"},{D:"div",I:"ytp-marker-progress-list"}]},{D:"div",I:"ytp-marker-icons"},{D:"div",I:"ytp-scrubber-container",K:[{D:"div",W:["ytp-scrubber-button","ytp-swatch-background-color"],K:[{D:"div",I:"ytp-scrubber-pull-indicator"}]}]}]},{D:"div",I:"ytp-bound-time-left",V:"{{boundTimeLeft}}"},{D:"div",I:"ytp-bound-time-right",V:"{{boundTimeRight}}"},
{D:"div",I:"ytp-clip-start",N:{title:"Watch entire video"},V:"{{clipstarticon}}"},{D:"div",I:"ytp-clip-end",N:{title:"Watch entire video"},V:"{{clipendicon}}"}]});this.updateValue("clipstarticon",kN());this.updateValue("clipendicon",jN());this.l=a;this.pa=b.kb();this.Va=!1;this.B=this.Ja=0;this.X=1;this.Cc=this.H=0;this.A=null;this.ob=!1;this.J=this.sa=0;this.Lc=this.g["ytp-ad-progress-list"];this.Mc=this.g["ytp-marker-progress-list"];this.Nc=this.g["ytp-marker-icons"];this.nb=this.g["ytp-marker-crenellation-list"];
this.R={};this.oa={};this.T={};this.ba=[];this.L=window.Infinity;var c=b.kb();this.ha=this.g["ytp-clip-end"];g.We(this,g.RP(c,this.ha));this.wa=new g.Vq(this.ha,!0);g.I(this,this.wa);this.wa.subscribe("hoverstart",this.Qx,this);this.wa.subscribe("hoverend",this.Px,this);this.M(this.ha,"click",this.dn);this.ab=this.g["ytp-clip-end-exclude"];this.cd=this.g["ytp-clip-start-exclude"];this.O=0;this.ga=this.g["ytp-clip-start"];g.We(this,g.RP(c,this.ga));this.Ca=new g.Vq(this.ga,!0);g.I(this,this.Ca);this.Ca.subscribe("hoverstart",
this.Qx,this);this.Ca.subscribe("hoverend",this.Px,this);this.M(this.ga,"click",this.dn);this.Wb=this.g["ytp-load-progress"];this.ka=0;this.Oc=this.g["ytp-play-progress"];this.Cb=this.g["ytp-hover-progress"];this.G=0;this.zc=this.g["ytp-progress-bar"];this.C=null;this.ed=this.g["ytp-scrubber-button"];this.fd=this.g["ytp-scrubber-container"];this.Ia=new g.Yc;this.yb=new YP;this.o=new tO(0,0);this.F=this.Oa=!1;this.Mb=null;this.Ya=new g.Pq(this);g.I(this,this.Ya);this.M(a,"presentingplayerstatechange",
this.lH);this.M(a,"videodatachange",this.Yw);this.M(a,"videoplayerreset",this.NC);this.M(a,"cuerangesadded",this.oA);this.M(a,"cuerangesremoved",this.BM);this.M(a,"cuerangemarkersupdated",this.oA);this.M(a,"onPlaybackQualityChange",this.RC);ZP(this,a.getVideoData(),!0)};
g.bQ=function(a){aQ(a);var b=a.l.ya();(b<a.O||b>a.L)&&a.dn()};
aQ=function(a){if(a.B){var b=a.l.fh(),c=new tO(b.seekableStart,b.seekableEnd),d=vO(c,b.loaded,0);b=vO(c,b.current,0);var e=a.o.l!=c.l||a.o.g!=c.g;a.o=c;cQ(a,b,d);e&&g.dQ(a);eQ(a)}};
ZP=function(a,b,c){c=void 0===c?!1:c;var d=!!b&&b.ld();a.Oa=d&&b.yg;fQ(a,a.l.ac());c&&(d?(c=b.clipEnd,a.O=b.clipStart,a.L=c,gQ(a),cQ(a,a.G,a.ka)):a.dn(),b=a.pa,1==b.o&&b.Zd());aQ(a)};
hQ=function(a){return!!a&&a.ld()&&!!a.ua&&a.ua.video.isAccelerated&&a.ua.video.o};
iQ=function(a,b){a.ob=b;g.K(a.Wb,"ytp-fast-load",b)};
jQ=function(a,b,c,d){b=g.Uc(b,0,a.F?60:40);a.H=b;var e=a.X,f=Math.max(a.o.getLength()/a.B,1);a.X=b/(a.F?60:40)*(f-1)+1;b=a.B*a.X;a.J=g.Uc(d*b-c,0,b-a.B);e!=a.X&&g.dQ(a)};
g.dQ=function(a){var b=kQ(a),c=-b.o/b.g,d=(-b.o+b.width)/b.g,e=g.Cd(a.nb),f=0;if(a.H>.2*(a.F?60:40)){var k=c*(a.o.getLength()/60),l=d*(a.o.getLength()/60);for(k=Math.ceil(k);k<l;k++){var m=e[f];m||(m=g.vd("DIV"),a.nb.appendChild(m));f++;m.className=0==k%60?"ytp-60m-progress":0==k%30?"ytp-30m-progress":0==k%15?"ytp-15m-progress":"ytp-1m-progress";var n=(60*k/a.o.getLength()-c)*b.g;m.style.left=n+"px"}}b=a.Oa?a.o.g:0;a.update({boundTimeLeft:g.MN(uO(a.o,c)-b),boundTimeRight:g.MN(uO(a.o,d)-b)});for(c=
e.length-1;c>=f;c--)g.Ad(e[c]);a.element.style.height=a.H+(a.F?8:5)+"px";a.P("height-change",a.H);a.ed.style.height=a.H+(a.F?20:13)+"px";for(var p in a.R)lQ(a,p);mQ(a);gQ(a);cQ(a,a.G,a.ka)};
kQ=function(a){var b=a.Ia.x,c=a.B*a.X;b=g.Uc(b,0,a.B);a.yb.update(b,a.B,-a.J,-(c-a.J-a.B));return a.yb};
cQ=function(a,b,c){a.G=b;a.ka=c;var d=kQ(a),e=a.o.g,f=uO(a.o,a.G);a.update({ariamin:Math.floor(a.o.l),ariamax:Math.floor(e),arianow:Math.floor(f),arianowtext:g.$L("$PLAY_PROGRESS of $DURATION",{PLAY_PROGRESS:g.MN(f),DURATION:g.MN(e)})});e=vO(a.o,a.O,0);var k=vO(a.o,a.L,1);f=g.Uc(b,e,k);c=a.ob?1:g.Uc(c,e,k);g.hh(a.fd,"transform","translateX("+(b*d.g+d.o)+"px)");nQ(a,a.Oc,d,e,f);nQ(a,a.Wb,d,e,c)};
oQ=function(a,b,c){b=Math.max(c*b.g+b.o,0);a.style.left=b+"px";return b};
nQ=function(a,b,c,d,e,f){f=void 0===f?!1:f;oQ(b,c,d);d=g.Uc((e-d)*c.g+c.o,0,c.width);f||g.V(a.l).o?b.style.width=d+"px":g.hh(b,"transform","scalex("+(c.width?d/c.width:0)+")")};
gQ=function(a){var b=a.O>a.o.l,c=0<a.o.g&&a.L<a.o.g;g.K(a.element,"ytp-clip-start-enabled",b);g.K(a.element,"ytp-clip-end-enabled",c);b=b?vO(a.o,a.O,0):0;c=c?vO(a.o,a.L,1):1;a.ga.style.left=Math.round(1E3*b)/10+"%";a.ha.style.left=Math.round(1E3*c)/10+"%";a.cd.style.width=Math.round(1E3*b)/10+"%";a.ab.style.left=Math.round(1E3*c)/10+"%";a.ab.style.width=Math.round(1E3*(1-c))/10+"%"};
mQ=function(a){for(var b=0;b<a.ba.length;b++){for(var c=a.T[a.ba[b].getId()],d=Number(c.getAttribute("data-left"))-24,e=!1,f=b-1;0<=f;f--){var k=a.T[a.ba[f].getId()];if("none"!=k.style.display){Number(k.getAttribute("data-left"))>d&&(e=!0);break}}c.style.display=e?"none":""}};
eQ=function(a){var b=kQ(a);nQ(a,a.Cb,b,a.G,b.l);g.K(a.Cb,"ytp-hover-progress-light",b.l>a.G)};
lQ=function(a,b){var c=a.R[b],d=a.oa[b],e=kQ(a),f=vO(a.o,c.start/1E3,0),k=mha(c,a.F),l=k/e.width;switch(c.style){case "ytp-chapter-marker":var m=f+l/2;f-=l/2;d.style.borderRadius=k+"px";break;default:m=vO(a.o,c.end/1E3,1),l!=Number.POSITIVE_INFINITY&&(f=g.Uc(f,0,m-l)),m=Math.min(m,f+l)}c.color&&(d.style.background=c.color);nQ(a,d,e,f,m,!0);(c=a.T[b])&&c.setAttribute("data-left",oQ(c,e,f))};
pQ=function(a,b){var c=b.getId();if(a.R[c]==b){g.Ad(a.oa[c]);delete a.R[c];delete a.oa[c];var d=a.T[c];d&&(g.Ad(d),delete a.T[c],c=a.ba,d=g.Za(c,b,g.$B),0<=d&&g.Pa(c,d))}};
fQ=function(a,b){b?a.C||(a.element.removeAttribute("aria-disabled"),a.C=new g.Vq(a.zc,!0),a.C.subscribe("hovermove",a.KK,a),a.C.subscribe("hoverend",a.JK,a),a.C.subscribe("dragstart",a.IK,a),a.C.subscribe("dragmove",a.MK,a),a.C.subscribe("dragend",a.LK,a),a.Mb=a.fa("keydown",a.mH)):a.C&&(a.element.setAttribute("aria-disabled",!0),a.Pa(a.Mb),a.C.cancel(),a.C.dispose(),a.C=null)};
g.qQ=function(a,b,c,d,e){var f={D:"div",I:"ytp-panel"};if(c){var k="ytp-panel-title";var l={D:"div",I:"ytp-panel-header",K:[{D:"button",W:["ytp-button",k],K:[c]}]};if(e){var m="ytp-panel-options";l.K.push({D:"button",W:["ytp-button",m],K:[d]})}f.K=[l]}g.Ns.call(this,f);this.X=b;b.aa(this.element);this.ga=!1;c&&(this.M(this.g[k],"click",this.oa),this.ga=!0,e&&this.M(this.g[m],"click",e));b.subscribe("size-change",this.ka,this);this.M(a,"fullscreentoggled",this.ka)};
g.rQ=function(a,b,c,d,e){b=void 0===b?null:b;var f={role:"menu"};b&&(f.id=b);b=new g.Ns({D:"div",I:"ytp-panel-menu",N:f});g.qQ.call(this,a,b,c,d,e);this.F=b;g.I(this,this.F);this.Ea=[]};
g.sQ=function(a,b,c){if(void 0===c?0:c)a.Ea.push(b),a.F.element.appendChild(b.element);else{c=g.Za(a.Ea,b,Oka);if(0<=c)return;c=~c;g.Wa(a.Ea,c,0,b);zd(a.F.element,b.element,c)}b.subscribe("size-change",a.ba,a);a.F.P("size-change")};
g.tQ=function(a,b){b.unsubscribe("size-change",a.ba,a);a.ea()||(g.Qa(a.Ea,b),a.F.element.removeChild(b.element),a.F.P("size-change"))};
g.uQ=function(a){for(var b=g.q(a.Ea),c=b.next();!c.done;c=b.next())c.value.unsubscribe("size-change",a.ba,a);a.Ea=[];g.yd(a.F.element);a.F.P("size-change")};
Oka=function(a,b){return b.priority-a.priority};
g.vQ=function(a,b,c,d,e,f){var k=g.Qs({"aria-haspopup":"true"});g.Ps.call(this,k,b,a);this.A=d;this.H=!1;this.F=null;this.o={};this.C=new g.rQ(c,void 0,a,e,f);g.I(this,this.C);this.fa("keydown",this.qH);this.fa("click",this.open)};
g.wQ=function(a,b){g.uQ(a.C);for(var c={},d=!1,e=0;e<b.length;e++){var f=b[e],k=a.o[f],l=f==a.F;l&&(d=!0);k&&k.priority==-e?(l=a,g.Os(l.o[f],l.ye(f,!0)),delete a.o[f]):k=a.Xn(f,-e,l);c[f]=k;g.sQ(a.C,k,!0)}d||(a.F=null);for(var m in a.o)a.o[m].dispose();a.o=c};
g.xQ=function(a,b){g.FP.call(this,a,{D:"div",W:["ytp-popup",b||null]},100,!0);this.A=[];this.size=new g.ad(0,0);this.C=this.F=null;this.O=this.T=0;this.fa("keydown",this.bH)};
zQ=function(a){g.Ah(a.element,a.T||"100%",a.O||"100%");var b=yQ(a);b.element.style.width="";b.element.style.height="";b.element.style.maxWidth="100%";b.element.style.maxHeight="100%";b.X.element.style.height="";var c=g.Bh(b.element);c.width+=1;c.height+=1;b.element.style.width=c.width+"px";b.element.style.height=c.height+"px";b.element.style.maxWidth="";b.element.style.maxHeight="";var d=0;b.ga&&(d=g.Bh(b.g["ytp-panel-header"]).height);b.X.element.style.height=c.height-d+"px";a.size=c};
g.BQ=function(a,b){var c=a.A[a.A.length-1];a.A.push(b);AQ(a,c,b)};
g.CQ=function(a){var b=a.A.pop(),c=a.A[0];a.A=[c];AQ(a,b,c,!0)};
AQ=function(a,b,c,d){DQ(a);yQ(a);g.wn(c.element,"ytp-panel-animate-back")||g.wn(c.element,"ytp-panel-animate-forward");b&&(b.unsubscribe("size-change",a.Bk,a),b.unsubscribe("back",a.ee,a));c.subscribe("size-change",a.Bk,a);c.subscribe("back",a.ee,a);if(a.Ma()){g.J(c.element,d?"ytp-panel-animate-back":"ytp-panel-animate-forward");c.aa(a.element);c.focus();a.element.scrollLeft=0;a.element.scrollTop=0;var e=a.size;zQ(a);g.Ah(a.element,e);a.F=new g.L(g.Ea(a.VM,b,c,d),20,a);a.F.start()}else c.aa(a.element),
b&&g.Ad(b.element)};
yQ=function(a){return a.A[a.A.length-1]};
DQ=function(a){a.F&&g.Jn(a.F);a.C&&g.Jn(a.C)};
EQ=function(a){return a.toLocaleString("en",{style:"percent"})};
g.GQ=function(a,b){g.P.call(this,{D:"div",W:["ytp-time-display","notranslate"],K:[{D:"span",I:"ytp-time-current",V:"{{currenttime}}"},{D:"span",I:"ytp-time-separator",V:" / "},{D:"span",I:"ytp-time-duration",V:"{{duration}}"}]});this.l=new g.P({D:"button",W:["ytp-live-badge","ytp-button"],N:{disabled:"true"},V:"{{content}}"});this.l.jb("Live");g.I(this,this.l);this.l.aa(this.element);this.B=a;this.L=b.kb();this.A=null;this.C=!1;this.H=null;this.J=!1;this.G=this.F=null;this.fa("click",this.O);this.M(a,
"presentingplayerstatechange",this.o);this.M(a,"appresize",this.o);this.M(a,"videodatachange",this.T);var c=a.getVideoData();c&&FQ(this,c);this.o()};
FQ=function(a,b){a.C=b.ra;a.J=b.isPremiere;g.K(a.element,"ytp-live",a.C)};
g.HQ=function(a){g.P.call(this,{D:"div",I:"ytp-bezel",N:{role:"status","aria-label":"{{label}}"},K:[{D:"div",I:"ytp-bezel-icon",V:"{{icon}}"}]});this.o=new g.L(this.show,10,this);g.I(this,this.o);this.l=new g.L(this.hide,500,this);g.I(this,this.l);this.A=a;this.hide()};
IQ=function(a,b,c){return b?a.baseYtUrl+"subscription_ajax":c?"/subscription_service":""};
g.JQ=function(a,b,c,d,e,f,k,l,m,n,p,u){f&&(a=a.charAt(0)+a.substring(1).toLowerCase(),c=c.charAt(0)+c.substring(1).toLowerCase());if("0"===b||"-1"===b)b=null;if("0"===d||"-1"===d)d=null;if(p){c=g.V(u);p={href:p,"aria-label":"Subscribe to channel"};if(g.Zx(c)||g.$x(c))p.target="_blank";g.P.call(this,{D:"div",W:["ytp-button","ytp-sb"],K:[{D:"a",I:"ytp-sb-subscribe",N:p,K:[{D:"div",I:"ytp-sb-text",K:[{D:"div",I:"ytp-sb-icon"},a]},b?{D:"div",I:"ytp-sb-count",V:b}:""]}]});f&&g.J(this.element,"ytp-sb-classic")}else{g.P.call(this,
{D:"div",W:["ytp-button","ytp-sb"],K:[{D:"div",I:"ytp-sb-subscribe",N:{"aria-label":"Subscribe to channel"},K:[{D:"div",I:"ytp-sb-text",K:[{D:"div",I:"ytp-sb-icon"},a]},b?{D:"div",I:"ytp-sb-count",V:b}:""]},{D:"div",I:"ytp-sb-unsubscribe",N:{"aria-label":"Unsubscribe to channel"},K:[{D:"div",I:"ytp-sb-text",K:[{D:"div",I:"ytp-sb-icon"},c]},d?{D:"div",I:"ytp-sb-count",V:d}:""]}]});var x=this;this.l=k;var B=this.g["ytp-sb-subscribe"],F=this.g["ytp-sb-unsubscribe"];f&&g.J(this.element,"ytp-sb-classic");
if(e){l&&g.J(this.element,"ytp-sb-subscribed");var H=null;"gaming"==g.V(u).playerStyle&&(H="gaming_channels");var Q=function(){if(m||n){var a=x.l;g.Fp(IQ(g.V(u),!!m,!!n),m?{method:"POST",Bc:{action_create_subscription_to_channel:1,c:a},qb:{feature:m,silo_name:H},withCredentials:!0}:n?{method:"POST",Bc:{action_subscribe:1},qb:{channel_ids:a,itct:n}}:{});u.na("SUBSCRIBE")}F.focus();F.removeAttribute("aria-hidden");B.setAttribute("aria-hidden",!0)},O=function(){if(m||n){var a=x.l;
g.Fp(IQ(g.V(u),!!m,!!n),m?{method:"POST",Bc:{action_remove_subscriptions:1},qb:{c:a,silo_name:H,feature:m},withCredentials:!0}:n?{method:"POST",Bc:{action_unsubscribe:1},qb:{channel_ids:a,itct:n}}:{});u.na("UNSUBSCRIBE")}B.focus();B.removeAttribute("aria-hidden");F.setAttribute("aria-hidden",!0)};
this.M(B,"click",Q);this.M(F,"click",O);this.M(B,"keypress",function(a){13==a.keyCode&&Q(a)});
this.M(F,"keypress",function(a){13==a.keyCode&&O(a)});
this.M(u,"SUBSCRIBE",this.o);this.M(u,"UNSUBSCRIBE",this.A)}else g.J(B,"ytp-sb-disabled"),g.J(F,"ytp-sb-disabled")}};
g.LQ=function(a,b,c,d,e,f){b=g.KQ(b,c,f);d=d||375;e=e||440;if(b=window.open(b,"loginPopup","width="+d+",height="+e+",resizable=yes,scrollbars=yes",!0))c=g.dr("LOGGED_IN",function(b){g.er(g.ep("LOGGED_IN_PUBSUB_KEY",void 0));g.dp("LOGGED_IN",!0);a(b)}),g.dp("LOGGED_IN_PUBSUB_KEY",c),b.moveTo((window.screen.width-d)/2,(window.screen.height-e)/2)};
g.KQ=function(a,b,c){var d="/signin?context=popup";c&&(d=window.document.location.protocol+"//"+c+d);c=window.document.location.protocol+"//"+window.document.domain+"/post_login";a&&(c=Hg(c,"mode",a));a=Hg(d,"next",c);b&&(a=Hg(a,"feature",b));return a};
g.MQ=function(a,b){var c=g.ZH(a).Ha();g.P.call(this,{D:"div",K:[{D:"div",I:"ytp-tooltip-bg",K:[{D:"div",I:"ytp-tooltip-duration",V:"{{duration}}"}]},{D:"div",I:"ytp-tooltip-text-wrapper",K:[{D:"div",I:"ytp-tooltip-image"},{D:"div",I:"ytp-tooltip-title",V:"{{title}}"},{D:"span",I:"ytp-tooltip-text",V:"{{text}}"}]}]});this.R=a;this.oa=b;this.L=g.V(a);this.ga=this.L.o;this.H=this.g["ytp-tooltip-bg"];this.pa=this.g["ytp-tooltip-image"];this.Y=(0,g.z)(this.cK,this);this.F=(0,g.z)(this.fK,this);this.X=
(0,g.z)(this.Zd,this);this.l=null;this.J=new g.EN(this,100);g.I(this,this.J);this.o=null;this.T=!1;this.A=null;this.C=window.NaN;this.G="";this.ka=c.width;this.O=!0;this.B=1;this.ba=new g.L(this.AD,250,this);g.I(this,this.ba);this.ha=new g.L(this.Zd,5E3,this);g.I(this,this.ha)};
g.RP=function(a,b){if(a.ga)return g.va;b.addEventListener("mouseover",a.F);g.R(a.L.experiments,"show_tooltip_on_tab_killswitch")||b.addEventListener("focus",a.F);return(0,g.z)(function(){this.l==b&&this.Zd();b.removeEventListener("mouseover",this.F);g.R(this.L.experiments,"show_tooltip_on_tab_killswitch")||b.removeEventListener("focus",this.F)},a)};
g.OQ=function(a,b,c,d){(0,window.isNaN)(a.C)||(a.C=window.NaN,a.H.style.background="");a.l=b;a.T=!!d;d?a.G=d:(a.G=b.getAttribute("title"),b.removeAttribute("title"));a.element.className="ytp-tooltip";if(d=b.getAttribute("data-tooltip-image"))a.pa.style.backgroundImage="url("+d+")";g.K(a.element,"ytp-tooltip-image-enabled",!!d);b=b.getAttribute("data-tooltip-opaque");g.K(a.element,"ytp-tooltip-opaque",!!b);a.o=c;a.R.addEventListener("appresize",a.X);a.O&&(g.NQ(a),a.J.show(0))};
g.NQ=function(a){var b;a.l&&(b=a.l.getAttribute("data-tooltip-text"));if(b&&!a.T){a.updateValue("text",b);var c=a.l.getAttribute("data-duration");a.update({title:a.G,duration:c});var d=a.l.getAttribute("data-preview"),e=160*a.B,f=90*a.B,k=160*a.B,l=90*a.B;a.H.style.width=e+"px";a.H.style.height=f+"px";a.H.style.backgroundImage=d?"url("+d+")":"";a.H.style.backgroundPosition=(e-k)/2+"px "+(f-l)/2+"px";a.H.style.backgroundSize=k+"px "+l+"px";g.xn(a.element,["ytp-text-detail","ytp-preview"]);g.K(a.element,
"ytp-has-duration",!!c)}else a.updateValue("text",a.G),g.zn(a.element,["ytp-text-detail","ytp-preview","ytp-has-duration"]);3==a.o?a.element.setAttribute("role","status"):a.element.removeAttribute("role");PQ(a,!!b)};
PQ=function(a,b,c,d){a.element.style.maxWidth=b?"":Math.min(a.ka,300*a.B)+"px";a.oa.Um(a.element,a.l,c,1==a.o,d);a.element.style.top?g.J(a.element,"ytp-bottom"):a.element.style.bottom&&g.J(a.element,"ytp-top");3==a.o&&a.ha.start()};
g.SP=function(a){a.l&&!a.T&&a.l.hasAttribute("title")&&(a.G=a.l.getAttribute("title"),a.l.removeAttribute("title"),a.O&&g.NQ(a))};
QQ=function(a,b){g.K(a.element,"ytp-preview",0<=b);if(!(0>b||b==a.C)){a.C=b;var c=160*a.B,d=160*a.B,e=g.cz(a.A,a.C,c);g.EP(a.H,e,c,d,!0);a.ba.start()}};
RQ=function(a,b,c,d){var e=b.getVideoData(),f=a.getVideoData();return 0==b.tb()||g.R(d.experiments,"html5_non_zero_gapless")?f.ra&&!(0,window.isFinite)(c)?"live-infinite":e.xa.g&&f.xa.g?!g.R(d.experiments,"html5_no_gapless_time_travel_killswitch")&&c<1E3*a.tb()?"timetravel":e.xa.videoInfos[0].containerType!=f.xa.videoInfos[0].containerType?"container":g.qA(f)&&g.qA(e)?"content-protection":g.qA(f)&&!g.R(d.experiments,"html5_gapless_encrypted_to_clear")?"encrypted-to-clear":f.xa.g[0].audio.sampleRate!=
e.xa.g[0].audio.sampleRate?"sample-rate":null:"non-dash":"non-zero"};
TQ=function(a,b,c){g.G.call(this);var d=this;this.g=a;this.L=b;c.getPlayerType();this.o=c;this.F=new window.Map;this.l=[];this.B=null;this.J=window.NaN;this.G=this.A=null;this.H=new g.L(function(){SQ(d,d.J)});
g.I(this,this.H);this.C=new g.Pq(this);g.I(this,this.C);this.C.M(this.g,g.aC("childplayback"),this.O);this.C.M(this.g,"onQueuedVideoLoaded",this.R);this.C.M(this.g,"presentingplayerstatechange",this.T)};
Qka=function(a,b,c,d,e){var f=a.o;e=e||d+c;f.zb();f.Xg();for(var k,l=g.q(a.l),m=l.next();!m.done;m=l.next())m=m.value,d==m.Be&&(k=m);l="childplayback_"+Pka++;m={hd:UQ(c,!0),Bi:window.Infinity,target:null};b={qd:l,playerVars:b,playerType:2,durationMs:c,Wd:d,Be:e,Xf:m};k?VQ(a,k,{hd:UQ(k.durationMs,!0),Bi:window.Infinity,target:b}):(d={hd:UQ(d,!1),Bi:d,target:b},a.F.set(d.hd,d),$G(f,d.hd));a.l=a.l.concat(b).sort(function(a,b){return a.Wd-b.Wd});
a.o==a.g.xb()&&(f=1E3*f.tb(),f>=b.Wd&&f<b.Be&&WQ(a,b,(f-b.Wd)/1E3,a.g.xb().o));return l};
UQ=function(a,b){return new g.YB(Math.max(0,a-2500),b?0x8000000000000:a-1,{namespace:"childplayback",priority:7})};
YQ=function(a,b,c){var d=b.qd,e=b.playerVars,f=b.playerType;a.B=b;b=new g.Xz(a.L,e);b.qd=d;c=void 0===c?window.Infinity:c;a=a.g.app;c=void 0===c?window.Infinity:c;f=f||a.o.getPlayerType();f=XQ(a,f);JG(f,b,(0,g.z)(a.kd,a));CI(a,f,c)};
VQ=function(a,b,c){var d=b.Xf;b.Xf=c;ZQ(a,b)&&(a=a.g.xb(),a.H.A(d.hd),$G(a,b.Xf.hd));d.hd.dispose()};
aR=function(a){a.B=null;var b=a.g.app;(b.ka?b.ka.g:b.J)&&$Q(a.g.app)};
bR=function(a,b){ZQ(a,b);return b.Be==b.Wd+b.durationMs?b.Wd+1E3*a.g.xb().tb():b.Be};
cR=function(a,b){for(var c=0,d=g.q(a.l),e=d.next();!e.done;e=d.next()){e=e.value;var f=e.Wd/1E3+c,k=f+e.durationMs/1E3;if(f>b)break;if(k>b)return{lo:e,Nq:b-f};c=k-e.Be/1E3}return{lo:null,Nq:b-c}};
SQ=function(a,b){var c=a.G||a.g.xb().o;dR(a,!0);aR(a);var d=cR(a,b),e=d.lo;d=d.Nq;e?WQ(a,e,d,c):eR(a,d,c)};
eR=function(a,b,c){var d=a.o;if(d!=a.g.xb()){var e=d.getPlayerType();g.VM(a.g.app,e)}YG(d,b,!0);fR(a,c)};
WQ=function(a,b,c,d){var e=ZQ(a,b);if(!e){g.VM(a.g.app,b.playerType);var f=new g.Xz(a.L,b.playerVars);f.qd=b.qd;f.zj=!0;gR(a.g.app,f,b.playerType,void 0)}f=a.g.xb();e||$G(f,b.Xf.hd);YG(f,c,!0);fR(a,d)};
fR=function(a,b){var c=a.g.xb(),d=c.o;g.qB(b)&&!g.qB(d)?qH(c):g.U(b,4)&&!g.U(d,4)&&xH(c)};
dR=function(a,b){a.J=window.NaN;a.H.stop();a.A&&b&&wH(a.A);a.G=null;a.A=null};
ZQ=function(a,b){var c=a.g.xb();return!!c&&c.getVideoData().qd==b.qd};
iR=function(a,b){for(var c=b=void 0===b?-1:b,d=g.q(a.F),e=d.next();!e.done;e=d.next()){var f=g.q(e.value);e=f.next().value;f=f.next().value;f.Bi>c&&(f.hd.dispose(),a.F["delete"](e))}c=b;d=[];e=g.q(a.l);for(f=e.next();!f.done;f=e.next())if(f=f.value,f.Wd>c){var k=a;k.B==f&&aR(k);ZQ(k,f)&&g.BI(k.g,f.playerType);f.Xf.hd.dispose()}else d.push(f);a.l=d;d=cR(a,b/1E3);c=d.lo;d=d.Nq;c&&(d*=1E3,hR(a,c,d,c.Be==c.Wd+c.durationMs?c.Wd+d:c.Be))};
hR=function(a,b,c,d){b.durationMs=c;b.Be=d;d={hd:UQ(c,!0),Bi:c,target:null};VQ(a,b,d);ZQ(a,b)&&1E3*a.g.xb().tb()>c&&(b=bR(a,b)/1E3,eR(a,b,a.g.xb().o))};
jR=function(a,b,c){this.g=a;this.l=b;this.B=c;this.A={status:"unstarted",error:null}};
Rka=function(a){if("success"==a.A.status){var b=a.g.l,c=kR(a);gH(a.l,new g.LF(b.ue()?b.l:b,c.Ex,c.Dx));a.l.Za("gapless",a.g.getVideoData().clientPlaybackNonce);g.Jf(function(){!a.l.getVideoData().Gd&&g.qB(a.l.o)&&KH(a.l)});
lR(a,"finished")}};
mR=function(a){a.g.unsubscribe("internalvideodatachange",a.o,a);a.l.unsubscribe("internalvideodatachange",a.o,a);a.g.unsubscribe("mediasourceattached",a.o,a)};
lR=function(a,b){a.A={status:b,error:null}};
nR=function(a,b){a.A={status:"error",error:b};a.l&&a.l.Za("gaplessError",b);mR(a)};
kR=function(a){var b=a.g.l;b=b.ue()?b.g:0;var c=a.g.getVideoData().ra?window.Infinity:NH(a.g,!0);c=Math.min(a.B/1E3,c)+b;a=c-a.l.tb();return{ZB:b,Ex:a,YB:c,Dx:window.Infinity}};
Ska=function(a){var b=this;this.l=a;this.C=this.A=this.g=null;this.G=!1;this.o=this.B=null;this.F=function(){return g.Jf(function(){b.G&&wG(b.l.xb(),!0,!1);b.o&&Rka(b.o);oR(b.l.app,b.g);var a=b.g.getPlayerType();g.VM(b.l.app,a);b.l.Kb();b.B.resolve(void 0);pR(b)})}};
Tka=function(a,b,c,d){d=void 0===d?0:d;a.B=new xE;a.g=b;b=c;var e=a.l.xb(),f=e.getVideoData().ra?window.Infinity:1E3*NH(e,!0);b>f&&(b=f,a.G=!0);e.tb()>=b/1E3?a.F():(a.A=e,a.l.addEventListener(g.aC("vqueued"),a.F),b=(0,window.isFinite)(b)||b/1E3>a.A.Xg()?b:0x8000000000000,a.C=new g.YB(b,0x8000000000000,{namespace:"vqueued"}),$G(a.A,a.C));a.g.getVideoData().mh=!0;a.g.getVideoData().zj=!0;PG(a.g,!0);a.g.Za("queued","1");0!=d&&YG(a.g,d/1E3,!0);g.R(g.V(a.l).experiments,"html5_gapless")&&(a.o=new jR(a.l.xb(),
a.g,c),c=a.o,"error"!=c.A.status&&(lR(c,"pending"),c.g.subscribe("internalvideodatachange",c.o,c),c.l.subscribe("internalvideodatachange",c.o,c),c.g.subscribe("mediasourceattached",c.o,c),c.o()));return a.B};
pR=function(a){a.A&&(a.l.removeEventListener(g.aC("vqueued"),a.F),a.A.H.A(a.C),a.A=null,a.C=null);if(a.o){if("finished"!=a.o.getStatus().status){var b=a.o;"error"!=b.A.status&&nR(b,"Canceled")}a.o=null}a.B=null;a.g=null;a.G=!1};
sR=function(a,b){g.G.call(this);var c=this;this.A=a||window.NaN;this.o=b||null;this.l=new g.L(function(){qR(c);rR(c)});
g.I(this,this.l);this.g=[]};
qR=function(a){var b=g.qr();a.g.forEach(function(c){c.expire<b&&tR(a,c,!0)});
a.g=(0,g.Bd)(a.g,function(a){return!(a.expire<b)})};
tR=function(a,b,c){c&&a.o&&a.o(b.value)};
rR=function(a){a.l.stop();var b=window.Infinity;for(var c=g.q(a.g),d=c.next();!d.done;d=c.next())d=d.value,d.expire<b&&(b=d.expire);b&&(0,window.isFinite)(b)&&(b=Math.max(b-(0,g.D)(),0),a.l.start(b))};
uR=function(){this.g=[];this.l=[];this.o=[]};
xR=function(a,b,c){c=g.vd(c?"AUDIO":"VIDEO");g.Fa(c,Uka);g.Cq(c,"loadeddata",(0,g.z)(c.l,c));Sx&&6<=g.vR&&g.Cq(c,"webkitbeginfullscreen",(0,g.z)(c.play,c));a.l.push(c);b?a.o.push(c):wR(a,c);return c};
wR=function(a,b){g.Ma(a.l,b)&&!g.Ma(a.g,b)&&(b.gf(),g.Qa(a.o,b)||a.g.push(b))};
yR=function(a){g.G.call(this);this.l=null;for(var b=[],c=0;100>=c;c++)b.push(c/100);b={threshold:b};(this.g=window.IntersectionObserver?new window.IntersectionObserver((0,g.z)(this.o,this),b):null)&&this.g.observe(a)};
zR=function(a){var b=a.g;g.P.call(this,{D:"div",W:["html5-video-player"],N:{tabindex:"-1",id:a.Ca.attrs.id},K:[{D:"div",I:"html5-video-container",N:{"data-layer":"0"}},{D:"input",I:"ytp-attestation-challenge",N:{id:"atr_challenge",type:"hidden",value:"","data-layer":"0"}}]});b.transparentBackground&&this.Jm("ytp-transparent");g.mq(this.element,"version",a.Ca.assets.js);this.app=a;this.A=this.g["html5-video-container"];this.ba=this.g["ytp-attestation-challenge"];this.o=new g.Tg(0,0,0,0);this.l=null;
this.H=new g.Tg(0,0,0,0);this.L=this.T=this.G=window.NaN;this.C=!1;this.J=window.NaN;this.O=!1;this.F=null;this.addEventListener=(0,g.z)(this.element.addEventListener,this.element);this.removeEventListener=(0,g.z)(this.element.removeEventListener,this.element);this.dispatchEvent=function(){};
this.R=(0,g.z)(function(){this.element.focus()},this);
g.ny(b)&&"blazer"!=b.playerStyle&&window.matchMedia&&(this.X="desktop-polymer"==b.playerStyle?[{query:window.matchMedia("(max-width: 656px)"),size:new g.ad(426,240)},{query:window.matchMedia("(max-width: 856px)"),size:new g.ad(640,360)},{query:window.matchMedia("(max-width: 999px)"),size:new g.ad(854,480)},{query:window.matchMedia("(min-width: 1720px) and (min-height: 980px)"),size:new g.ad(1280,720)},{query:window.matchMedia("(min-width: 1294px) and (min-height: 630px)"),size:new g.ad(854,480)},
{query:window.matchMedia("(min-width: 1000px)"),size:new g.ad(640,360)}]:[{query:window.matchMedia("(max-width: 656px)"),size:new g.ad(426,240)},{query:window.matchMedia("(min-width: 1720px) and (min-height: 980px)"),size:new g.ad(1280,720)},{query:window.matchMedia("(min-width: 1294px) and (min-height: 630px)"),size:new g.ad(854,480)},{query:window.matchMedia("(min-width: 657px)"),size:new g.ad(640,360)}]);this.Y=b.useFastSizingOnWatchDefault;this.B=new g.ad(window.NaN,window.NaN);Vka(this);this.M(a.l,
"mutedautoplaychange",this.UG)};
Vka=function(a){var b=a.app.l,c=(0,g.z)(a.fD,a),d=(0,g.z)(a.gD,a),e=(0,g.z)(a.TG,a),f=(0,g.z)(a.PC,a);b.addEventListener("initializingmode",c);b.addEventListener("videoplayerreset",d);b.addEventListener("videodatachange",e);b.addEventListener("presentingplayerstatechange",f);g.We(a,function(){b.removeEventListener("initializingmode",c);b.removeEventListener("videoplayerreset",d);b.removeEventListener("videodatachange",e);b.removeEventListener("presentingplayerstatechange",f)})};
AR=function(a){a.l&&(a.l.removeEventListener("focus",a.R),g.Ad(a.l),a.l=null)};
BR=function(a,b){if(a.l){var c=a.app.g;cu&&(a.l.setAttribute("x-webkit-airplay","allow"),b.title?a.l.setAttribute("title",b.title):a.l.removeAttribute("title"));g.R(a.app.g.experiments,"html5_no_360_remote_killswitch")||(nA(b)?a.l.setAttribute("disableremoteplayback",""):a.l.removeAttribute("disableremoteplayback"));a.l.setAttribute("controlslist","nodownload");c.Bl&&b.videoId&&(a.l.poster=b.tc("default.jpg"))}c=g.uA(b,"yt:bgcolor");a.A.style.backgroundColor=c?c:"";a.G=Kx(g.uA(b,"yt:stretch"));a.T=
Kx(g.uA(b,"yt:crop"),!0);g.K(a.element,"ytp-dni",b.isDni);a.xe()};
g.DR=function(a){return(0,window.isNaN)(a.G)||g.R(a.app.g.experiments,"html5_video_aspect_ratio_stretch_killswitch")?CR(a):a.G};
CR=function(a){var b=g.R(a.app.g.experiments,"html5_aspect_from_adaptive_format"),c=g.W(a.app);if(c=c?c.getVideoData():null){if(c.yf()||c.zf()||c.Oe())return 16/9;if(b&&bA(c)&&c.xa.g)return b=c.xa.videoInfos[0],ER(b.video.width,b.video.height)}return(a=a.l)?ER(a.videoWidth,a.videoHeight):b?16/9:window.NaN};
g.hK=function(a,b){var c=a.Ha(),d=FR(a,c,g.DR(a),b);return new g.Tg((c.width-d.width)/2,(c.height-d.height)/2,d.width,d.height)};
FR=function(a,b,c,d){g.R(a.app.g.experiments,"html5_video_aspect_ratio_stretch_killswitch")&&!(0,window.isNaN)(a.G)&&(c=a.G);var e=c;(0,window.isNaN)(a.L)?(0,window.isNaN)(a.T)||(e=a.T):e=a.L;a=ER(b.width,b.height);(0,window.isFinite)(e)||(e=Math.max(c,a));var f;e>a?f={width:b.width,height:b.width/e,aspectRatio:e}:e<a?f={width:b.height*e,height:b.height,aspectRatio:e}:f={width:b.width,height:b.height,aspectRatio:a};d||(0,window.isNaN)(c)||(c>e?f.width=f.height*c:c<e&&(f.height=f.width/c),f.aspectRatio=
c);return f};
ER=function(a,b){return 1>Math.abs(GR*b-a)||1>Math.abs(GR/a-b)?GR:a/b};
HR=function(a){if(1==a.app.Y)return!1;var b=g.YH(a.app.l);a=g.U(b,1024)&&!g.R(a.app.g.experiments,"dompaused_video_visible_killswitch");return b&&!g.U(b,2)&&!a&&!g.rB(b)};
g.LK=function(a){var b="3"==a.app.g.A&&!a.C&&HR(a)&&!a.app.da;a.l.controls=b;a.l.tabIndex=b?0:-1;b?a.l.removeEventListener("focus",a.R):g.R(a.app.g.experiments,"disable_focus_redirect")||a.l.addEventListener("focus",a.R)};
IR=function(a){var b=a.Ha(),c=1,d=!1,e=FR(a,b,g.DR(a)),f=Tp();if(HR(a)){var k=CR(a);var l=(0,window.isNaN)(k)||g.uu||IF&&g.ry;cu&&!g.jc(601)?k=e.aspectRatio:l=l||"3"==a.app.g.A;l?l=new g.Tg(0,0,b.width,b.height):(c=e.aspectRatio/k,l=new g.Tg((b.width-e.width/c)/2,(b.height-e.height)/2,e.width/c,e.height),1==c&&g.ry&&(k=l.width-b.height*k,0<k&&(l.width+=k,l.height+=k)));f&&(a.l.style.display="");a.O=!0}else l=-b.height,cu?l*=window.devicePixelRatio:g.Js&&(l-=window.screen.height),l=new g.Tg(0,l,b.width,
b.height),f&&(a.l.style.display="none"),a.O=!1;g.Vg(a.H,l)||(a.H=l,g.hy(a.app.g)?(a.l.style.setProperty("width",l.width+"px","important"),a.l.style.setProperty("height",l.height+"px","important")):g.Ah(a.l,g.Xg(l)),g.ph(a.l,g.Yg(l)),d=!0);b=new g.Tg((b.width-e.width)/2,(b.height-e.height)/2,e.width,e.height);g.Vg(a.o,b)||(a.o=b,d=!0);g.hh(a.l,"transform",1==c?"":"scaleX("+c+")");return d};
JR=function(a,b){this.L=a;this.l=void 0===b?!1:b;this.B=g.js();this.g=[];this.C=[];this.G=[];this.J=1;this.o=[];this.A=[];this.F=!1};
g.wI=function(a,b,c){a.F?a.G.push({type:b,data:c}):a.L.P(b,c)};
g.kJ=function(a,b,c){g.Ma(a.g,b);g.Oa(a.g,b);var d=String(a.J++);b.setAttribute("data-visual-id",d);g.We(c,(0,g.z)(a.H,a,b))};
KR=function(a){if(a.l&&a.B!=g.js()){var b=g.js(),c=g.is();if(b&&c){a.B=b;for(var d=g.q(a.g),e=d.next();!e.done;e=d.next())e=e.value,e.visualElement&&Rr(e.visualElement)&&g.Sr(b,c,[e.visualElement])}if(b)for(a=g.q(a.A),e=a.next();!e.done;e=a.next())c=e.value,c.visualElement&&Rr(c.visualElement)&&g.Tr(b,c.visualElement)}};
g.lJ=function(a,b,c){var d=b.getAttribute("data-visual-id");g.Ma(a.g,b);a.l?c&&(b.visualElement=g.Pr(c)):g.wI(a,"onLogServerVeCreated",{id:d,tracking_params:c})};
LR=function(a,b,c,d,e){g.P.call(this,{D:"div",I:"ytp-horizonchart"});this.o=Math.round(a/c);this.H=b;this.C=c;this.F=d;this.G=e;this.Ua=0;this.element.style.width=this.o*this.C+"px";this.element.style.height=this.H+"em";this.l=-1;this.B=this.A=null};
MR=function(a,b){if(-1==a.l){try{var c=g.vd("CANVAS");a.A=c.getContext("2d")}catch(m){}if(a.A){var d=a.o*a.C;a.B=c;a.B.width=d;a.B.style.width=d+"px";a.element.appendChild(a.B)}else for(a.C=Math.floor(a.C/4),a.o*=4,c=0;c<a.C;c++)d=g.vd("SPAN"),d.style.width=a.o+"px",d.style.left=a.o*c+"px",a.element.appendChild(d)}c=a.element.clientHeight||24;c!=a.l&&(a.l=c,a.A&&(c=1<(window.devicePixelRatio||1)?2:1,a.B.height=a.l*c,a.B.style.height=a.l+"px",a.A.scale(1,c)));c=g.q(b);for(var e=c.next();!e.done;e=
c.next()){d=a;var f=a.Ua,k=e.value;for(e=0;e+2<d.F.length&&d.F[e+1]<k;)e++;k=Math.min(1,(k-d.F[e])/(d.F[e+1]-d.F[e]));if(d.A)d.A.fillStyle=d.G[e],d.A.fillRect(f*d.o,0,d.o,d.l),d.A.fillStyle=d.G[e+1],d.A.fillRect(f*d.o,d.l*(1-k),d.o,d.l);else{f=d.element.children[f];var l=window.devicePixelRatio||1;k=Math.min(d.l,Math.round(d.l*k*l)/l)||0;f.style.height=k+"px";f.style.backgroundColor=d.G[e+1];f.style.borderTop="solid "+(d.l-k)+"px "+d.G[e]}a.Ua=(a.Ua+1)%a.C}c=a.Ua;a.A?a.A.clearRect(c*a.o,0,a.o,a.l):
(c=a.element.children[c],c.style.height="0px",c.style.borderTop="")};
NR=function(a){var b=null;b={D:"button",W:["html5-video-info-panel-close","ytp-button"],N:{title:"close"},V:"[x]"};g.P.call(this,{D:"div",I:"html5-video-info-panel",K:[b,{D:"div",I:"html5-video-info-panel-content",K:[{D:"div",K:[{D:"div",V:"Video ID / sCPN"},{D:"span",V:"{{video_id_and_cpn}}"}]},{D:"div",K:[{D:"div",V:"Viewport"},{D:"span",V:"{{dimensions}}"}]},{D:"div",K:[{D:"div",V:"Current / Optimal Res"},{D:"span",V:"{{resolution}}"}]},{D:"div",K:[{D:"div",V:"Volume / Normalized"},{D:"span",V:"{{volume}}"}]},
{D:"div",K:[{D:"div",V:"Codecs"},{D:"span",V:"{{codecs}}"}]},{D:"div",N:{style:"{{shader_info_style}}"},K:[{D:"div",V:"Shader Info"},{D:"span",V:"{{shader_info}}"}]},{D:"div",N:{style:"{{color_style}}"},K:[{D:"div",V:"Color"},{D:"span",V:"{{color}}"}]},{D:"div",N:{style:"{{drm_style}}"},K:[{D:"div",V:"Protected"},{D:"span",V:"{{drm}}"}]},{D:"div",N:{style:"{{host_style}}"},K:[{D:"div",V:"Host"},{D:"span",V:"{{stream_host}}"}]},{D:"div",N:{style:"{{bandwidth_style}}"},K:[{D:"div",V:"Connection Speed"},
{D:"span",K:[{D:"span",V:"{{bandwidth_chart}}"},{D:"span",V:"{{bandwidth_kbps}}"}]}]},{D:"div",N:{style:"{{network_activity_style}}"},K:[{D:"div",V:"Network Activity"},{D:"span",K:[{D:"span",V:"{{network_activity_chart}}"},{D:"span",V:"{{network_activity_bytes}}"}]}]},{D:"div",K:[{D:"div",V:"Buffer Health"},{D:"span",K:[{D:"span",V:"{{buffer_health_chart}}"},{D:"span",V:"{{buffer_health_seconds}}"}]}]},{D:"div",N:{style:"{{live_latency_style}}"},K:[{D:"div",V:"Live Latency"},{D:"span",K:[{D:"span",
V:"{{live_latency_chart}}"},{D:"span",V:"{{live_latency_secs}}"}]}]},{D:"div",N:{style:"{{live_mode_style}}"},K:[{D:"div",V:"Live Mode"},{D:"span",V:"{{live_mode}}"}]},{D:"div",K:[{D:"div",V:"Dropped Frames"},{D:"span",V:"{{dropped_frames}}"}]},{D:"div",N:{style:"{{playback_categories_style}}"},K:[{D:"div",V:"Playback Categories"},{D:"span",V:"{{playback_categories}}"}]}]}]});b&&this.M(this.g["html5-video-info-panel-close"],"click",this.hide);b=[0,18750,37500,81250,128E3,256E3,512E3,2048E3,8192E3,
32768E3,131072E3];var c="#000 #d53e4f #f46d43 #fdae61 #fee08b #e6f598 #abdda4 #66c2a5 #3288bd #124588 #fff".split(" "),d=b.map(function(a){return a/4});
this.A=new LR(300,1,150,b,c);g.I(this,this.A);this.updateValue("bandwidth_chart",this.A);this.C=new LR(300,1,150,[0,3,10,15,30,60,90],"#000 #66c2a5 #abdda4 #e6f598 #fdae61 #f46d43 #a8330f".split(" "));g.I(this,this.C);this.updateValue("live_latency_chart",this.C);this.B=new LR(300,1,150,[0,15,30,60,90,120],"#000 #fdae61 #e6f598 #66c2a5 #3288bd #fff".split(" "));g.I(this,this.B);this.updateValue("buffer_health_chart",this.B);this.F=new LR(300,1,150,d,c);g.I(this,this.F);this.updateValue("network_activity_chart",
this.F);this.l=new g.L(this.Fq,500,this);g.I(this,this.l);this.o=a};
OR=function(a){var b=/codecs="([^"]*)"/.exec(a.mimeType);return(b&&b[1]?b[1]+" ("+g.ot(a)+")":g.ot(a))+(a.video&&a.video.isAccelerated?" [acc]":"")};
QR=function(a,b){g.G.call(this);var c=this;this.Ca=Bea(b);var d=this.Ca.args||{};this.g=new iy(d);g.I(this,this.g);g.R(this.g.experiments,"html5_parse_inline_fallback_host")&&(iw=!0);g.R(this.g.experiments,"html5_vp9_new_mime")&&void 0!=window.navigator.mediaCapabilities&&(px=!0);g.R(this.g.experiments,"html5_manifestless_otf_killswitch")&&($w=!1);g.R(this.g.experiments,"html5_disable_subtract_cuepoint_offset")&&(yD=!0);g.R(this.g.experiments,"html5_enable_webm_cue_refactor")&&(PR=!0);this.ie=T(g.Wx(this.g)&&
!0,d.enablesizebutton);this.cd=T(!1,d.player_wide);this.H=new oG;g.I(this,this.H);this.X=T(!1,d.external_list);this.Ta=(this.ed=T(!1,d.external_play_video))&&g.R(this.g.experiments,"player_unified_fullscreen_transitions");this.O=new g.Pq(this);g.I(this,this.O);og=function(a,b){g.M(b,"WARNING")};
this.T=null;this.ba=new g.fo;g.I(this,this.ba);this.ha=new g.fo;g.I(this,this.ha);this.L=new JR(this.ha,g.R(this.g.experiments,"use_local_interactions_library"));this.L.pause();this.l=new g.TH(this);g.I(this,this.l);this.Z=new g.TH(this,1);g.I(this,this.Z);this.G=new zR(this);g.I(this,this.G);this.Y=1;this.Wb={};this.R=this.g.storeUserVolume?Wfa():{volume:100,muted:this.g.mute};this.nb=this.g.sb?new SB(this,1):new Ts(this,1);g.I(this,this.nb);this.B=null;this.Nc={};d={};this.zc=(d.internalvideodatachange=
this.sI,d.playbackready=this.tI,d.playbackstarted=this.uI,d.statechange=this.TD,d.signatureexpired=this.wL,d);this.C=Wka(this);this.dd=new g.Pq(this);g.I(this,this.dd);this.pa=new UB(this.g,this.C);this.A=Xka(this);d={};this.he=(d.airplayactivechange=this.kI,d.airplayavailabilitychange=this.lI,d.beginseeking=this.BI,d.endseeking=this.lJ,d.internalAbandon=this.xJ,d.internalaudioformatchange=this.wI,d.internalvideodatachange=this.Jp,d.internalvideoformatchange=this.VL,d.liveviewshift=this.FJ,d.playbackstalledatstart=
this.BL,d.progresssync=this.NK,d.seekcomplete=this.WD,d.seekto=this.XD,d.onLoadProgress=this.GJ,d.onVideoProgress=this.ZD,d.onLoadedMetadata=this.IJ,d.onDompaused=this.gJ,d.playbackready=this.AK,d.statechange=this.Ay,d.connectionissue=this.VI,d.newelementrequired=this.fy,d.heartbeatparams=this.UD,d.videoelementevent=this.YD,d.drmoutputrestricted=this.iJ,d.requestmediasource=this.bL,d);this.Ia=new g.Pq(this);g.I(this,this.Ia);this.o=null;d=g.gy(this.g)?3:10;this.Va=new sR(d,function(a){a!=g.W(c,a.getPlayerType())&&
(Yka("c","prefetch_"+a.getVideoData().videoId),a.dispose())});
g.I(this,this.Va);this.Cc=this.Lc=-1;this.Mb=new g.L(this.G.xe,16,this.G);g.I(this,this.Mb);this.ob=!1;this.oa=!0;this.Ja=this.ab=this.F=null;this.fd=!1;this.Mc=this.Qd=null;this.wa=0;this.da=this.Oa=!1;this.ga=this.yb=this.Ya=this.J=null;this.Cb=window.NaN;this.Fd=!1;this.ge=!0;this.sa=new TQ(this.l,this.g,this.A);this.ka=this.la("html5_new_queueing")?new Ska(this.l):null;this.O.M(this.l,g.aC("appapi"),this.qI);this.O.M(this.l,"crx_appapi",this.rI);this.O.M(this.l,g.aC("appad"),this.Ix);this.O.M(this.l,
"crx_appad",this.Ix);this.O.M(this.l,g.aC("queued"),function(){return g.Jf(c.QK,c)});
this.O.M(this.l,"presentingplayerstatechange",this.VD);this.O.M(this.l,"resize",this.dL);this.G.aa(g.gd(a));this.O.M(this.l,"offlineslatestatechange",this.pK);this.Oc=Zka(this,this.G.element);g.I(this,this.Oc);g.eN=this.g.J;$ka(this);(0,g.VB)("fs",void 0,"");ala(this);this.g.wa&&this.C.Vt();g.zP.ad=rP;if(.001>Math.random()){d=g.q(["web_player_sentinel","web_player_sentinel_is_uniplayer","web_player_sentinel_launch"]);for(var e=d.next();!e.done;e=d.next())e=e.value,this.la(e)||g.kp(Error("Player flag missing: "+
e))}};
Xka=function(a){var b=new xG(a.g,1,a.pa,a.G,(0,g.z)(a.ba.P,a.ba),(0,g.z)(a.l.Cf,a.l),a.G.ba,a.H);OH(b,a.g.g?1:RR(a,g.ps("yt-player-playback-rate")||1));Sq(b,a.zc,a);return b};
Wka=function(a){var b="",c=a.Ca.assets;c=c?c.js||"":"";0==c.indexOf("//")&&(c=a.g.protocol+":"+c);"/base.js"==c.substr(-8)&&(b=c.substr(0,c.length-8)+"/");!g.R(a.g.experiments,"web_player_module_url_debug_killswitch")&&(c=Error().stack)&&(c=c.match(/\((.*?\/(debug-)?player-.*?):\d+:\d+\)/))&&(c=c[1],c.includes(b)||g.M(Error("Player module URL mismatch: "+(c+" vs "+b+".")),"WARNING"));b=new uP(a.l,b,a);c={};a=(c.loaded=(0,g.z)(a.YJ,a),c.unloaded=(0,g.z)(a.ZJ,a),c.destroyed=(0,g.z)(a.Pq,a),c);b.ka=
a;return b};
TR=function(a,b){var c=!(!a.T||!a.T.Ma());a.T||(a.T=new NR(a),g.I(a,a.T),g.sI(a.l,a.T.element,4));g.Ms(a.T,b);SR(a)&&c!=b&&g.$H(a.C).iG();c=a.o;b&&c&&c.Za("sfn","1",!0)};
WR=function(a){var b=UR.getTag(!0,!a.g.deviceHasDisplay);a.B=new g.jC(b);g.I(a,a.B);a.o&&VR(a,a.o);try{a.g.da?(a.Ja&&a.O.Pa(a.Ja),a.Ja=a.O.M(a.B,"volumechange",a.WJ)):(a.B.setVolume(a.R.volume/100),a.B.ci(a.R.muted))}catch(d){var c="setvolume.1;emsg."+(d.message&&d.message.replace(/[;:,]/g,"_"));g.LG(a.A,"html5.missingapi","UNSUPPORTED_DEVICE",c);return}g.Rq(a.Ia);bla(a);c=a.G;c.l=b;c.C=!1;c.l.parentNode||zd(c.A,c.l,0);c.H=new g.Tg(0,0,0,0);IR(c);g.LK(c);g.J(c.l,"video-stream");g.J(c.l,"html5-main-video");
b=c.app.g;b.ob&&c.l.setAttribute("data-no-fullscreen",!0);b.fd&&(c.l.setAttribute("webkit-playsinline",""),c.l.setAttribute("playsinline",""));b.Sk&&c.l&&c.M(c.l,"click",c.l.play,c.l);try{a.B.gf()}catch(d){c="activate.1;emsg."+(d.message&&d.message.replace(/[;:,]/g,"_")),g.LG(a.A,"html5.missingapi","UNSUPPORTED_DEVICE",c)}};
VR=function(a,b){a.la("html5_gapless_to_standard_killswitch")||iH(b)||a.ka||(a.B.G=!1,a.B.Kc());if(a.la("html5_use_media_element_view")){var c=window.MediaSource&&window.SourceBuffer&&window.SourceBuffer.prototype.hasOwnProperty("timestampOffset")?g.S(a.g.experiments,"html5_view_offset"):0;gH(b,new g.LF(a.B,c,window.Infinity))}else gH(b,a.B)};
XR=function(a){a.B&&(a.Ja&&(a.O.Pa(a.Ja),a.Ja=null),g.Rq(a.Ia),a.o&&lH(a.o,!0),AR(a.G),a.B.hg()&&UR.releaseTag(a.B.ia()),a.B=null)};
g.VM=function(a,b){var c=g.W(a,b);c||(c=XQ(a,b),YR(a,c));zI(a,c)};
zI=function(a,b){if(a.o!=b){var c=null;a.o&&(c=a.o.o,CP(a.C,3),mI(a,"cuerangesremoved",uE(a.o.H)||[]),a.ka&&!jH(b)&&jH(a.o)&&a.B.Kc(),AI(a));YR(a,b);a.o=b;a.B&&VR(a,b);Sq(b,a.he,a);a.Jp("newdata",b,b.getVideoData());c&&!g.oB(c,b.o)&&a.Ay(new g.uB(b.o,c));b.Y.g&&a.Jp("dataloaded",b,b.getVideoData());(c=(c=b.getVideoData().ua)&&c.video)&&a.l.na("onPlaybackQualityChange",c.quality);mI(a,"cuerangesadded",uE(a.o.H)||[]);a.la("web_player_play_dompaused_presenting_killswitch")?g.qB(b.o)?qH(b):g.U(b.o,2)&&
ZR(a):(c=b.o,g.U(c,2)?ZR(a):g.U(c,8)&&qH(b))}};
ZR=function(a){if(a.F&&(g.Zx(a.g)||a.l.isFullscreen()&&!a.Ta)&&g.$R(a)){var b=g.R(a.g.experiments,"html5_player_autonav_logging");aS(a,!1,b);b=!0}else b=!1;b||((b=a.A.l)&&b.Yi(),g.R(a.g.experiments,"web_player_state_on_player_change_killswitch")||bS(a,tB(XH(a))))};
bla=function(a){var b=a.B;g.Et()?a.Ia.M(b,"webkitpresentationmodechanged",a.kL):g.Ft()&&(a.Ia.M(b,"enterpictureinpicture",function(){pG(a.H,!0)}),a.Ia.M(b,"leavepictureinpicture",function(){pG(a.H,!1)}))};
YR=function(a,b){if(b!=a.A){var c=b.getPlayerType();a.Nc[c]=b}};
AI=function(a){var b;if(b=a.ga)b=a.B,b=!!b&&b==a.ga.o;b&&(XR(a),WR(a));a.o&&(lH(a.o),Tq(a.o,a.he,a),iH(a.o)&&!a.o.ea()&&CG(a.o,0,window.Infinity));a.o=null};
g.W=function(a,b){return b?1==b?a.A:a.Nc[b]||null:a.o};
XQ=function(a,b){var c=a.pa;2==b&&(c=new UB(a.g));return new xG(a.g,b,c,a.G,(0,g.z)(a.ba.P,a.ba),(0,g.z)(a.l.Cf,a.l),a.G.ba,a.H)};
cS=function(a,b){return $M(a,b)?a.A:b};
dS=function(a,b){var c=a.o;return c&&b==a.A&&$M(a,b)&&$M(a,c)?c:b};
eS=function(a){var b=a.getVideoData(),c=10<b.lengthSeconds,d=a.C;if(!d.A)try{yP(d)?(d.A=new rP(d.pa.Z),d.A&&d.A.create()):g.pI(d.g,"ad")}catch(e){g.pI(d.g,"ad"),g.M(e)}d.Tt();d.ga&&c?g.pI(d.g,"endscreen"):d.po();d.Yt();d.au();d.Zt();d.St();d.ga&&c?(g.pI(d.g,"annotations_module"),g.pI(d.g,"creatorendscreen")):(d.no(),d.oo());d.Qt();d.Pt();d.qo();d.Ut();d.Rt();d.bu();d.Xt();xP(d);c&&FA(b)?a.dd.M(a.l,"presentingplayerstatechange",a.FK):wP(a.C);a.l.P("videoready",b)};
fS=function(a){return a.A.getVideoData()};
gS=function(a,b){var c=g.W(a,b);return(c=c?c.l:null)?dB(c):0};
hS=function(a){a=fS(a);return FA(a)};
$ka=function(a){var b=new g.Xz(a.g,a.Ca.args);g.rs()&&b.xc.push("remote");b.ld()&&(JG(a.A,b,(0,g.z)(a.kd,a)),!g.R(a.g.experiments,"html5_delay_initial_loading")&&hS(a)&&(a.g.Lc||a.g.Mc)&&PG(a.A))};
ala=function(a){var b=a.G,c=b.app.g;c.ie||b.Jm("tag-pool-enabled");c.Sb&&b.Jm("house-brand");"gvn"==c.playerStyle&&(b.Jm("ytp-gvn"),b.element.style.backgroundColor="transparent");c.X&&(b.J=g.dr("yt-dom-content-change",b.xe,b));b.M(window,"resize",b.xe,b);b=a.nb;b.o=a.G.element;for(var d in b.A)b.o[d]=b.A[d];(d=g.wq(a.G.element))&&a.O.M(a.G,d,a.oJ);a.O.M(window,"resize",a.eL);b=a.Ca.args;WR(a);d=fS(a);a.l.na("onVolumeChange",a.R);if(b&&eC(b))if((c=g.ny(a.g))&&!a.X&&(b.fetch=0),iS(a,b),c&&!a.X)jS(a);
else if(!d.ld())a.F.onReady((0,g.z)(a.Wq,a));zI(a,a.A);if(!g.U(a.A.o,128)){b=a.g.deviceHasDisplay;try{var e=Dt('video/mp4; codecs="avc1.42001E"')||Dt('video/webm; codecs="vp9"');var f=(Dt('audio/mp4; codecs="mp4a.40.2"')||Dt('audio/webm; codecs="opus"'))&&(e||!b)||Bt('video/mp4; codecs="avc1.42001E, mp4a.40.2"')?null:"fmt.noneavailable"}catch(k){f="html5.missingapi"}"fmt.noneavailable"==f?g.LG(a.A,"html5.missingapi","HTML5_NO_AVAILABLE_FORMATS_FALLBACK","nocodecs.1"):"html5.missingapi"==f?g.LG(a.A,
f,"UNSUPPORTED_DEVICE","nocanplaymedia.1"):d&&d.ld()&&hS(a)&&(a.g.Lc||a.g.Mc)?kS(a):g.uy(a.g)||lS(a)}};
lS=function(a){a.l.P("initializingmode");g.mS(a,2);a.C.qo()};
kS=function(a){if(g.U(a.A.o,128))return!1;hS(a)&&a.g.Mc&&(UR.hasTags(void 0)&&a.da?(Xs(a,{muted:!1,volume:a.R.volume},!1),nS(a,!1)):UR.hasTags(void 0)||a.R.muted||(Xs(a,{muted:!0,volume:a.R.volume},!1),nS(a,!0)));oS(a,1,a.A.getVideoData());a.l.P("initializingmode");zI(a,a.A);g.mS(a,3);var b;if(!(b=!a.g.ie)){if(b=a.ga)b=a.B,b=!!b&&b==a.ga.o;b=b&&a.fd}b&&(XR(a),WR(a),VR(a,a.A));WG(a.A);if(g.U(a.A.o,128))return!1;bS(a,3);return a.fd=!0};
SR=function(a){a=g.$H(a.C);return!!a&&a.loaded};
g.pS=function(a,b){if(a.o==a.A&&g.QH(a.o)!=b){var c=a.o;c.dd=b;c.l&&c.l.rm(b);a.l.P("loopchange",b)}};
qS=function(a,b,c){(0,window.isNaN)(b)||(b=RR(a,b),a.A.pa!=b&&(OH(a.A,b),c&&!a.g.g&&g.os("yt-player-playback-rate",b),a.l.na("onPlaybackRateChange",b)))};
RR=function(a,b){var c=1;c=a.l.di();return c=1>b?g.Ja(c,function(a){return a>=b}):gaa(c,function(a){return a<=b})};
sS=function(a,b,c){c=void 0===c?!0:c;if(3==lI(a))return g.$H(a.C).C;b=g.W(a,b);return b?c?(c=dS(a,b),rS(a,c.tb(),c)):b.tb():0};
tS=function(a,b,c){b=g.W(a,b);return b?void 0===c||c?(c=cS(a,b),rS(a,c.Xg(),c)):b.Xg():0};
uS=function(a,b){var c=g.W(a,b);return c?$M(a,c)?(c=cS(a,c),HH(c)-c.tb()+sS(a,b)):HH(c):0};
rS=function(a,b,c){if($M(a,c)){c=c.getVideoData();a=a.sa;for(var d=g.q(a.l),e=d.next();!e.done;e=d.next())if(e=e.value,c.qd==e.qd){b+=e.Wd/1E3;break}d=b;a=g.q(a.l);for(e=a.next();!e.done;e=a.next()){e=e.value;if(c.qd==e.qd)break;var f=e.Wd/1E3;if(f<b)d+=e.durationMs/1E3+f-e.Be/1E3;else break}return d}return b};
xS=function(a,b){var c=IH(a.A,b);if(a.o&&a.o!=a.A&&(c=vS(c,IH(a.o,b),"ad_"),b)){var d=c;var e={};var f=g.gd("movie_player");f&&(e.bounds=f.getBoundingClientRect(),e["class"]=f.className);f={};var k=g.jd("video-ads");k?(wS(k,f),f.html=k.outerHTML):f.missing=1;k={};var l=g.jd("videoAdUiSkipContainer"),m=g.jd("ytp-ad-skip-button-container"),n=l||m;n?(wS(n,k),k.ima=l?1:0,k.bulleit=m?1:0):k.missing=1;l={};l.player=e;l.videoAds=f;l.skipButton=k;e=JSON.stringify(l);d.ad_skipBtnDbgInfo=e}b&&a.B&&(c["0sz"]=
0==a.B.Kj().ke(),c.op=a.B.ij("opacity"),d=a.B.Qp().y+a.B.Kj().height,c.yof=0>=d,c.dis=a.B.ij("display"));(d=b?(0,g.OG)():null)&&(c.gpu=d);c.cgr=!0;c.debug_playbackQuality=a.Z.Pj();c.debug_date=(new Date).toString();delete c.uga;delete c.q;(d=a.C.G)&&(c=vS(c,d.KA(),"fresca_"));return JSON.stringify(c,null,2)};
lI=function(a){return 1==a.Y?1:SR(a)?3:g.W(a).getPlayerType()};
XH=function(a,b){return 3==lI(a)?g.$H(a.C).F:g.W(a,b).o};
yS=function(a,b){return 3==lI(a)?tB(g.$H(a.C).F):2!=b||$M(a)?a.Lc:a.Cc};
AS=function(a){zS(a);g.pS(a,!1);a.Wb={};var b=a.pa;if(b.g){var c=b.g;c.ha={};c.ba={}}b.l=!1;b=a.sa;a=a.A;a.getPlayerType();dR(b,!1);iR(b);b.o=a};
jS=function(a){var b=BS();if(b)if(b.list){if(a.F&&a.F.listId.toString()==b.list)if(0<=b.index){var c=b.video;a.l.isFullscreen()&&((c=c[a.F.Ua])&&c.encrypted_id!=a.F.za().videoId||(b.index=a.F.Ua));iC(a.F,b);a.ab&&CS(a,a.ab)}else a.ab=null}else a.rl()};
iS=function(a,b){a.F&&(a.F.unsubscribe("error",a.rl,a),g.Xe(a.F),a.F=null);b&&(a.X&&(b.fetch=0),a.F=new g.dC(a.g,b),a.F.subscribe("error",a.rl,a))};
DS=function(a,b,c,d){b in a.Wb||(c=new g.YB(c,d,{id:b,priority:1}),c.namespace="appad",$G(a.A,c),a.Wb[b]=c)};
g.mS=function(a,b){b!=a.Y&&(2!=b||1!=lI(a)&&!g.R(a.g.experiments,"web_player_app_state_fix_killswitch")||(bS(a,-1),bS(a,5)),a.Y=b,a.l.P("appstatechange",b))};
bS=function(a,b){if(a.o){var c=a.o.getPlayerType();if(2==c&&!$M(a)){a.Cc!=b&&(a.Cc=b,a.l.na("onAdStateChange",b));return}if(2==c&&$M(a)||5==c||6==c)if(-1==b||0==b||5==b)return}a.Lc!=b&&(a.Lc=b,a.l.na("onStateChange",b))};
ES=function(a,b,c,d,e){c=0!=c;if(e=g.W(a,e))2==a.Y&&kS(a),$M(a,e)?(a=a.sa,b=void 0===b?0:b,d=void 0===d?null:d,(void 0===c?0:c)?SQ(a,b):(c=b,b=a.g.xb(),e=b==a.A?a.G:null,dR(a,!1),a.J=c,null!=d&&a.H.start(d),b&&(a.G=e||b.o,uH(b),a.A=b))):YG(e,b,c,d)};
$M=function(a,b){var c=b||a.o,d;if(d=!g.R(a.g.experiments,"web_player_continuous_timeline_killswitch")&&c)a:if(d=a.sa,c=c.getVideoData(),c==d.o.getVideoData()&&d.l.length)d=!0;else{d=g.q(d.l);for(var e=d.next();!e.done;e=d.next())if(c.qd==e.value.qd){d=!0;break a}d=!1}return d?!0:!1};
CI=function(a,b,c,d){d=void 0===d?0:d;a.ka?Tka(a.ka,b,c,d).then(function(){a.l.na("onQueuedVideoLoaded")}):(0!=d&&YG(b,d/1E3,!0),a.Cb=c,dla(a,b),ela(a,FS(a)))};
FS=function(a){return Math.min(1E3*NH(a.o,!0),a.Cb)};
dla=function(a,b){a.J=b;b.getVideoData().mh=!0;b.getVideoData().zj=!0;PG(b,!0);b.Za("queued","1");a.la("html5_gapless")&&(a.o.subscribe("internalvideodatachange",a.Ag,a),b.subscribe("internalvideodatachange",a.Ag,a),a.o.subscribe("mediasourceattached",a.Ag,a),a.Ag())};
GS=function(a){a.o.unsubscribe("internalvideodatachange",a.Ag,a);a.o.unsubscribe("mediasourceattached",a.Ag,a);a.J&&a.J.unsubscribe("internalvideodatachange",a.Ag,a)};
ela=function(a,b){a.Ya=new g.YB((0,window.isFinite)(b)?b:0x8000000000000,0x8000000000000,{namespace:"queued"});a.yb=a.o;$G(a.yb,a.Ya);b<=1E3*sS(a)&&!a.o.H.C&&HS(a)};
HS=function(a){var b=a.J,c=a.o;(0,window.isFinite)(a.Cb)||wG(a.o,!0,!1);b==a.A?(zI(a,b),qH(b),$Q(a)):(gR(a,a.J.getVideoData(),b.getPlayerType()),g.VM(a,b.getPlayerType()),qH(b),iH(a.o)&&g.Jf(function(){!a.o.getVideoData().Gd&&g.qB(a.o.o)&&KH(a.o)}),$Q(a),c.ea()||CG(c,0,window.Infinity));
a.l.na("onQueuedVideoLoaded")};
$Q=function(a){a.ka?(a=a.ka,a.B&&a.B.reject("Queue cleared"),pR(a)):(a.yb.H.A(a.Ya),a.Ya.dispose(),a.yb=null,a.Ya=null,a.J=null,a.Cb=window.NaN)};
g.IS=function(a,b,c,d,e){a.g.Sb&&Yy(b);var f=new g.Xz(a.g,b);d||(b&&eC(b)?(g.ny(a.g)&&!a.X&&(b.fetch=0),iS(a,b)):a.F&&iS(a,null),a.X=T(!1,b.external_list),g.ny(a.g)&&!a.X&&jS(a));return gR(a,f,c,e)};
oS=function(a,b,c){if(a.J&&b==a.J.getPlayerType()&&c==a.J.getVideoData()){var d=a.J;a.J=null}if(!d){var e=b+c.videoId;d=a.Va.get(e);if(!d)return null;a.Va.remove(e);if(g.U(d.o,128))return d.dispose(),null}if(d==g.W(a,b))return d;if((d.getVideoData().oauthToken||c.oauthToken)&&d.getVideoData().oauthToken!=c.oauthToken)return null;oR(a,d);return d};
oR=function(a,b){var c=b.getPlayerType();b!=g.W(a,c)&&(1==b.getPlayerType()?(b.getVideoData().autonavState=a.A.getVideoData().autonavState,Tq(a.A,a.zc,a),c=a.A.pa,a.A.dispose(),a.A=b,OH(a.A,c),Sq(b,a.zc,a),AS(a)):(c=g.W(a,c))&&c.dispose(),a.o.getPlayerType()==b.getPlayerType()?zI(a,b):YR(a,b))};
gR=function(a,b,c,d){Oz("_start","")||(Ez("yt_sts","p",""),Fz("_start",void 0,""),a.pa.info("srt",0));var e=oS(a,c||a.o.getPlayerType(),b);e&&(0,g.VB)("pfp",void 0,"prefetch_"+b.videoId);if(!e){e=g.W(a,c);if(!e)return!1;a.Mb.stop();JS(a,c);JG(e,b,(0,g.z)(a.kd,a),d)}e==a.A&&(a.g.Oa=b.oauthToken);if(!MG(e))return!1;a.ob&&(e.Ta=!1,a.ob=!1);if(e==a.A)return g.mS(a,1),kS(a);WG(e);return!0};
KS=function(a,b,c){c=g.W(a,c);b&&c==a.A&&(c.getVideoData().jg=!0)};
MS=function(a,b,c){a.g.Sb&&Yy(b);if(b&&eC(b))if(a.oa=!0,iS(a,b),(b=a.F.za())&&b.ld())LS(a,b,c);else a.F.onReady((0,g.z)(a.Wq,a));else c||(c=lI(a)),1==c&&a.rl(),LS(a,new g.Xz(a.g,b),c)};
LS=function(a,b,c){var d=g.W(a,c);d&&(JS(a,c),JG(d,b,(0,g.z)(a.kd,a)),d==a.A&&(g.mS(a,1),lS(a)))};
g.OS=function(a,b,c,d,e,f,k){if(!b&&!d)throw Error("Playback source is invalid");a.l.isFullscreen()&&!a.Ta||!g.Wx(a.g)&&!g.py(a.g)?(c=a.pa,c.g&&(f=c.g,f.ha={},f.ba={}),c.l=!1,a.pa.reset(),b={video_id:b},e&&(b.autoplay="1"),g.R(a.g.experiments,"html5_player_autonav_logging")&&e&&(b.autonav="1"),d?(b.list=d,a.oa=!1,NS(a,b,void 0,void 0,void 0)):g.IS(a,b,1)):(c=c||{},c.lact=Gr(),c.vis=a.l.Cf(),a.ed||"gaming"==a.g.playerStyle?a.l.na("onPlayVideo",{videoId:b,watchEndpoint:k,sessionData:c,listId:d}):(a=
f&&a.getVideoData().isLiveDestination?a.g.loaderUrl:a.g.getVideoUrl(b,d),g.y("yt.player.exports.navigate")(a,c)))};
NS=function(a,b,c,d,e){if(g.Ba(b)&&!g.ya(b)){c="playlist list listType index startSeconds suggestedQuality".split(" ");d={};for(e=0;e<c.length;e++){var f=c[e];b[f]&&(d[f]=b[f])}b=d}else c={index:c,startSeconds:d,suggestedQuality:e},g.v(b)&&16==b.length?c.list="PL"+b:c.playlist=b,b=c;iS(a,b);a.F.onReady((0,g.z)(a.Wq,a))};
g.$R=function(a){if(a.l.app.da)return!1;if(3==lI(a))return!0;g.ny(a.g)&&!a.X&&jS(a);return!(!a.F||!a.F.hasNext())};
aS=function(a,b,c){var d=a.A.getVideoData().suggestions;g.uI(a.l)&&d?(d=(0,g.E)(d,function(b){return g.DP(a.g,b)}),b=d[0],d=c?b.iu:b.Zc,g.OS(a,b.za().videoId,d,b.getPlaylistId(),c)):!a.X||a.l.isFullscreen()&&!a.Ta?3==lI(a)?g.$H(a.C).gG():a.F&&(g.ny(a.g)&&!a.l.isFullscreen()?CS(a,"yt.www.watch.lists.next"):(a.F.hasNext(b)&&hC(a.F,fC(a.F)),a.F.Te?(b=c&&g.R(a.g.experiments,"html5_player_autonav_logging"),gR(a,a.F.za(void 0,c,b),1)):a.oa=!1)):a.l.na("onPlaylistNext")};
PS=function(a,b){!a.X||a.l.isFullscreen()&&!a.Ta?3==lI(a)?g.$H(a.C).hG():a.F&&(g.ny(a.g)&&!a.l.isFullscreen()?CS(a,"yt.www.watch.lists.prev"):(a.F.Pe(b)&&hC(a.F,gC(a.F)),a.F.Te?gR(a,a.F.za(),1):a.oa=!1)):a.l.na("onPlaylistPrevious")};
CS=function(a,b){var c=g.y(b);if(c){var d=BS();d&&d.list&&c();a.ab=null}else a.ab=b};
BS=function(){var a=g.y("yt.www.watch.lists.getState");return a?a():null};
QS=function(a,b,c,d,e,f){b={id:b};"chapter"==f?(b.style="ytp-chapter-marker",b.visible=!0):(0,window.isNaN)(e)||("ad"==f?b.style="ytp-ad-progress":(b.style="ytp-time-marker",b.color=e),b.visible=!0);c=new g.YB(1E3*c,1E3*d,b);c.namespace="appapi";jI(a,[c],1);return!0};
jI=function(a,b,c){var d=g.W(a,c);d&&(d=d.H,d.l(),sE(d.g,b),d.B=window.NaN,d.l(),c&&lI(a)!=c||mI(a,"cuerangesadded",b))};
ZM=function(a){var b=g.qr(),c=sS(a);a=a.getVideoData();return b-Math.max(1E3*(c-a.startSeconds),0)};
Xs=function(a,b,c){a.g.L&&(a.R=b,b.muted||nS(a,!1),c&&a.g.storeUserVolume&&!a.g.da&&(c={volume:Math.floor(b.volume),muted:b.muted},c.unstorable||(g.os("yt-player-volume",c),g.os("yt-player-volume",c,2592E3))),RS(a),c=g.Ct&&!a.B.Rc(),!a.g.da||c)&&(b=g.Wb(b),a.g.storeUserVolume||(b.unstorable=!0),a.l.na("onVolumeChange",b))};
RS=function(a){var b=a.getVideoData();if(!b.Cg){b=a.g.da?1:IA(b);var c=a.B;c.setVolume(a.R.volume*b/100);c.ci(a.R.muted)}};
nS=function(a,b){b!=a.da&&(a.da=b,a.l.P("mutedautoplaychange",b))};
SS=function(a){var b=g.uq();return b&&(b==a.G.element||a.B&&b==a.B.ia())?b:null};
US=function(a,b){var c=window.screen&&window.screen.orientation;if(g.R(a.g.experiments,"lock_fullscreen2")&&c&&c.lock&&(!g.Ct||!g.TS))if(b){var d=0==c.type.indexOf("portrait"),e=g.DR(a.G),f=d;1>e?f=!0:1<e&&(f=!1);if(!a.Oa||f!=d){if(c=c.lock(f?"portrait":"landscape"))c["catch"](g.va);a.Oa=!0}}else a.Oa&&(a.Oa=!1,c.unlock())};
VS=function(a,b){var c=!!b,d=!!a.H.o!=c,e=a.H;e.o!=b&&(e.o=b,e.B());a.la("html5_media_fullscreen")&&!c&&a.B&&g.uq()==a.B.ia()&&a.B.Yi();a.G.xe();d&&(0,g.VB)("fsc",void 0,"");d&&(a.l.P("fullscreentoggled",c),d=fS(a),c={fullscreen:c,videoId:d.ypcOrigin||d.videoId,time:sS(a)},a.Z.getPlaylistId()&&(c.listId=a.Z.getPlaylistId()),a.l.na("onFullscreenChange",c))};
mI=function(a,b,c){a.l.P(b,c);var d=g.gy(a.g)||g.hy(a.g)||qy(a.g);if(c&&d){switch(b){case "cuerangemarkersupdated":var e="onCueRangeMarkersUpdated";break;case "cuerangesadded":e="onCueRangesAdded";break;case "cuerangesremoved":e="onCueRangesRemoved"}e&&a.l.na(e,c)}};
XS=function(a,b){var c=g.W(a,b);c&&(2==a.Y?kS(a):g.R(a.g.experiments,"html5_restore_userreload_killswitch")&&c.o.isError()?WS(a,"user"):(null!=a.T&&a.T.Ma()&&a.T.start(),g.U(c.o,2)?ES(a,0):qH(c)))};
JS=function(a,b){g.uz(a.wa);a.wa=0;var c=g.W(a,b);c&&1!=a.Y&&2!=a.Y&&(c==a.o&&CP(a.C,4),1==b&&(g.R(a.g.experiments,"html5_stop_video_in_cancel_playback")&&FH(c),zS(a)),g.fH(c),mI(a,"cuerangesremoved",uE(c.H)||[]),c.H.reset(),a.ka&&jH(c)?(lH(c,!0),gH(c,a.B)):iH(c)&&(a.B.G=!1,a.B.Kc()))};
YS=function(a,b,c,d,e){c=void 0===c?!0:c;var f=g.W(a,e);f&&(2==f.getPlayerType()&&!$M(a,f)||g.AA(f.getVideoData()))||(3==lI(a)?g.$H(a.C).Wj("control_seek",b,c):ES(a,b,c,d,e))};
WS=function(a,b,c,d){if(!(a.ob||a.la("html5_only_reload_for_yt_killswitch")&&"yt"!=a.g.Z)){c&&(XR(a),WR(a));a.ob=!0;c=g.W(a);c.Ta=!0;c.Za("reloading","reason."+b);var e=a.getVideoData(),f={};f.video_id=e.videoId;f.adformat=e.adFormat;e.ra||(f.start=c.tb(),f.resume="1");e.df&&(f.vvt=e.df);e.vssCredentialsToken&&(f.vss_credentials_token=e.vssCredentialsToken,f.vss_credentials_token_type=e.In);e.oauthToken&&(f.oauth_token=e.oauthToken);f.autoplay=1;f.reload_count=e.bf+1;f.reload_reason=b;e.Ci&&(f.unplugged_partner_opt_out=
e.Ci);g.IS(a,f,void 0,d)}};
g.ZS=function(a,b){fS(a).autonavState=b;g.os("yt-player-autonavstate",b);a.l.P("autonavchange",b)};
$S=function(a){var b=a.getVideoData().Cg,c=a.g.Rf,d=a.B;b||c?d.to():(d.vo(),Xs(a,a.R))};
Zka=function(a,b){return g.R(a.g.experiments,"html5_enable_embedded_player_visibility_signals")&&a.g.g?new yR(b):null};
zS=function(a){(a=a.C.A)&&a.created&&(a.unload(),a.created=!1)};
wS=function(a,b){b.bounds=a.getBoundingClientRect();for(var c=g.q(["display","opacity","visibility","zIndex"]),d=c.next();!d.done;d=c.next())d=d.value,b[d]=g.mh(a,d);b.hidden=!!a.hidden};
vS=function(a,b,c){for(var d in b)a[c+d]=b[d];return a};
aa=[];fa="function"==typeof Object.create?Object.create:function(a){function b(){}
b.prototype=a;return new b};
if("function"==typeof Object.setPrototypeOf)aT=Object.setPrototypeOf;else{var bT;a:{var fla={Pc:!0},cT={};try{cT.__proto__=fla;bT=cT.Pc;break a}catch(a){}bT=!1}aT=bT?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}
var ha=aT,la="function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,c){a!=Array.prototype&&a!=Object.prototype&&(a[b]=c.value)},ka="undefined"!=typeof window&&window===this?this:"undefined"!=typeof window.global&&null!=window.global?window.global:this;
ma("Array.prototype.findIndex",function(a){return a?a:function(a,c){return ia(this,a,c).ev}});
ma("String.prototype.repeat",function(a){return a?a:function(a){var b=na(this,null,"repeat");if(0>a||1342177279<a)throw new window.RangeError("Invalid count value");a|=0;for(var d="";a;)if(a&1&&(d+=b),a>>>=1)b+=b;return d}});
ma("Array.prototype.find",function(a){return a?a:function(a,c){return ia(this,a,c).tA}});
ma("String.prototype.endsWith",function(a){return a?a:function(a,c){var b=na(this,a,"endsWith");a+="";void 0===c&&(c=b.length);for(var e=Math.max(0,Math.min(c|0,b.length)),f=a.length;0<f&&0<e;)if(b[--e]!=a[--f])return!1;return 0>=f}});
var aaa=function(){var a=0;return function(b){return"jscomp_symbol_"+(b||"")+a++}}(),gla="function"==typeof Object.assign?Object.assign:function(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];
if(d)for(var e in d)ra(d,e)&&(a[e]=d[e])}return a};
ma("Object.assign",function(a){return a||gla});
ma("Promise",function(a){function b(a){this.l=0;this.o=void 0;this.g=[];var b=this.A();try{a(b.resolve,b.reject)}catch(m){b.reject(m)}}
function c(){this.g=null}
function d(a){return a instanceof b?a:new b(function(b){b(a)})}
if(a)return a;c.prototype.l=function(a){null==this.g&&(this.g=[],this.A());this.g.push(a)};
c.prototype.A=function(){var a=this;this.o(function(){a.C()})};
var e=ka.setTimeout;c.prototype.o=function(a){e(a,0)};
c.prototype.C=function(){for(;this.g&&this.g.length;){var a=this.g;this.g=[];for(var b=0;b<a.length;++b){var c=a[b];a[b]=null;try{c()}catch(n){this.B(n)}}}this.g=null};
c.prototype.B=function(a){this.o(function(){throw a;})};
b.prototype.A=function(){function a(a){return function(d){c||(c=!0,a.call(b,d))}}
var b=this,c=!1;return{resolve:a(this.J),reject:a(this.B)}};
b.prototype.J=function(a){if(a===this)this.B(new TypeError("A Promise cannot resolve to itself"));else if(a instanceof b)this.L(a);else{a:switch(typeof a){case "object":var c=null!=a;break a;case "function":c=!0;break a;default:c=!1}c?this.H(a):this.C(a)}};
b.prototype.H=function(a){var b=void 0;try{b=a.then}catch(m){this.B(m);return}"function"==typeof b?this.O(b,a):this.C(a)};
b.prototype.B=function(a){this.F(2,a)};
b.prototype.C=function(a){this.F(1,a)};
b.prototype.F=function(a,b){if(0!=this.l)throw Error("Cannot settle("+a+", "+b+"): Promise already settled in state"+this.l);this.l=a;this.o=b;this.G()};
b.prototype.G=function(){if(null!=this.g){for(var a=0;a<this.g.length;++a)f.l(this.g[a]);this.g=null}};
var f=new c;b.prototype.L=function(a){var b=this.A();a.kl(b.resolve,b.reject)};
b.prototype.O=function(a,b){var c=this.A();try{a.call(b,c.resolve,c.reject)}catch(n){c.reject(n)}};
b.prototype.then=function(a,c){function d(a,b){return"function"==typeof a?function(b){try{e(a(b))}catch(H){f(H)}}:b}
var e,f,k=new b(function(a,b){e=a;f=b});
this.kl(d(a,e),d(c,f));return k};
b.prototype["catch"]=function(a){return this.then(void 0,a)};
b.prototype.kl=function(a,b){function c(){switch(d.l){case 1:a(d.o);break;case 2:b(d.o);break;default:throw Error("Unexpected state: "+d.l);}}
var d=this;null==this.g?f.l(c):this.g.push(c)};
b.resolve=d;b.reject=function(a){return new b(function(b,c){c(a)})};
b.race=function(a){return new b(function(b,c){for(var e=g.q(a),f=e.next();!f.done;f=e.next())d(f.value).kl(b,c)})};
b.all=function(a){var c=g.q(a),e=c.next();return e.done?d([]):new b(function(a,b){function f(b){return function(c){k[b]=c;l--;0==l&&a(k)}}
var k=[],l=0;do k.push(void 0),l++,d(e.value).kl(f(k.length-1),b),e=c.next();while(!e.done)})};
return b});
ma("Math.trunc",function(a){return a?a:function(a){a=Number(a);if((0,window.isNaN)(a)||window.Infinity===a||-window.Infinity===a||0===a)return a;var b=Math.floor(Math.abs(a));return 0>a?-b:b}});
ma("Array.prototype.fill",function(a){return a?a:function(a,c,d){var b=this.length||0;0>c&&(c=Math.max(0,b+c));if(null==d||d>b)d=b;d=Number(d);0>d&&(d=Math.max(0,b+d));for(c=Number(c||0);c<d;c++)this[c]=a;return this}});
ma("Math.log10",function(a){return a?a:function(a){return Math.log(a)/Math.LN10}});
ma("WeakMap",function(a){function b(a){this.Ga=(k+=Math.random()+1).toString();if(a){a=g.q(a);for(var b;!(b=a.next()).done;)b=b.value,this.set(b[0],b[1])}}
function c(){}
function d(a){ra(a,f)||la(a,f,{value:new c})}
function e(a){var b=Object[a];b&&(Object[a]=function(a){if(a instanceof c)return a;d(a);return b(a)})}
if(function(){if(!a||!Object.seal)return!1;try{var b=Object.seal({}),c=Object.seal({}),d=new a([[b,2],[c,3]]);if(2!=d.get(b)||3!=d.get(c))return!1;d["delete"](b);d.set(c,4);return!d.has(b)&&4==d.get(c)}catch(p){return!1}}())return a;
var f="$jscomp_hidden_"+Math.random();e("freeze");e("preventExtensions");e("seal");var k=0;b.prototype.set=function(a,b){d(a);if(!ra(a,f))throw Error("WeakMap key fail: "+a);a[f][this.Ga]=b;return this};
b.prototype.get=function(a){return ra(a,f)?a[f][this.Ga]:void 0};
b.prototype.has=function(a){return ra(a,f)&&ra(a[f],this.Ga)};
b.prototype["delete"]=function(a){return ra(a,f)&&ra(a[f],this.Ga)?delete a[f][this.Ga]:!1};
return b});
ma("Map",function(a){function b(){var a={};return a.previous=a.next=a.head=a}
function c(a,b){var c=a.g;return pa(function(){if(c){for(;c.head!=a.g;)c=c.previous;for(;c.next!=c.head;)return c=c.next,{done:!1,value:b(c)};c=null}return{done:!0,value:void 0}})}
function d(a,b){var c=b&&typeof b;"object"==c||"function"==c?f.has(b)?c=f.get(b):(c=""+ ++k,f.set(b,c)):c="p_"+b;var d=a.l[c];if(d&&ra(a.l,c))for(var e=0;e<d.length;e++){var l=d[e];if(b!==b&&l.key!==l.key||b===l.key)return{id:c,list:d,index:e,jd:l}}return{id:c,list:d,index:-1,jd:void 0}}
function e(a){this.l={};this.g=b();this.size=0;if(a){a=g.q(a);for(var c;!(c=a.next()).done;)c=c.value,this.set(c[0],c[1])}}
if(function(){if(!a||"function"!=typeof a||!a.prototype.entries||"function"!=typeof Object.seal)return!1;try{var b=Object.seal({x:4}),c=new a(g.q([[b,"s"]]));if("s"!=c.get(b)||1!=c.size||c.get({x:4})||c.set({x:4},"t")!=c||2!=c.size)return!1;var d=c.entries(),e=d.next();if(e.done||e.value[0]!=b||"s"!=e.value[1])return!1;e=d.next();return e.done||4!=e.value[0].x||"t"!=e.value[1]||!d.next().done?!1:!0}catch(u){return!1}}())return a;
qa();var f=new window.WeakMap;e.prototype.set=function(a,b){a=0===a?0:a;var c=d(this,a);c.list||(c.list=this.l[c.id]=[]);c.jd?c.jd.value=b:(c.jd={next:this.g,previous:this.g.previous,head:this.g,key:a,value:b},c.list.push(c.jd),this.g.previous.next=c.jd,this.g.previous=c.jd,this.size++);return this};
e.prototype["delete"]=function(a){a=d(this,a);return a.jd&&a.list?(a.list.splice(a.index,1),a.list.length||delete this.l[a.id],a.jd.previous.next=a.jd.next,a.jd.next.previous=a.jd.previous,a.jd.head=null,this.size--,!0):!1};
e.prototype.clear=function(){this.l={};this.g=this.g.previous=b();this.size=0};
e.prototype.has=function(a){return!!d(this,a).jd};
e.prototype.get=function(a){return(a=d(this,a).jd)&&a.value};
e.prototype.entries=function(){return c(this,function(a){return[a.key,a.value]})};
e.prototype.keys=function(){return c(this,function(a){return a.key})};
e.prototype.values=function(){return c(this,function(a){return a.value})};
e.prototype.forEach=function(a,b){for(var c=this.entries(),d;!(d=c.next()).done;)d=d.value,a.call(b,d[1],d[0],this)};
e.prototype[window.Symbol.iterator]=e.prototype.entries;var k=0;return e});
ma("Set",function(a){function b(a){this.g=new window.Map;if(a){a=g.q(a);for(var b;!(b=a.next()).done;)this.add(b.value)}this.size=this.g.size}
if(function(){if(!a||"function"!=typeof a||!a.prototype.entries||"function"!=typeof Object.seal)return!1;try{var b=Object.seal({x:4}),d=new a(g.q([b]));if(!d.has(b)||1!=d.size||d.add(b)!=d||1!=d.size||d.add({x:4})!=d||2!=d.size)return!1;var e=d.entries(),f=e.next();if(f.done||f.value[0]!=b||f.value[1]!=b)return!1;f=e.next();return f.done||f.value[0]==b||4!=f.value[0].x||f.value[1]!=f.value[0]?!1:e.next().done}catch(k){return!1}}())return a;
qa();b.prototype.add=function(a){a=0===a?0:a;this.g.set(a,a);this.size=this.g.size;return this};
b.prototype["delete"]=function(a){a=this.g["delete"](a);this.size=this.g.size;return a};
b.prototype.clear=function(){this.g.clear();this.size=0};
b.prototype.has=function(a){return this.g.has(a)};
b.prototype.entries=function(){return this.g.entries()};
b.prototype.values=function(){return this.g.values()};
b.prototype.keys=b.prototype.values;b.prototype[window.Symbol.iterator]=b.prototype.values;b.prototype.forEach=function(a,b){var c=this;this.g.forEach(function(d){return a.call(b,d,d,c)})};
return b});
ma("Object.is",function(a){return a?a:function(a,c){return a===c?0!==a||1/a===1/c:a!==a&&c!==c}});
ma("Array.prototype.includes",function(a){return a?a:function(a,c){var b=this;b instanceof String&&(b=String(b));var e=b.length,f=c||0;for(0>f&&(f=Math.max(f+e,0));f<e;f++){var k=b[f];if(k===a||Object.is(k,a))return!0}return!1}});
ma("String.prototype.includes",function(a){return a?a:function(a,c){return-1!==na(this,a,"includes").indexOf(a,c||0)}});
ma("Array.from",function(a){return a?a:function(a,c,d){c=null!=c?c:function(a){return a};
var b=[],f="undefined"!=typeof window.Symbol&&window.Symbol.iterator&&a[window.Symbol.iterator];if("function"==typeof f){a=f.call(a);for(var k=0;!(f=a.next()).done;)b.push(c.call(d,f.value,k++))}else for(f=a.length,k=0;k<f;k++)b.push(c.call(d,a[k],k));return b}});
ma("Object.values",function(a){return a?a:function(a){var b=[],d;for(d in a)ra(a,d)&&b.push(a[d]);return b}});
var hla=function(){function a(){function a(){}
window.Reflect.construct(a,[],function(){});
return new a instanceof a}
if("undefined"!=typeof window.Reflect&&window.Reflect.construct){if(a())return window.Reflect.construct;var b=window.Reflect.construct;return function(a,d,e){a=b(a,d);e&&window.Reflect.setPrototypeOf(a,e.prototype);return a}}return function(a,b,e){void 0===e&&(e=a);
e=fa(e.prototype||Object.prototype);return Function.prototype.apply.call(a,e,b)||e}}();
ma("Reflect.construct",function(){return hla});
ma("WeakSet",function(a){function b(a){this.g=new window.WeakMap;if(a){a=g.q(a);for(var b;!(b=a.next()).done;)this.add(b.value)}}
if(function(){if(!a||!Object.seal)return!1;try{var b=Object.seal({}),d=Object.seal({}),e=new a([b]);if(!e.has(b)||e.has(d))return!1;e["delete"](b);e.add(d);return!e.has(b)&&e.has(d)}catch(f){return!1}}())return a;
b.prototype.add=function(a){this.g.set(a,!0);return this};
b.prototype.has=function(a){return this.g.has(a)};
b.prototype["delete"]=function(a){return this.g["delete"](a)};
return b});
ma("Object.entries",function(a){return a?a:function(a){var b=[],d;for(d in a)ra(a,d)&&b.push([d,a[d]]);return b}});
ma("Number.isFinite",function(a){return a?a:function(a){return"number"!==typeof a?!1:!(0,window.isNaN)(a)&&window.Infinity!==a&&-window.Infinity!==a}});
ma("Number.parseInt",function(a){return a||window.parseInt});
ma("Math.log2",function(a){return a?a:function(a){return Math.log(a)/Math.LN2}});
g.dT=g.dT||{};g.w=this;Haa=/^[\w+/_-]+[=]{0,2}$/;Rc=null;Ca="closure_uid_"+(1E9*Math.random()>>>0);baa=0;g.D=Date.now||function(){return+new Date};g.A(Ga,Error);Ga.prototype.name="CustomError";var ed;var Aj;g.La=Array.prototype.indexOf?function(a,b){return Array.prototype.indexOf.call(a,b,void 0)}:function(a,b){if(g.v(a))return g.v(b)&&1==b.length?a.indexOf(b,0):-1;
for(var c=0;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1};
g.ila=Array.prototype.lastIndexOf?function(a,b){return Array.prototype.lastIndexOf.call(a,b,a.length-1)}:function(a,b){var c=a.length-1;
0>c&&(c=Math.max(0,a.length+c));if(g.v(a))return g.v(b)&&1==b.length?a.lastIndexOf(b,c):-1;for(;0<=c;c--)if(c in a&&a[c]===b)return c;return-1};
g.C=Array.prototype.forEach?function(a,b,c){Array.prototype.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=g.v(a)?a.split(""):a,f=0;f<d;f++)f in e&&b.call(c,e[f],f,a)};
g.Bd=Array.prototype.filter?function(a,b,c){return Array.prototype.filter.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=[],f=0,k=g.v(a)?a.split(""):a,l=0;l<d;l++)if(l in k){var m=k[l];
b.call(c,m,l,a)&&(e[f++]=m)}return e};
g.E=Array.prototype.map?function(a,b,c){return Array.prototype.map.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=Array(d),f=g.v(a)?a.split(""):a,k=0;k<d;k++)k in f&&(e[k]=b.call(c,f[k],k,a));
return e};
Aj=Array.prototype.reduce?function(a,b,c){return Array.prototype.reduce.call(a,b,c)}:function(a,b,c){var d=c;
(0,g.C)(a,function(c,f){d=b.call(void 0,d,c,f,a)});
return d};
g.rj=Array.prototype.some?function(a,b,c){return Array.prototype.some.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=g.v(a)?a.split(""):a,f=0;f<d;f++)if(f in e&&b.call(c,e[f],f,a))return!0;
return!1};
g.em=Array.prototype.every?function(a,b,c){return Array.prototype.every.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=g.v(a)?a.split(""):a,f=0;f<d;f++)if(f in e&&!b.call(c,e[f],f,a))return!1;
return!0};var sb=String.prototype.trim?function(a){return a.trim()}:function(a){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]},naa=/&/g,oaa=/</g,paa=/>/g,qaa=/"/g,raa=/'/g,saa=/\x00/g,maa=/[\x00&<>"']/,taa=String.prototype.repeat?function(a,b){return a.repeat(b)}:function(a,b){return Array(b+1).join(a)};a:{var eT=g.w.navigator;if(eT){var fT=eT.userAgent;if(fT){g.zb=fT;break a}}g.zb=""};var Yb="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");fc[" "]=g.va;var IF,gT,hT,jla,jT;g.kh=Ab("Opera");g.pd=Ab("Trident")||Ab("MSIE");g.uu=Ab("Edge");g.Js=g.uu||g.pd;g.jh=Ab("Gecko")&&!(ob(g.zb,"WebKit")&&!Ab("Edge"))&&!(Ab("Trident")||Ab("MSIE"))&&!Ab("Edge");g.rd=ob(g.zb,"WebKit")&&!Ab("Edge");IF=Ab("Macintosh");g.TS=Ab("Windows");g.by=Ab("Android");gT=dc();hT=Ab("iPad");jla=Ab("iPod");g.iT=g.ec();g.ay=ob(g.zb,"KaiOS");
a:{var kT="",lT=function(){var a=g.zb;if(g.jh)return/rv:([^\);]+)(\)|;)/.exec(a);if(g.uu)return/Edge\/([\d\.]+)/.exec(a);if(g.pd)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);if(g.rd)return/WebKit\/(\S+)/.exec(a);if(g.kh)return/(?:Version)[ \/]?(\S+)/.exec(a)}();
lT&&(kT=lT?lT[1]:"");if(g.pd){var mT=hc();if(null!=mT&&mT>(0,window.parseFloat)(kT)){jT=String(mT);break a}}jT=kT}var ic=jT,vaa={},nT;var oT=g.w.document;nT=oT&&g.pd?hc()||("CSS1Compat"==oT.compatMode?(0,window.parseInt)(ic,10):5):void 0;var xaa=nT;var Iaa,Kaa,Laa;Iaa=!g.pd||g.kc(9);Kaa=!g.jh&&!g.pd||g.pd&&g.kc(9)||g.jh&&g.jc("1.9.1");g.pT=g.pd&&!g.jc("9");Laa=g.pd||g.kh||g.rd;var kla={area:!0,base:!0,br:!0,col:!0,command:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0};pc.prototype.vf=!0;pc.prototype.qe=function(){return this.g};
pc.prototype.toString=function(){return"Const{"+this.g+"}"};
var oc={},nc={};var lla,mla,nla,ola;lla=RegExp("[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]");g.qT=RegExp("^[\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc]");g.rT=RegExp("^[^\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc]*[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]");
g.sT=RegExp("^[^A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]*[\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc]");mla=/^http:\/\/.*/;nla=/\s+/;ola=/[\d\u06f0-\u06f9]/;tc.prototype.vf=!0;tc.prototype.qe=function(){return this.l};
tc.prototype.cp=!0;tc.prototype.g=function(){return 1};
var sc={};g.yc.prototype.vf=!0;g.yc.prototype.qe=function(){return this.l};
g.yc.prototype.cp=!0;g.yc.prototype.g=function(){return 1};
var Ac=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,xc={};Bc("about:blank");Fc.prototype.vf=!0;var Ec={};Fc.prototype.qe=function(){return this.g};
var pla=Gc(""),Baa=/^[-,."'%_!# a-zA-Z0-9\[\]]+$/,Jc=RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))","g"),Ic=RegExp("\\b(hsl|hsla|rgb|rgba|matrix|calc|minmax|fit-content|repeat|(rotate|scale|translate)(X|Y|Z|3d)?)\\([-+*/0-9a-z.%\\[\\], ]+\\)","g"),Caa=/\/\*/;g.Lc.prototype.cp=!0;g.Lc.prototype.g=function(){return this.o};
g.Lc.prototype.vf=!0;g.Lc.prototype.qe=function(){return this.l};
var tT=/^[a-zA-Z0-9-]+$/,qla={action:!0,cite:!0,data:!0,formaction:!0,href:!0,manifest:!0,poster:!0,src:!0},rla={APPLET:!0,BASE:!0,EMBED:!0,IFRAME:!0,LINK:!0,MATH:!0,META:!0,OBJECT:!0,SCRIPT:!0,STYLE:!0,SVG:!0,TEMPLATE:!0},Kc={};Nc("<!DOCTYPE html>",0);Nc("",0);Nc("<br>",0);var Gaa=mc(function(){var a=window.document.createElement("div");a.innerHTML="<div><div></div></div>";var b=a.firstChild.firstChild;a.innerHTML="";return!b.parentElement});g.Yc.prototype.clone=function(){return new g.Yc(this.x,this.y)};
g.Yc.prototype.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};
g.Yc.prototype.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};
g.Yc.prototype.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};g.h=g.ad.prototype;g.h.clone=function(){return new g.ad(this.width,this.height)};
g.h.ke=function(){return this.width*this.height};
g.h.aspectRatio=function(){return this.width/this.height};
g.h.isEmpty=function(){return!this.ke()};
g.h.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
g.h.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
g.h.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};var kd={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",nonce:"nonce",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};g.h=cd.prototype;g.h.ia=function(){return g.v(void 0)?this.g.getElementById(void 0):void 0};
g.h.getElementsByTagName=function(a,b){return(b||this.g).getElementsByTagName(String(a))};
g.h.createElement=function(a){return this.g.createElement(String(a))};
g.h.appendChild=g.xd;g.h.append=function(a,b){td(g.dd(a),a,arguments,1)};
g.h.canHaveChildren=function(a){if(1!=a.nodeType)return!1;switch(a.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case "SCRIPT":case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
g.h.removeNode=g.Ad;g.h.contains=g.Fd;var Maa=g.va;var Sx,Rx;g.hu=$b();Sx=dc()||Ab("iPod");Rx=Ab("iPad");g.Tx=g.cc();g.Ct=ac();g.ry=bc()&&!g.ec();var Td=null,Xd=null,Sd=null;var Yd=0,Zd=0;var fe=[];ce.prototype.clone=function(){return ge(this.l,this.A,this.o-this.A)};
ce.prototype.clear=function(){this.l=null;this.g=this.o=this.A=0;this.B=!1};
ce.prototype.reset=function(){this.g=this.A};ie.prototype.reset=function(){this.g.reset();this.l=this.o=-1};oe.prototype.length=function(){return this.g.length};
oe.prototype.end=function(){var a=this.g;this.g=[];return a};te.prototype.reset=function(){this.o=[];this.g.end();this.l=0};var Ee="function"==typeof window.Uint8Array,Fe=[];De.prototype.toString=function(){Se(this);return this.l.toString()};
De.prototype.clone=function(){return new this.constructor(Te(Qe(this)))};g.w.console&&"function"===typeof g.w.console.log&&(0,g.z)(g.w.console.log,g.w.console);var Ve={};var qf=!g.pd||g.kc(9),sla=g.pd&&!g.jc("9"),Uaa=function(){if(!g.w.addEventListener||!Object.defineProperty)return!1;var a=!1,b=Object.defineProperty({},"passive",{get:function(){a=!0}});
try{g.w.addEventListener("test",g.va,b),g.w.removeEventListener("test",g.va,b)}catch(c){}return a}();g.G.prototype.Fc=!1;g.G.prototype.ea=function(){return this.Fc};
g.G.prototype.dispose=function(){this.Fc||(this.Fc=!0,this.U())};
g.G.prototype.U=function(){if(this.sc)for(;this.sc.length;)this.sc.shift()()};g.Ze.prototype.stopPropagation=function(){this.oh=!0};
g.Ze.prototype.preventDefault=function(){this.defaultPrevented=!0;this.kz=!1};g.uT=g.rd?"webkitAnimationEnd":g.kh?"oanimationend":"animationend";g.A($e,g.Ze);var tla={2:"touch",3:"pen",4:"mouse"};
$e.prototype.init=function(a,b){var c=this.type=a.type,d=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement;this.currentTarget=b;var e=a.relatedTarget;e?g.jh&&(gc(e,"nodeName")||(e=null)):"mouseover"==c?e=a.fromElement:"mouseout"==c&&(e=a.toElement);this.relatedTarget=e;d?(this.clientX=void 0!==d.clientX?d.clientX:d.pageX,this.clientY=void 0!==d.clientY?d.clientY:d.pageY,this.screenX=d.screenX||0,this.screenY=d.screenY||0):(this.clientX=void 0!==
a.clientX?a.clientX:a.pageX,this.clientY=void 0!==a.clientY?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0);this.button=a.button;this.keyCode=a.keyCode||0;this.key=a.key||"";this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.pointerId=a.pointerId||0;this.pointerType=g.v(a.pointerType)?a.pointerType:tla[a.pointerType]||"";this.state=a.state;this.g=a;a.defaultPrevented&&this.preventDefault()};
$e.prototype.stopPropagation=function(){$e.Aa.stopPropagation.call(this);this.g.stopPropagation?this.g.stopPropagation():this.g.cancelBubble=!0};
$e.prototype.preventDefault=function(){$e.Aa.preventDefault.call(this);var a=this.g;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,sla)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(b){}};var Raa;g.af="closure_listenable_"+(1E6*Math.random()|0);Raa=0;df.prototype.add=function(a,b,c,d,e){var f=a.toString();a=this.listeners[f];a||(a=this.listeners[f]=[],this.g++);var k=gf(a,b,d,e);-1<k?(b=a[k],c||(b.jl=!1)):(b=new Saa(b,this.src,f,!!d,e),b.jl=c,a.push(b));return b};
df.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.listeners))return!1;var e=this.listeners[a];b=gf(e,b,c,d);return-1<b?(cf(e[b]),g.Pa(e,b),0==e.length&&(delete this.listeners[a],this.g--),!0):!1};
df.prototype.fj=function(a,b,c,d){a=this.listeners[a.toString()];var e=-1;a&&(e=gf(a,b,c,d));return-1<e?a[e]:null};var nf="closure_lm_"+(1E6*Math.random()|0),tf={},pf=0,wf="__closure_events_fn_"+(1E9*Math.random()>>>0);g.A(g.xf,g.G);g.xf.prototype[g.af]=!0;g.h=g.xf.prototype;g.h.Ar=function(a){this.J=a};
g.h.addEventListener=function(a,b,c,d){g.jf(this,a,b,c,d)};
g.h.removeEventListener=function(a,b,c,d){g.rf(this,a,b,c,d)};
g.h.dispatchEvent=function(a){var b=this.J;if(b){var c=[];for(var d=1;b;b=b.J)c.push(b),++d}b=this.ba;d=a.type||a;if(g.v(a))a=new g.Ze(a,b);else if(a instanceof g.Ze)a.target=a.target||b;else{var e=a;a=new g.Ze(d,b);g.Zb(a,e)}e=!0;if(c)for(var f=c.length-1;!a.oh&&0<=f;f--){var k=a.currentTarget=c[f];e=yf(k,d,!0,a)&&e}a.oh||(k=a.currentTarget=b,e=yf(k,d,!0,a)&&e,a.oh||(e=yf(k,d,!1,a)&&e));if(c)for(f=0;!a.oh&&f<c.length;f++)k=a.currentTarget=c[f],e=yf(k,d,!1,a)&&e;return e};
g.h.U=function(){g.xf.Aa.U.call(this);this.oe&&g.ff(this.oe);this.J=null};
g.h.fa=function(a,b,c,d){return this.oe.add(String(a),b,!1,c,d)};
g.h.km=function(a,b,c,d){return this.oe.add(String(a),b,!0,c,d)};
g.h.Pa=function(a,b,c,d){this.oe.remove(String(a),b,c,d)};
g.h.fj=function(a,b,c,d){return this.oe.fj(String(a),b,c,d)};zf.prototype.get=function(){if(0<this.l){this.l--;var a=this.g;this.g=a.next;a.next=null}else a=this.o();return a};var Cf;var Lf=new zf(function(){return new Ff},function(a){a.reset()});
Ef.prototype.add=function(a,b){var c=Lf.get();c.set(a,b);this.l?this.l.next=c:this.g=c;this.l=c};
Ef.prototype.remove=function(){var a=null;this.g&&(a=this.g,this.g=this.g.next,this.g||(this.l=null),a.next=null);return a};
Ff.prototype.set=function(a,b){this.mf=a;this.scope=b;this.next=null};
Ff.prototype.reset=function(){this.next=this.scope=this.mf=null};var Gf,Hf=!1,If=new Ef;Qf.prototype.reset=function(){this.context=this.onRejected=this.o=this.g=null;this.l=!1};
var Rf=new zf(function(){return new Qf},function(a){a.reset()});
g.Pf.prototype.then=function(a,b,c){return ag(this,g.Aa(a)?a:null,g.Aa(b)?b:null,c)};
Mf(g.Pf);g.Pf.prototype.cancel=function(a){0==this.g&&g.Jf(function(){var b=new gg(a);cg(this,b)},this)};
g.Pf.prototype.H=function(a){this.g=0;Of(this,2,a)};
g.Pf.prototype.J=function(a){this.g=0;Of(this,3,a)};
g.Pf.prototype.G=function(){for(var a;a=dg(this);)eg(this,a,this.g,this.F);this.C=!1};
var ig=Bf;g.A(gg,Ga);gg.prototype.name="cancel";g.A(g.jg,g.xf);g.h=g.jg.prototype;g.h.enabled=!1;g.h.Fa=null;g.h.setInterval=function(a){this.Uc=a;this.Fa&&this.enabled?(this.stop(),this.start()):this.Fa&&this.stop()};
g.h.yc=function(){if(this.enabled){var a=(0,g.D)()-this.Av;0<a&&a<.8*this.Uc?this.Fa=this.zk.setTimeout(this.xt,this.Uc-a):(this.Fa&&(this.zk.clearTimeout(this.Fa),this.Fa=null),this.dispatchEvent("tick"),this.enabled&&(this.stop(),this.start()))}};
g.h.start=function(){this.enabled=!0;this.Fa||(this.Fa=this.zk.setTimeout(this.xt,this.Uc),this.Av=(0,g.D)())};
g.h.stop=function(){this.enabled=!1;this.Fa&&(this.zk.clearTimeout(this.Fa),this.Fa=null)};
g.h.U=function(){g.jg.Aa.U.call(this);this.stop();delete this.zk};var og=g.va,sg={'"':'\\"',"\\":"\\\\","/":"\\/","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\x0B":"\\u000b"},eba=/\uffff/.test("\uffff")?/[\\"\x00-\x1f\x7f-\uffff]/g:/[\\"\x00-\x1f\x7f-\xff]/g;g.h=tg.prototype;g.h.isEnabled=function(){return window.navigator.cookieEnabled};
g.h.set=function(a,b,c,d,e,f){if(/[;=\s]/.test(a))throw Error('Invalid cookie name "'+a+'"');if(/[;\r\n]/.test(b))throw Error('Invalid cookie value "'+b+'"');g.t(c)||(c=-1);e=e?";domain="+e:"";d=d?";path="+d:"";f=f?";secure":"";c=0>c?"":0==c?";expires="+(new Date(1970,1,1)).toUTCString():";expires="+(new Date((0,g.D)()+1E3*c)).toUTCString();this.g.cookie=a+"="+b+e+d+c+f};
g.h.get=function(a,b){for(var c=a+"=",d=(this.g.cookie||"").split(";"),e=0,f;e<d.length;e++){f=sb(d[e]);if(0==f.lastIndexOf(c,0))return f.substr(c.length);if(f==a)return""}return b};
g.h.remove=function(a,b,c){var d=g.t(this.get(a));this.set(a,"",0,b,c);return d};
g.h.Hd=function(){return ug(this).keys};
g.h.uc=function(){return ug(this).values};
g.h.isEmpty=function(){return!this.g.cookie};
g.h.clear=function(){for(var a=ug(this).keys,b=a.length-1;0<=b;b--)this.remove(a[b])};
var Ir=new tg("undefined"==typeof window.document?null:window.document);var fba=/^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/,Lg=/#|$/,gba=/[?&]($|#)/;Og.prototype.remove=function(a){Sb(this.g,a)};
Og.prototype.set=function(a,b){this.g[a]=b};
Og.prototype.get=function(a){return Tb(this.g,a,null)};g.h=g.Qg.prototype;g.h.se=function(){return this.right-this.left};
g.h.getHeight=function(){return this.bottom-this.top};
g.h.clone=function(){return new g.Qg(this.top,this.right,this.bottom,this.left)};
g.h.contains=function(a){return this&&a?a instanceof g.Qg?a.left>=this.left&&a.right<=this.right&&a.top>=this.top&&a.bottom<=this.bottom:a.x>=this.left&&a.x<=this.right&&a.y>=this.top&&a.y<=this.bottom:!1};
g.h.ceil=function(){this.top=Math.ceil(this.top);this.right=Math.ceil(this.right);this.bottom=Math.ceil(this.bottom);this.left=Math.ceil(this.left);return this};
g.h.floor=function(){this.top=Math.floor(this.top);this.right=Math.floor(this.right);this.bottom=Math.floor(this.bottom);this.left=Math.floor(this.left);return this};
g.h.round=function(){this.top=Math.round(this.top);this.right=Math.round(this.right);this.bottom=Math.round(this.bottom);this.left=Math.round(this.left);return this};g.h=g.Tg.prototype;g.h.clone=function(){return new g.Tg(this.left,this.top,this.width,this.height)};
g.h.contains=function(a){return a instanceof g.Yc?a.x>=this.left&&a.x<=this.left+this.width&&a.y>=this.top&&a.y<=this.top+this.height:this.left<=a.left&&this.left+this.width>=a.left+a.width&&this.top<=a.top&&this.top+this.height>=a.top+a.height};
g.h.ceil=function(){this.left=Math.ceil(this.left);this.top=Math.ceil(this.top);this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
g.h.floor=function(){this.left=Math.floor(this.left);this.top=Math.floor(this.top);this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
g.h.round=function(){this.left=Math.round(this.left);this.top=Math.round(this.top);this.width=Math.round(this.width);this.height=Math.round(this.height);return this};var ch=null;Zg.prototype.getValue=function(){return this.g};
Zg.prototype.l=function(){return String(this.g)};
g.A($g,Zg);$g.prototype.l=function(){return this.g?"1":"0"};
g.A(ah,Zg);ah.prototype.l=function(){return this.g?Math.round(this.g.top)+"."+Math.round(this.g.left)+"."+(Math.round(this.g.top)+Math.round(this.g.height))+"."+(Math.round(this.g.left)+Math.round(this.g.width)):""};var ih={},Gh={thin:2,medium:4,thick:6};new g.jg(200);var Zh=window.document,Wh=window;var oba=/https?:\/\/[^\/]+/,mba={KN:"allow-forms",LN:"allow-modals",MN:"allow-orientation-lock",NN:"allow-pointer-lock",ON:"allow-popups",PN:"allow-popups-to-escape-sandbox",QN:"allow-presentation",RN:"allow-same-origin",SN:"allow-scripts",TN:"allow-top-navigation",UN:"allow-top-navigation-by-user-activation"},rba=mc(function(){return nba()});var tba=mc(function(){var a=!1;try{var b=Object.defineProperty({},"passive",{get:function(){a=!0}});
g.w.addEventListener("test",null,b)}catch(c){}return a});var Iba={VP:1,GQ:2,CP:3};var Xh=!!window.google_async_iframe_id,Yh=Xh&&window.parent||window;var ula=[0,2,1],vT=null;window.document.addEventListener&&window.document.addEventListener("mousedown",function(a){vT=a},!0);
window.mb=function(a){if(a){var b;if(b=window.event||vT){var c;(c=b.which?1<<ula[b.which-1]:b.button)&&b.shiftKey&&(c|=8);c&&b.altKey&&(c|=16);c&&b.ctrlKey&&(c|=32);b=c}else b=null;b&&(window.css?window.css(a.id,"mb",b,void 0,void 0):a&&(a.href=Mh(a.href,"mb",b,void 0)))}};var Tba={NONE:0,GO:1},Hba={zQ:1};ci.prototype.isVisible=function(){return this.Tg?.3<=this.g:.5<=this.g};var kj={vO:0,NO:1},Gba={NONE:0,nP:1};di.prototype.getValue=function(){return this.l};ei.prototype.disable=function(){this.o=!1};
ei.prototype.enable=function(){this.o=!0};
ei.prototype.isEnabled=function(){return this.o};
ei.prototype.reset=function(){this.g={};this.o=!0;this.l={}};var xba=(0,g.D)(),mi=-1,ki=-1,Ok,ni=-1,li=!1;pi.prototype.ld=function(){return!!this.l||!!this.g};
pi.prototype.toString=function(){return this.l+(this.g?"-":"")+this.g};
pi.prototype.matches=function(a){return this.g||a.g?this.g==a.g:this.l||a.l?this.l==a.l:!1};var yba=/^https?:\/\/(\w|-)+\.cdn\.ampproject\.(net|org)(\?|\/|$)/;ui.prototype.Ib=function(a,b,c,d){a=a+"//"+b+c;var e=Aba(this)-c.length-d.length;if(0>e)return"";this.g.sort(function(a,b){return a-b});
c=null;b="";for(var f=0;f<this.g.length;f++)for(var k=this.g[f],l=this.l[k],m=0;m<l.length;m++){if(!e){c=null==c?k:c;break}var n=xi(l[m],this.o,",$");if(n){n=b+n;if(e>=n.length){e-=n.length;a+=n;b=this.o;break}else this.B&&(b=e,n[b-1]==this.o&&--b,a+=n.substr(0,b),b=this.o,e=0);c=null==c?k:c}}f="";this.A&&null!=c&&(f=b+this.A+"="+c);return a+f+d};g.Ai.prototype.clone=function(){return new g.Ai(this.start,this.end)};
g.Ai.prototype.getLength=function(){return this.end-this.start};var wT=null;var Gi=g.w.performance,vla=!!(Gi&&Gi.mark&&Gi.measure&&Gi.clearMarks),Ei=mc(function(){var a;if(a=vla){var b;if(null===wT){wT="";try{a="";try{a=g.w.top.location.hash}catch(c){a=g.w.location.hash}a&&(wT=(b=a.match(/\bdeid=([\d,]+)/))?b[1]:"")}catch(c){}}b=wT;a=!!b.indexOf&&0<=b.indexOf("1337")}return a});
Fi.prototype.disable=function(){this.g=!1;this.events!=this.l.google_js_reporting_queue&&(Ei()&&(0,g.C)(this.events,Hi),this.events.length=0)};
Fi.prototype.start=function(a,b){if(!this.g)return null;var c=Ci()||Bi();c=new Bba(a,b,c);var d="goog_"+c.uniqueId+"_start";Gi&&Ei()&&Gi.mark(d);return c};
Fi.prototype.end=function(a){if(this.g&&g.ta(a.value)){var b=Ci()||Bi();a.duration=b-a.value;b="goog_"+a.uniqueId+"_end";Gi&&Ei()&&Gi.mark(b);this.g&&this.events.push(a)}};Ki.prototype.pinger=function(){return this.o};
Ki.prototype.g=function(a,b,c,d,e){e=e||this.B;try{var f=new ui;f.B=!0;yi(f,1,"context",a);b.error&&b.meta&&b.id||(b=Li(b));b.msg&&yi(f,2,"msg",b.msg.substring(0,512));b.file&&yi(f,3,"file",b.file);0<b.line&&yi(f,4,"line",b.line);var k=b.meta||{};if(this.l)try{this.l(k)}catch(m){}if(d)try{d(k)}catch(m){}b=[k];f.g.push(5);f.l[5]=b;var l=ti();l.l&&yi(f,6,"top",l.l.url||"");yi(f,7,"url",l.g.url||"");zi(this.o,e,f,c)}catch(m){try{zi(this.o,e,{context:"ecmserr",rctx:a,msg:Qi(m),url:l&&l.g.url},c)}catch(n){}}return this.A};
g.r(Pi,qi);var Ji,Ni,Di=$h(),Ii=new Fi;Ji=new function(){var a=void 0===a?Wh:a;this.A="http:"===a.location.protocol?"http:":"https:";this.l="pagead2.googlesyndication.com";this.o="/pagead/gen_204?id=";this.g=.01};
Ni=new Ki;"complete"==Di.document.readyState?Di.google_measure_js_timing||Ii.disable():Ii.g&&Th(Di,"load",function(){Di.google_measure_js_timing||Ii.disable()});
var Dba=Ni.g;if(Zh&&Zh.URL){var xT,Rh=Zh.URL;xT=!!Rh&&0<qba().length;Ni.A=!xT};g.hk=!g.pd&&!bc();ej.prototype.ia=function(){return this.G};fj.prototype.update=function(a){this.B=bi(!1,a,this.J);hj(this,a);this.G=this.o&&this.l?this.C:this.g};
g.wa(fj);g.wa(Vi);lj.prototype.cancel=function(){Wh.clearTimeout(this.g);this.g=null};
lj.prototype.schedule=function(){var a=this;Wh&&(this.g=Wh.setTimeout(Si(143,function(){a.l++;a.o.lz()}),oi(Vi.getInstance().o)))};g.h=mj.prototype;g.h.rh=function(){return this.jf()};
g.h.jf=function(){return!1};
g.h.initialize=function(){this.J=!0};
g.h.Hh=function(){return this.T};
g.h.Pg=function(){return this.L};
g.h.lg=function(){return this.l==this?this.Z:this.l.lg()};
g.h.qf=function(){return{}};
g.h.tf=function(){return this.A};
g.h.bw=function(){hj(fj.getInstance(),this.fc)};
g.h.ew=function(){gj(fj.getInstance(),this.fc)};
g.h.cw=function(){ij(fj.getInstance(),this.fc)};
g.h.dw=function(){var a=fj.getInstance();a.B=bi(!1,this.fc,a.J)};
g.h.lz=function(){};
g.h.qn=function(){};
g.h.Og=function(a){var b=this.A,c=a.tf();this.l=c<this.F?this:a;this.A=this.l!=this?c:this.F;this.l==this||1==c&&0!=this.F||this.qn();this.A!=b&&nj(this)};
g.h.fg=function(a){this.l!=this&&tj(this,a)};
g.h.Jf=function(){return this.C};
g.h.dispose=function(){this.R=!0};
g.h.ea=function(){return this.R};g.h=uj.prototype;g.h.Nv=function(){};
g.h.Gp=function(){};
g.h.Ni=function(){this.l=new ej(this.g.g,this.element,this.l.g,this.l.A,this.ej(),this.l.l,this.l.F,this.l.H,this.l.o)};
g.h.dispose=function(){this.ea()||(qj(this.g,this),this.F=!0)};
g.h.ea=function(){return this.F};
g.h.qf=function(){return this.A.qf()};
g.h.tf=function(){return this.A.tf()};
g.h.Hh=function(){return this.A.Hh()};
g.h.Pg=function(){return this.A.Pg()};
g.h.Og=function(a){this.A=a;this.G.Og(this)};
g.h.fg=function(){this.Ni()};
g.h.Jf=function(){return this.G.Jf()};g.h=vj.prototype;g.h.tf=function(){return this.g.tf()};
g.h.Hh=function(){return this.g.Hh()};
g.h.Pg=function(){return this.g.Pg()};
g.h.create=function(a,b,c){var d=null;this.g&&(d=this.Mv(a,b,c),pj(this.g,d));return d};
g.h.rh=function(){return this.jf()};
g.h.jf=function(){return!1};
g.h.init=function(){return!0};
g.h.dispose=function(){this.B=!0};
g.h.ea=function(){return this.B};
g.h.qf=function(){return{}};yj.prototype.add=function(a,b,c){++this.o;var d=this.o/4096;this.g.push(Kba(new wj(a,b,c),d));this.l=!0;return this};var Cj;Cj=["av.key","js","unreleased"].slice(-1)[0];var Gj={},Hj=null;Gj.le=0;Gj.nt=2;Gj.Fr=3;Gj.Po=5;Gj.me=1;Gj.om=4;Jj.prototype.update=function(a,b,c){a&&(this.g+=b,this.l+=b,this.A+=b,this.o=Math.max(this.o,this.A));if(void 0===c?!a:c)this.A=0};var Oba=[1,.75,.5,.3,0];Kj.prototype.update=function(a,b,c,d,e,f){f=void 0===f?!0:f;b=e?Math.min(a,b):b;for(e=0;e<this.l.length;e++){var k=this.l[e],l=0<b&&b>=k;k=!(0<a&&a>=k)||c;this.g[e].update(f&&l,d,!f||k)}};Tj.prototype.update=function(a,b,c,d,e){this.F=-1!=this.F?Math.min(this.F,b.g):b.g;e&&(this.O=Math.max(this.O,b.g));this.ba.update(b.l,c.l,b.o,a,d);this.g.update(b.g,c.g,b.o,a,d);c=d||c.Tg!=b.Tg?c.isVisible()&&b.isVisible():c.isVisible();b=!b.isVisible()||b.o;this.Z.update(c,a,b)};
Tj.prototype.Vg=function(){return this.Z.o>=this.da};g.r(bk,uj);g.h=bk.prototype;g.h.ej=function(){return!0};
g.h.Ni=function(){if(this.element){var a=this.element.getBoundingClientRect(),b=a.right-a.left;a=a.bottom-a.top;var c=g.wh(this.element,this.g.fc),d=c.x;c=c.y;this.o=new g.Qg(Math.round(c),Math.round(d+b),Math.round(c+a),Math.round(d))}(a=this.g.g.g)?(b=Yj()&&this.element?ak(this.element):this.o,a=dk(b,a),b=a.top>=a.bottom||a.left>=a.right?new g.Qg(0,0,0,0):Sg(a,-b.left,-b.top)):b=new g.Qg(0,0,0,0);var e=this.g.g.g;c=d=a=0;var f=1==hi(this.Sa,"od"),k=(this.o.bottom-this.o.top)*(this.o.right-this.o.left);
e&&b&&0<k&&(ck(b,e,this.element,f)?b=new g.Qg(0,0,0,0):(c=new g.Qg(0,window.screen.height,window.screen.width,0),a=fk(b,this.o),d=fk(b,e),c=fk(b,c)));e=this.g.g;f=-1===e.time?ji():e.time;this.l=new ej(e,this.element,this.o,b,this.ej(),a,d,f,c)};
g.h.Pg=function(){return this.A.Pg()};
g.h.lg=function(){return this.A.lg()};
g.h.fg=function(a){if(null==this.element){var b=fj.getInstance().B;this.o=null!=b?b:new g.Qg(0,0,0,0)}uj.prototype.fg.call(this,a)};var gk=new g.Qg(0,0,0,0);g.r(ik,g.G);g.h=ik.prototype;g.h.U=function(){this.element&&(this.Eh.Kq&&(Uh(this.element,"mouseover",this.Eh.Kq),this.Eh.Kq=null),this.Eh.Jq&&(Uh(this.element,"mouseout",this.Eh.Jq),this.Eh.Jq=null));g.G.prototype.U.call(this)};
g.h.fg=function(){};
g.h.Og=function(a){a.Pg()&&this.jA(this,a.Hh(),a)};
g.h.Jf=function(){return!1};
g.h.Ll=function(){return new Tj};
g.h.xd=function(){return this.Cp};
g.h.Gv=function(){};
g.h.Fv=function(){};
g.h.Ru=function(){};
g.h.Bn=function(){};
g.h.uh=function(a,b,c,d,e,f,k,l,m){k=void 0===k?{}:k;l=void 0===l?this.Hu(c,k):l;k=this.Wn(a,b,d,k,void 0===m?-1:m);g.ta(b)||(this.Gx=new g.Yc(a.left-b.left,a.top-b.top));e=e&&this.dc.g>=(this.Tg()?.3:.5);this.Tr(l,k,e,f);this.Bj=c;0<k.g&&-1===this.Uz&&(this.Uz=c);-1==this.Yz&&this.Vg()&&(this.Yz=c);if(-2==this.zp)try{a:{var n=g.ta(b)?null:b;if(a&&a!=gk&&0!=this.ke){var p=fj.getInstance();if(!n){if(!p.g){var u=-1;break a}n=new g.Qg(0,p.g.se(),p.g.getHeight(),0)}u=n.se&&0<n.se()&&n.getHeight&&0<n.getHeight()?
this.Ti(a,n):-1}else u=-1}this.zp=u}catch(x){Ti(207,x)}this.dc=k;d&&(this.dc.g=0);this.Dp(this)};
g.h.Tr=function(a,b,c,d){this.xd().update(a,b,this.dc,c,d)};
g.h.Fo=function(){return new ci};
g.h.Wn=function(a,b,c,d,e){e=void 0===e?-1:e;d=this.Fo();d.o=c;c=Yi(Zh);d.A=0==c?-1:1==c?0:1;g.ta(b)?(d.g=this.Ti(b),d.l=e):(d.g=this.Ti(a,b),d.l=0<=e?e:d.g*ek(a)/(Wh.screen.height*Wh.screen.width));d.Tg=this.Tg();return d};
g.h.Hu=function(a){if(-1==this.Bj)return 0;a=a-this.Bj||1;return 1E4<a?1:a};
g.h.Ti=function(a,b){if(0===this.opacity&&1===hi(this.Sa,"opac"))return 0;if(g.ta(a))return a;var c=dk(a,b),d=1==hi(this.Sa,"od");if(0>=this.ke||ck(c,b,this.Hg,d))return 0;d=ek(c)/this.ke;fk(c,b);return d};
g.h.Tg=function(){return!1};
g.h.re=function(){return 0};
g.h.Vg=function(){return this.Cp.Vg()};var qk="StopIteration"in g.w?g.w.StopIteration:{message:"StopIteration",stack:""};pk.prototype.next=function(){throw qk;};
pk.prototype.ff=function(){return this};var Ml={currentTime:1,duration:2,isVpaid:4,volume:8,isYouTube:16,isPlaying:32},Lk={AB:"start",fB:"firstquartile",oB:"midpoint",DB:"thirdquartile",VA:"complete",nB:"metric",PAUSE:"pause",tB:"resume",xB:"skip",FB:"viewable_impression",pB:"mute",EB:"unmute",gB:"fullscreen",eB:"exitfullscreen",hO:"bufferstart",gO:"bufferfinish",hB:"fully_viewable_audible_half_duration_impression",mB:"measurable_impression",QA:"abandon",bB:"engagedview",kB:"impression",WA:"creativeview",lB:"loaded",YP:"progress",CLOSE:"close",
sO:"collapse",MP:"overlay_resize",NP:"overlay_unmeasurable_impression",OP:"overlay_unviewable_impression",QP:"overlay_viewable_immediate_impression",PP:"overlay_viewable_end_of_session_impression",XA:"custom_metric_viewable"},jda="start firstquartile midpoint thirdquartile resume loaded".split(" "),kda=["start","firstquartile","midpoint","thirdquartile"],mca=["abandon"],nl={UNKNOWN:-1,AB:0,fB:1,oB:2,DB:3,VA:4,nB:5,PAUSE:6,tB:7,xB:8,FB:9,pB:10,EB:11,gB:12,eB:13,hB:14,mB:15,QA:16,bB:17,kB:18,WA:19,
lB:20,XA:21};g.r(tk,ci);xk.prototype.getValue=function(){return this.l};
xk.prototype.update=function(a,b){32<=a||(this.g&1<<a&&!b?this.l&=~(1<<a):this.g&1<<a||!b||(this.l|=1<<a),this.g|=1<<a)};g.r(yk,Tj);
yk.prototype.update=function(a,b,c,d,e){if(!b.paused){Tj.prototype.update.call(this,a,b,c,d,e);e=uk(b)&&uk(c);var f=.5<=(d?Math.min(b.g,c.g):c.g);bj(b.volume)&&(this.A=-1!=this.A?Math.min(this.A,b.volume):b.volume,this.C=Math.max(this.C,b.volume));f&&(this.L+=a,this.H+=e?a:0);this.l.update(b.g,c.g,b.o,a,d,e);this.o.update(!0,a);this.B.update(e,a);this.J.update(c.fullscreen,a);this.ha.update(e&&!f,a);a=Math.floor(b.B/1E3);this.T.update(a,b.isVisible());this.X.update(a,1<=b.g);this.Y.update(a,uk(b))}};g.r(Ak,gca);Ak.prototype.o=function(){return!0};
Ak.prototype.B=function(){return!1};
Ak.prototype.getId=function(){var a=this,b=Ob(Lk,function(b){return b==a.A});
return nl[b].toString()};
Ak.prototype.toString=function(){var a="";this.B()&&(a+="c");this.g&&(a+="s");0<this.l&&(a+=":"+this.l);return this.getId()+a};var wla=new g.Qg(0,0,0,0),yT={},lca=(yT.firstquartile=0,yT.midpoint=1,yT.thirdquartile=2,yT.complete=3,yT);g.r(Ck,ik);g.h=Ck.prototype;g.h.Jf=function(){return!0};
g.h.Gv=function(a){var b=this,c=a-this.Ja;this.ka&&1E3>=c||(c=g.y("ima.bridge.getNativeViewability"),g.Aa(c)&&(c(this.jc,function(a){b.ka=!1;g.Qb(a)&&b.pa++;b.Bn(a)}),this.ka=!0,this.Ja=a))};
g.h.Fv=function(a){var b=Vi.getInstance();a-this.Ia>oi(b.o)&&(a=g.y("ima.admob.getViewability"),g.Aa(a)&&a(this.jc))};
g.h.Ru=function(a){this.Ia=ji();this.Bn(a)};
g.h.Bn=function(a){var b=a.opt_nativeViewBounds||{},c=a.opt_nativeViewVisibleBounds||{},d=a.opt_nativeTime||-1,e=a.opt_nativeVolume,f=a.opt_nativeViewAttached;a=a.opt_nativeViewHidden;void 0!==f&&(this.da=!!f);b=new g.Qg(b.top||0,b.left+b.width||0,b.top+b.height||0,b.left||0);c=a?wla.clone():new g.Qg(c.top||0,c.left+c.width||0,c.top+c.height||0,c.left||0);f=void 0;if("n"==this.A||"ml"==this.A)f={volume:e};e=f;e=void 0===e?{}:e;this.ke=(b.bottom-b.top)*(b.right-b.left);this.position=b;this.uh(b,c,
d,!1,!0,!0,e)};
g.h.uh=function(a,b,c,d,e,f,k,l,m){var n=this;k=void 0===k?{}:k;var p=this.ha(this)||{};g.Zb(p,k);this.B=p.duration||this.B;this.H=p.isVpaid||this.H;this.ga=p.isYouTube||this.ga;this.X=f;ik.prototype.uh.call(this,a,b,c,d,e,f,p,l,m);(0,g.C)(this.F,function(a){a.g||(a.g=Bk(a,n))})};
g.h.Tr=function(a,b,c,d){ik.prototype.Tr.call(this,a,b,c,d);Fk(this).update(a,b,this.dc,c,d);this.ba=uk(this.dc)&&uk(b);-1==this.R&&this.wa&&(this.R=this.xd().o.g);this.gc.o=0;a=this.dc;b=this.Vg();.5<=a.g&&vk(this.gc,"vs");b&&vk(this.gc,"vw");bj(a.volume)&&vk(this.gc,"am");this.ba&&vk(this.gc,"a");this.Nh&&vk(this.gc,"f");-1!=a.A&&(vk(this.gc,"bm"),1==a.A&&vk(this.gc,"b"));this.ba&&b&&vk(this.gc,"avw");this.X&&vk(this.gc,"cm");this.X&&0<a.g&&vk(this.gc,"pv");Ik(this,this.xd().o.g,!0)&&vk(this.gc,
"gdr");2E3<=Qj(this.xd().g,1)&&vk(this.gc,"pmx")};
g.h.Ll=function(){return new yk};
g.h.xd=function(){return this.Cp};
g.h.Fo=function(){return new tk};
g.h.Wn=function(a,b,c,d,e){a=ik.prototype.Wn.call(this,a,b,c,d,void 0===e?-1:e);a.fullscreen=this.Nh;a.paused=2==this.wc;a.volume=d.volume;bj(a.volume)||(this.Ta++,b=this.dc,bj(b.volume)&&(a.volume=b.volume));d=d.currentTime;a.B=g.t(d)&&0<=d?d:-1;return a};
g.h.Hu=function(a,b){var c=g.t(b.currentTime)?b.currentTime:this.L;if(-1==this.Bj||2==this.wc)var d=0;else{d=a-this.Bj||1;var e=1E4;g.t(this.B)&&-1!=this.B&&(e=Math.max(e,this.B/3));d=d>e?1:d}e=c-this.L;var f=0;0<=e?(this.J+=d,this.Z+=Math.max(d-e,0),f=Math.min(e,this.J)):this.oa+=Math.abs(e);0!=e&&(this.J=0);-1==this.sa&&0<e&&(this.sa=0<=ni?ji()-ni:-1);this.L=c;return 1==Gk(this)?f:d};
g.h.Ti=function(a,b){return this.Ca?0:this.Nh?1:ik.prototype.Ti.call(this,a,b)};
g.h.re=function(){return 1};var xla=(0,g.D)();Qk.prototype.reset=function(){this.g=[];this.l=[]};
g.wa(Qk);var Sk=Qk.getInstance();g.wa(Uk);var xca={threshold:[0,.01,.02,.03,.04,.05,.06,.07,.08,.09,.1,.11,.12,.13,.14,.15,.16,.17,.18,.19,.2,.21,.22,.23,.24,.25,.26,.27,.28,.29,.3,.31,.32,.33,.34,.35,.36,.37,.38,.39,.4,.41,.42,.43,.44,.45,.46,.47,.48,.49,.5,.51,.52,.53,.54,.55,.56,.57,.58,.59,.6,.61,.62,.63,.64,.65,.66,.67,.68,.69,.7,.71,.72,.73,.74,.75,.76,.77,.78,.79,.8,.81,.82,.83,.84,.85,.86,.87,.88,.89,.9,.91,.92,.93,.94,.95,.96,.97,.98,.99,1]};g.r(Wk,uj);g.h=Wk.prototype;g.h.lg=function(){return"nio"};
g.h.ej=function(){return!0};
g.h.Nv=function(){var a=this;this.C||(this.C=ji());Ri(298,function(){return yca(a)})||oj(this.g,"msf")};
g.h.Gp=function(){if(this.o&&this.element)try{this.o.unobserve(this.element)}catch(a){}};
g.h.Ni=function(){uj.prototype.Ni.call(this);if(1===hi(Vi.getInstance().Sa,"nio_mode")){var a=this.o&&this.o.takeRecords?this.o.takeRecords():[];0<a.length?Xk(this,a):this.l=new ej(this.l.C,this.l.ia(),this.l.g,this.l.A,this.l.B,this.l.l,this.l.F,this.g.fc.performance.now(),this.l.o)}};
g.h.qf=function(){var a={};return Object.assign(this.g.qf(),(a.niot_obs=this.C,a.niot_cbk=this.B,a))};g.r(Yk,vj);Yk.prototype.lg=function(){return"nio"};
Yk.prototype.rh=function(){var a=1===hi(Vi.getInstance().Sa,"nio_mode"),b=fj.getInstance().l;return(a||b)&&this.jf()};
Yk.prototype.jf=function(){return"exc"!==Vi.getInstance().bb&&1!=hi(Vi.getInstance().Sa,"inapp")&&null!=this.g.fc.IntersectionObserver};
Yk.prototype.Mv=function(a,b,c){return new Wk(a,this.g,b,c)};g.A(g.Zk,g.G);g.h=g.Zk.prototype;g.h.Kh=!1;g.h.nj=0;g.h.Fa=null;g.h.mj=function(a){this.g=arguments;this.Fa||this.nj?this.Kh=!0:$k(this)};
g.h.stop=function(){this.Fa&&(g.w.clearTimeout(this.Fa),this.Fa=null,this.Kh=!1,this.g=[])};
g.h.pause=function(){this.nj++};
g.h.resume=function(){this.nj--;this.nj||!this.Kh||this.Fa||(this.Kh=!1,$k(this))};
g.h.U=function(){g.Zk.Aa.U.call(this);this.stop()};
g.h.AC=function(){this.Fa=null;this.Kh&&!this.nj&&(this.Kh=!1,$k(this))};al.prototype.C=function(){el(this,Tk(),!1)};
al.prototype.lz=function(){el(this,Tk(),!1)};
al.prototype.H=function(){var a=jj(),b=ji();a?(li||(mi=b,(0,g.C)(Sk.g,function(a){var c=a.xd();c.R=zk(c,b,1!=a.wc)})),li=!0):(this.O=fl(this,b),li=!1,Ok=b,(0,g.C)(Sk.g,function(a){a.Fh&&(a.xd().G=b)}));
el(this,Tk(),!a)};
al.prototype.T=function(a){return g.pd&&g.jc(8)&&g.Aa(Ij(a&&a.document))?(Vi.getInstance().bb="iem",!0):!1};
g.wa(al);var cl=al.getInstance();var gl=null,Fl="",El=!1;var Gca=function(a,b){return function(c){for(var d=0;d<b.length;d++)if(b[d]===c[a]||!g.t(b[d])&&!c.hasOwnProperty(a))return!0;return!1}}("e",[void 0,
1,2,3,4,8,16]),yla={sv:"sv",cb:"cb",e:"e",nas:"nas",msg:"msg","if":"if",sdk:"sdk",p:"p",tos:"tos",mtos:"mtos",mcvt:"mcvt",ps:"ps",scs:"scs",bs:"bs",pt:"pt",vht:"vht",mut:"mut",a:"a",ft:"ft",dft:"dft",at:"at",dat:"dat",as:"as",vpt:"vpt",gmm:"gmm",std:"std",efpf:"efpf",swf:"swf",nio:"nio",px:"px",nnut:"nnut",vmer:"vmer",vmmk:"vmmk",vmiec:"vmiec",nmt:"nmt",tcm:"tcm",bt:"bt",pst:"pst",vpaid:"vpaid",dur:"dur",vmtime:"vmtime",dtos:"dtos",dtoss:"dtoss",dvs:"dvs",dfvs:"dfvs",dvpt:"dvpt",fmf:"fmf",vds:"vds",
is:"is",i0:"i0",i1:"i1",i2:"i2",i3:"i3",ic:"ic",cs:"cs",c:"c",mc:"mc",nc:"nc",mv:"mv",nv:"nv",qmt:ll("qmtos"),qnc:ll("qnc"),qmv:ll("qmv"),qnv:ll("qnv"),raf:"raf",rafc:"rafc",lte:"lte",ces:"ces",tth:"tth",femt:"femt",femvt:"femvt",emc:"emc",emuc:"emuc",emb:"emb",avms:"avms",nvat:"nvat",qi:"qi",psm:"psm",psv:"psv",psfv:"psfv",psa:"psa",pnk:"pnk",pnc:"pnc",pnmm:"pnmm",pns:"pns",ptlt:"ptlt",dc_rfl:"urlsigs",pngs:"pings",obd:"obd",veid:"veid",ssb:"ssb"},zla={c:hl("c"),at:"at",atos:kl("atos",[0,2,4]),ta:function(a,
b){return function(c){if(!g.t(c[a]))return b}}("tth","1"),
a:"a",dur:"dur",p:"p",tos:jl(),j:"dom",mtos:kl("mtos",[0,2,4]),gmm:"gmm",gdr:"gdr",ss:hl("ss"),vsv:lc("w2"),t:"t"},Ala={atos:"atos",amtos:"amtos",avt:kl("atos",[2]),davs:"davs",dafvs:"dafvs",dav:"dav",ss:hl("ss"),t:"t"},Bla={a:"a",tos:jl(),at:"at",c:hl("c"),mtos:kl("mtos",[0,2,4]),dur:"dur",fs:"fs",p:"p",vpt:"vpt",vsv:lc("ias_w2"),dom:"dom",gmm:"gmm",gdr:"gdr",t:"t"},Cla={tos:jl(),at:"at",c:hl("c"),mtos:kl("mtos",[0,2,4]),p:"p",vpt:"vpt",vsv:lc("dv_w4"),gmm:"gmm",gdr:"gdr",dom:"dom",t:"t",mv:"mv",
qmpt:kl("qmtos",[0,2,4]),qvs:function(a,b){return function(c){var d=c[a];if(g.ta(d))return(0,g.E)(b,function(a){return 0<d&&d>=a?1:0})}}("qnc",[1,
.5,0]),qmv:"qmv",qa:"qas",a:"a"};g.r(ql,Ak);ql.prototype.o=function(a){return a.xd().Vg()};g.r(tl,Hca);tl.prototype.g=function(a){var b=new rl;b.g=sl(a,yla);b.o=sl(a,Ala);return b};g.r(vl,vj);g.h=vl.prototype;g.h.lg=function(){return(this.l?this.l:this.g).lg()};
g.h.qf=function(){return(this.l?this.l:this.g).qf()};
g.h.tf=function(){return(this.l?this.l:this.g).tf()};
g.h.init=function(a){this.A=a;(0,g.C)(this.o,function(a){return a.initialize()});
pj(this.g,this);return!0};
g.h.dispose=function(){(0,g.C)(this.o,function(a){a.qn();a.dispose()});
vj.prototype.dispose.call(this)};
g.h.rh=function(){return(0,g.rj)(this.o,function(a){return a.rh()})};
g.h.jf=function(){return(0,g.rj)(this.o,function(a){return a.jf()})};
g.h.Mv=function(a,b,c){return new bk(a,this.g,b,c)};
g.h.Og=function(a){0==a.tf()&&this.A(a.Hh(),this)};
g.h.fg=function(a){this.l=a.o};
g.h.Jf=function(){return!1};g.r(wl,mj);g.h=wl.prototype;g.h.qf=function(){var a={};return a.exg=1,a};
g.h.initialize=function(){var a=this;if(!this.J)if(this.J=!0,Vi.getInstance().l.ld()){Ui(g.w,"message",function(b){if(null!=b&&b.data&&g.v(b.data)){var c=b.data;if(g.v(c)){var e={};c=c.split("\n");for(var f=0;f!=c.length;++f){var k=c[f],l=k.indexOf("=");if(!(0>=l)){var m=Number(k.substr(0,l));k=k.substr(l+1);switch(m){case 36:case 26:case 15:case 8:case 11:case 16:case 5:case 18:k="true"==k;break;case 4:case 33:case 6:case 25:case 28:case 29:case 24:case 31:case 30:case 23:case 22:case 7:case 21:case 20:k=
Number(k);break;case 19:case 3:if(g.Aa(window.decodeURIComponent))try{k=(0,window.decodeURIComponent)(k)}catch(p){throw Error("Error: URI malformed: "+k);}}e[m]=k}}e=e[0]?e:null}else e=null;if(e&&(c=new pi(e[4],e[12]),Vi.getInstance().l.matches(c)&&(c=e[29],f=e[0],g.Ma(["goog_acknowledge_monitoring","goog_get_mode","goog_update_data","goog_image_request"],f)))){Kca(a,e);m=1==hi(Vi.getInstance().Sa,"me");if("goog_get_mode"==f&&!m&&b.source){k={};Wi(k);k[0]="goog_provide_mode";k[6]=4;k[16]=!1;try{var n=
Xi(k);b.source.postMessage(n,b.origin);Al(a,n)}catch(p){Ti(406,p)}}if("goog_get_mode"==f&&!m||"goog_acknowledge_monitoring"==f)a.H=2,yl(a);if(b=e[32])a.Z=b;if(a.o.length&&4!=c){f=e[0];n=!1;c=fj.getInstance();b=a.g.g;"goog_acknowledge_monitoring"==f&&(a.A=(void 0!==e[36]?e[36]:!e[8])?2:0,nj(a));e[37]&&(f=cj(e[37]))&&(n=!0,c.B=f);if(e[38]){if(f=cj(e[38]))n=!0,c.g=f}else(0,window.isNaN)(e[30])||(0,window.isNaN)(e[31])||(c.g||(c.g=new g.Qg(0,0,0,0)),n=!0,c.g.right=c.g.left+e[30],c.g.bottom=c.g.top+e[31]);
e[9]&&(n=!0,f=cj(e[9]))&&(b=f,c.G=f);e[39]&&((e=e[39])?(e=e.split("-"),e=2==e.length?new g.ad(wb(e[0]),wb(e[1])):null):e=null,e&&(c.A=e));n&&(n=ji(),a.ew(),a.bw(),a.dw(),a.cw(),n=new dj(n,jj(),a),n.g=b,tj(a,n))}}}},118);
var b=Si(197,function(){zl(a)});
this.H=1;b();this.B=this.fc.setInterval(b,100)}else oj(this,"ib")};
g.h.qn=function(){var a={};Wi(a);a[0]="goog_stop_monitoring";Al(this,Xi(a));yl(this)};
g.h.rh=function(){var a=Vi.getInstance();return 4===a.g?!!hi(a.Sa,"cm"):hi(a.Sa,"osd")&&this.jf()?!0:!1};
g.h.bw=function(){};
g.h.ew=function(){};
g.h.cw=function(){};
g.h.dw=function(){};
g.h.jf=function(){return fj.getInstance().l};
g.wa(wl);g.h=Bl.prototype;g.h.Wi=function(a){jk(a,!1);Pca(a.re(),a.jc);a.dispose()};
g.h.Ol=function(){};
g.h.cn=function(a,b,c,d){this.g||(this.g=this.Wt());b=c?b:-1;if(null==this.g||this.B)return a=new Ck(Wh,a,b,7),a.jc=d,a;a=new Ck(Wh,a,b,7,new Ak("measurable_impression",this.g),this.Mo());a.jc=d;return a};
g.h.Mo=function(){return[new ql("viewable_impression",this.g)]};
g.h.Og=function(a){var b=fj.getInstance();switch(a.tf()){case 0:b.o=!1;(a=Uk.getInstance().g)&&qj(a.g,this);(a=wl.getInstance())&&qj(a,this);Dl();break;case 2:b.o&&b.l&&dl()}};
g.h.fg=function(a){var b=fj.getInstance();b.o&&b.l&&(b.C=a.g)};
g.h.Jf=function(){return!1};
g.h.VC=function(a,b){a.Uh=!0;switch(a.re()){case 1:Jl(this,a,b);break;case 2:this.mr(a)}this.wr(a)};
g.h.dD=function(a){Kk(a,0);return Nk(a,"start",jj())};
g.h.Di=function(a,b,c){el(cl,[a],!jj(),b);return this.cg(a,b,c)};
g.h.cg=function(a,b,c){return Nk(a,c,jj())};
g.h.YC=function(a,b){return Kl(a,"firstquartile",1,b)};
g.h.aD=function(a,b){a.wa=!0;return Kl(a,"midpoint",2,b)};
g.h.eD=function(a,b){return Kl(a,"thirdquartile",3,b)};
g.h.WC=function(a,b){var c=Kl(a,"complete",4,b);Dk(a);return c};
g.h.jz=function(a,b,c){var d=jj();if(2==a.wc&&!d){var e=ji();a.xd().G=e}el(cl,[a],!d,b);2==a.wc&&(a.wc=1);return Nk(a,c,d)};
g.h.cD=function(a,b){var c=this.Di(a,b||{},"skip");Dk(a);return c};
g.h.ZC=function(a,b){jk(a,!0);return this.Di(a,b||{},"fullscreen")};
g.h.XC=function(a,b){jk(a,!1);return this.Di(a,b||{},"exitfullscreen")};
g.h.gr=function(a,b,c){var d=a.xd(),e=ji();d.R=zk(d,e,1!=a.wc);el(cl,[a],!jj(),b);1==a.wc&&(a.wc=2);return Nk(a,c,jj())};
g.h.bD=function(a,b){el(cl,[a],!jj(),b);return a.l()};
g.h.Zo=function(a,b){el(cl,[a],!jj(),b);this.ez(a);Dk(a);return a.l()};
g.h.Yo=function(){};
g.h.mr=function(){};
g.h.ez=function(){};
g.h.Lv=function(){};
g.h.wr=function(){};
g.h.Wt=function(){};var Vca={OO:"visible",WN:"audible",tQ:"time",uQ:"timetype"},Ol={visible:function(a){return/^(100|[0-9]{1,2})$/.test(a)},
audible:function(a){return"0"==a||"1"==a},
timetype:function(a){return"mtos"==a||"tos"==a},
time:function(a){return/^(100|[0-9]{1,2})%$/.test(a)||/^([0-9])+ms$/.test(a)}};g.r(Pl,Ak);Pl.prototype.getId=function(){return this.Ga};
Pl.prototype.B=function(){return!0};
Pl.prototype.o=function(a){var b=a.xd(),c=a.B;return(0,g.rj)(this.C,function(a){if(void 0!=a.g)var d=Xca(a,b);else b:{switch(a.B){case "mtos":d=a.l?b.B.o:b.o.g;break b;case "tos":d=a.l?b.B.g:b.o.g;break b}d=0}0==d?a=!1:(a=-1!=a.o?a.o:g.t(c)&&0<c?a.A*c:-1,a=-1!=a&&d>=a);return a})};g.r(Ql,Ak);Ql.prototype.o=function(a){var b=Oj(a.xd().l,1);return Ik(a,b)};var Sl=(0,g.D)(),Ul=!1,Vl=!1,Wl=!1,Zca=[function(a){return!(!a.chrome||!a.chrome.webstore)},
function(a){return!!a.document.documentMode},
function(a){return!!a.document.fonts.ready},
function(){return Tl(0)},
function(a){return!!a.ActiveXObject},
function(a){return!!a.chrome},
function(a){return!!a.navigator.serviceWorker},
function(a){return!!a.opera},
function(a){return!!a.sidebar},
function(){return!+"\v1"},
function(){return Tl(1)},
function(a){return!a.ActiveXObject},
function(a){return"-ms-ime-align"in a.document.documentElement.style},
function(a){return"-ms-scroll-limit"in a.document.documentElement.style},
function(a){return"-webkit-font-feature-settings"in a.document.body.style},
function(){return Tl(2)},
function(a){return"ActiveXObject"in a},
function(a){return"MozAppearance"in a.document.documentElement.style},
function(a){return"_phantom"in a},
function(a){return"callPhantom"in a},
function(a){return"content"in a.document.createElement("template")},
function(a){return"getEntriesByType"in a.performance},
function(){return Tl(3)},
function(a){return"image-rendering"in a.document.body.style},
function(a){return"object-fit"in a.document.body.style},
function(a){return"open"in a.document.createElement("details")},
function(a){return"orientation"in a.screen},
function(a){return"performance"in a},
function(a){return"shape-image-threshold"in a.document.body.style},
function(){return Tl(4)},
function(a){return"srcset"in a.document.createElement("img")},
function(){return Vl},
function(){return Wl},
function(){return Tl(5)},
function(a){a=a.document.createElement("div");a.style.width="1px";a.style.width="-webkit-min-content";a.style.width="min-content";return"1px"!=a.style.width},
function(a){a=a.document.createElement("div");a.style.width="1px";a.style.width="calc(1px - 1px)";a.style.width="-webkit-calc(1px - 1px)";return"1px"!=a.style.width},
function(){var a=!1;eval('var DummyFunction1 = function(x){ "use strict"; var a = 12; b = a + x*35; }');try{(0,window.DummyFunction1)()}catch(b){a=!0}return a},
function(){var a=!1;try{(0,window.DummyFunction2)()}catch(b){a=!0}return a},
function(){return!1},
function(){return Tl(6)},
function(a){var b=a.document.createElement("canvas");b.width=b.height=1;b=b.getContext("2d");b.globalCompositeOperation="multiply";b.fillStyle="rgb(0,255,255)";b.fillRect(0,0,1,1);b.fill();b.fillStyle="rgb(255,255,0)";b.fillRect(0,0,1,1);b.fill();b=b.getImageData(0,0,1,1).data;return b[0]==b[2]&&b[1]==b[3]||Rl(a.navigator.vibrate)},
function(a){a=a.document.createElement("canvas");a.width=a.height=1;a=a.getContext("2d");a.globalCompositeOperation="multiply";a.fillStyle="rgb(0,255,255)";a.fillRect(0,0,1,1);a.fill();a.fillStyle="rgb(255,255,0)";a.fillRect(0,0,1,1);a.fill();a=a.getImageData(0,0,1,1).data;return a[0]==a[2]&&a[1]==a[3]},
function(a){a=a.document.createElement("div");return Rl(a.matches)},
function(a){a=a.document.createElement("input");a.setAttribute("type","range");return"text"!==a.type},
function(a){return a.CSS.supports("image-rendering","pixelated")},
function(a){return a.CSS.supports("object-fit","contain")},
function(){return Tl(7)},
function(a){return a.CSS.supports("object-fit","inherit")},
function(a){return a.CSS.supports("shape-image-threshold","0.9")},
function(a){return a.CSS.supports("word-break","keep-all")},
function(){return eval("1 == [for (item of [1,2,3]) item][0]")},
function(a){return Rl(a.CSS.supports)},
function(){return Rl(window.Intl.Collator)},
function(a){return Rl(a.document.createElement("dialog").show)},
function(){return Tl(8)},
function(a){return Rl(a.document.createElement("div").animate([{transform:"scale(1)",easing:"ease-in"},{transform:"scale(1.3)",easing:"ease-in"}],{duration:1300,iterations:1}).reverse)},
function(a){return Rl(a.document.createElement("div").animate)},
function(a){return Rl(a.document.documentElement.webkitRequestFullScreen)},
function(a){return Rl(a.navigator.getBattery)},
function(a){return Rl(a.navigator.permissions.query)},
function(){return!1},
function(){return Tl(9)},
function(){return Rl(window.webkitRequestAnimationFrame)},
function(a){return Rl(a.BroadcastChannel.call)},
function(a){return Rl(a.FontFace)},
function(a){return Rl(a.Gamepad)},
function(){return Tl(10)},
function(a){return Rl(a.MutationEvent)},
function(a){return Rl(a.MutationObserver)},
function(a){return Rl(a.crypto.getRandomValues)},
function(a){return Rl(a.document.body.createShadowRoot)},
function(a){return Rl(a.document.body.webkitCreateShadowRoot)},
function(a){return Rl(a.fetch)},
function(){return Tl(11)},
function(a){return Rl(a.navigator.serviceWorker.register)},
function(a){return Rl(a.navigator.webkitGetGamepads)},
function(a){return Rl(a.speechSynthesis.speak)},
function(a){return Rl(a.webkitRTCPeerConnection)},
function(a){return a.CSS.supports("--fake-var","0")},
function(){return Tl(12)},
function(a){return a.CSS.supports("cursor","grab")},
function(a){return a.CSS.supports("cursor","zoom-in")},
function(a){return a.CSS.supports("image-orientation","270deg")},
function(){return Tl(13)},
function(a){return a.CSS.supports("position","sticky")},
function(a){return void 0===a.document.createElement("style").scoped},
function(a){return a.performance.getEntriesByType("resource")instanceof Array},
function(){return"undefined"==typeof window.InstallTrigger},
function(){return"object"==typeof(new window.Intl.Collator).resolvedOptions()},
function(a){return"boolean"==typeof a.navigator.onLine},
function(){return Tl(14)},
function(a){return"undefined"==typeof a.navigator.cR},
function(a){return"number"==typeof a.performance.now()},
function(){return 0==(new window.Uint16Array(1))[0]},
function(a){return-1==a.ActiveXObject.toString().indexOf("native")},
function(a){return-1==Object.prototype.toString.call(a.HTMLElement).indexOf("Constructor")}],$ca=[function(a){a=a.document.createElement("div");
var b=null,c=["{45EA75A0-A269-11D1-B5BF-0000F8051515}","{3AF36230-A269-11D1-B5BF-0000F8051515}","{89820200-ECBD-11CF-8B85-00AA005B4383}"];try{a.style.behavior="url(#default#clientcaps)"}catch(e){}for(var d=0;d<c.length;d++){try{b=a.getComponentVersion(c[d],"componentid").replace(/,/g,".")}catch(e){}if(b)return b.split(".")[0]}return!1},
function(){return(new Date).getTimezoneOffset()},
function(a){return(a.innerWidth||a.document.documentElement.clientWidth||a.document.body.clientWidth)/(a.innerHeight||a.document.documentElement.clientHeight||a.document.body.clientHeight)},
function(a){return(a.outerWidth||a.document&&a.document.body&&a.document.body.offsetWidth)/(a.outerHeight||a.document&&a.document.body&&a.document.body.offsetHeight)},
function(a){return a.screen.availWidth/a.screen.availHeight},
function(a){return a.screen.width/a.screen.height}],ada=[function(a){return a.navigator.userAgent},
function(a){return a.navigator.platform},
function(a){return a.navigator.vendor}];g.A(Xl,aba);Xl.prototype.reset=function(){this.g[0]=1732584193;this.g[1]=4023233417;this.g[2]=2562383102;this.g[3]=271733878;this.A=this.o=0};
Xl.prototype.update=function(a,b){g.t(b)||(b=a.length);for(var c=b-this.l,d=this.B,e=this.o,f=0;f<b;){if(0==e)for(;f<=c;)Yl(this,a,f),f+=this.l;if(g.v(a))for(;f<b;){if(d[e++]=a.charCodeAt(f++),e==this.l){Yl(this,d);e=0;break}}else for(;f<b;)if(d[e++]=a[f++],e==this.l){Yl(this,d);e=0;break}}this.o=e;this.A+=b};
Xl.prototype.digest=function(){var a=Array((56>this.o?this.l:2*this.l)-this.o);a[0]=128;for(var b=1;b<a.length-8;++b)a[b]=0;var c=8*this.A;for(b=a.length-8;b<a.length;++b)a[b]=c&255,c/=256;this.update(a);a=Array(16);for(b=c=0;4>b;++b)for(var d=0;32>d;d+=8)a[c++]=this.g[b]>>>d&255;return a};g.r(Zl,tl);Zl.prototype.g=function(a){var b=tl.prototype.g.call(this,a);var c=Sl=(0,g.D)();var d=Tl(5);c=(Vl?!d:d)?c|2:c&-3;d=Tl(2);c=(Wl?!d:d)?c|8:c&-9;c={s1:(c>>>0).toString(16)};this.l||(this.l=bda());b.B=this.l;b.C=sl(a,zla,c,"h",$l("kArwaWEsTs"));b.A=sl(a,Bla,{},"h",$l("b96YPMzfnx"));b.l=sl(a,Cla,{},"h",$l("yb8Wev6QDg"));return b};am.prototype.report=function(a,b){var c=this.g(b);if(g.Aa(c)){var d={};d=(d.sv="682",d.cb="j",d.e=cda(a),d);var e=Nk(b,a,jj());g.Zb(d,e);b.vA[a]=e;d=2==b.re()?Mba(d).join("&"):this.o.g(d).g;try{return c(b.jc,d,a),0}catch(f){return 2}}else return 1};
am.prototype.g=function(){return g.y(this.l)};g.r(bm,am);bm.prototype.g=function(a){if(!a.qg)return am.prototype.g.call(this,a);var b=this.A[a.qg];if(b)return function(a,d,e){b.l(a,d,e)};
Ti(393,Error());return null};g.r(gm,Bl);g.h=gm.prototype;g.h.Ol=function(a,b){var c=this;switch(Vi.getInstance().bb){case "nis":var d=gda(this,a,b);break;case "gsv":d=fda(this,a,b);break;case "exc":d=hda(this,a);break;default:b.opt_overlayAdElement?d=void 0:b.opt_adElement?d=Rca(this,a,b.opt_adElement,b.opt_osdId):d=Rk(Sk,a)||void 0}d&&1==d.re()&&(d.ha==g.va&&(d.ha=function(a){return c.Lv(a)}),eda(this,d,b));
return d};
g.h.Lv=function(a){var b=Vi.getInstance();a.g=0;a.T=0;if("h"==a.A||"n"==a.A){if("exc"==b.bb||"nis"==b.bb)var c=g.y("ima.bridge.getVideoMetadata");else if(a.qg&&km(this)){var d=this.F[a.qg];d?c=function(a){return d.g(a)}:null!==d&&Ti("lidar::missingPlayerCallback",Error())}else c=g.y("ima.common.getVideoMetadata");
if(g.Aa(c))try{var e=c(a.jc)}catch(f){a.g|=4}else a.g|=2}else if("b"==a.A)if(b=g.y("ytads.bulleit.getVideoMetadata"),g.Aa(b))try{e=b(a.jc)}catch(f){a.g|=4}else a.g|=2;else if("ml"==a.A)if(b=g.y("ima.common.getVideoMetadata"),g.Aa(b))try{e=b(a.jc)}catch(f){a.g|=4}else a.g|=2;else a.g|=1;a.g||(g.t(e)?null===e?a.g|=16:g.Qb(e)?a.g|=32:null!=e.errorCode&&(a.T=e.errorCode,a.g|=64):a.g|=8);null!=e||(e={});Sca(e,a);bj(e.volume)&&bj(this.G)&&(e.volume*=this.G);return e};
g.h.Wt=function(){if(km(this))return new bm("ima.common.triggerExternalActivityEvent",this.o,this.F);var a=ida(this);return null!=a?new am(a,this.o):null};
g.h.Mo=function(){var a=this.g,b=Bl.prototype.Mo.call(this);b.push(new Ql(a));return b};
g.h.mr=function(a){!a.g&&a.Uh&&Il(this,a,"overlay_unmeasurable_impression")&&(a.g=!0)};
g.h.ez=function(a){a.Gz&&(a.Vg()?Il(this,a,"overlay_viewable_end_of_session_impression"):Il(this,a,"overlay_unviewable_impression"),a.Gz=!1)};
g.h.Yo=function(a){this.B&&1==a.re()&&lm(this,a)};
g.h.wr=function(a){this.B&&1==a.re()&&lm(this,a)};
g.h.cn=function(a,b,c,d){a=Bl.prototype.cn.call(this,a,b,c,d);this.C&&(b=this.H,null==a.C&&(a.C=new bca),b.g[a.jc]=a.C,a.C.B=xla);return a};
g.h.Wi=function(a){a&&1==a.re()&&this.C&&delete this.H.g[a.jc];return Bl.prototype.Wi.call(this,a)};
g.wa(gm);var im=new rl;im.B="stopped";im.g="stopped";im.o="stopped";im.C="stopped";im.A="stopped";im.l="stopped";Object.freeze(im);g.ua("Goog_AdSense_Lidar_sendVastEvent",Oi(193,nm,Ll),void 0);g.ua("Goog_AdSense_Lidar_getViewability",Si(194,function(a,b){b=void 0===b?{}:b;var c=jm(gm.getInstance(),a,b);return mm(c)}),void 0);
g.ua("Goog_AdSense_Lidar_getUrlSignalsArray",Si(195,function(){return fm()}),void 0);
g.ua("Goog_AdSense_Lidar_getUrlSignalsList",Si(196,function(){return g.qg(fm())}),void 0);var iea=(new Date).getTime();g.h=g.rm.prototype;g.h.uc=function(){tm(this);for(var a=[],b=0;b<this.g.length;b++)a.push(this.l[this.g[b]]);return a};
g.h.Hd=function(){tm(this);return this.g.concat()};
g.h.isEmpty=function(){return 0==this.Ba};
g.h.clear=function(){this.l={};this.wg=this.Ba=this.g.length=0};
g.h.remove=function(a){return sm(this.l,a)?(delete this.l[a],this.Ba--,this.wg++,this.g.length>2*this.Ba&&tm(this),!0):!1};
g.h.get=function(a,b){return sm(this.l,a)?this.l[a]:b};
g.h.set=function(a,b){sm(this.l,a)||(this.Ba++,this.g.push(a),this.wg++);this.l[a]=b};
g.h.forEach=function(a,b){for(var c=this.Hd(),d=0;d<c.length;d++){var e=c[d],f=this.get(e);a.call(b,f,e,this)}};
g.h.clone=function(){return new g.rm(this)};
g.h.ff=function(a){tm(this);var b=0,c=this.wg,d=this,e=new pk;e.next=function(){if(c!=d.wg)throw Error("The map has changed since the iterator was created");if(b>=d.g.length)throw qk;var e=d.g[b++];return a?e:d.l[e]};
return e};g.um.prototype.toString=function(){var a=[],b=this.A;b&&a.push(Bm(b,zT,!0),":");var c=this.g;if(c||"file"==b)a.push("//"),(b=this.G)&&a.push(Bm(b,zT,!0),"@"),a.push(g.jb(c).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c=this.B,null!=c&&a.push(":",String(c));if(c=this.l)this.g&&"/"!=c.charAt(0)&&a.push("/"),a.push(Bm(c,"/"==c.charAt(0)?Dla:Ela,!0));(c=this.o.toString())&&a.push("?",c);(c=this.C)&&a.push("#",Bm(c,Fla));return a.join("")};
g.um.prototype.resolve=function(a){var b=this.clone(),c=!!a.A;c?g.vm(b,a.A):c=!!a.G;c?b.G=a.G:c=!!a.g;c?g.wm(b,a.g):c=null!=a.B;var d=a.l;if(c)g.xm(b,a.B);else if(c=!!a.l){if("/"!=d.charAt(0))if(this.g&&!this.l)d="/"+d;else{var e=b.l.lastIndexOf("/");-1!=e&&(d=b.l.substr(0,e+1)+d)}e=d;if(".."==e||"."==e)d="";else if(-1!=e.indexOf("./")||-1!=e.indexOf("/.")){d=g.fb(e,"/");e=e.split("/");for(var f=[],k=0;k<e.length;){var l=e[k++];"."==l?d&&k==e.length&&f.push(""):".."==l?((1<f.length||1==f.length&&
""!=f[0])&&f.pop(),d&&k==e.length&&f.push("")):(f.push(l),d=!0)}d=f.join("/")}else d=e}c?b.l=d:c=""!==a.o.toString();c?ym(b,a.o.clone()):c=!!a.C;c&&(b.C=a.C);return b};
g.um.prototype.clone=function(){return new g.um(this)};
var zT=/[#\/\?@]/g,Ela=/[#\?:]/g,Dla=/[#\?]/g,oda=/[#\?@]/g,Fla=/#/g;g.h=g.Am.prototype;g.h.add=function(a,b){Em(this);this.l=null;a=Fm(this,a);var c=this.g.get(a);c||this.g.set(a,c=[]);c.push(b);this.Ba=this.Ba+1;return this};
g.h.remove=function(a){Em(this);a=Fm(this,a);return sm(this.g.l,a)?(this.l=null,this.Ba=this.Ba-this.g.get(a).length,this.g.remove(a)):!1};
g.h.clear=function(){this.g=this.l=null;this.Ba=0};
g.h.isEmpty=function(){Em(this);return 0==this.Ba};
g.h.forEach=function(a,b){Em(this);this.g.forEach(function(c,d){(0,g.C)(c,function(c){a.call(b,c,d,this)},this)},this)};
g.h.Hd=function(){Em(this);for(var a=this.g.uc(),b=this.g.Hd(),c=[],d=0;d<b.length;d++)for(var e=a[d],f=0;f<e.length;f++)c.push(b[d]);return c};
g.h.uc=function(a){Em(this);var b=[];if(g.v(a))Gm(this,a)&&(b=g.Sa(b,this.g.get(Fm(this,a))));else{a=this.g.uc();for(var c=0;c<a.length;c++)b=g.Sa(b,a[c])}return b};
g.h.set=function(a,b){Em(this);this.l=null;a=Fm(this,a);Gm(this,a)&&(this.Ba=this.Ba-this.g.get(a).length);this.g.set(a,[b]);this.Ba=this.Ba+1;return this};
g.h.get=function(a,b){if(!a)return b;var c=this.uc(a);return 0<c.length?String(c[0]):b};
g.h.toString=function(){if(this.l)return this.l;if(!this.g)return"";for(var a=[],b=this.g.Hd(),c=0;c<b.length;c++){var d=b[c],e=g.jb(d);d=this.uc(d);for(var f=0;f<d.length;f++){var k=e;""!==d[f]&&(k+="="+g.jb(d[f]));a.push(k)}}return this.l=a.join("&")};
g.h.clone=function(){var a=new g.Am;a.l=this.l;this.g&&(a.g=this.g.clone(),a.Ba=this.Ba);return a};var Ym={iB:5E3,jB:15E3,Js:"://secure-...imrworldwide.com/ ://cdn.imrworldwide.com/ ://aksecure.imrworldwide.com/ ://[^.]*.moatads.com ://youtube[0-9]+.moatpixel.com ://pm.adsafeprotected.com/youtube ://pm.test-adsafeprotected.com/youtube ://e[0-9]+.yt.srs.doubleverify.com www.google.com/pagead/sul www.google.com/pagead/xsul www.youtube.com/pagead/sul www.youtube.com/pagead/psul www.youtube.com/pagead/slav".split(" "),sB:/\bocr\b/,mo:0,If:{},MM:function(a,b,c){a&&(Ym.up(a)?Ym.wz(a,b):Ym.vz(a,b,c))},
up:function(a){if(g.ib(g.qb(a)))return!1;if(0<=a.indexOf("://pagead2.googlesyndication.com/pagead/gen_204?id=yt3p&sr=1&"))return!0;try{var b=new g.um(a)}catch(c){return null!=g.Ja(Ym.Js,function(b){return 0<a.search(b)})}return b.C.match(Ym.sB)?!0:null!=g.Ja(Ym.Js,function(b){return null!=a.match(b)})},
wz:function(a,b){if(a&&(a=Ym.sC(a),!g.ib(a))){var c='javascript:"<body><img src=\\""+'+a+'+"\\"></body>"';b?Ym.lv(function(b){Ym.sz(b?c:'javascript:"<body><object data=\\""+'+a+'+"\\" type=\\"text/html\\" width=1 height=1 style=\\"visibility:hidden;\\"></body>"')}):Ym.sz(c)}},
sz:function(a){var b=g.ud("IFRAME",{src:a,style:"display:none"});a=g.dd(b).body;var c=g.kg(function(){g.sf(d);g.Ad(b)},Ym.jB);
var d=hf(b,["load","error"],function(){g.kg(function(){g.w.clearTimeout(c);g.Ad(b)},Ym.iB)});
a.appendChild(b)},
lv:function(a,b){var c=Ym.If.imageLoadingEnabled;if(null!=c)a(c);else{var d=!1;c=function(b,c){delete Ym.If[c];d||(d=!0,null!=Ym.If.imageLoadingEnabled||(Ym.If.imageLoadingEnabled=b),a(b))};
b?b(c):Ym.BD(c)}},
BD:function(a){var b=new window.Image,c=""+Ym.mo++;Ym.If[c]=b;b.onload=function(){(0,window.clearTimeout)(d);a(!0,c)};
var d=(0,window.setTimeout)(function(){a(!1,c)},300);
b.src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="},
LM:function(a){if(a){var b=g.vd("OBJECT");b.data=a;b.width="1";b.height="1";b.style.visibility="hidden";var c=""+Ym.mo++;Ym.If[c]=b;b.onload=b.onerror=function(){delete Ym.If[c]};
window.document.body.appendChild(b)}},
uz:function(a){if(a){var b=new window.Image,c=""+Ym.mo++;Ym.If[c]=b;b.onload=b.onerror=function(){delete Ym.If[c]};
b.src=a}},
vz:function(a,b,c){if(a){if(c)try{if(g.w.navigator&&g.w.navigator.sendBeacon&&g.w.navigator.sendBeacon(a,""))return}catch(d){}b?Ym.lv(function(b){b?Ym.uz(a):Ym.LM(a)}):Ym.uz(a)}},
sC:function(a){a=g.zc(g.Cc(a));if("about:invalid#zClosurez"===a)return"";a=g.Mc(Oc(a));return g.jb(g.qg(a))}};g.A(g.Im,g.G);var AT=[];g.h=g.Im.prototype;g.h.fa=function(a,b,c,d){g.ya(b)||(b&&(AT[0]=b.toString()),b=AT);for(var e=0;e<b.length;e++){var f=g.jf(a,b[e],c||this.handleEvent,d||!1,this.l||this);if(!f)break;this.g[f.key]=f}return this};
g.h.km=function(a,b,c,d){return Jm(this,a,b,c,d)};
g.h.Pa=function(a,b,c,d,e){if(g.ya(b))for(var f=0;f<b.length;f++)this.Pa(a,b[f],c,d,e);else c=c||this.handleEvent,d=g.Ba(d)?!!d.capture:!!d,e=e||this.l||this,c=kf(c),d=!!d,b=g.bf(a)?a.fj(b,c,d,e):a?(a=g.mf(a))?a.fj(b,c,d,e):null:null,b&&(g.sf(b),delete this.g[b.key])};
g.h.U=function(){g.Im.Aa.U.call(this);g.Km(this)};
g.h.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented");};var qda=/(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g;g.A(Mm,g.Ze);Om.prototype.g=function(){return this.A};
Om.prototype.getPlayerType=function(){return""};
var Pm=new Om;Qm.prototype.getId=function(){return this.Ga};Rm.prototype.getId=function(){return this.Ga};var Tm=null;var zda=["*.youtu.be","*.youtube.com"],Dda="ad.doubleclick.net bid.g.doubleclick.net corp.google.com ggpht.com google.co.uk google.com googleads.g.doubleclick.net googleads4.g.doubleclick.net googleadservices.com googlesyndication.com googleusercontent.com gstatic.com gvt1.com prod.google.com pubads.g.doubleclick.net s0.2mdn.net static.doubleclick.net static.doubleclick.net surveys.g.doubleclick.net youtube.com ytimg.com".split(" "),Cda=["c.googlesyndication.com"];var Eda=function(){if(g.hu)return $m(/Firefox\/([0-9.]+)/);if(g.pd||g.uu||g.kh)return ic;if(g.Ct)return g.ec()?$m(/CriOS\/([0-9.]+)/):$m(/Chrome\/([0-9.]+)/);if(g.ry&&!g.ec())return $m(/Version\/([0-9.]+)/);if(Sx||Rx){var a=/Version\/(\S+).*Mobile\/(\S+)/.exec(g.zb);if(a)return a[1]+"."+a[2]}else if(g.Tx)return(a=$m(/Android\s+([0-9.]+)/))?a:$m(/Version\/([0-9.]+)/);return""}();var BT;
BT={dB:["BC","AD"],cB:["Before Christ","Anno Domini"],qB:"JFMAMJJASOND".split(""),yB:"JFMAMJJASOND".split(""),Ds:"January February March April May June July August September October November December".split(" "),Os:"January February March April May June July August September October November December".split(" "),Ms:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),Ps:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),Zs:"Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),Rs:"Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
Ns:"Sun Mon Tue Wed Thu Fri Sat".split(" "),Qs:"Sun Mon Tue Wed Thu Fri Sat".split(" "),EP:"SMTWTFS".split(""),zB:"SMTWTFS".split(""),vB:["Q1","Q2","Q3","Q4"],rB:["1st quarter","2nd quarter","3rd quarter","4th quarter"],ls:["AM","PM"],Ln:["EEEE, MMMM d, y","MMMM d, y","MMM d, y","M/d/yy"],Vs:["h:mm:ss a zzzz","h:mm:ss a z","h:mm:ss a","h:mm a"],ZA:["{1} 'at' {0}","{1} 'at' {0}","{1}, {0}","{1}, {0}"],Gk:6,GB:[5,6],Hk:5};g.CT=BT;g.CT=BT;g.h=g.dn.prototype;g.h.Cl=g.CT.Gk;g.h.El=g.CT.Hk;g.h.clone=function(){var a=new g.dn(this.date);a.Cl=this.Cl;a.El=this.El;return a};
g.h.getFullYear=function(){return this.date.getFullYear()};
g.h.getMonth=function(){return this.date.getMonth()};
g.h.getDate=function(){return this.date.getDate()};
g.h.getTime=function(){return this.date.getTime()};
g.h.getDay=function(){return this.date.getDay()};
g.h.getUTCFullYear=function(){return this.date.getUTCFullYear()};
g.h.getUTCMonth=function(){return this.date.getUTCMonth()};
g.h.getUTCDate=function(){return this.date.getUTCDate()};
g.h.getUTCHours=function(){return this.date.getUTCHours()};
g.h.getUTCMinutes=function(){return this.date.getUTCMinutes()};
g.h.getTimezoneOffset=function(){return this.date.getTimezoneOffset()};
g.h.set=function(a){this.date=new Date(a.getFullYear(),a.getMonth(),a.getDate())};
g.h.add=function(a){if(a.g||a.months){var b=this.getMonth()+a.months+12*a.g,c=this.getFullYear()+Math.floor(b/12);b%=12;0>b&&(b+=12);a:{switch(b){case 1:var d=0!=c%4||0==c%100&&0!=c%400?28:29;break a;case 5:case 8:case 10:case 3:d=30;break a}d=31}d=Math.min(d,this.getDate());this.date.setDate(1);this.date.setFullYear(c);this.date.setMonth(b);this.date.setDate(d)}a.days&&(a=new Date((new Date(this.getFullYear(),this.getMonth(),this.getDate(),12)).getTime()+864E5*a.days),this.date.setDate(1),this.date.setFullYear(a.getFullYear()),
this.date.setMonth(a.getMonth()),this.date.setDate(a.getDate()),cn(this,a.getDate()))};
g.h.wn=function(a){return[this.getFullYear(),g.pb(this.getMonth()+1,2),g.pb(this.getDate(),2)].join(a?"-":"")+""};
g.h.toString=function(){return this.wn()};
g.h.valueOf=function(){return this.date.valueOf()};var fn=new en;en.prototype.clear=function(){this.g=null;this.o="";this.l=null};g.wa(gn);gn.prototype.report=function(a,b,c){if(this.g||c){b=b||{};b.lid=a;b.sdkv=Fda();a=yda();g.ib(g.qb(a))||(b.e=a);b=Gda(this,b);var d=new g.um("http://pagead2.googlesyndication.com/pagead/gen_204");g.Bb(b,function(a,b){g.Cm(d,b,null!=a?"boolean"==typeof a?a?"t":"f":""+a:"")},this);
a=hn();g.vm(d,a.A);Zm(d.toString())}};
gn.prototype.isLoggingEnabled=function(){return this.g};g.A(jn,g.xf);var kn=null;g.ua("ima.bridge.getNativeViewability",function(a,b){ln();b({})},void 0);
g.ua("ima.bridge.getVideoMetadata",function(){var a=(ln(),null);return g.Aa(a)?a():{}},void 0);
g.ua("ima.bridge.triggerViewEvent",function(a,b){var c={};c.queryId=a;c.viewabilityString=b;ln().dispatchEvent(new Mm("viewable_impression",null,c))},void 0);
g.ua("ima.bridge.triggerMeasurableEvent",function(a,b){var c={};c.queryId=a;c.viewabilityString=b;ln().dispatchEvent(new Mm("measurable_impression",null,c))},void 0);
g.ua("ima.bridge.triggerExternalActivityEvent",function(a,b,c){var d={};d.queryId=a;d.viewabilityString=b;d.eventName=c;ln().dispatchEvent(new Mm("externalActivityEvent",null,d))},void 0);var DT=!1;
(function(){if(window.navigator.plugins&&window.navigator.plugins.length){var a=window.navigator.plugins["Shockwave Flash"];if(a&&(DT=!0,a.description)){mn(a.description);return}if(window.navigator.plugins["Shockwave Flash 2.0"]){DT=!0;return}}if(window.navigator.mimeTypes&&window.navigator.mimeTypes.length&&(a=window.navigator.mimeTypes["application/x-shockwave-flash"],DT=!(!a||!a.enabledPlugin))){mn(a.enabledPlugin.description);return}if("undefined"!=typeof window.ActiveXObject){try{var b=new window.ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
DT=!0;mn(b.GetVariable("$version"));return}catch(c){}try{b=new window.ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");DT=!0;return}catch(c){}try{b=new window.ActiveXObject("ShockwaveFlash.ShockwaveFlash"),DT=!0,mn(b.GetVariable("$version"))}catch(c){}}})();g.A(nn,g.xf);var on=null;nn.prototype.U=function(){this.ca.Pa(this.g,"activityMonitor",this.A);this.l=!1;this.C.clear();nn.Aa.U.call(this)};
nn.prototype.init=function(a){if(!this.l){if(this.g=a||null)this.ca.fa(this.g,"activityMonitor",this.A),qn(this);if(!(g.w.ima&&g.w.ima.video&&g.w.ima.video.client&&g.w.ima.video.client.tagged)){g.ua("ima.video.client.sdkTag",!0,void 0);var b=g.w.document;a=b.createElement("script");var c=b.location.protocol;"http:"!=c&&"https:"!=c&&(c="");a.src=c+"//s0.2mdn.net/instream/video/client.js";a.async=!0;a.type="text/javascript";b=b.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)}(a=Pm.g())||
(a=!1);a||(gm.getInstance().B=!0);this.o=(g.Aa(null),null);hm();this.l=!0}};
nn.prototype.A=function(a){var b=a.g(),c=b.queryId,d={};d.eventId=b.eventId;switch(a.l()){case "getPageSignals":qn(this);break;case "reportVastEvent":a=b.vastEvent;var e=b.osdId,f={};f.opt_fullscreen=b.isFullscreen;b.isOverlay&&(f.opt_bounds=b.overlayBounds);if(this.l)if(this.o)c=this.o(a,c,f);else{b=f||{};if(e=e?this.B.get(e):Pm.B){if(null==b.opt_fullscreen){if(null==e)f=!1;else if((gT&&!hT||ob(g.zb,"iPod"))&&null!=e.webkitDisplayingFullscreen)f=e.webkitDisplayingFullscreen;else{f=window.screen.availWidth||
window.screen.width;var k=window.screen.availHeight||window.screen.height;var l=g.Aa(e.getBoundingClientRect)&&g.Fd(g.dd(e),e)?e.getBoundingClientRect():{left:e.offsetLeft,top:e.offsetTop,width:e.offsetWidth,height:e.offsetHeight};f=0>=f-l.width&&42>=k-l.height}b.opt_fullscreen=f}null!=b.opt_adElement||(b.opt_adElement=e)}c=Ri(471,g.Ea(nm,a,c,b))||{}}else c={};d.viewabilityData=c;this.g.send("activityMonitor","viewability",d);break;case "fetchAdTagUrl":c={},c.eventId=b.eventId,e=b.osdId,d=null,Mb(b,
"isFullscreen")&&(d=b.isFullscreen),Mb(b,"loggingId")&&(a=b.loggingId,c.loggingId=a,gn.getInstance().report(43,{step:"beforeLookup",logid:a,time:(0,g.D)()},!0)),c.engagementString=Hda(this,e,d),this.g.send("activityMonitor","engagement",c)}};
g.ua("ima.common.getVideoMetadata",function(a){a=pn().C.get(a);return g.Aa(a)?a():{}},void 0);
g.ua("ima.common.triggerViewEvent",function(a,b){var c={};c.queryId=a;c.viewabilityString=b;var d=pn().g;d?d.send("activityMonitor","viewableImpression",c):pn().dispatchEvent(new Mm("viewable_impression",null,c))},void 0);
g.ua("ima.common.triggerViewabilityMeasurementUpdate",function(a,b){var c=pn().g,d={};d.queryId=a;d.viewabilityData=b;c&&c.send("activityMonitor","viewabilityMeasurement",d)},void 0);
g.ua("ima.common.triggerMeasurableEvent",function(a,b){var c={};c.queryId=a;c.viewabilityString=b;var d=pn().g;d?d.send("activityMonitor","measurableImpression",c):pn().dispatchEvent(new Mm("measurable_impression",null,c))},void 0);
g.ua("ima.common.triggerExternalActivityEvent",function(a,b,c){var d={};d.queryId=a;d.viewabilityString=b;d.eventName=c;(a=pn().g)?a.send("activityMonitor","externalActivityEvent",d):pn().dispatchEvent(new Mm("externalActivityEvent",null,d))},void 0);
pn();g.rn.prototype.g=function(a){var b=0,c=0,d=!1;a=a.split(nla);for(var e=0;e<a.length;e++){var f=a[e];g.sT.test(f)?(b++,c++):mla.test(f)?d=!0:lla.test(f)?c++:ola.test(f)&&(d=!0)}return 0==c?d?1:0:.4<b/c?-1:1};var tn={};var Gla=g.pd?wc(g.rc('javascript:""')):wc(g.rc("about:blank"));uc(Gla);var Hla=g.pd?wc(g.rc('javascript:""')):wc(g.rc("javascript:undefined"));uc(Hla);un("a","");un("a","fixedDirectionality");un("a","redesign2014q4");un("b","");un("b","redesign2014q4");un("b","forcedlinebreak");un("b","postroll");un("b","postrollforcedlinebreak");var Jda=g.pd&&Ida();g.A(g.Cn,g.xf);g.Cn.prototype.A=function(){this.Vd("begin")};
g.Cn.prototype.o=function(){this.Vd("end")};
g.Cn.prototype.Yc=function(){this.Vd("finish")};
g.Cn.prototype.Vd=function(a){this.dispatchEvent(a)};var Ila=mc(function(){if(g.pd)return g.jc("10.0");var a=g.vd("DIV"),b=g.rd?"-webkit":g.jh?"-moz":g.pd?"-ms":g.kh?"-o":null,c={transition:"opacity 1s linear"};b&&(c[b+"-transition"]="opacity 1s linear");b={style:c};if(!tT.test("div"))throw Error("Invalid tag name <div>.");if("DIV"in rla)throw Error("Tag name <div> is not allowed for SafeHtml.");c=null;var d="";if(b)for(n in b){if(!tT.test(n))throw Error('Invalid attribute name "'+n+'".');var e=b[n];if(null!=e){var f=n;var k=e;if(k instanceof pc)k=
qc(k);else if("style"==f.toLowerCase()){e=void 0;if(!g.Ba(k))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof k+" given: "+k);if(!(k instanceof Fc)){var l="";for(e in k){if(!/^[-_a-zA-Z0-9]+$/.test(e))throw Error("Name allows only [-_a-zA-Z0-9], got: "+e);var m=k[e];null!=m&&(m=g.ya(m)?(0,g.E)(m,Hc).join(" "):Hc(m),l+=e+":"+m+";")}k=l?Gc(l):pla}k instanceof Fc&&k.constructor===Fc&&k.l===Ec?e=k.g:(xa(k),e="type_error:SafeStyle");k=e}else{if(/^on/i.test(f))throw Error('Attribute "'+
f+'" requires goog.string.Const value, "'+k+'" given.');if(f.toLowerCase()in qla)if(k instanceof tc)k=uc(k);else if(k instanceof g.yc)k=g.zc(k);else if(g.v(k))k=g.Cc(k).qe();else throw Error('Attribute "'+f+'" on tag "div" requires goog.html.SafeUrl, goog.string.Const, or string, value "'+k+'" given.');}k.vf&&(k=k.qe());f=f+'="'+g.lb(String(k))+'"';d+=" "+f}}var n="<div"+d;d=void 0;null!=d?g.ya(d)||(d=[d]):d=[];!0===kla.div?n+=">":(c=Faa(d),n+=">"+g.Mc(c)+"</div>",c=c.g());(b=b&&b.dir)&&(/^(ltr|rtl|auto)$/i.test(b)?
c=0:c=null);b=Nc(n,c);g.Pc(a,g.Mc(b));return""!=lh(a.firstChild,"transition")});g.A(Dn,g.Cn);g.h=Dn.prototype;g.h.play=function(){if(1==this.g)return!1;this.A();this.Vd("play");this.startTime=(0,g.D)();this.g=1;if(Ila())return g.hh(this.l,this.H),this.C=g.kg(this.uM,void 0,this),!0;this.Gr(!1);return!1};
g.h.uM=function(){g.Bh(this.l);Kda(this.l,this.G);g.hh(this.l,this.B);this.C=g.kg((0,g.z)(this.Gr,this,!1),1E3*this.F)};
g.h.stop=function(){1==this.g&&this.Gr(!0)};
g.h.Gr=function(a){g.hh(this.l,"transition","");g.w.clearTimeout(this.C);g.hh(this.l,this.B);this.endTime=(0,g.D)();this.g=0;a?this.Vd("stop"):this.Yc();this.o()};
g.h.U=function(){this.stop();Dn.Aa.U.call(this)};
g.h.pause=function(){};g.A(g.Fn,g.G);g.h=g.Fn.prototype;g.h.start=function(){this.stop();this.o=!1;var a=Gn(this),b=Hn(this);a&&!b&&this.g.mozRequestAnimationFrame?(this.Ga=g.jf(this.g,"MozBeforePaint",this.l),this.g.mozRequestAnimationFrame(null),this.o=!0):this.Ga=a&&b?a.call(this.g,this.l):this.g.setTimeout(yaa(this.l),20)};
g.h.lj=function(){this.isActive()||this.start()};
g.h.stop=function(){if(this.isActive()){var a=Gn(this),b=Hn(this);a&&!b&&this.g.mozRequestAnimationFrame?g.sf(this.Ga):a&&b?b.call(this.g,this.Ga):this.g.clearTimeout(this.Ga)}this.Ga=null};
g.h.isActive=function(){return null!=this.Ga};
g.h.xC=function(){this.o&&this.Ga&&g.sf(this.Ga);this.Ga=null;this.B.call(this.A,(0,g.D)())};
g.h.U=function(){this.stop();g.Fn.Aa.U.call(this)};g.A(g.L,g.G);g.h=g.L.prototype;g.h.Ga=0;g.h.U=function(){g.L.Aa.U.call(this);this.stop();delete this.g;delete this.l};
g.h.start=function(a){this.stop();this.Ga=g.kg(this.o,g.t(a)?a:this.Uc)};
g.h.stop=function(){this.isActive()&&g.w.clearTimeout(this.Ga);this.Ga=0};
g.h.isActive=function(){return 0!=this.Ga};
g.h.Mu=function(){this.Ga=0;this.g&&this.g.call(this.l)};g.Jla=function(){if(g.TS){var a=/Windows NT ([0-9.]+)/;return(a=a.exec(g.zb))?a[1]:"0"}return IF?(a=/10[_.][0-9_.]+/,(a=a.exec(g.zb))?a[0].replace(/_/g,"."):"10"):g.by?(a=/Android\s+([^\);]+)(\)|;)/,(a=a.exec(g.zb))?a[1]:""):gT||hT||jla?(a=/(?:iPhone|CPU)\s+OS\s+(\S+)/,(a=a.exec(g.zb))?a[1].replace(/_/g,"."):""):""}();g.wa(g.Ln);g.Ln.prototype.g=0;g.A(g.Nn,g.xf);g.h=g.Nn.prototype;g.h.lD=g.Ln.getInstance();g.h.getId=function(){return this.Ga||(this.Ga=g.Mn(this.lD))};
g.h.ia=function(){return this.l};
g.h.Ar=function(a){if(this.H&&this.H!=a)throw Error("Method not supported");g.Nn.Aa.Ar.call(this,a)};
g.h.To=ba(0);g.h.Xi=function(){On(this,function(a){a.Qg&&a.Xi()});
this.B&&g.Km(this.B);this.Qg=!1};
g.h.U=function(){this.Qg&&this.Xi();this.B&&(this.B.dispose(),delete this.B);On(this,function(a){a.dispose()});
this.l&&g.Ad(this.l);this.H=this.l=this.C=this.G=null;g.Nn.Aa.U.call(this)};
g.h.removeChild=function(a,b){if(a){var c=g.v(a)?a:a.getId();a=this.C&&c?Tb(this.C,c)||null:null;if(c&&a){Sb(this.C,c);g.Qa(this.G,a);b&&(a.Xi(),a.l&&g.Ad(a.l));c=a;if(null==c)throw Error("Unable to set parent component");c.H=null;g.Nn.Aa.Ar.call(c,null)}}if(!a)throw Error("Child is not in parent component");return a};wc(g.rc("https://imasdk.googleapis.com/flash/sdkloader/flashinhtml.swf"));wc(g.rc("http://imasdk.googleapis.com/flash/sdkloader/flashinhtml.swf"));Qn("d");Rn("d");Sn("d");Qn("f");Rn("f");Sn("f");Qn("i");Rn("i");Sn("i");Qn("j");Rn("j");Sn("j");Sn("j");Qn("u");Rn("u");Sn("u");Qn("v");Rn("v");Sn("v");Sn("v");Qn("b");Rn("b");Sn("b");Qn("e");Rn("e");Sn("e");Qn("s");Rn("s");Sn("s");Qn("B");Rn("B");Sn("B");Qn("x");Rn("x");Sn("x");Qn("y");Rn("y");Sn("y");Sn("y");Qn("g");Rn("g");Sn("g");Qn("h");Rn("h");Sn("h");Sn("h");Qn("n");Rn("n");Sn("n");Qn("o");Rn("o");Sn("o");Sn("o");wc(g.rc("https://imasdk.googleapis.com/flash/sdkloader/flashinhtml.swf"));wc(g.rc("http://imasdk.googleapis.com/flash/sdkloader/flashinhtml.swf"));Un.prototype.g=null;g.A(Vn,Un);g.ET=new Vn;new g.rm;wc(g.rc("https://www.youtube.com/iframe_api"));var FT=[];g.ua("onYouTubeIframeAPIReady",function(){(0,g.C)(FT,function(a){a()});
Na(FT)},window);(function(){for(var a=["ms","moz","webkit","o"],b=0,c;c=a[b]&&!g.w.requestAnimationFrame;++b)g.w.requestAnimationFrame=g.w[c+"RequestAnimationFrame"],g.w.cancelAnimationFrame=g.w[c+"CancelAnimationFrame"]||g.w[c+"CancelRequestAnimationFrame"];if(!g.w.requestAnimationFrame){var d=0;g.w.requestAnimationFrame=function(a){var b=(new Date).getTime(),c=Math.max(0,16-(b-d));d=b+c;return g.w.setTimeout(function(){a(b+c)},c)};
g.w.cancelAnimationFrame||(g.w.cancelAnimationFrame=function(a){(0,window.clearTimeout)(a)})}})();
var Wn=[[],[]],Xn=0,Yn=!1,Mda=0;g.Zn.prototype.clone=function(){return new g.Zn(this.g,this.F,this.o,this.B,this.A,this.C,this.l,this.G)};g.ao.prototype.l=0;g.ao.prototype.reset=function(){this.g=this.o=this.A;this.l=0};
g.ao.prototype.getValue=function(){return this.o};g.A(g.fo,g.G);g.h=g.fo.prototype;g.h.subscribe=function(a,b,c){var d=this.l[a];d||(d=this.l[a]=[]);var e=this.Tb;this.g[e]=a;this.g[e+1]=b;this.g[e+2]=c;this.Tb=e+3;d.push(e);return e};
g.h.unsubscribe=function(a,b,c){if(a=this.l[a]){var d=this.g;if(a=g.Ja(a,function(a){return d[a+1]==b&&d[a+2]==c}))return this.Ac(a)}return!1};
g.h.Ac=function(a){var b=this.g[a];if(b){var c=this.l[b];0!=this.A?(this.o.push(a),this.g[a+1]=g.va):(c&&g.Qa(c,a),delete this.g[a],delete this.g[a+1],delete this.g[a+2])}return!!b};
g.h.P=function(a,b){var c=this.l[a];if(c){for(var d=Array(arguments.length-1),e=1,f=arguments.length;e<f;e++)d[e-1]=arguments[e];if(this.B)for(e=0;e<c.length;e++){var k=c[e];Pda(this.g[k+1],this.g[k+2],d)}else{this.A++;try{for(e=0,f=c.length;e<f;e++)k=c[e],this.g[k+1].apply(this.g[k+2],d)}finally{if(this.A--,0<this.o.length&&0==this.A)for(;c=this.o.pop();)this.Ac(c)}}return 0!=e}return!1};
g.h.clear=function(a){if(a){var b=this.l[a];b&&((0,g.C)(b,this.Ac,this),delete this.l[a])}else this.g.length=0,this.l={}};
g.h.U=function(){g.fo.Aa.U.call(this);this.clear();this.o.length=0};g.go.prototype.set=function(a,b){g.t(b)?this.g.set(a,g.qg(b)):this.g.remove(a)};
g.go.prototype.get=function(a){try{var b=this.g.get(a)}catch(c){return}if(null!==b)try{return JSON.parse(b)}catch(c){throw"Storage: Invalid value was encountered";}};
g.go.prototype.remove=function(a){this.g.remove(a)};g.A(ho,g.go);ho.prototype.set=function(a,b){ho.Aa.set.call(this,a,jo(b))};
ho.prototype.l=function(a){a=ho.Aa.get.call(this,a);if(!g.t(a)||a instanceof Object)return a;throw"Storage: Invalid value was encountered";};
ho.prototype.get=function(a){if(a=this.l(a)){if(a=a.data,!g.t(a))throw"Storage: Invalid value was encountered";}else a=void 0;return a};g.A(ko,ho);ko.prototype.set=function(a,b,c){if(b=jo(b)){if(c){if(c<(0,g.D)()){ko.prototype.remove.call(this,a);return}b.expiration=c}b.creation=(0,g.D)()}ko.Aa.set.call(this,a,b)};
ko.prototype.l=function(a,b){var c=ko.Aa.l.call(this,a);if(c)if(!b&&g.lo(c))ko.prototype.remove.call(this,a);else return c};g.A(g.mo,ko);g.A(no,Qda);no.prototype.clear=function(){var a=aca(this.ff(!0)),b=this;(0,g.C)(a,function(a){b.remove(a)})};g.A(oo,no);g.h=oo.prototype;g.h.isAvailable=function(){if(!this.g)return!1;try{return this.g.setItem("__sak","1"),this.g.removeItem("__sak"),!0}catch(a){return!1}};
g.h.set=function(a,b){try{this.g.setItem(a,b)}catch(c){if(0==this.g.length)throw"Storage mechanism: Storage disabled";throw"Storage mechanism: Quota exceeded";}};
g.h.get=function(a){a=this.g.getItem(a);if(!g.v(a)&&null!==a)throw"Storage mechanism: Invalid value was encountered";return a};
g.h.remove=function(a){this.g.removeItem(a)};
g.h.ff=function(a){var b=0,c=this.g,d=new pk;d.next=function(){if(b>=c.length)throw qk;var d=c.key(b++);if(a)return d;d=c.getItem(d);if(!g.v(d))throw"Storage mechanism: Invalid value was encountered";return d};
return d};
g.h.clear=function(){this.g.clear()};
g.h.key=function(a){return this.g.key(a)};g.A(po,oo);g.A(qo,oo);g.A(so,no);var Rda={".":".2E","!":".21","~":".7E","*":".2A","'":".27","(":".28",")":".29","%":"."},ro=null;g.h=so.prototype;g.h.isAvailable=function(){return!!this.g};
g.h.set=function(a,b){this.g.setAttribute(to(a),b);uo(this)};
g.h.get=function(a){a=this.g.getAttribute(to(a));if(!g.v(a)&&null!==a)throw"Storage mechanism: Invalid value was encountered";return a};
g.h.remove=function(a){this.g.removeAttribute(to(a));uo(this)};
g.h.ff=function(a){var b=0,c=this.g.XMLDocument.documentElement.attributes,d=new pk;d.next=function(){if(b>=c.length)throw qk;var d=c[b++];if(a)return(0,window.decodeURIComponent)(d.nodeName.replace(/\./g,"%")).substr(1);d=d.nodeValue;if(!g.v(d))throw"Storage mechanism: Invalid value was encountered";return d};
return d};
g.h.clear=function(){for(var a=this.g.XMLDocument.documentElement,b=a.attributes.length;0<b;b--)a.removeAttribute(a.attributes[b-1].nodeName);uo(this)};g.A(vo,no);vo.prototype.set=function(a,b){this.l.set(this.g+a,b)};
vo.prototype.get=function(a){return this.l.get(this.g+a)};
vo.prototype.remove=function(a){this.l.remove(this.g+a)};
vo.prototype.ff=function(a){var b=this.l.ff(!0),c=this,d=new pk;d.next=function(){for(var d=b.next();d.substr(0,c.g.length)!=c.g;)d=b.next();return a?d.substr(c.g.length):c.l.get(d)};
return d};xo.prototype.getValue=function(){return this.g};
xo.prototype.clone=function(){return new xo(this.Tb,this.g)};g.h=yo.prototype;g.h.remove=function(){var a=this.g,b=a.length,c=a[0];if(!(0>=b)){if(1==b)Na(a);else{a[0]=a.pop();a=0;b=this.g;for(var d=b.length,e=b[a];a<d>>1;){var f=2*a+1,k=2*a+2;f=k<d&&b[k].Tb<b[f].Tb?k:f;if(b[f].Tb>e.Tb)break;b[a]=b[f];a=f}b[a]=e}return c.getValue()}};
g.h.uc=function(){for(var a=this.g,b=[],c=a.length,d=0;d<c;d++)b.push(a[d].getValue());return b};
g.h.Hd=function(){for(var a=this.g,b=[],c=a.length,d=0;d<c;d++)b.push(a[d].Tb);return b};
g.h.clone=function(){return new yo(this)};
g.h.isEmpty=function(){return 0==this.g.length};
g.h.clear=function(){Na(this.g)};g.A(Ao,yo);g.h=Bo.prototype;g.h.PM=function(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];this.Dh.set(this.gw(c),[new Sda(a)])};
g.h.yu=function(a){for(var b=[],c=0;c<arguments.length;++c)b[c-0]=arguments[c];b=this.gw(b);return this.Dh.has(b)?this.Dh.get(b):void 0};
g.h.rC=function(a){for(var b=[],c=0;c<arguments.length;++c)b[c-0]=arguments[c];return(b=this.yu(b))&&b.length?b[0]:void 0};
g.h.clear=function(){this.Dh.clear()};
g.h.gw=function(a){for(var b=[],c=0;c<arguments.length;++c)b[c-0]=arguments[c];return b?b.join(","):"key"};g.A(Co,De);g.A(Do,De);g.A(Eo,De);g.A(Fo,De);g.A(Go,De);g.A(Io,De);g.A(Ko,De);g.A(Lo,De);g.A(Mo,De);var Tda=[3,6,4],Uda=[[1,2]],Vda=[1],Ho=[[1,2,3]],Jo=[[1,2,3]],Wda=[1];g.r(No,Bo);No.prototype.o=function(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];d=0;var e=this.rC(c);e&&(d=e.Ct);this.PM(d+a,c)};Po.prototype.B=function(){var a=this.l.values();a=[].concat(g.ea(a)).filter(function(a){return a.Dh.size});
a.length&&this.J.flush(a);eea(a);this.o=0;this.g.enabled&&this.g.stop()};
Po.prototype.C=function(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];this.l.has(a)||this.l.set(a,new No(a,c))};
Po.prototype.G=function(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];this.H.apply(this,[a,1].concat(g.ea(c)))};
Po.prototype.H=function(a,b,c){for(var d=[],e=2;e<arguments.length;++e)d[e-2]=arguments[e];(e=this.F.has(a)?void 0:this.l.get(a))&&e instanceof No&&(e.o(b,d),this.g.enabled||this.g.start(),this.o++,this.o>=this.A&&this.B())};Qo.prototype.set=function(a,b){b=void 0===b?!0:b;0<=a&&52>a&&0===a%1&&this.l[a]!=b&&(this.l[a]=b,this.g=-1)};
Qo.prototype.get=function(a){return!!this.l[a]};/*
 Portions of this code are from MochiKit, received by
 The Closure Authors under the MIT license. All other code is Copyright
 2005-2009 The Closure Authors. All Rights Reserved.
*/
Ro.prototype.cancel=function(a){if(this.g)this.o instanceof Ro&&this.o.cancel();else{if(this.l){var b=this.l;delete this.l;a?b.cancel(a):(b.G--,0>=b.G&&b.cancel())}this.O?this.O.call(this.L,this):this.H=!0;this.g||(a=new $o(this),Vo(this),To(this,!1,a))}};
Ro.prototype.J=function(a,b){this.F=!1;To(this,a,b)};
Ro.prototype.ll=function(a){Vo(this);To(this,!0,a)};
Ro.prototype.then=function(a,b,c){var d,e,f=new g.Pf(function(a,b){d=a;e=b});
Wo(this,d,function(a){a instanceof $o?f.cancel():e(a)});
return f.then(a,b,c)};
Mf(Ro);Ro.prototype.isError=function(a){return a instanceof Error};
g.A(Uo,Ga);Uo.prototype.message="Deferred has already fired";Uo.prototype.name="AlreadyCalledError";g.A($o,Ga);$o.prototype.message="Deferred was canceled";$o.prototype.name="CanceledError";Zo.prototype.l=function(){delete Yo[this.Ga];throw this.g;};
var Yo={};g.A(ap,De);g.A(bp,De);var gea=[2,13,14];g.qr=window.performance&&window.performance.timing&&window.performance.now?function(){return window.performance.timing.navigationStart+window.performance.now()}:function(){return(new Date).getTime()};g.cp=window.yt&&window.yt.config_||window.ytcfg&&window.ytcfg.data_||{};g.ua("yt.config_",g.cp,void 0);var hp=new function(){var a=window.document;this.g=window;this.l=a};(0,g.D)();var mp=g.t(window.XMLHttpRequest)?function(){return new window.XMLHttpRequest}:g.t(window.ActiveXObject)?function(){return new window.ActiveXObject("Microsoft.XMLHTTP")}:null;var Bp={Authorization:"AUTHORIZATION","X-Goog-Visitor-Id":"SANDBOXED_VISITOR_ID","X-YouTube-Client-Name":"INNERTUBE_CONTEXT_CLIENT_NAME","X-YouTube-Client-Version":"INNERTUBE_CONTEXT_CLIENT_VERSION","X-Youtube-Identity-Token":"ID_TOKEN","X-YouTube-Page-CL":"PAGE_CL","X-YouTube-Page-Label":"PAGE_BUILD_LABEL","X-YouTube-Variants-Checksum":"VARIANTS_CHECKSUM"},nea="app debugcss debugjs expflag force_ad_params force_viral_ad_response_params forced_experiments internalcountrycode internalipoverride absolute_experiments conditional_experiments sbb sr_bns_address".split(" "),
Hp=!1;var cu=Sx||Rx;var Xp={},uea=0;g.r(Yp,Ga);aq.prototype.then=function(a,b,c){return this.o?this.o.then(a,b,c):1===this.l&&a?(a=a.call(c,this.g),Nf(a)?a:cq(a)):2===this.l&&b?(a=b.call(c,this.g),Nf(a)?a:bq(a)):this};
aq.prototype.getValue=function(){return this.g};
Mf(aq);g.r(eq,Ga);eq.prototype.name="BiscottiError";g.r(dq,Ga);dq.prototype.name="BiscottiMissingError";var gq={format:"RAW",method:"GET",timeout:5E3,withCredentials:!0},fq=null;var oq={};var Kla,pq;Kla=0;pq=g.rd?"webkit":g.jh?"moz":g.pd?"ms":g.kh?"o":"";g.GT=g.y("ytDomDomGetNextId")||function(){return++Kla};
g.ua("ytDomDomGetNextId",g.GT,void 0);var wea={stopImmediatePropagation:1,stopPropagation:1,preventMouseEvent:1,preventManipulation:1,preventDefault:1,layerX:1,layerY:1,screenX:1,screenY:1,scale:1,rotation:1,webkitMovementX:1,webkitMovementY:1};xq.prototype.preventDefault=function(){this.event&&(this.event.returnValue=!1,this.event.preventDefault&&this.event.preventDefault())};
xq.prototype.jv=function(){return this.event?!1===this.event.returnValue:!1};
xq.prototype.stopPropagation=function(){this.event&&(this.event.cancelBubble=!0,this.event.stopPropagation&&this.event.stopPropagation())};
xq.prototype.stopImmediatePropagation=function(){this.event&&(this.event.cancelBubble=!0,this.event.stopImmediatePropagation&&this.event.stopImmediatePropagation())};var zq=g.y("ytEventsEventsListeners")||{};g.ua("ytEventsEventsListeners",zq,void 0);var Aq=g.y("ytEventsEventsCounter")||{count:0};g.ua("ytEventsEventsCounter",Aq,void 0);var Lla=mc(function(){var a=!1;try{var b=Object.defineProperty({},"passive",{get:function(){a=!0}});
window.addEventListener("test",null,b)}catch(c){}return a}),Bq=mc(function(){var a=!1;
try{var b=Object.defineProperty({},"capture",{get:function(){a=!0}});
window.addEventListener("test",null,b)}catch(c){}return a});g.A(Oq,g.G);Oq.prototype.J=function(a){g.t(a.g)||yq(a);var b=a.g;g.t(a.l)||yq(a);this.g=new g.Yc(b,a.l)};
Oq.prototype.C=function(){if(this.g){var a=g.qr();if(0!=this.A){var b=this.B,c=this.g,d=b.x-c.x;b=b.y-c.y;d=Math.sqrt(d*d+b*b)/(a-this.A);this.l[this.Ua]=.5<Math.abs((d-this.o)/this.o)?1:0;for(c=b=0;4>c;c++)b+=this.l[c]||0;3<=b&&this.G();this.o=d}this.A=a;this.B=this.g;this.Ua=(this.Ua+1)%4}};
Oq.prototype.U=function(){window.clearInterval(this.H);g.Dq(this.F)};g.r(g.Pq,g.G);g.Pq.prototype.M=function(a,b,c,d,e){c=jp((0,g.z)(c,d||this.yb));c={target:a,name:b,ll:c};var f;e&&Lla()&&(f={passive:!0});a.addEventListener(b,c.ll,f);this.L.push(c);return c};
g.Pq.prototype.Pa=function(a){for(var b=0;b<this.L.length;b++)if(this.L[b]==a){this.L.splice(b,1);a.target.removeEventListener(a.name,a.ll);break}};
g.Pq.prototype.U=function(){g.Rq(this);g.G.prototype.U.call(this)};g.A(g.N,g.G);g.N.prototype.subscribe=function(a,b,c){return this.ea()?0:this.ha.subscribe(a,b,c)};
g.N.prototype.unsubscribe=function(a,b,c){return this.ea()?!1:this.ha.unsubscribe(a,b,c)};
g.N.prototype.Ac=function(a){return this.ea()?!1:this.ha.Ac(a)};
g.N.prototype.P=function(a,b){return this.ea()?!1:this.ha.P.apply(this.ha,arguments)};g.r(g.Vq,g.N);g.h=g.Vq.prototype;g.h.cancel=function(){this.A&&(this.A=!1,this.P("dragend",0,0,null));this.l&&(this.l=!1,this.P("hoverend",0,0,null),g.Rq(this.g),Uq(this))};
g.h.Qv=function(a){g.Rq(this.g);Wq(this,Xq("move"),this.Ov);Wq(this,Xq("out"),this.Pv);Wq(this,"touchstart",this.Ip);this.o&&Wq(this,Xq("down"),this.Hp);var b=g.Eq(a);a=g.Hq(a);this.l=!0;this.P("hoverstart",a.x,a.y,b);this.P("hovermove",a.x,a.y,b)};
g.h.Ov=function(a){var b=g.Eq(a);a=g.Hq(a);if(this.B){var c=this.B;this.B=null;if(g.Gq(c)==b&&g.Zc(g.Hq(c),a))return}this.P("hovermove",a.x,a.y,b)};
g.h.Pv=function(a){var b=g.Hq(a),c=g.Gq(a);c&&g.Fd(this.C,c)?(this.B=a,this.P("hovermove",b.x,b.y,c)):(g.Rq(this.g),Uq(this),this.l=!1,this.P("hoverend",b.x,b.y,c))};
g.h.RH=function(a){this.Qv(a);this.Hp(a)};
g.h.Hp=function(a){if(!g.ta(a.button)||0==a.button){g.Rq(this.g);this.g.M(window.document,Xq("move"),this.QH);this.g.M(window.document,Xq("up"),this.SD);var b=g.Eq(a);if(g.rd)Wq(this,"dragstart",this.cC);else if(g.Iq(a),(g.Js||g.jh)&&b)a:{for(var c=b;c;){if(g.Jd(c)||"-1"===c.getAttribute("tabindex")){c.focus();break a}c=c.parentElement}window.document.activeElement.blur()}this.A=!0;a=g.Hq(a);this.P("dragstart",a.x,a.y,b);this.P("dragmove",a.x,a.y,b)}};
g.h.cC=function(a){g.Iq(a)};
g.h.QH=function(a){var b=g.Eq(a);b==window.document&&(b=null);a=g.Hq(a);this.P("hovermove",a.x,a.y,b);this.P("dragmove",a.x,a.y,b)};
g.h.SD=function(a){g.Rq(this.g);this.A=!1;var b=g.Fq(a),c=g.Eq(a);a=g.Hq(a);b&&g.Fd(this.C,b)?(Wq(this,Xq("move"),this.Ov),Wq(this,Xq("out"),this.Pv),Wq(this,Xq("down"),this.Hp),Wq(this,"touchstart",this.Ip),this.P("dragend",a.x,a.y,c)):(Uq(this),this.l=!1,this.P("dragend",a.x,a.y,c),this.P("hoverend",a.x,a.y,c))};
g.h.Ip=function(a){var b=a.changedTouches[0];b&&(g.Rq(this.g),Wq(this,"touchmove",this.bN),Wq(this,"touchend",this.Rv),Wq(this,"touchcancel",this.Rv),this.F=b.identifier,a=g.Eq(a),this.l||(this.l=!0,this.P("hoverstart",b.pageX,b.pageY,a)),this.P("hovermove",b.pageX,b.pageY,a),this.o&&(this.A=!0,this.P("dragstart",b.pageX,b.pageY,a),this.P("dragmove",b.pageX,b.pageY,a)))};
g.h.bN=function(a){var b=Yq(this,a);b&&(this.o&&g.Iq(a),a=g.Eq(a),this.P("hovermove",b.pageX,b.pageY,a),this.o&&this.P("dragmove",b.pageX,b.pageY,a))};
g.h.Rv=function(a){var b=Yq(this,a);if(b){g.Rq(this.g);Uq(this);this.l=!1;var c=g.Eq(a);this.o&&(this.G||g.Iq(a),this.A=!1,this.P("dragend",b.pageX,b.pageY,c));this.P("hoverend",b.pageX,b.pageY,c)}};
g.h.U=function(){this.o&&(g.rd&&this.C.removeAttribute("draggable"),this.C.style.touchAction="");g.Rq(this.g);g.N.prototype.U.call(this)};var zea={enablejsapi:1},Aea={};Zq.prototype.clone=function(){var a=new Zq,b;for(b in this)if(this.hasOwnProperty(b)){var c=this[b];"object"==xa(c)?a[b]=g.Wb(c):a[b]=c}return a};var as={},$r=0;var Mla=g.y("ytPubsubPubsubInstance")||new g.fo;g.fo.prototype.subscribe=g.fo.prototype.subscribe;g.fo.prototype.unsubscribeByKey=g.fo.prototype.Ac;g.fo.prototype.publish=g.fo.prototype.P;g.fo.prototype.clear=g.fo.prototype.clear;g.ua("ytPubsubPubsubInstance",Mla,void 0);g.ar=g.y("ytPubsubPubsubSubscribedKeys")||{};g.ua("ytPubsubPubsubSubscribedKeys",g.ar,void 0);g.cr=g.y("ytPubsubPubsubTopicToKeys")||{};g.ua("ytPubsubPubsubTopicToKeys",g.cr,void 0);var br=g.y("ytPubsubPubsubIsSynchronous")||{};
g.ua("ytPubsubPubsubIsSynchronous",br,void 0);var Eea=Math.pow(2,16)-1,tr=null,ur=0,Dea={log_event:"events",log_interaction:"interactions"},HT=Object.create(null);HT.log_event="GENERIC_EVENT_LOGGING";HT.log_interaction="INTERACTION_LOGGING";var Fea=new window.Set(["log_event"]),lr={},ir=0,jr=0,kr=g.y("ytLoggingTransportLogPayloadsQueue_")||{};g.ua("ytLoggingTransportLogPayloadsQueue_",kr,void 0);var sr=g.y("ytLoggingTransportTokensToCttTargetIds_")||{};g.ua("ytLoggingTransportTokensToCttTargetIds_",sr,void 0);
var pr=g.y("ytLoggingTransportDispatchedStats_")||{};g.ua("ytLoggingTransportDispatchedStats_",pr,void 0);g.ua("ytytLoggingTransportCapturedTime_",g.y("ytLoggingTransportCapturedTime_")||{},void 0);g.r(yr,Hea);yr.prototype.start=function(){var a=g.y("yt.scheduler.instance.start");a&&a()};
yr.prototype.pause=function(){var a=g.y("yt.scheduler.instance.pause");a&&a()};
g.wa(yr);yr.getInstance();var Fr={};Lr.prototype.set=function(a,b,c,d){c=c||31104E3;this.remove(a);if(this.g)try{this.g.set(a,b,(0,g.D)()+1E3*c);return}catch(f){}var e="";if(d)try{e=(0,window.escape)(g.qg(b))}catch(f){return}else e=(0,window.escape)(b);g.Jr(a,e,c,this.l)};
Lr.prototype.get=function(a,b){var c=void 0,d=!this.g;if(!d)try{c=this.g.get(a)}catch(e){d=!0}if(d&&(c=Ir.get(""+a,void 0))&&(c=(0,window.unescape)(c),b))try{c=JSON.parse(c)}catch(e){this.remove(a),c=void 0}return c};
Lr.prototype.remove=function(a){this.g&&this.g.remove(a);g.Kr(a,"/",this.l)};new Lr;Oo.prototype.flush=function(a){a=void 0===a?[]:a;if(g.lp("enable_client_streamz_web")){a=g.q(a);for(var b=a.next();!b.done;b=a.next()){var c=b.value;b=new Co;Le(b,1,c.A);for(var d=c,e=[],f=0;f<d.g.length;f++)e.push(d.g[f].mu);Le(b,3,e||[]);d=[];e=[];f=g.q(c.Dh.keys());for(var k=f.next();!k.done;k=f.next())e.push(k.value.split(","));for(f=0;f<e.length;f++){k=e[f];var l=c.l;for(var m=c.yu(k)||[],n=[],p=0;p<m.length;p++){var u=m[p];u=u&&u.Ct;var x=new Ko;switch(l){case 3:Me(x,1,Jo[0],Number(u));break;
case 2:Me(x,2,Jo[0],Number(u))}n.push(x)}l=n;for(m=0;m<l.length;m++){u=l[m];p=n=new Go;p.g||(p.g={});x=u?Qe(u):u;p.g[2]=u;Le(p,2,x);p=k;u=[];x=c;for(var B=[],F=0;F<x.g.length;F++)B.push(x.g[F].nu);x=B;for(B=0;B<x.length;B++){F=x[B];var H=p[B],Q=new Io;switch(F){case 3:Me(Q,1,Ho[0],String(H));break;case 2:Me(Q,2,Ho[0],Number(H));break;case 1:Me(Q,3,Ho[0],"true"==H)}u.push(Q)}Re(n,1,u);d.push(n)}}Re(b,4,d);d=c=new te;e=Je(b,1);null!=e&&Ae(d,1,e);e=Je(b,5);null!=e&&ye(d,5,e);e=Ne(b,Do,2);null!=e&&Be(d,
2,e,Zda);e=Ke(b,3);if(0<e.length&&null!=e)for(f=0;f<e.length;f++)Ae(d,3,e[f]);e=Ke(b,6);if(0<e.length&&null!=e)for(f=0;f<e.length;f++)ye(d,6,e[f]);e=Pe(b,Go,4);0<e.length&&Ce(d,4,e,bea);b=c;c=new window.Uint8Array(b.l+b.g.length());e=b.o;f=e.length;for(k=d=0;k<f;k++)l=e[k],c.set(l,d),d+=l.length;e=b.g.end();c.set(e,d);b.o=[c];b={serializedIncrementBatch:g.Ud(c,!1)};Nr("streamzIncremented",b)}}};var Yr=g.y("ytLoggingLatencyUsageStats_")||{};g.ua("ytLoggingLatencyUsageStats_",Yr,void 0);var Zr=0;var bs=(0,g.D)().toString();var ks=g.y("ytLoggingTimeDocumentNonce_")||ds();g.ua("ytLoggingTimeDocumentNonce_",ks,void 0);g.ua("yt.logging.screen.getRootVeType",hs,void 0);g.ua("yt.logging.screen.getCurrentCsn",g.js,void 0);g.ua("yt.logging.screen.setCurrentScreen",ls,void 0);var hO;var ns;g.ms=mc(function(){var a=new po;return a.isAvailable()?new g.mo(a):null});
ns=mc(function(){var a=new qo;return a.isAvailable()?new g.mo(a):null});var Nga={DO:1,IO:2,PAUSED:3};var GR=16/9,IT=[.25,.5,.75,1,1.25,1.5,2],Nla=IT.concat([3,4,5,6,7,8,9,10,15]);var JT={},KT=(JT["api.invalidparam"]=2,JT.auth=150,JT["drm.auth"]=150,JT["heartbeat.net"]=150,JT["heartbeat.servererror"]=150,JT["heartbeat.stop"]=150,JT["html5.unsupportedads"]=5,JT["fmt.noneavailable"]=5,JT["fmt.decode"]=5,JT["fmt.unplayable"]=5,JT["html5.missingapi"]=5,JT["html5.unsupportedlive"]=5,JT["drm.unavailable"]=5,JT);var Mea=/^https?:\/\/([^.]*\.moatads\.com\/|e[0-9]+\.yt\.srs\.doubleverify\.com|pagead2\.googlesyndication\.com\/pagead\/gen_204\?id=yt3p&sr=1&|pm\.adsafeprotected\.com\/youtube|pm\.test-adsafeprotected\.com\/youtube|youtube[0-9]+\.moatpixel\.com\/)/,Kea=/^http:\/\/0\.[a-z0-9\-_]+\.[a-z0-9\-_]+\.l2gfe\.[a-z0-9_]+\.([a-z]{2}|i)\.borg\.google\.com(:[0-9]+)?\/|^https?:\/\/((?:uytfe\.corp|dev-uytfe\.corp|uytfe\.sandbox)\.google\.com\/|([-\w]*www[-\w]*\.|[-\w]*web[-\w]*\.|[-\w]*canary[-\w]*\.|[-\w]*dev[-\w]*\.|[-\w]{1,3}\.)+youtube(education|-nocookie|kids)?\.com\/|([A-Za-z0-9-]{1,63}\.)*(youtube\.googleapis\.com)(:[0-9]+)?\/|([a-z]+\.)?[a-z0-9\-]{1,63}\.([a-z]{3}|i)\.corp\.google\.com(:[0-9]+)?\/|([a-z]+\.)?[a-z0-9\-]{1,63}\.c\.googlers\.com(:[0-9]+)?\/|(docs|drive)\.google\.com\/(a\/[^/\\%]+\/|)|[A-Za-z0-9]+(-v6)?\.prod\.google\.com(:[0-9]+)?\/|m?web-ppg\.corp\.google\.com\/|play\.google\.com\/)/,
Nea=/^https?:\/\/(www\.google\.com\/pagead\/sul|www\.google\.com\/pagead\/xsul|www\.youtube\.com\/pagead\/psul|www\.youtube\.com\/pagead\/slav|www\.youtube\.com\/pagead\/sul)/,Rea=/^https?:\/\/(([A-Za-z0-9-]{1,63}\.)*(corp\.google\.com|c\.googlers\.com|docs\.google\.com|drive\.google\.com|prod\.google\.com|plus\.google\.com|mail\.google\.com|youtube\.com|youtube\-nocookie\.com|youtubeeducation\.com|youtubekids\.com)(:[0-9]+)?\/|([A-Za-z0-9-]{1,63}\.)*(sandbox\.google\.com)(:[0-9]+)?\/(?!url\b))/,
lia=/^https?:\/\/(([A-Za-z0-9-]{1,63}\.)*(corp\.google\.com|c\.googlers\.com|borg\.google\.com|prod\.google\.com|youtube\.com)(:[0-9]+)?\/|([A-Za-z0-9-]{1,63}\.)*(sandbox\.google\.com)(:[0-9]+)?\/(?!url\b))/,Pea=/^((http(s)?):)?\/\/((((lh[3-6](-tt|-d[a-g,z])?\.((ggpht)|(googleusercontent)|(google)))|(([1-4]\.bp\.blogspot)|(bp[0-3]\.blogger))|((((cp|ci|gp)[3-6])|(ap[1-2]))\.(ggpht|googleusercontent))|(gm[1-4]\.ggpht)|(((yt[3-4])|(sp[1-3]))\.(ggpht|googleusercontent)))\.com)|(dp[3-6]\.googleusercontent\.cn)|(dp4\.googleusercontent\.com)|(photos\-image\-(dev|qa)(-auth)?\.corp\.google\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\.sandbox\.google\.com\/image)|(image\-(dev|qa)\-lighthouse(-auth)?\.sandbox\.google\.com(\/image)?))\/|^https?:\/\/(([A-Za-z0-9-]{1,63}\.)*(corp\.google\.com|c\.googlers\.com|borg\.google\.com|docs\.google\.com|drive\.google\.com|googleplex\.com|play\.google\.com|prod\.google\.com|plus\.google\.com|video\.google\.com|youtube\.com|ytimg\.com|chat\.google\.com)(:[0-9]+)?\/|([A-Za-z0-9-]{1,63}\.)*(sandbox\.google\.com)(:[0-9]+)?\/(?!url\b)|s2\.googleusercontent\.com\/s2\/favicons\?|yt[3-4]\.ggpht\.com\/)/,
Lea=/^https?.*#ocr$|^https?:\/\/(aksecure\.imrworldwide\.com\/|cdn\.imrworldwide\.com\/|secure\-..\.imrworldwide\.com\/)/,Qea=/^https?:\/\/(googleads\.g\.doubleclick\.net\/(aclk|pagead\/conversion)|www\.google\.com\/(aclk|pagead\/conversion)|www\.googleadservices\.com\/(aclk|pagead\/(aclk|conversion))|www\.youtube\.com\/pagead\/conversion)/,Oea=/^((http(s)?):)?\/\/((((lh[3-6](-tt|-d[a-g,z])?\.((ggpht)|(googleusercontent)|(google)))|(([1-4]\.bp\.blogspot)|(bp[0-3]\.blogger))|((((cp|ci|gp)[3-6])|(ap[1-2]))\.(ggpht|googleusercontent))|(gm[1-4]\.ggpht)|(((yt[3-4])|(sp[1-3]))\.(ggpht|googleusercontent)))\.com)|(dp[3-6]\.googleusercontent\.cn)|(dp4\.googleusercontent\.com)|(photos\-image\-(dev|qa)(-auth)?\.corp\.google\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\.sandbox\.google\.com\/image)|(image\-(dev|qa)\-lighthouse(-auth)?\.sandbox\.google\.com(\/image)?))\/|^https?:\/\/(([A-Za-z0-9-]{1,63}\.)*(corp\.google\.com|c\.googlers\.com|borg\.google\.com|docs\.google\.com|drive\.google\.com|googleplex\.com|googlevideo\.com|play\.google\.com|prod\.google\.com|c\.lh3\.googleusercontent\.com|plus\.google\.com|mail\.google\.com|youtube\.com|xfx7\.com|yt\.akamaized\.net|chat\.google\.com)(:[0-9]+)?\/|([A-Za-z0-9-]{1,63}\.)*(sandbox\.google\.com)(:[0-9]+)?\/(?!url\b))/,
dga=/^https?:\/\/(([A-Za-z0-9-]{1,63}\.)*(imasdk\.googleapis\.com|2mdn\.net|googlesyndication\.com|corp\.google\.com|c\.googlers\.com|borg\.google\.com|googleads\.g\.doubleclick\.net|prod\.google\.com|static\.doubleclick\.net|static\.googleadsserving\.cn|studioapi\.doubleclick\.net|youtube\.com|youtube\.googleapis\.com|youtube\-nocookie\.com|youtubeeducation\.com|youtubekids\.com|ytimg\.com)(:[0-9]+)?\/|lightbox-(demos|builder)\.appspot\.com\/|s[01](qa)?\.2mdn\.net\/ads\/richmedia\/studio\/mu\/templates\/tetris|www\.gstatic\.com\/doubleclick\/studio\/innovation\/h5\/layouts\/tetris|www\.gstatic\.com\/doubleclick\/studio\/innovation\/ytplayer)/,
cga=/^https?:\/\/(([A-Za-z0-9-]{1,63}\.)*(imasdk\.googleapis\.com|corp\.google\.com|c\.googlers\.com|borg\.google\.com|docs\.google\.com|drive\.google\.com|googleads\.g\.doubleclick\.net|googleplex\.com|play\.google\.com|prod\.google\.com|photos\.google\.com|get\.google\.com|class\.photos\.google\.com|plus\.google\.com|books\.googleusercontent\.com|blogger\.com|mail\.google\.com|play\-books\-internal\-sandbox\.googleusercontent\.com|talkgadget\.google\.com|survey\.g\.doubleclick\.net|youtube\.com|youtube\.googleapis\.com|youtube\-nocookie\.com|youtubekids\.com|vevo\.com|jamboard\.google\.com|chat\.google\.com|meet\.google\.com)(:[0-9]+)?\/|([A-Za-z0-9-]{1,63}\.)*(sandbox\.google\.com)(:[0-9]+)?\/(?!url\b)|(www\.|encrypted\.)?google\.(cat|com(\.(a[fgiru]|b[dhnorz]|c[ouy]|do|e[cgt]|fj|g[hit]|hk|jm|kh|kw|l[bcy]|m[mtxy]|n[afgip]|om|p[aeghkry]|qa|s[abglv]|t[jnrw]|ua|uy|vc|vn))?|a[cdelmstz]|c[acdfghilmnvz]|b[aefgijsty]|ee|es|d[ejkmz]|g[aefglmpry]|f[imr]|i[emoqrst]|h[nrtu]|k[giz]|je|jo|m[degklnsuvw]|l[aiktuv]|n[eloru]|p[lnst]|s[cehikmnort]|r[osuw]|us|t[dgklmnot]|ws|vg|vu|co\.(ao|bw|ck|cr|i[dln]|jp|ke|kr|ls|ma|mz|nz|th|tz|u[gkz]|ve|vi|z[amw]))\/(search|webhp)\?|lightbox-(demos|builder)\.appspot\.com\/|s0\.2mdn\.net\/instream\/html5\/native\/|s[01](qa)?\.2mdn\.net\/ads\/richmedia\/studio\/mu\/templates\/tetris|www\.gstatic\.com\/doubleclick\/studio\/innovation\/h5\/layouts\/tetris)/,
Ola=/^(https\:\/\/googleads\.g\.doubleclick\.net|https\:\/\/play\.google\.com|https\:\/\/photos\.google\.com|https\:\/\/get\.google\.com|https\:\/\/class\.photos\.google\.com|https\:\/\/plus\.google\.com|https\:\/\/mail\.google\.com|https\:\/\/talkgadget\.google\.com|https\:\/\/jamboard\.google\.com|https\:\/\/chat\.google\.com)$|^http:\/\/0\.[a-z0-9\-_]+\.[a-z0-9\-_]+\.[a-z0-9\-_]+\.([a-z]{2}|i)\.borg\.google\.com(:[0-9]+)?$|^http:\/\/[A-Za-z0-9]+(-v6)?\.prod\.google\.com(:[0-9]+)?$|^https:\/\/((staging|stream|today)\.)?meet\.google\.com$|^https:\/\/([A-Za-z0-9-]{1,63}\.)*youtube\.com$|^https:\/\/([A-Za-z0-9-]{1,63}\.)+sandbox\.google\.com$|^https:\/\/(books|play-books-internal-sandbox)\.googleusercontent\.com$|^https:\/\/(draft|www|(www\.)?daily\.alpha|(www\.)?weekly\.alpha|(www\.)?dev\.sandbox|(www\.)?autopush\.sandbox|(www\.)?restore\.sandbox)\.blogger\.com$|^https?:\/\/(((docs|m|sing|ss|sss|www)\.)?drive\.google\.com$|([A-Za-z0-9-]{1,63}\.)*corp\.google\.com(:[0-9]+)?$|([A-Za-z0-9-]{1,63}\.)*googleplex\.com(:[0-9]+)?$|(www\.|encrypted\.)google\.(cat|com(\.(a[fgiru]|b[dhnorz]|c[ouy]|do|e[cgt]|fj|g[hit]|hk|jm|kh|kw|l[bcy]|m[mtxy]|n[afgip]|om|p[aeghkry]|qa|s[abglv]|t[jnrw]|ua|uy|vc|vn))?|a[cdelmstz]|c[acdfghilmnvz]|b[aefgijsty]|ee|es|d[ejkmz]|g[aefglmpry]|f[imr]|i[emoqrst]|h[nrtu]|k[giz]|je|jo|m[degklnsuvw]|l[aiktuv]|n[eloru]|p[lnst]|s[cehikmnort]|r[osuw]|us|t[dgklmnot]|ws|vg|vu|co\.(ao|bw|ck|cr|i[dln]|jp|ke|kr|ls|ma|mz|nz|th|tz|u[gkz]|ve|vi|z[amw]))$|docs\.google\.com$|imasdk\.googleapis\.com$|lightbox-(demos|builder)\.appspot\.com$|s[01](qa)?\.2mdn\.net$|survey\.g\.doubleclick\.net$|www\.gstatic\.com$)/;var Sea=1;g.r(g.Is,g.G);g.Is.prototype.aa=function(a,b){g.ta(b)?zd(a,this.element,b):a.appendChild(this.element)};
g.Is.prototype.update=function(a){for(var b in a)this.updateValue(b,a[b])};
g.Is.prototype.updateValue=function(a,b){var c=this.Ta["{{"+a+"}}"];c&&Ls(this,c[0],c[1],b)};
g.Is.prototype.U=function(){this.g={};this.Ta={};g.Ad(this.element);g.G.prototype.U.call(this)};g.r(g.P,g.Is);g.h=g.P.prototype;g.h.jb=function(a,b){this.updateValue(b||"content",a)};
g.h.show=function(){this.da||(this.element.style.display=this.dd,this.da=!0)};
g.h.hide=function(){this.da&&(this.element.style.display="none",this.da=!1)};
g.h.Ma=function(){return this.da};
g.h.fa=function(a,b,c){return this.M(this.element,a,b,c)};
g.h.M=function(a,b,c,d){c=(0,g.z)(c,d||this);d={target:a,type:b,listener:c};this.Z.push(d);a.addEventListener(b,c);return d};
g.h.Pa=function(a){for(var b=0;b<this.Z.length;b++)if(this.Z[b]==a){a=this.Z.splice(b,1)[0];a.target.removeEventListener(a.type,a.listener);break}};
g.h.focus=function(){g.Jd(this.element);this.element.focus()};
g.h.U=function(){for(;this.Z.length;){var a=this.Z.pop();a.target.removeEventListener(a.type,a.listener)}g.Is.prototype.U.call(this)};g.r(g.Ns,g.P);g.Ns.prototype.subscribe=function(a,b,c){return this.Y.subscribe(a,b,c)};
g.Ns.prototype.unsubscribe=function(a,b,c){return this.Y.unsubscribe(a,b,c)};
g.Ns.prototype.Ac=function(a){return this.Y.Ac(a)};
g.Ns.prototype.P=function(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];return this.Y.P.apply(this.Y,[a].concat(g.ea(c)))};g.r(g.Ps,g.Ns);g.Ps.prototype.updateValue=function(a,b){g.Ns.prototype.updateValue.call(this,a,b);this.P("size-change")};var dfa={ZN:"auto",vQ:"tiny",tP:"light",mQ:"small",AP:"medium",rP:"large",YO:"hd720",UO:"hd1080",VO:"hd1440",WO:"hd2160",XO:"hd2880",dP:"highres",UNKNOWN:"unknown"};g.r(Ts,g.G);g.h=Ts.prototype;
g.h.ZE=function(a,b,c){var d=this.H[a];if(!(d||!(d=this.J[a])||c&&Ola.test(c)))throw Error('API call from an untrusted origin: "'+c+'"');var e=this.app.g;e.xg&&!this.L.has(a)&&(this.L.add(a),Ws(this,"webPlayerApiCalled",{callerUrl:e.loaderUrl,methodName:a,origin:c||void 0,playerStyle:e.playerStyle||void 0}));if(d){if(!g.R(this.app.g.experiments,"player_injection_reporting_killswitch")){c=!1;e=g.q(b);for(var f=e.next();!f.done;f=e.next())if(String(f.value).includes("javascript:")){c=!0;break}c&&g.kp(Error('Dangerous call to "'+
a+'" with ['+b+"]."))}return d.apply(this,b)}throw Error('Unknown API method: "'+a+'".');};
g.h.TE=function(){return this.F.slice()};
g.h.UE=function(){return g.Kb(this.A)};
g.h.ia=function(){return this.o};
g.h.addEventListener=function(a,b){if(g.v(b)){var c=function(){g.y(b).apply(window,arguments)};
this.C[b]=c}else c=b;this.app.ha.subscribe(a,c)};
g.h.iC=function(a,b){var c=this,d=g.v(b)?a+b:a+g.Da(b);if(!this.B[d]){var e;g.v(b)?e=function(){g.y(b).apply(window,arguments)}:e=b;
var f=function(a){e({target:c.l,data:a})};
this.B[d]=f;this.app.ha.subscribe(a,f)}};
g.h.removeEventListener=function(a,b){if(g.v(b)){var c=this.C[b];Sb(this.C,b);b=c}this.app.ha.unsubscribe(a,b)};
g.h.jC=function(a,b){var c=g.v(b)?a+b:a+g.Da(b),d=this.B[c];d&&(this.app.ha.unsubscribe(a,d),Sb(this.B,c))};
g.h.Kd=function(){return yS(this.app)};
g.h.Ab=function(a,b,c){this.g&&KS(this.app,!0,this.playerType);YS(this.app,a,b,c,this.playerType)};
g.h.ya=function(){return sS(this.app,this.playerType)};
g.h.VE=function(){var a=uS(this.app,this.playerType);return(0,window.isNaN)(a)?this.ya():a};
g.h.ec=function(){return tS(this.app,this.playerType)};
g.h.Jb=function(){return this.app.R.volume};
g.h.setVolume=function(a){Ys(this,a)};
g.h.isMuted=function(){return this.app.R.muted};
g.h.mute=function(){Zs(this)};
g.h.We=function(){$s(this)};
g.h.Kb=function(){this.g&&KS(this.app,!0,this.playerType);var a=lI(this.app);2!=a||$M(this.app)?3==a?g.$H(this.app.C).Wj("control_play"):XS(this.app,a):(a=this.app.C.A)&&sP(a,"control_play")};
g.h.Lb=function(){var a=lI(this.app);2!=a||$M(this.app)?3==a?g.$H(this.app.C).Wj("control_pause"):(a=g.W(this.app,a))&&xH(a):(a=this.app.C.A)&&sP(a,"control_pause")};
g.h.Kc=function(){var a=this.app;a.g.X&&(a.l.isFullscreen()&&!g.R(a.g.experiments,"player_external_control_on_classic_desktop")&&a.l.Ad(),a.l.P("pageTransition"));var b=a.A.getVideoData(),c=new g.Xz(a.g,{video_id:b.ypcOrigin||b.videoId,oauth_token:b.oauthToken});g.R(a.g.experiments,"html5_stopVideo_copy_thumbs_killswitch")||(c.tg=g.Wb(b.tg));LS(a,c,1);null!=a.T&&a.T.stop()};
g.h.PE=function(){};
g.h.Pb=function(){return g.W(this.app,1).pa};
g.h.be=function(a){qS(this.app,a)};
g.h.di=function(){var a=this.app.g;if(a.ga){var b=a.Cb[0];a="https://admin.youtube.com"!=b&&"https://viacon.corp.google.com"!=b||g.R(a.experiments,"web_player_admin_faster_playback_speeds_killswitch")?IT:Nla}else a=[1];return a};
g.h.Pj=function(){var a=g.W(this.app,this.playerType);if(a){var b="unknown";a.g.ua&&(b=a.g.ua.video.quality,"auto"==b&&a.l&&(a=KG(a))&&0<a.videoHeight&&(b=it(a.videoWidth,a.videoHeight)))}else b="unknown";return b};
g.h.tm=function(){};
g.h.Sp=function(){var a=g.W(this.app,this.playerType);return a?(a=(0,g.E)(rH(a),function(a){return a.quality}),a.length&&("auto"==a[0]&&a.shift(),a=a.concat(["auto"])),a):[]};
g.h.WE=function(){return this.Up()};
g.h.XE=function(){return 1};
g.h.Up=function(){return gS(this.app)};
g.h.YE=function(){return 0};
g.h.iF=function(){this.app.G.xe()};
g.h.ow=function(a){this.Vp(a?2:1)};
g.h.Vp=function(a){g.ZS(this.app,a)};
g.h.NE=function(){this.na("SUBSCRIBE")};
g.h.OE=function(){this.na("UNSUBSCRIBE")};
g.h.fi=function(a){"captions"==a&&(a=this.app.C.l)&&!a.loaded&&a.load()};
g.h.Rj=function(a){"captions"==a&&(a=this.app.C.l)&&a.loaded&&a.gN()};
g.h.eF=function(a,b,c){a=g.IS(this.app,ts(a,b,c),this.playerType);this.g&&KS(this.app,a,this.playerType)};
g.h.iw=function(a,b,c){MS(this.app,ts(a,b,c),this.playerType)};
g.h.fF=function(a,b,c){a=us(a,b,c);a=g.IS(this.app,a,this.playerType);this.g&&KS(this.app,a,this.playerType)};
g.h.RE=function(a,b,c){a=us(a,b,c);MS(this.app,a,this.playerType)};
g.h.getVideoUrl=function(){var a=this.app.g;if(a.F)return"";var b=fS(this.app),c=void 0;b.ra||(c=Math.floor(sS(this.app,1)));return a.getVideoUrl(b.videoId,this.getPlaylistId()||void 0,c)};
g.h.Oj=function(){return xS(this.app)};
g.h.lw=function(){var a=this.app.g;if(a.F)var b="";else{var c=fS(this.app).videoId;b=this.app.G.Ha();var d=this.getPlaylistId()||void 0;c="https://"+g.ly(a)+"/embed/"+c;d&&(c=g.Ig(c,{list:d}));d=!a.la("enable_responsive_embed_snippet");a.la("embed_snippet_includes_version")&&(c=g.Ig(c,{ecver:d?"1":"2"}));a=b.width;b=b.height;d?(d=g.lb(c),b='<iframe width="'+a+'" height="'+b+'" src="'+d+'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'):
(d=Math.round(360*a/b),b='<div style="position:relative;height:0;padding-bottom:'+Math.round(1E4*b/a)/100+'%"><iframe src="'+g.lb(c)+'" style="position:absolute;width:100%;height:100%;left:0" width="'+d+'" height="360" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>')}return b};
g.h.hw=function(a,b,c){return QS(this.app,a,b,c)};
g.h.nw=function(a){a:{for(var b=this.app,c=uE(b.A.H)||[],d=0;d<c.length;d++){var e=c[d];if(e.getId()==a){b.A.H.A(e);mI(b,"cuerangesremoved",[e]);a=!0;break a}}a=!1}return a};
g.h.dF=function(a,b,c,d){var e=this.app;e.oa=!1;NS(e,a,b,c,d);this.g&&KS(this.app,!0,this.playerType)};
g.h.QE=function(a,b,c,d){var e=this.app;e.oa=!0;NS(e,a,b,c,d)};
g.h.gi=function(){aS(this.app);this.g&&KS(this.app,!0,this.playerType)};
g.h.Qj=function(){PS(this.app);this.g&&KS(this.app,!0,this.playerType)};
g.h.mw=function(a){var b=this.app;!b.X||b.l.isFullscreen()&&!b.Ta?b.F&&(b.F.Te?gR(b,b.F.za(a),1):b.oa=!1,hC(b.F,a)):b.l.na("onPlaylistIndex",a);this.g&&KS(this.app,!0,this.playerType)};
g.h.setShuffle=function(a){var b=this.app.F;b&&b.setShuffle(a)};
g.h.hF=function(a){var b=this.app.F;b&&(b.loop=a)};
g.h.Ve=function(){var a=this.app.F;if(!a)return null;for(var b=[],c=0;c<a.getLength();c++){var d=a.za(c);d&&b.push(d.videoId)}return b};
g.h.kw=function(){var a=this.app.F;return a?a.Ua:-1};
g.h.getPlaylistId=function(){var a=this.app.F;return a&&a.listId?a.listId.toString():null};
g.h.md=function(a,b,c){if(!b)return null;var d=this.app.C;return"captions"==a?(a=d.l)&&a.Op(b,c):null};
g.h.Ub=function(a,b,c){return this.md(a,b,c)};
g.h.bh=function(a){var b=this.app.C;return"captions"==a?(b=b.l)&&b.yE():a?null:(a=[],b.l&&a.push("captions"),a)};
g.h.getVideoData=function(){var a={},b=g.W(this.app,this.playerType);if(b&&(b=b.getVideoData(),a.video_id=b.videoId,a.author=b.author,a.title=b.title,b.ua&&b.ua.video)){a.video_quality=b.ua.video.quality;b=b.ua.video;var c=[];32<b.fps&&c.push("hfr");mt(b)&&c.push("hdr");"bt2020"==b.primaries&&c.push("wcg");a.video_quality_features=c}(b=this.getPlaylistId())&&(a.list=b);return a};
g.h.pw=function(){TR(this.app,!0)};
g.h.aF=function(){TR(this.app,!1)};
g.h.cF=function(){var a=this.app;return!(!a.T||!a.T.Ma())};
g.h.jw=function(){a:{var a=this.app;if(a.la("web_player_mdx_ad_killswitch")||3!=lI(a)){if(!$M(a)&&(a=a.C.A)){a=a.g?a.g.T:-1;break a}a=-1}else a=g.$H(a.C).G}return a};
g.h.bF=function(a){if(a!=this.app.Ca.args.video_id)return!1;var b=(a=(a=g.W(this.app,1))?a.o:null)?a.l:null;return!!(a&&b&&g.U(a,128)&&5==KT[b.errorCode])};
g.h.jF=function(){this.app.g.C&&this.app.L.resume()};
g.h.Tp=function(){var a=this.app.C.B;return a?2==this.playerType?{}:a.Zv():{}};
g.h.Wp=function(a){if(a&&2!=this.playerType){var b=this.app.C.B;b&&b.aw(a)}};
g.h.SE=function(){this.app.dispose()};
g.h.gF=function(){var a=g.W(this.app);a&&!g.U(a.o,128)&&(a.P("internalAbandon"),AG(a),yG(a))};
g.h.P=function(a,b){for(var c=1;c<arguments.length;++c);this.app.g.sb&&("videodatachange"==a||"audiotrackchanged"==a||"resize"==a||"cardstatechange"==a)&&this.app.ha.P.apply(this.app.ha,arguments);this.app.ba.P.apply(this.app.ba,arguments)};
g.h.na=function(a,b){this.app.ha.P.apply(this.app.ha,arguments);this.app.ba.P.apply(this.app.ba,arguments)};
g.h.U=function(){if(this.o){for(var a in this.A)this.o[a]=null;this.o=null}this.B={};this.C={};g.G.prototype.U.call(this)};ct.prototype.l=function(){return this.name};
ct.prototype.getId=function(){return this.id};
ct.prototype.g=function(){return this.isDefault};
ct.prototype.toString=function(){return this.name};
ct.prototype.getName=ct.prototype.l;ct.prototype.getId=ct.prototype.getId;ct.prototype.getIsDefault=ct.prototype.g;g.dt.prototype.toString=function(){return this.languageCode+"_"+this.languageName+"_"+this.g+"_"+this.id+"_"+this.isDefault};g.h=g.et.prototype;g.h.getId=function(){return this.Ga};
g.h.Ib=function(){return this.H};
g.h.toString=function(){return this.l+": "+g.ft(this)+" - "+this.C};
g.h.Pp=ba(1);g.h.ld=function(){return!(!this.l||this.g&&!this.g.languageCode)};gt.prototype.l=function(){return this.ib};
gt.prototype.toString=function(){return this.ib.name};
gt.prototype.getLanguageInfo=gt.prototype.l;var iu={name:"width",video:!0,valid:640,gg:99999},ju={name:"height",video:!0,valid:360,gg:99999},ku={name:"framerate",video:!0,valid:30,gg:9999},lu={name:"bitrate",video:!0,valid:3E5,gg:2E9},gu={name:"eotf",video:!0,valid:"bt709",gg:"catavision"},ou={name:"channels",video:!1,valid:2,gg:99},mu={name:"cryptoblockformat",video:!0,valid:"subsample",gg:"invalidformat"},nu={name:"decode-to-texture",video:!0,valid:"false",gg:"nope"},pu={KQ:iu,ZO:ju,RO:ku,cO:lu,JO:gu,qO:ou,wO:mu,AO:nu};var Uea={0:"f",160:"h",133:"h",134:"h",135:"h",136:"h",137:"h",264:"h",266:"h",138:"h",298:"h",299:"h",304:"h",305:"h",140:"a",141:"ah",327:"sa",258:"m",380:"mac3",328:"meac3",161:"H",142:"H",143:"H",144:"H",222:"H",223:"H",145:"H",224:"H",225:"H",146:"H",226:"H",227:"H",147:"H",384:"H",376:"H",385:"H",377:"H",149:"A",261:"M",381:"MAC3",329:"MEAC3",278:"9",242:"9",243:"9",244:"9",247:"9",248:"9",271:"9",313:"9",272:"9",302:"9",303:"9",308:"9",315:"9",330:"9h",331:"9h",332:"9h",333:"9h",334:"9h",335:"9h",
336:"9h",337:"9h",171:"v",338:"so",250:"o",251:"o",194:"*",195:"*",220:"*",221:"*",196:"*",197:"*",198:"V",279:"(",280:"(",317:"(",318:"(",273:"(",274:"(",357:"(",358:"(",275:"(",359:"(",360:"(",276:"(",314:"(",277:"(",362:"(h",363:"(h",364:"(h",365:"(h",366:"(h",367:"(h",368:"(h",394:"1",395:"1",396:"1",397:"1",398:"1",399:"1",400:"1",401:"1",402:"1",386:"3",387:"w",406:"6"};var LT;LT={};g.jt=(LT.auto=0,LT.tiny=144,LT.light=144,LT.small=240,LT.medium=360,LT.large=480,LT.hd720=720,LT.hd1080=1080,LT.hd1440=1440,LT.hd2160=2160,LT.hd2880=2880,LT.highres=4320,LT);var nt="highres hd2880 hd2160 hd1440 hd1080 hd720 large medium small tiny".split(" ");pt.prototype.za=function(){return this.video};g.h=Ht.prototype;g.h.append=function(a){this.g.webkitSourceAppend(this.l,a)};
g.h.abort=function(){this.g.webkitSourceAbort(this.l)};
g.h.pN=function(){return this.g.webkitSourceState==this.g.SOURCE_CLOSED?new Wea:this.g.webkitSourceBuffered(this.l)};
g.h.rN=function(){return this.o};
g.h.vN=function(a){this.o=a;this.g.webkitSourceTimestampOffset(this.l,a)};g.h=It.prototype;g.h.addEventListener=function(a,b,c){this.g.addEventListener(a,b,c)};
g.h.removeEventListener=function(a,b,c){this.g.removeEventListener(a,b,c)};
g.h.DG=function(){return this.g.webkitMediaSourceURL};
g.h.addSourceBuffer=function(a){var b=(this.o++).toString();this.g.webkitSourceAddId(b,a);a=new Ht(this.g,b);this.sourceBuffers.push(a);return a};
g.h.removeSourceBuffer=function(a){for(var b=0;b<this.sourceBuffers.length;b++)if(a===this.sourceBuffers[b]){this.g.webkitSourceRemoveId(a.l);for(a=b+1;a<this.sourceBuffers.length;a++)this.sourceBuffers[a-1]=this.sourceBuffers[a];this.sourceBuffers.pop();break}};
g.h.sN=function(){switch(this.g.webkitSourceState){case this.g.SOURCE_CLOSED:return"closed";case this.g.SOURCE_OPEN:return"open";case this.g.SOURCE_ENDED:return"ended"}return""};
g.h.endOfStream=function(){this.g.webkitSourceEndOfStream(this.g.EOS_NO_ERROR)};
g.h.tN=function(){Na(this.sourceBuffers)};
g.h.qN=function(){return this.l};
g.h.uN=function(a){this.l=a;this.g.webkitSourceSetDuration&&this.g.webkitSourceSetDuration(a)};Jt.prototype.start=function(){return 0};
Jt.prototype.end=function(){return window.Infinity};g.h=Kt.prototype;g.h.addEventListener=function(){};
g.h.removeEventListener=function(){};
g.h.dispatchEvent=function(){return!1};
g.h.abort=function(){};
g.h.remove=function(){};
g.h.appendBuffer=function(){};g.h=St.prototype;g.h.nq=function(a,b){this.l=!b;this.supports(0)?this.g.appendBuffer(a):this.g.append(a)};
g.h.abort=function(){this.l=!1;this.g.abort()};
g.h.remove=function(a,b){this.g.remove(a,b)};
g.h.Br=function(a){this.supports(1)&&(this.g.timestampOffset=a)};
g.h.Fm=function(){return this.supports(1)?this.g.timestampOffset:0};
g.h.Nb=function(){try{return this.g.buffered}catch(a){return Lt([],[])}};
g.h.Hf=function(){return this.g.updating};
g.h.qh=function(a){this.A=a};
g.h.pf=function(){return this.A};
g.h.Rr=function(a,b){this.o&&this.o!=a&&(this.supports(4),this.g.changeType(b));this.o=a};
g.h.tp=function(){return this.l};
g.h.oq=function(){return!1};
g.h.supports=function(a){switch(a){case 1:return void 0!=this.g.timestampOffset;case 0:return!!this.g.appendBuffer;case 2:return!!this.g.remove;case 3:return!!this.g.removeEventListener;case 4:return!!this.g.changeType;default:return!1}};
g.h.addEventListener=function(a,b){this.supports(3);this.g.addEventListener(a,b)};
g.h.removeEventListener=function(a,b){this.supports(3);this.g.removeEventListener(a,b)};
g.h.ao=function(){return!this.Hf()};g.h=Tt.prototype;g.h.nq=function(a,b){this.g.Fm()!=this.o+this.l&&(this.g.supports(1),this.g.Br(this.o+this.l),this.g.g.appendWindowEnd=this.A);this.g.nq(a,b)};
g.h.abort=function(){this.g.abort()};
g.h.remove=function(a,b){this.g.remove(a-this.l,b-this.l)};
g.h.Br=function(a){this.o=a};
g.h.Fm=function(){return this.o};
g.h.Nb=function(){return Rt(this.g.Nb(),this.l,this.A)};
g.h.Hf=function(){return this.g.Hf()};
g.h.qh=function(a){this.g.qh(a)};
g.h.pf=function(){return this.g.pf()};
g.h.Rr=function(a,b){return this.g.Rr(a,b)};
g.h.supports=function(a){return this.g.supports(a)};
g.h.addEventListener=function(a,b){this.g.addEventListener(a,b)};
g.h.removeEventListener=function(a,b){this.g.removeEventListener(a,b)};
g.h.tp=function(){return this.g.tp()};
g.h.oq=function(){return!0};
g.h.ao=function(){return this.g.ao()?!(this.g.Fm()!=this.o+this.l&&this.tp()):!1};Ut.prototype.dispose=function(){if(!this.o){if(this.l)try{window.URL.revokeObjectURL(this.g)}catch(a){}this.o=!0}};
Ut.prototype.ea=function(){return this.o};g.r(Vt,g.G);Vt.prototype.G=function(){!this.ea()&&Wt(this)&&this.A&&(this.A(this),this.A=null)};
Vt.prototype.F=function(){this.dispose()};var MT={cupcake:1.5,donut:1.6,eclair:2,froyo:2.2,gingerbread:2.3,honeycomb:3,"ice cream sandwich":4,jellybean:4.1,kitkat:4.4,lollipop:5.1,marshmallow:6,nougat:7.1},NT;a:{var OT=g.zb;OT=OT.toLowerCase();if(-1!=OT.indexOf("android")){var PT=OT.match(/android\s*(\d+(\.\d+)?)[^;|)]*[;)]/);if(PT){var QT=(0,window.parseFloat)(PT[1]);if(100>QT){NT=QT;break a}}var RT=OT.match("("+g.Kb(MT).join("|")+")");NT=RT?MT[RT[0]]:0}else NT=void 0}var du=NT,Xx=0<=du;var $ea={'video/mp4; codecs="avc1.42001E, mp4a.40.2"':"maybe"},afa={"application/x-mpegURL":"maybe"},Zea={"application/x-mpegURL":"maybe"};g.h=vu.prototype;g.h.Me=function(){return this.nf};
g.h.hi=function(){return null};
g.h.Au=function(){var a=this.hi();return a?+g.up(a.g).expire:window.NaN};
g.h.ur=function(){};
g.h.getHeight=function(){return this.nf.za().height};xu.prototype.isLocked=function(){return this.o&&!!this.l&&this.l==this.g};
xu.prototype.A=function(a){return a.video?Eu(this,a.video.quality):!1};
var Pla=zu("auto","hd1080",!1,"l"),vF=zu("auto","large",!1,"l"),Bu=zu("auto","auto",!1,"p");zu("small","auto",!1,"p");g.h=g.Gu.prototype;g.h.yw=function(a){this.segments.push(a)};
g.h.Df=function(a){return(a=this.Yf(a))?a.duration:0};
g.h.Ao=function(a){return this.Df(a)};
g.h.pe=function(){return this.segments.length?this.segments[0].vb:-1};
g.h.bq=function(a){return(a=this.Yf(a))?a.ingestionTime:window.NaN};
g.h.rb=function(){return this.segments.length?this.segments[this.segments.length-1].vb:-1};
g.h.Jg=function(){var a=this.segments[this.segments.length-1];return a?a.endTime:window.NaN};
g.h.zb=function(){return this.segments[0].startTime};
g.h.Jh=function(){return this.segments.length};
g.h.zm=function(){return 0};
g.h.sf=function(a){return(a=this.dj(a))?a.vb:-1};
g.h.Ho=function(a){return(a=this.Yf(a))?a.sourceURL:""};
g.h.od=function(a){return(a=this.Yf(a))?a.startTime:0};
g.h.Nl=ba(3);g.h.Ob=function(){return 0<this.segments.length};
g.h.Yf=function(a){a=g.Za(this.segments,new Fu(a,0,0,0,""),function(a,c){return a.vb-c.vb});
return 0<=a?this.segments[a]:null};
g.h.dj=function(a){a=g.Za(this.segments,{startTime:a},function(a,c){return a.startTime-c.startTime});
return 0<=a?this.segments[a]:this.segments[Math.max(0,-a-2)]};
g.h.append=function(a){if(0!=a.length)if(a=g.Ta(a),0==this.segments.length)this.segments=a;else{var b=this.segments.length?g.Ha(this.segments).endTime:0,c=a[0].vb-this.rb();1<c&&Na(this.segments);for(c=0<c?0:-c+1;c<a.length;c++){var d=a[c];d.startTime=b;d.endTime=d.startTime+d.duration;b+=a[c].duration;this.segments.push(a[c])}}};
g.h.Du=function(){return 0};Iu.prototype.skip=function(a){this.g+=a};Ou.prototype.wl=function(a,b,c){(new window.Uint8Array(this.data.buffer,this.g,c)).set(new window.Uint8Array(a.buffer,b+a.byteOffset,c));this.g+=c};var ST={},Qla=(ST.predictStart="predictStart",ST.start="start",ST["continue"]="continue",ST.stop="stop",ST),Gha={EVENT_PREDICT_START:"predictStart",EVENT_START:"start",EVENT_CONTINUE:"continue",EVENT_STOP:"stop"};var yD=!1;g.Fv.prototype.toString=function(){return this.start+"-"+(null==this.end?"":this.end)};Sv.prototype.verify=function(a){if(this.info.Na!=this.range.length)return a.slength=this.info.Na.toString(),a.range=this.range.length.toString(),!1;if(1==this.info.g.info.containerType){if(8>this.info.Na||4==this.info.type)return!0;var b=Tv(this),c=b.getUint32(0,!1);b=b.getUint32(4,!1);a.infotype=this.info.type.toString();a.slicesize=c.toString();a.boxtype=b.toString();if(2==this.info.type)return c==this.info.Na&&1936286840==b;if(3==this.info.type&&0==this.info.o)return 1836019558==b||1936286840==
b||1937013104==b||1718909296==b||1701671783==b||1936419184==b}else if(2==this.info.g.info.containerType){if(4>this.info.Na||4==this.info.type)return!0;c=Tv(this).getUint32(0,!1);a.ebm=c.toString();if(3==this.info.type&&0==this.info.o)return 524531317==c||440786851==c}return!0};var cw={pL:function(a){a.reverse()},
ZF:function(a,b){a.splice(0,b)},
zP:function(a,b){var c=a[0];a[0]=a[b%a.length];a[b%a.length]=c}};g.ew.prototype.set=function(a,b){this.g[a]!==b&&(this.g[a]=b,this.o="")};
g.ew.prototype.get=function(a){fw(this);return this.g[a]||null};
g.ew.prototype.Ib=function(){this.o||(this.o=rfa(this));return this.o};
g.ew.prototype.clone=function(){var a=new g.ew(this.A);a.C=this.C;a.l=this.l;a.B=this.B;a.g=g.Wb(this.g);a.o=this.o;return a};
var iw=!1;nw.prototype.set=function(a,b){this.g.get(a);this.l[a]=b;this.o=""};
nw.prototype.get=function(a){return this.l[a]||this.g.get(a)};
nw.prototype.Ib=function(){this.o||(this.o=tfa(this));return this.o};g.h=Bw.prototype;g.h.Je=function(){};
g.h.Sh=function(){};
g.h.qp=function(){return!1};
g.h.hc=function(){return!!this.g&&this.index.Ob()};
g.h.Bf=function(){};
g.h.Tv=function(){return!1};
g.h.Ih=function(){};
g.h.Yg=function(){};
g.h.Yh=function(){};
g.h.rf=function(){};
g.h.Rl=function(){};
g.h.Uv=function(a){return[a]};
g.h.fn=function(a){return[a]};
g.h.Sm=function(){};
g.h.Jl=function(){};g.r(Dw,Bw);g.h=Dw.prototype;g.h.Je=function(){return!1};
g.h.Sh=function(){return!1};
g.h.Tv=function(){return this.l};
g.h.Ih=function(){if(this.l)return[];var a=new Jv(1,this,this.initRange,"getMetadataRequestInfos");return[new vw([a],this.O)]};
g.h.Yg=function(){return null};
g.h.Yh=function(a){this.Bf(a);return this.Vj(a.A?a.l+1:a.l,!1)};
g.h.rf=function(a,b){b=void 0===b?!1:b;var c=this.index.sf(a);b&&(c=Math.min(this.index.rb(),c+1));return this.Vj(c,!0)};
g.h.Rl=function(a){this.g=new window.Uint8Array(Tv(a).buffer)};
g.h.qp=function(){return!1};
g.h.Bf=function(a){return 0==a.Na?!0:this.index.rb()>a.l&&this.index.pe()<=a.l+1};
g.h.update=function(a,b,c){this.index.append(a);Hu(this.index,c);this.H=b};
g.h.hc=function(){return this.l?!0:Bw.prototype.hc.call(this)};
g.h.Vj=function(a,b){var c=this.index.Ho(a),d=this.index.od(a),e=this.index.Df(a),f;b?e=f=0:f=0<this.info.g?this.info.g*e:1E3;d=new Jv(3,this,null,"liveCreateRequestInfoForSegment",a,d,e,0,f,a==this.index.rb()&&!this.H&&0<f);return new vw([d],c)};
g.h.Jl=function(){return this.l?0:this.initRange.length};
g.h.Sm=function(){return!1};g.r(Ew,g.Gu);g.h=Ew.prototype;g.h.pe=function(){return this.l?this.segments.length?this.dj(this.zb()).vb:-1:g.Gu.prototype.pe.call(this)};
g.h.zb=function(){if(!this.l)return g.Gu.prototype.zb.call(this);if(!this.segments.length)return 0;var a=Math.max(g.Ha(this.segments).endTime-this.B,0);return 0<this.A&&this.dj(a).vb<this.A?this.Yf(this.A).startTime:a};
g.h.Jg=function(){var a=this.rb();return!this.l||!this.segments.length||a<=this.segments[this.segments.length-1].vb?g.Gu.prototype.Jg.call(this):Iw(this,a,this.segments[this.segments.length-1]).endTime};
g.h.Jh=function(){return this.l?this.segments.length?this.rb()-this.pe()+1:0:g.Gu.prototype.Jh.call(this)};
g.h.rb=function(){return Math.min(this.C,Math.max(g.Gu.prototype.rb.call(this),this.o))};
g.h.yw=function(a){var b=Fw(this,a.vb);0<=b?this.segments[b]=a:this.segments.splice(-(b+1),0,a)};
g.h.dj=function(a){if(!this.l)return g.Gu.prototype.dj.call(this,a);if(!this.segments.length)return null;var b=g.Za(this.segments,{startTime:a},function(a,b){return a.startTime-b.startTime}),c=this.segments[0<=b?b:Math.max(-(b+2),0)];
return c.startTime+c.duration>a&&c.startTime<=a?c:-1==b?Iw(this,Math.max(c.vb-Math.ceil((c.startTime-a)/this.g),0),c):Iw(this,c.vb+Math.ceil((a-c.endTime)/this.g),c)};
g.h.Yf=function(a){if(!this.l)return g.Gu.prototype.Yf.call(this,a);if(!this.segments.length)return null;var b=Fw(this,a);return 0<=b?this.segments[b]:Iw(this,a,this.segments[Math.max(-(b+2),0)])};g.r(Jw,Dw);g.h=Jw.prototype;g.h.Sh=function(){return!0};
g.h.hc=function(){return!0};
g.h.Bf=function(){return!0};
g.h.Ih=function(){return[]};
g.h.rf=function(a,b){if(g.ta(a)&&!(0,window.isFinite)(a)){var c=new Jv(3,this,null,"mlLiveGetReqInfoStubForTime",-1,void 0,this.F,void 0,this.F*this.info.g);return new vw([c],"")}return Dw.prototype.rf.call(this,a,b)};
g.h.Vj=function(a,b){if(Gw(this.index,a))return Dw.prototype.Vj.call(this,a,b);var c=this.index.od(a),d=b?0:this.F*this.info.g;c=new Jv(3,this,null,"mlLiveCreateReqInfoForSeg",a,c,void 0,void 0,d,a==this.index.rb()&&!this.H&&0<d);return new vw([c],0<=a?"sq/"+a:"")};Ow.prototype.update=function(a,b){var c=void 0;this.l&&(c=this.l);var d=new Ow,e=Array.from(a.getElementsByTagName("S"));if(e.length){var f=+Kw(a,"timescale")||1,k=(+e[0].getAttribute("t")||0)/f,l=+Kw(a,"startNumber")||0;var m=k;var n=+Kw(a,"presentationTimeOffset")||0;m=c?c.g+c.durationSecs:b?m-n/f:0;n=Date.parse(Nw(Kw(a,"yt:segmentIngestTime")))/1E3;d.o="SegmentTemplate"==a.parentNode.tagName;d.o&&(d.C=Kw(a,"media"));var p=c?l-c.vb:1;d.B=0<p?0:-p+1;e=g.q(e);for(p=e.next();!p.done;p=e.next()){p=
p.value;for(var u=+p.getAttribute("d")/f,x=(+p.getAttribute("yt:sid")||0)/f,B=+p.getAttribute("r")||0,F=0;F<=B;F++)if(c&&l<=c.vb)l++;else{var H=new wfa(l,m,u,n+x,k);d.g.push(H);var Q=H.g;H=p.getAttribute("yt:cuepointTimeOffset");var O=p.getAttribute("yt:cuepointDuration");if(H&&O){H=(0,window.parseFloat)(H);Q=(yD?+H/f:-H/f)+Q;O=(0,window.parseFloat)(O)/f;var ab=p.getAttribute("yt:cuepointContext")||null,Cb=p.getAttribute("yt:cuepointIdentifier");var de=p.getAttribute("yt:cuepointEvent");de=Qla[de]||
"unknown";H=new Ru(Q,O,ab,Cb,de,H)}else H=null;H&&d.A.push(H);l++;m+=u;k+=u;n+=u+x}}d.g.length&&(d.l=g.Ha(d.g))}this.B=d.B;this.l=d.l||this.l;Ua(this.g,d.g);Ua(this.A,d.A);this.o=d.o;this.C=d.C};g.r(Pw,Bw);g.h=Pw.prototype;g.h.Je=function(){return!1};
g.h.Sh=function(){return!1};
g.h.Ih=function(){if(this.l){var a=new Jv(1,this,null,"otfInit");return[new vw([a],this.l)]}a=new Jv(1,this,this.initRange,"otfInitInfo");var b=new Jv(2,this,this.indexRange,"otfIndexInfo");return[new vw([a,b])]};
g.h.Yg=function(){return null};
g.h.Yh=function(a){this.Bf(a);return Qw(this,a.A?a.l+1:a.l,!1)};
g.h.rf=function(a,b){b=void 0===b?!1:b;var c=this.index.sf(a);b&&(c=Math.min(this.index.rb(),c+1));return Qw(this,c,!0)};
g.h.Rl=function(a){if(1==a.info.type)this.g||(a.l&&"http://youtube.com/streaming/otf/durations/112015"==a.l.uri&&Efa(this,a.l),this.g=Uv(a));else if(g.tt(this.info)&&2==a.info.type&&!this.index.Ob()){var b=g.Yu(Tv(a),1936286840);if(b){a=[];var c=fv(b);b=c.jr.length;var d=c.Mr,e=c.jr,f=c.wk;c=this.indexRange.end+c.qu+1;for(var k=0,l=0;l<b;l++){var m=f[l]/d,n=e[l];a.push(new Fu(l,k,m,window.NaN,"range/"+c+"-"+(c+n-1)));k+=m;c+=n}this.index.append(a)}}};
g.h.Bf=function(a){return 0==a.Na?!0:this.index.rb()>a.l&&this.index.pe()<=a.l+1};
g.h.Jl=function(){return this.initRange&&this.indexRange?this.initRange.length+this.indexRange.length:0};
g.h.Sm=function(){return!1};g.h=g.Rw.prototype;g.h.zm=function(a){return this.g[a]};
g.h.od=function(a){return this.l[a]/this.A};
g.h.Nl=ba(2);g.h.bq=function(){return window.NaN};
g.h.Df=function(a){a=this.Ao(a);return 0<=a?a/this.A:-1};
g.h.Ao=function(a){return a+1<this.Ba||this.o?this.l[a+1]-this.l[a]:-1};
g.h.pe=function(){return 0};
g.h.rb=function(){return this.Ba-1};
g.h.Jg=function(){return this.o?this.l[this.Ba]/this.A:window.NaN};
g.h.zb=function(){return 0};
g.h.Jh=function(){return this.Ba};
g.h.Ho=function(){return""};
g.h.sf=function(a){a=g.Za(this.l.subarray(0,this.Ba),a*this.A);return 0<=a?a:Math.max(0,-a-2)};
g.h.Ob=function(){return 0<=this.rb()};
g.h.Du=function(a,b){if(a>=this.rb())return 0;for(var c=0,d=this.od(a)+b,e=a;e<this.rb()&&d>this.od(e);e++)c=Math.max(c,(e+1<this.Ba||this.o?this.g[e+1]-this.g[e]:-1)/this.Df(e));return c};
g.h.cap=function(a,b){Sw(this);this.o=!0;this.l[this.Ba]=b;this.g[this.Ba]=a};
var PR=!1;g.r(g.Tw,Bw);g.h=g.Tw.prototype;g.h.Ih=function(a){var b=new Jv(1,this,this.initRange,"initInfo"),c=new Jv(2,this,this.indexRange,"indexInfo"),d=[],e=[b];Lv(b,c)?e.push(c):(d.push(new vw([c])),a=0);(0,window.isNaN)(this.l)&&(a=0);b=e[e.length-1];a=Math.min(a,this.l-(b.range.end-e[0].range.start+1));0<a&&(a=Hv(b.range.end+1,a),e.push(new Jv(4,this,a,"tbdRange")));d.push(new vw(e));return d};
g.h.Rl=function(a){if(1==a.info.type){if(this.g)return;this.g=Uv(a)}else if(2==a.info.type){if(this.F||0<=this.index.rb())return;if(g.tt(this.info)){var b=this.index,c=Tv(a);a=a.info.range.start;var d=g.Yu(c,1936286840);c=fv(d);b.A=c.Mr;var e=c.eC;b.g[0]=c.qu+a+d.size;b.l[0]=e;b.o=!0;a=c.wk.length;for(d=0;d<a;d++){e=b;var f=c.jr[d],k=c.wk[d];e.Ba++;Sw(e);e.g[e.Ba]=e.g[e.Ba-1]+f;e.l[e.Ba]=e.l[e.Ba-1]+k}}else this.F=Tv(a)}if(2==this.info.containerType&&this.g&&this.F){a=new window.DataView(this.g.buffer);
b=this.index;e=this.F;c=this.indexRange.end;if(PR){d=new mv(a);a=d;d=a.g;f={Wz:1E6,Xz:1E9,duration:0,nz:0,tr:0};if(qv(a,408125543))if(f.nz=rv(a,!0),f.tr=a.o+a.g,qv(a,357149030)){for(k=pv(a);!nv(k);){var l=rv(k,!1);2807729==l?f.Wz=wv(k):2807730==l?f.Xz=wv(k):17545==l?f.duration=yv(k):xv(k)}a.g=d;a=f}else a.g=d,a=null;else a.g=d,a=null;if(null!=a){b.A=a.Xz/a.Wz;d=new mv(e);k=a.tr;e=d.g;f=[];if(qv(d,475249515)){for(l=pv(d);qv(l,187);){var m=pv(l);if(qv(m,179)){var n=wv(m);if(qv(m,183)){m=pv(m);for(var p=
k;qv(m,241);)p=wv(m)+k;f.push({tl:p,XB:n})}}}if(0<f.length&&c==f[0].tl)for(c=0;c<f.length;c++)f[c].tl+=1;d.g=e;c=f}else d.g=e,c=null;if(null!=c){c=g.q(c);for(d=c.next();!d.done;d=c.next())f=d.value,d=b,e=f.tl,f=f.XB,Sw(d),d.g[d.Ba]=e,d.l[d.Ba]=f,d.Ba++;b.cap(a.nz+a.tr,a.duration)}}}else if(a=new mv(a),qv(a,440786851)&&(xv(a),qv(a,408125543)&&(f=a,k=f.g,d=rv(f,!0),f.g=k,a=pv(a),f=a.o+a.g,qv(a,357149030)))){a=pv(a);l=1E6;m=1E9;for(k=0;!nv(a);)n=rv(a,!1),2807729==n?l=wv(a):2807730==n?m=wv(a):17545==
n?k=yv(a):xv(a);b.A=m/l;a=new mv(e);if(qv(a,475249515)){a=pv(a);e=!0;for(l=!1;qv(a,187);){m=pv(a);if(qv(m,179))if(n=wv(m),qv(m,183)){m=pv(m);for(p=f;qv(m,241);)p=wv(m)+f;m=[p,n]}else m=null;else m=null;p=m;e&&c==p[0]&&(l=!0);e=!1;l&&(p[0]+=1);m=b;n=p[0];p=p[1];Sw(m);m.g[m.Ba]=n;m.l[m.Ba]=p;m.Ba++}b.cap(d+f,k)}}this.F=null}};
g.h.Uv=function(a){for(var b=this.fn(a.info),c=[],d=a.o,e=0;e<b.length;e++){var f=Hv(b[e].range.start+b[e].o-a.info.range.start+a.range.start,b[e].Na);c.push(new Sv(b[e],a.g,f,a.A,d));d=!1}return c};
g.h.fn=function(a){for(var b=0;b<this.index.rb()&&a.range.start>=this.index.zm(b+1);)b++;return Uw(this,b,a.range.start,a.range.length).g};
g.h.Bf=function(a){return this.hc()?!0:(0,window.isNaN)(this.l)?!1:a.range.end+1<this.l};
g.h.Yg=function(a,b){this.Bf(a);if(!this.hc()){var c=Hv(a.range.end+1,b);c.end+1>this.l&&(c=new g.Fv(c.start,this.l-1));c=[new Jv(4,a.g,c,"getNextRequestInfoByLength")];return new vw(c)}4==a.type&&(c=this.fn(a),a=c[c.length-1]);c=0;var d=a.range.start+a.o+a.Na;3==a.type&&(c=a.l,d==a.range.end+1&&(c+=1));return Uw(this,c,d,b)};
g.h.Yh=function(){return null};
g.h.rf=function(a,b){var c=this.index.sf(a);b&&(c=Math.min(this.index.rb(),c+1));return Uw(this,c,this.index.zm(c),0)};
g.h.qp=function(){var a;if(a=this.hc()&&!(0,window.isNaN)(this.l))a=this.index,a=(a.o?a.g[a.Ba]:-1)!=this.l;return a};
g.h.Je=function(){return!0};
g.h.Sh=function(){return!1};
g.h.Jl=function(){return this.indexRange.length+this.initRange.length};
g.h.Sm=function(){return this.indexRange&&this.initRange&&this.initRange.end+1==this.indexRange.start?!0:!1};var TT={},Ofa=(TT["258"]=6,TT["380"]=6,TT["328"]=6,TT["261"]=6,TT["381"]=6,TT["329"]=6,TT);g.r(Xw,g.N);g.h=Xw.prototype;g.h.yf=function(){return Fb(this.g,function(a){return a.info.video?2==a.info.video.projectionType:!1})};
g.h.zf=function(){return Fb(this.g,function(a){return a.info.video?3==a.info.video.projectionType:!1})};
g.h.Oe=function(){return Fb(this.g,function(a){return a.info.video?4==a.info.video.projectionType:!1})};
g.h.Rg=function(){return Fb(this.g,function(a){return a.info.video?1==a.info.video.stereoLayout:!1})};
g.h.oM=function(a){var b=a.getElementsByTagName("Representation");if(0<a.getElementsByTagName("SegmentList").length||0<a.getElementsByTagName("SegmentTemplate").length){this.xf=this.o=!0;this.B||(this.B=new yfa);Cfa(this.B,a,this.da);this.P("refresh");for(a=0;a<b.length;a++){var c=gx(this,b[a]),d=this.isLive&&g.tt(c)&&this.ba;if(!this.g[c.id]){var e=cx(Lw(b[a],"BaseURL").textContent),f=Lw(b[a],"Initialization"),k=Kw(f,"sourceURL");f=Gv(Kw(f,"range"));d&&(k="",f=void 0);this.g[c.id]=new Dw(e,c,k,null===
f?void 0:f)}c=this.g[c.id];e=Kw(b[a],"id","AdaptationSet");e=""!=e?e:Kw(b[a],"mimetype","AdaptationSet");k=this.B;e=k.o[c.info.id]||k.l[e]||k.g||null;k=e.g;if(e.o)for(d=[],k=g.q(k),f=k.next();!f.done;f=k.next()){f=f.value;for(var l=c.info.id,m=8*c.info.g,n=f.vb,p=f.g,u=e.C.split("$$"),x=0;x<u.length;x++)u[x]=u[x].replace("$RepresentationID$",l),u[x]=u[x].replace("$Number$",n.toString()),u[x]=u[x].replace("$Bandwidth$",m.toString()),u[x]=u[x].replace("$Time$",p.toString());d.push(new Fu(f.vb,f.g,f.durationSecs,
f.l,u.join("$"),null,f.o))}else{e=g.Va(Lw(b[a],"SegmentList").getElementsByTagName("SegmentURL"),e.B);f=[];for(l=0;l<e.length;l++)f.push(Rfa(e[l],k[l],d));d=f}c.update(d,this.isLive,this.R)}Dfa(this.B);return!0}this.duration=Mw(Kw(a,"mediaPresentationDuration"));a:{for(a=0;a<b.length;a++){k=b[a];c=gx(this,k);e=Lw(k,"BaseURL");d=cx(e.textContent);f=Lw(k,"SegmentBase");k=Gv(f.attributes.indexRange.value);f=Gv(f.getElementsByTagName("Initialization")[0].attributes.range.value);e=(0,window.parseInt)(e.getAttribute(ex(this,
"contentLength")),10);c=new g.Tw(d,c,f,k,e,window.NaN);if(!c){b=!1;break a}Zw(this,c)}b=!0}return b};
g.h.EC=function(a){if(this.ea())return this;this.O=a.status;a=a.responseText;a=(new window.DOMParser).parseFromString(a,"text/xml").getElementsByTagName("MPD")[0];this.F=1E3*Mw(Kw(a,"minimumUpdatePeriod"))||window.Infinity;if(!this.T){var b;a:{if(a.attributes)for(b=0;b<a.attributes.length;b++)if("http://youtube.com/yt/2012/10/10"==a.attributes[b].value){b=a.attributes[b].name.split(":")[1];break a}b=""}this.Z=b}this.isLive=window.Infinity>this.F&&this.ga;this.R=(0,window.parseInt)(Kw(a,ex(this,"earliestMediaSequence")),
10)||0;if(b=Date.parse(Nw(Kw(a,ex(this,"mpdResponseTime")))))this.G=((0,g.D)()-b)/1E3;this.isLive&&0>=a.getElementsByTagName("SegmentTimeline").length||(0,g.em)(a.getElementsByTagName("Period"),this.oM,this);this.C=2;this.P("loaded");kx(this);return this};
g.h.GC=function(a){this.O=a.Wg.status;this.C=3;this.P("loaderror");return Uf(a.Wg)};
g.h.zw=function(){if(1!=this.C&&!this.ea()){var a=g.Ig(this.sourceUrl,{start_seq:Sfa(this).toString()});g.bg(hx(this,a),function(){})}};
g.h.resume=function(){kx(this)};
g.h.Gc=function(){var a=this.g,b=window.NaN,c;for(c in a)if(!g.wt(a[c].info.mimeType)){var d=a[c].index;d.Ob()&&((0,window.isNaN)(b)||d.Jg()<b)&&(b=d.Jg())}return b};
g.h.zb=function(){var a=this.g,b;for(b in a){var c=a[b].index;if(c.Ob())return c.zb()}return 0};
var ox=null,px=!1,$w=!0,fx={commentary:1,alternate:2,dub:3,main:4};var fga={RED:"red",IQ:"white"};var ega={JN:"adunit",BO:"detailpage",FO:"editpage",HO:"embedded",sP:"leanback",WP:"previewpage",XP:"profilepage",BQ:"unplugged"};var cy={uP:1,vP:2,wP:3};g.r(qx,g.N);qx.prototype.add=function(a,b){if(!this.Ea[a]&&(b.pl||b.ql||b.Nr)){var c=this.Ea,d=b;Object.isFrozen&&!Object.isFrozen(b)&&(d=Object.create(b),Object.freeze(d));c[a]=d;this.P("vast_info_card_add",a)}};
qx.prototype.remove=function(a){var b=this.get(a);delete this.Ea[a];return b};
qx.prototype.get=function(a){return this.Ea[a]||null};
qx.prototype.isEmpty=function(){return g.Qb(this.Ea)};vx.prototype.l=function(a,b){var c=Math.pow(this.B,a);this.o=b*(1-c)+c*this.o;this.A+=a};
vx.prototype.g=function(){return this.o/(1-Math.pow(this.B,this.A))};xx.prototype.l=function(a,b){var c=Math.min(this.o,Math.max(1,Math.round(a*this.L)));c+this.A>=this.o&&(this.C=!0);for(;c--;)this.B[this.A]=b,this.A=(this.A+1)%this.o;this.G=!0};
xx.prototype.g=function(){return this.H?(yx(this,this.F-this.H)+yx(this,this.F)+yx(this,this.F+this.H))/3:yx(this,this.F)};var $fa=/^([0-9\.]+):([0-9\.]+)$/;var Mx=g.y("ytglobal.prefsUserPrefsPrefs_")||{};g.ua("ytglobal.prefsUserPrefsPrefs_",Mx,void 0);g.h=Nx.prototype;g.h.get=function(a,b){Px(a);Ox(a);var c=void 0!==Mx[a]?Mx[a].toString():null;return null!=c?c:b?b:""};
g.h.set=function(a,b){Px(a);Ox(a);if(null==b)throw Error("ExpectedNotNull");Mx[a]=b.toString()};
g.h.remove=function(a){Px(a);Ox(a);delete Mx[a]};
g.h.save=function(){g.Jr(this.g,this.dump(),63072E3)};
g.h.clear=function(){g.Rb(Mx)};
g.h.dump=function(){var a=[],b;for(b in Mx)a.push(b+"="+(0,window.encodeURIComponent)(String(Mx[b])));return a.join("&")};
g.wa(Nx);var Qx="blogger books docs google-live play chat hangouts-meet photos-edu picasaweb gmail jamboard".split(" ");g.r(iy,g.G);iy.prototype.la=function(a){return g.R(this.experiments,a)};
iy.prototype.Lf=function(a){this.ha=Jx(this.ha,a.video_id);this.Ta=Jx(this.Ta,a.eventid);for(var b in UT){var c=UT[b],d=a[c];void 0!=d&&(this.l[c]=d)}this.userAge=Ix(this.userAge,a.user_age);this.O=Jx(this.O,a.user_display_image);g.Bs(this.O)||(this.O="");this.userDisplayName=Jx(this.userDisplayName,a.user_display_name);this.userGender=Jx(this.userGender,a.user_gender);this.csiPageType=Jx(this.csiPageType,a.csi_page_type);this.Va=Jx(this.Va,a.csi_service_name);this.zc=T(this.zc,a.enablecsi);if(b=
a.enabled_engage_types)this.nb=new window.Set(b.split(","));this.isDni=T(!1,a.is_dni)};
iy.prototype.getVideoUrl=function(a,b,c,d,e){b={list:b};c&&(e?b.time_continue=c:b.t=c);c=g.ly(this);d&&"www.youtube.com"==c?d="https://youtu.be/"+a:g.hy(this)?(d="https://"+c+"/fire",b.v=a):(d=this.protocol+"://"+c+"/watch",b.v=a,cu&&(a=fp())&&(b.ebc=a));return g.Ig(d,b)};
var UT={dO:"cbrand",eO:"cbr",fO:"cbrver",jP:"c",mP:"cver",lP:"ctheme",kP:"cplayer",BP:"cmodel",FP:"cnetwork",KP:"cos",LP:"cosver",RP:"cplatform"};var VT={},My=(VT.playready=["com.youtube.playready","com.microsoft.playready"],VT.widevine=["com.widevine.alpha"],VT);Dy.prototype.getAvailableAudioTracks=function(){return this.audioTracks};g.r(Ly,g.G);Ly.prototype.G=function(){(this.F=!this.F&&"widevine"==this.l[this.g[0]].flavor)||this.g.shift();Ny(this)};
Ly.prototype.H=function(a,b){this.ea()||(a.l=b,oga(this,a),this.o.push(a),g.R(this.B,"html5_drm_fallback_to_playready_on_retry")?(this.g.shift(),Ny(this)):this.C(this.o))};g.r(Ty,vu);Ty.prototype.Au=function(){return this.o};
Ty.prototype.hi=function(){if(!this.g||this.g.ea()){var a=this.l;uga(a);var b=["#EXTM3U","#EXT-X-INDEPENDENT-SEGMENTS"],c={};a:if(a.l)var d=a.l;else{d=g.q(a.o);for(var e=d.next();!e.done;e=d.next())if(e=e.value,e.ib&&e.ib.isDefault){d=e.ib.getId();break a}d=""}e=0;for(var f=a.o.length;e<f;++e){var k=a.o[e];k.ib&&k.ib.getId()!=d||(c[k.itag]=k,b.push(tga(a,k)))}d=0;for(e=a.g.length;d<e;++d)if(f=a.g[d],a.C)for(var l in c)Sy(a,b,f,c[l]);else Sy(a,b,f,c[f.audioItag]);a="data:application/x-mpegurl;charset=utf-8,"+
(0,window.encodeURIComponent)(b.join("\n"));this.g=new Ut(a)}return this.g};g.r(Vy,vu);Vy.prototype.hi=function(){return new Ut(this.g.Ib())};
Vy.prototype.ur=function(){this.g=jw(this.g)};g.r(Xy,vu);Xy.prototype.hi=function(){return new Ut(this.g)};var yga=new window.Set("BASE_URL BASE_YT_URL abd adformat allow_embed authuser autoplay captions_load_policy cc_load_policy cc3_module dash dashmpd disable_native_context_menu docid el enable_cardio enablecastapi enablepostapi end errorcode fmt_list fmt_stream_map forcenewui hl hlsdvr hlsrange hlsvp html5 invite iurl iurlhq iurlmq length_seconds live_playback nohtml5 origin override_hl partnerid playsinline plid postid ps public reason rel reload_count reload_reason reportabuseurl resume start status streaminglib_load_policy streaminglib_preroll t timestamp title token ttsurl use_native_controls url_encoded_fmt_stream_map video_id videoid videoId wmode".split(" "));var Rla={UNKNOWN:"UNKNOWN",NORMAL:"NORMAL",xP:"LOW",AQ:"ULTRALOW"};g.h=g.Zy.prototype;g.h.getHeight=function(){return this.B};
g.h.Bu=ba(4);g.h.Eo=function(){return this.o};
g.h.isDefault=function(){return-1!=this.A.indexOf("default")};
g.h.Ob=function(a){return this.Te.has(a)};
g.h.Ib=function(a){var b=this.J;b=b.replace("$N",this.A);b=b.replace("$L",this.H.toString());b=b.replace("$M",a.toString());this.F&&(b=g.Ig(b,{sigh:this.F}));return Fs(b)};
g.h.Im=function(a){var b=this.Eo()-1;return g.Uc(0==this.g?Math.round(a*this.o/this.L):Math.round(1E3*a/this.g),0,b)};
g.h.ak=function(){return this.o-1};
g.h.uq=function(){return this.o?0:-1};
g.h.Ez=function(){};g.r(az,g.N);az.prototype.H=function(a,b){this.l=this.l.onload=null;var c=this.g[a];c.Te.add(b);dz(this);var d=c.columns*c.rows;var e=b*d;c=Math.min(e+d-1,c.Eo()-1);e=[e,c];this.P("l",e[0],e[1])};
az.prototype.U=function(){this.l&&(this.l=this.l.onload=null);g.N.prototype.U.call(this)};g.r(fz,az);fz.prototype.o=function(a,b){for(var c=[],d=a.split("|"),e=d[0],f=1;f<d.length;f++){var k=this.C(f-1,e,d[f],b);180>k.getHeight()&&c.push(k)}return c};
fz.prototype.C=function(a,b,c,d){return new g.Zy(a,b,c,d)};g.r(hz,g.Zy);g.h=hz.prototype;g.h.Eo=function(){return this.l.Jh()};
g.h.Im=function(a){var b=this.rows*this.columns*this.G,c=this.l,d=c.rb();a=c.sf(a);return a>d-b?-1:a};
g.h.ak=function(){return this.l.rb()};
g.h.uq=function(){return this.l.pe()};
g.h.Ez=function(a){this.l=a};g.r(iz,fz);iz.prototype.o=function(a,b){return fz.prototype.o.call(this,"$N|"+a,b)};
iz.prototype.C=function(a,b,c){return new hz(a,b,c,this.isLive)};var jz={iurl:"default.jpg",iurlmq:"mqdefault.jpg",iurlhq:"hqdefault.jpg",iurlsd:"sddefault.jpg",iurlpop1:"pop1.jpg",iurlpop2:"pop2.jpg",iurlhq720:"hq720.jpg",iurlmaxres:"maxresdefault.jpg"};g.mz.prototype.toString=function(){return this.topic};var Sla=g.y("ytPubsub2Pubsub2Instance")||new g.fo;g.fo.prototype.subscribe=g.fo.prototype.subscribe;g.fo.prototype.unsubscribeByKey=g.fo.prototype.Ac;g.fo.prototype.publish=g.fo.prototype.P;g.fo.prototype.clear=g.fo.prototype.clear;g.ua("ytPubsub2Pubsub2Instance",Sla,void 0);var pz=g.y("ytPubsub2Pubsub2SubscribedKeys")||{};g.ua("ytPubsub2Pubsub2SubscribedKeys",pz,void 0);var rz=g.y("ytPubsub2Pubsub2TopicToKeys")||{};g.ua("ytPubsub2Pubsub2TopicToKeys",rz,void 0);
var qz=g.y("ytPubsub2Pubsub2IsAsync")||{};g.ua("ytPubsub2Pubsub2IsAsync",qz,void 0);g.ua("ytPubsub2Pubsub2SkipSubKey",null,void 0);var Kz=window.performance||window.mozPerformance||window.msPerformance||window.webkitPerformance||{};g.r(xz,g.lz);g.r(yz,g.lz);var Ega=new g.mz("aft-recorded",xz),tz=new g.mz("timing-sent",yz);var Hga,WT,Qz,Dga,Bga,Cga,XT,Rz,Uz,Aga,Yka;Hga={vc:!0};WT={};
Qz=(WT.ad_allowed="adTypesAllowed",WT.yt_abt="adBreakType",WT.ad_cpn="adClientPlaybackNonce",WT.ad_docid="adVideoId",WT.yt_ad_an="adNetworks",WT.ad_at="adType",WT.browse_id="browseId",WT.p="httpProtocol",WT.t="transportProtocol",WT.cpn="clientPlaybackNonce",WT.csn="clientScreenNonce",WT.docid="videoId",WT.is_continuation="isContinuation",WT.is_nav="isNavigation",WT.b_p="kabukiInfo.browseParams",WT.is_prefetch="kabukiInfo.isPrefetch",WT.is_secondary_nav="kabukiInfo.isSecondaryNav",WT.prev_browse_id=
"kabukiInfo.prevBrowseId",WT.query_source="kabukiInfo.querySource",WT.voz_type="kabukiInfo.vozType",WT.yt_lt="loadType",WT.yt_ad="isMonetized",WT.nr="webInfo.navigationReason",WT.ncnp="webInfo.nonPreloadedNodeCount",WT.paused="playerInfo.isPausedOnLoad",WT.fmt="playerInfo.itag",WT.yt_pl="watchInfo.isPlaylist",WT.yt_ad_pr="prerollAllowed",WT.yt_red="isRedSubscriber",WT.st="serverTimeMs",WT.aq="tvInfo.appQuality",WT.br_trs="tvInfo.bedrockTriggerState",WT.label="tvInfo.label",WT.is_mdx="tvInfo.isMdx",
WT.preloaded="tvInfo.isPreloaded",WT.query="unpluggedInfo.query",WT.upg_chip_ids_string="unpluggedInfo.upgChipIdsString",WT.yt_vst="videoStreamType",WT.vph="viewportHeight",WT.vpw="viewportWidth",WT.yt_vis="isVisible",WT);Dga="ap c cver cbrand cmodel ei srt yt_fss yt_li plid vpil vpni vpst yt_eil vpni2 vpil2 icrc icrt pa GetBrowse_rid GetPlayer_rid GetSearch_rid GetWatchNext_rid cmt d_vpct d_vpnfi d_vpni pc pfa pfeh pftr prerender psc rc start tcrt tcrc ssr vpr vps yt_abt yt_fn yt_fs yt_pft yt_pre yt_pt yt_pvis yt_ref yt_sts".split(" ");
Bga={ad_to_ad:"LATENCY_ACTION_AD_TO_AD",ad_to_video:"LATENCY_ACTION_AD_TO_VIDEO",app_startup:"LATENCY_ACTION_APP_STARTUP",browse:"LATENCY_ACTION_BROWSE",channels:"LATENCY_ACTION_CHANNELS",channel:"LATENCY_ACTION_CREATOR_CHANNEL_DASHBOARD","channel.analytics":"LATENCY_ACTION_CREATOR_CHANNEL_ANALYTICS","channel.comments":"LATENCY_ACTION_CREATOR_CHANNEL_COMMENTS","channel.copyright":"LATENCY_ACTION_CREATOR_CHANNEL_COPYRIGHT","channel.monetization":"LATENCY_ACTION_CREATOR_CHANNEL_MONETIZATION","channel.translations":"LATENCY_ACTION_CREATOR_CHANNEL_TRANSLATIONS",
"channel.videos":"LATENCY_ACTION_CREATOR_CHANNEL_VIDEOS",chips:"LATENCY_ACTION_CHIPS",embed:"LATENCY_ACTION_EMBED",home:"LATENCY_ACTION_HOME",library:"LATENCY_ACTION_LIBRARY",live:"LATENCY_ACTION_LIVE",prebuffer:"LATENCY_ACTION_PREBUFFER",prefetch:"LATENCY_ACTION_PREFETCH",results:"LATENCY_ACTION_RESULTS",search:"LATENCY_ACTION_RESULTS",search_zero_state:"LATENCY_ACTION_SEARCH_ZERO_STATE",tenx:"LATENCY_ACTION_TENX",video_to_ad:"LATENCY_ACTION_VIDEO_TO_AD",watch:"LATENCY_ACTION_WATCH","watch,watch7":"LATENCY_ACTION_WATCH",
"watch,watch7_html5":"LATENCY_ACTION_WATCH","watch,watch7ad":"LATENCY_ACTION_WATCH","watch,watch7ad_html5":"LATENCY_ACTION_WATCH",wn_comments:"LATENCY_ACTION_LOAD_COMMENTS","video.analytics":"LATENCY_ACTION_CREATOR_VIDEO_ANALYTICS","video.comments":"LATENCY_ACTION_CREATOR_VIDEO_COMMENTS","video.edit":"LATENCY_ACTION_CREATOR_VIDEO_EDIT","video.translations":"LATENCY_ACTION_CREATOR_VIDEO_TRANSLATIONS","video.video_editor":"LATENCY_ACTION_CREATOR_VIDEO_VIDEO_EDITOR","video.video_editor_async":"LATENCY_ACTION_CREATOR_VIDEO_VIDEO_EDITOR_ASYNC"};
Cga="isContinuation isNavigation kabukiInfo.isPrefetch kabukiInfo.isSecondaryNav isMonetized playerInfo.isPausedOnLoad prerollAllowed isRedSubscriber tvInfo.isMdx tvInfo.isPreloaded isVisible watchInfo.isPlaylist".split(" ");XT={};Rz=(XT.yt_vst="VIDEO_STREAM_TYPE_",XT);Uz=!1;Aga=(0,g.z)(Kz.clearResourceTimings||Kz.webkitClearResourceTimings||Kz.mozClearResourceTimings||Kz.msClearResourceTimings||Kz.oClearResourceTimings||g.va,Kz);g.WB=Ez;Yka=Cz;g.VB=Fz;var ZT;var $T=g.zb,aU=$T.match(/\((iPad|iPhone|iPod)( Simulator)?;/);if(!aU||2>aU.length)ZT=void 0;else{var bU=$T.match(/\((iPad|iPhone|iPod)( Simulator)?; (U; )?CPU (iPhone )?OS (\d+_\d)[_ ]/);ZT=bU&&6==bU.length?Number(bU[5].replace("_",".")):0}g.vR=ZT;g.cU=0<=g.vR;g.cU&&0<=g.zb.search("Safari")&&g.zb.search("Version");var Uga={0:"UNKNOWN",1:"OFF",2:"ON",3:"FORCED_ON"},dU={},Tla=(dU.ALWAYS=1,dU.BY_REQUEST=3,dU);g.r(g.Xz,g.N);g.h=g.Xz.prototype;g.h.Lf=function(a,b){b?(this.setData(a),wA(this)&&mA(this)):(aA(this,a,!0),this.P("dataupdated"))};
g.h.setData=function(a){a=a||{};this.clientPlaybackNonce||(this.clientPlaybackNonce=a.cpn||ds());var b=a.raw_player_response;if(!b){var c=a.player_response;c&&(b=g.Tn(c))}b&&(this.Xa=b);if(this.Xa&&((b=this.Xa.attestation)&&Vga(this,b),(b=this.Xa.heartbeatParams)&&Wga(this,b,a),(b=this.Xa.multicamera)&&Xga(this,b),(b=this.Xa.overlay)&&Yga(this,b),(b=this.Xa.playabilityStatus)&&Zga(this,b,a),(b=this.Xa.playbackTracking)&&$ga(this,b,a),(b=this.Xa.playerConfig)&&aha(this,b),(b=this.Xa.streamingData)&&
cha(this,b),(b=this.Xa.videoDetails)&&dha(this,b),b=this.Xa.interstitialPods))for(b=g.q(b),c=b.next();!c.done;c=b.next()){c=c.value;var d=c.interstitials.map(function(a){return(a=a.playerVars)&&Object.assign({is_yto_interstitial:!0},g.sp(a))});
switch(c.podConfig.playbackPlacement){case "INTERSTITIAL_PLAYBACK_PLACEMENT_PRE":this.Wm=this.Wm.concat(d);break;case "INTERSTITIAL_PLAYBACK_PLACEMENT_POST":this.Vm=this.Vm.concat(d)}}this.yg="1"!=a.hlsdvr?!1:ru()?!0:Rx&&5>g.vR?!1:!0;this.adQueryId=a.ad_query_id||null;this.adSafetyReason=a.encoded_ad_safety_reason||null;this.NB=a.agcid||null;this.adIds=a.ad_id||null;this.adSystems=a.ad_sys||null;this.gu=a.encoded_ad_playback_context||null;this.Cg=T(this.Cg,a.infringe||a.muted);this.authKey=a.authkey;
this.Dc=a.authuser;this.enableCardio=T(this.enableCardio,a.enable_cardio);this.enableCardioBeforePlayback=T(this.enableCardioBeforePlayback,a.enable_cardio_before_playback);this.endSeconds=Ix(this.endSeconds,this.Yq||a.end||a.endSeconds);this.Ph=Jx(this.Ph,a.itct);this.pp=T(this.pp,a.noiba);this.wj="1"==a.livemonitor;this.ra="1"==a.live_playback;this.yj="1"==a.post_live_playback;this.isLiveDestination=T(this.isLiveDestination,a.is_live_destination);this.isLiveDefaultBroadcast="1"==a.live_default_broadcast;
this.isLowLatencyLiveStream="1"==a.is_low_latency_live_stream;if(b=a.latency_class)this.latencyClass=Hx("UNKNOWN",b,Rla);this.kk||(this.isVisualizerEligible="1"==a.is_visualizer_eligible)&&this.xc.push("visualizer");this.isMdxPlayback=T(this.isMdxPlayback,a.mdx);if(b=a.mdx_control_mode)this.mdxControlMode=wb(b);this.np=T(this.np,a.is_inline_playback_no_ad);this.bf=Ix(this.bf,a.reload_count);this.reloadReason=Jx(this.reloadReason,a.reload_reason);this.pn=T(this.pn,a.show_content_thumbnail);this.vp=
T(this.vp,a.utpsa);this.cycToken=a.cyc||null;this.Zz=a.tkn||null;this.tg=kz(a);this.df=Jx(this.df,a.vvt);this.revocableUnlistedToken=a.revocable_unlisted_token;this.mdxEnvironment=Jx(this.mdxEnvironment,a.mdx_environment);this.YH=a.osig;this.Gy||(this.ar=a.ptchn,this.dr=a.oid,this.lk=a.ptk,this.fr=a.pltype);this.Hy||(this.playbackId=a.plid,this.eventId=a.eventid,this.osid=a.osid,this.videoMetadata=a.vm,this.Rm=a.of,this.Ak=a.upt,this.qk=a.sdetail);this.playlistId=Jx(this.playlistId,a.list);this.Ny=
a.pyv_view_beacon_url;this.Py=a.pyv_quartile25_beacon_url;this.Qy=a.pyv_quartile50_beacon_url;this.Ry=a.pyv_quartile75_beacon_url;this.Oy=a.pyv_quartile100_beacon_url;if(b=a.remarketing_url)this.remarketingUrl=b;if(b=a.ppv_remarketing_url)this.ppvRemarketingUrl=b;b=a.session_data;!this.kr&&b&&(this.kr=g.rp(b).feature);this.isFling=1==Ix(this.isFling?1:0,a.is_fling);this.vnd=Ix(this.vnd,a.vnd);this.yo=Jx(this.yo,a.force_ads_url);this.Ee=Jx(this.Ee,a.ctrl);this.Fe=Jx(this.Fe,a.ytr);this.vl=a.ytrcc;
this.dz=a.ytrexp;this.ir=Jx(this.ir,a.adformat);this.Wr=Jx(this.Wr,a.attrib);this.slotPosition=Ix(this.slotPosition,a.slot_pos);this.breakType=a.break_type;this.tk=T(this.tk,a.ssrt);this.videoId=Lx(a)||this.videoId;this.vssCredentialsToken=Jx(this.vssCredentialsToken,a.vss_credentials_token);this.In=Jx(this.In,a.vss_credentials_token_type);this.Zq||(this.heartbeatToken=Jx(this.heartbeatToken,a.heartbeat_token),this.heartbeatInterval=Ix(this.heartbeatInterval,a.heartbeat_interval),this.heartbeatRetries=
Ix(this.heartbeatRetries,a.heartbeat_retries),this.heartbeatSoftFail=T(this.heartbeatSoftFail,a.heartbeat_soft_fail),this.sj=T(this.sj,a.ithb));this.Cy||(this.relativeLoudness=Ix(this.relativeLoudness,a.relative_loudness));this.Yr=T(this.Yr,a.audio_only);this.Xr=T(this.Xr,a.aac_high);this.preferLowQualityAudio=T(this.preferLowQualityAudio,a.prefer_low_quality_audio);this.Fy||(this.isDni=T(!1,a.is_dni),this.dniColor=Jx(this.dniColor,a.dni_color));this.nk=Jx(this.nk,a.qoe_cat);Pga(this.Xa)&&(this.adModule=
!0,this.xc.push("ad"));if(b=a.adaptive_fmts)this.adaptiveFormats=b;!this.Ey&&(b=a.license_info)&&(this.Ec=Tga(b),this.drmParams=Jx(this.drmParams,a.drm_params));if(b=a.allow_embed)this.allowEmbed="1"==b;if(b=a.backgroundable)this.backgroundable="1"==b;if(b=a.autonav)this.Qh="1"==b;if(b=a.autoplay)this.oi="1"==b;(b=a.iv_load_policy)?this.Qf=Hx(this.Qf,b,cy):(b=Zz(this.Xa))&&b.loadPolicy&&(this.Qf=Tla[b.loadPolicy]);if(b=a.cc_lang_pref)this.Sf=Jx(b,this.Sf);if(b=a.cc_load_policy)this.Tf=Hx(this.Tf,
b,cy);if(b=a.cached_load)this.Zn=T(this.Zn,b);"0"==a.dash&&(this.cu=!0);if(b=a.dashmpd)this.Ud=g.Ig(b,{cpn:this.clientPlaybackNonce});if(b=a.delay)this.ne=wb(b);!this.Zq&&(b=a.drm_session_id)&&(this.drmSessionId=b);b=this.Yq||a.end;void 0!=b&&(this.clipEnd=Ix(this.clipEnd,b));this.Dy||(a.fair_play_cert&&window.atob&&(this.fairPlayCert=(0,window.atob)(a.fair_play_cert)),a.fair_play_key_rotation_period&&(this.bj=wb(a.fair_play_key_rotation_period)),a.fair_play_key_prefetch_margin&&(this.aj=wb(a.fair_play_key_prefetch_margin)));
if(b=a.fmt_list)this.fmtList=b;a.fresca_preroll&&this.xc.push("fresca");a.heartbeat_preroll&&this.xc.push("heartbeat");if(b=a.idpj)this.Oh=wb(b);!this.kk&&(b=a.ismb)&&(this.Qe=wb(b));if(b=a.is_listed)this.isListed=T(this.isListed,b);if(b=a.pipable)this.pipable=T(this.pipable,b);b=g.Ft()||g.Et();this.Dr=this.la("web_player_pip")&&b&&this.pipable;this.Kz=!this.Dr&&b&&this.pipable&&!this.Ra.showMiniplayerButton;if(b=a.paid_content_overlay_duration_ms)this.By=wb(b);if(b=a.paid_content_overlay_text)this.mM=
b;if(b=a.url_encoded_fmt_stream_map)this.Ei=b;if(b=a.hls_formats)this.hlsFormats=b;if(b=a.hlsvp)this.hlsvp=b;if(b=a.length_seconds)this.lengthSeconds=g.v(b)?wb(b):b;if(b=a.live_chunk_readahead)this.liveChunkReadahead=Ix(this.liveChunkReadahead,b);if(b=a.live_start_walltime)this.liveStartWalltime=wb(b);if(b=a.live_manifest_duration)this.yp=wb(b);if(b=a.ldpj)this.Dj=wb(b);if(b=a.player_params)this.playerParams=b;if(b=a.partnerid)this.Ce=Ix(this.Ce,b);if(b=a.probe_url)this.probeUrl=Fs(g.Ig(b,{cpn:this.clientPlaybackNonce}));
if(b=a.profile_picture)this.profilePicture=Jx(b,this.profilePicture);(b=a.pyv_billable_url)&&g.Cs(b)&&(this.Ym=b);(b=a.pyv_conv_url)&&g.Cs(b)&&(this.Zm=b);if(b=a.video_masthead_ad_quartile_urls)this.Ep=b.quartile_0_url,this.Iv=b.quartile_25_url,this.Jv=b.quartile_50_url,this.Kv=b.quartile_75_url,this.Hv=b.quartile_100_url;"1"==a.spacecast_playback&&(this.xc.push("spacecast"),this.spacecastModule=!0,this.sh.playback=!0);if(c=a.spacecast_addrs)this.spacecastModule=!0,b={},b.addresses=c.split(","),b.probe=
!0,(c=a.spacecast_query_params)&&(b.applianceQueryParams=c),this.sh.init=b;0<this.startSeconds||(this.wf=this.startSeconds=Ix(this.startSeconds,this.Jy||this.lp||a.start||a.startSeconds));b=a.live_utc_start;null!=b&&(this.liveUtcStartSeconds=(0,window.parseInt)(b,10));if(b=a.utc_start_millis)this.liveUtcStartSeconds=.001*(0,window.parseInt)(b,10);if(b=a.stream_time_start_millis)this.un=.001*(0,window.parseInt)(b,10);b=this.lp||a.start;void 0==b||"1"==a.resume||this.ra||(this.clipStart=Ix(this.clipStart,
b));if(b=a.url_encoded_third_party_media)this.Ai=tp(b);if(b=a.watch_ajax_token)this.watchAjaxToken=b;a.ypc_module&&this.xc.push("ypc");a.ypc_clickwrap_module&&this.xc.push("ypc_clickwrap");if(b=a.ypc_offer_button_formatted_text)c=g.Tn(b),this.ypcOfferButtonFormattedText=null!=c?c:null,this.BA=b;if(b=a.ypc_offer_button_text)this.ypcOfferButtonText=b;if(b=a.ypc_offer_description)this.ypcOfferDescription=b;if(b=a.ypc_offer_headline)this.ypcOfferHeadline=b;if(b=a.ypc_full_video_message)this.ypcFullVideoMessage=
b;if(b=a.ypc_offer_id)this.ypcOfferId=b;if(b=a.ypc_buy_url)this.es=b;if(b=a.ypc_item_thumbnail)this.ypcItemThumbnail=b;if(b=a.ypc_item_title)this.ypcItemTitle=b;if(b=a.ypc_item_url)this.ypcItemUrl=b;if(b=a.ypc_vid)this.ypcVid=b;a.ypc_overlay_timeout&&(this.ypcOverlayTimeout=(0,window.parseInt)(a.ypc_overlay_timeout,10));if(b=a.ypc_trailer_player_vars)this.ypcTrailerPlayerVars=g.sp(b);this.vh=Jx(this.vh,a.ucid);(0,g.C)("baseUrl uid oeid ieid ppe engaged subscribed".split(" "),function(b){a[b]&&(this.Qc[b]=
a[b])},this);
this.Qc.focEnabled=T(this.Qc.focEnabled,a.focEnabled);this.Qc.rmktEnabled=T(this.Qc.rmktEnabled,a.rmktEnabled);this.Nd=a;aA(this,a,!1);kA(this)?Op()&&(this.ra&&this.Ud?this.zh=!0:this.fairPlayCert&&(this.Vh=!0)):!Rga(this,this.Ra.experiments)&&this.Ud&&(this.zh=!0);if(b=a.adpings)this.jt=b?g.sp(b):null;if(b=a.feature)this.ri=b;if(b=a.referrer)this.referrer=b;this.clientScreenNonce=Jx(this.clientScreenNonce,a.csn);this.rootVeType=Ix(this.rootVeType,a.root_ve_type);this.gm=Ix(this.gm,a.kids_age_up_mode);
this.Cn=T(this.Cn,a.upg_content_filter_mode);if(b=a.unplugged_location_info)this.bd=b;if(b=a.unplugged_partner_opt_out)this.Ci=Jx("",b);!this.kk&&(b=a.partial_spherical)&&(this.xj="1"==b);void 0!=a.is_home_group&&(this.uj=T(!!this.uj,a.is_home_group));this.tj=Jx(this.tj,a.internal_ip_override);this.hasSubfragmentedFmp4=T(this.hasSubfragmentedFmp4,a.sfmp4);this.defraggedFromSubfragments=T(this.defraggedFromSubfragments,a.dfs);this.liveExperimentalContentId=Ix(this.liveExperimentalContentId,a.live_experimental_content_id);
(this.Wm.length||this.Vm.length||a.is_yto_interstitial)&&this.xc.push("yto")};
g.h.la=function(a){return g.R(this.Ra.experiments,a)};
g.h.ac=function(){return!this.ra||this.yg};
g.h.wD=function(a){for(var b=g.q(a),c=b.next();!c.done;c=b.next())switch(c=c.value,c.flavor){case "fairplay":c.fairPlayCert=this.fairPlayCert;c.bj=this.bj;c.aj=this.aj;break;case "widevine":c.Ck=this.Ck}this.mk=a;0<this.mk.length&&(this.Re=this.mk[0]);mA(this)};
g.h.bJ=function(a){if(!this.ea()){if(this.tn){var b=ix(a,this.tn);b&&(a=b)}fA(this,a);this.ma.o&&this.ma.subscribe("refresh",this.Sx,this);(0,g.VB)("mrc");Yw(this.ma)&&(this.Vh=!0);mA(this)}};
g.h.aJ=function(a){this.ea()||(this.Af=!1,this.P("dataloaderror",new g.Oy("manifest.net.retryexhausted",!0,{backend:"manifest",rc:a.status})))};
g.h.Sx=function(){this.ea()||(this.ma.o||this.ma.unsubscribe("refresh",this.Sx,this),this.Ht())};
g.h.Ht=function(){var a=dx(this.ma,this.wp);0<a.length&&(this.P("cuepointupdated",a),this.wp+=a.length)};
g.h.LD=function(){if(this.spacecastFormatMap){var a=eA(this,this.spacecastFormatMap);return Wy(this.Ra,this.isAd(),a,pA(this)).then(this.ln,void 0,this).then(this.pu,void 0,this)}return bq()};
g.h.ID=function(a){a=a||kA(this);if(this.ma&&!a){if(cA(this)&&(a=this.ma,!a.g["0"])){var b=new pt("0","fakesb",void 0,new kt(0,0,0,void 0,void 0,"auto"),null,null,1);a.g["0"]=this.ra?new Dw(new g.ew("http://www.youtube.com/videoplayback"),b,"fake"):new g.Tw(new g.ew("http://www.youtube.com/videoplayback"),b,new g.Fv(0,0),new g.Fv(0,0),0,window.NaN)}return Ky(dA(this),this.Ra.T,this.ma,this.Re).then(this.mn,void 0,this)}return bq()};
g.h.JD=function(a){if(!this.la("html5_hlsvp_airplay_killswitch")&&a&&this.hlsvp)return bq();if(this.hlsFormats){a=eA(this,this.hlsFormats);if(cu||Sp()||Op()){var b=Qy(a);if(b){var c=[],d={};for(l in b)for(var e=g.q(b[l]),f=e.next();!f.done;f=e.next()){var k=f.value;k.ib&&(f=k.ib.getId(),d[f]||(k=new gt(f,k.ib),d[f]=k,c.push(k)))}var l=0<c.length?c:null}else l=null}else l=null;this.Ul=l;l=this.la("html5_hls_cpn_killswitch")?"":this.clientPlaybackNonce;return wga(this.Ra,this.isAd(),a,this.Qe,l).then(this.ln,
void 0,this)}return bq()};
g.h.MD=function(){if(this.Ai&&this.rv){var a=this.Ra;var b=this.isAd(),c=xga(this.Ai);a=wu(c,jy(a,b)).then(this.ln,void 0,this)}else a=bq();return a};
g.h.KD=function(){var a=eA(this,this.Ei,this.fmtList);if(this.hlsvp){var b=this.hlsvp;var c=this.Qe,d={cpn:this.clientPlaybackNonce};-1==b.indexOf("/ibw/")&&(d.ibw=c?String(c):"1369843");b={url:g.Ig(b,d),type:"application/x-mpegURL",quality:"auto",itag:"93"};a.push(b)}return Wy(this.Ra,this.isAd(),a,pA(this)).then(this.ln,void 0,this)};
g.h.mn=function(a){this.xa=a;a=this.getAvailableAudioTracks();a=a.concat(this.Vi);for(var b=0;b<this.Pi.length;b++)for(var c=this.Pi[b],d=0;d<a.length;d++){var e=a[d],f=e.ib.id==c.audioTrackId;if(e.ib.isDefault&&b==this.bo||f){if(c.captionTrackIndices)for(f=0;f<c.captionTrackIndices.length;f++)e.captionTracks[f]=this.captionTracks[c.captionTrackIndices[f]];g.t(c.defaultCaptionTrackIndex)&&(e.so=this.captionTracks[c.defaultCaptionTrackIndex]);g.t(c.forcedCaptionTrackIndex)&&(e.Gl=this.captionTracks[c.forcedCaptionTrackIndex]);
e.eo=c.visibility||"UNKNOWN"}}};
g.h.ln=function(a){this.De=a;this.mn(new Dy((0,g.E)(this.De,function(a){return a.Me()})))};
g.h.pu=function(){var a=Aj(this.xa.videoInfos,function(a,c){return c.video.isAccelerated&&(!a||a.height<c.video.height)?c.video:a},null);
a&&(this.Yn=zu(a.quality,a.quality,!0,"c"))};
g.h.kd=function(){var a={};this.ua&&(a.fmt=g.ot(this.ua),this.Yb&&g.ot(this.Yb)!=g.ot(this.ua)&&(a.afmt=g.ot(this.Yb)));a.plid=this.playbackId;a.ei=this.eventId;a.list=this.playlistId;a.cpn=this.clientPlaybackNonce;this.videoId&&(a.v=this.videoId);this.Cg&&(a.infringe=1);this.jg&&(a.splay=1);var b=tA(this);b&&(a.live=b);this.oi&&(a.autoplay=1);this.qk&&(a.sdetail=this.qk);this.Ce&&(a.partnerid=this.Ce);this.osid&&(a.osid=this.osid);return a};
g.h.Xd=function(){if(!this.sd)if(this.Xa&&this.Xa.storyboards){var a=this.Xa.storyboards,b=a.playerStoryboardSpecRenderer;b&&b.spec?this.sd=new fz(b.spec,this.lengthSeconds):(a=a.playerLiveStoryboardSpecRenderer)&&a.spec&&this.ma&&(b=Ib(this.ma.g).index)&&(this.sd=new iz(a.spec,this.ma.isLive,b))}else(a=this.Nd.storyboard_spec)?this.sd=new fz(a,this.lengthSeconds):(a=this.Nd.live_storyboard_spec)&&this.ma&&(b=Ib(this.ma.g).index)&&(this.sd=new iz(a,this.ma.isLive,b));return this.sd};
g.h.getStoryboardFormat=function(){if(this.Xa&&this.Xa.storyboards){var a=this.Xa.storyboards;return(a=a.playerStoryboardSpecRenderer||a.playerLiveStoryboardSpecRenderer)&&a.spec||null}return this.Nd.storyboard_spec||this.Nd.live_storyboard_spec||null};
g.h.Gc=function(){return this.ma&&!(0,window.isNaN)(this.ma.Gc())?this.ma.Gc():gA(this)?0:this.lengthSeconds};
g.h.zb=function(){return this.ma&&!(0,window.isNaN)(this.ma.zb())?this.ma.zb():0};
g.h.getPlaylistSequenceForTime=function(a){if(this.ma&&this.ua){var b=this.ma.g[this.ua.id];if(!b)return null;var c=b.index.sf(a);b=b.index.od(c);return{sequence:c,elapsed:Math.floor(1E3*(a-b))}}return null};
g.h.ld=function(){return!this.ea()&&!(!this.videoId&&!this.Ai)};
g.h.Ob=function(){return wA(this)&&!this.zh&&!this.Vh};
g.h.rz=function(){var a={format:"RAW",method:"GET",withCredentials:this.fz};this.xi&&this.visitorData&&(a.headers={"X-Goog-Visitor-Id":this.visitorData});0<this.Lo&&(a.timeout=this.Lo);var b=this.Ju;0<this.hn&&(b=g.xp(b,{playerretry:this.hn}));this.mh&&(b=g.xp(b,{preload:1}));this.Ku?Vw(Zp,b,a).then(jp(this.Xx),jp(this.rJ),this):(a.context=this,a.onSuccess=this.Xx,a.onError=this.Xo,g.Fp(b,a));(0,g.VB)("vir");Pz("vir");this.Iu=g.qr()};
g.h.tc=function(a){if(30==this.Ce)return(a=this.tg["default.jpg"])?a:this.videoId?g.Ig("//docs.google.com/vt",{id:this.videoId,authuser:this.Dc,authkey:this.authKey}):"//docs.google.com/images/doclist/cleardot.gif";a||(a="hqdefault.jpg");var b=this.tg[a];return b||this.Ra.F||"pop1.jpg"==a||"pop2.jpg"==a||"sddefault.jpg"==a||"hq720.jpg"==a||"maxresdefault.jpg"==a?b:g.my(this.Ra,this.videoId,a)};
g.h.Xx=function(a){if(!this.ea()){var b=a.responseText;if(b){this.Af=!1;var c=g.sp(b);this.kv&&Yy(c);"fail"==c.status?(this.setData(c),this.P("onStatusFail",c)):((0,g.VB)("virc"),Pz("virc"),(0,g.C)(Ula,function(a){a in this.Nd&&(c[a]=this.Nd[a])},this),this.setData(c),wA(this)?mA(this):this.P("dataloaderror",new g.Oy("manifest.net.retryexhausted",!0,{successButUnplayable:"1"})))}else this.Xo(a)}};
g.h.rJ=function(a){this.Xo(a.Wg)};
g.h.Xo=function(a){if(!this.ea()){var b=a?a.status:-1;a=this.hn>=this.rr||400==b;var c=200<b?"manifest.net.badstatus":"manifest.net.connect",d=((g.qr()-this.Iu)/1E3).toFixed(3);b={backend:"gvi",rc:b,rt:d};a&&this.rr?c="manifest.net.retryexhausted":a||(this.hn++,this.qz.start());this.P("dataloaderror",new g.Oy(c,a,b))}};
g.h.xf=function(){return this.ra||this.yj};
g.h.getAvailableAudioTracks=function(){return this.xa?0<this.xa.getAvailableAudioTracks().length?this.xa.getAvailableAudioTracks():this.Ul||[]:[]};
g.h.getAudioTrack=function(){var a=this;if(this.Yb&&!ut(this.Yb))return g.Ja(this.getAvailableAudioTracks(),function(b){return b.id==a.Yb.id})||this.Vi;
if(this.Ul){if(!this.rk)for(var b=g.q(this.Ul),c=b.next();!c.done;c=b.next())if(c=c.value,c.ib.isDefault){this.rk=c;break}return this.rk||this.Vi}return this.Vi};
g.h.getPlayerResponse=function(){return this.Xa};
g.h.getPlaylistId=function(){return null};
g.h.za=function(){return this};
g.h.kj=function(){return this.Ra.getVideoUrl(this.videoId)};
g.h.yf=function(){return!!this.ma&&this.ma.yf()};
g.h.zf=function(){return!!this.ma&&this.ma.zf()};
g.h.Oe=function(){return!!this.ma&&this.ma.Oe()};
g.h.Rg=function(){return!!this.ma&&this.ma.Rg()};
g.h.isAd=function(){return!!this.adFormat};
g.h.sk=function(){return g.zA(this,"ypc_module")};
var eU={},bha=(eU.FAIRPLAY="fairplay",eU.PLAYREADY="playready",eU.WIDEVINE="widevine",eU),Ula="oauth_token ypc_buy_url ypc_full_video_message ypc_item_thumbnail ypc_item_title ypc_item_url ypc_module ypc_offer_button_text ypc_offer_button_formatted_text ypc_offer_description ypc_offer_headline ypc_offer_id ypc_overlay_timeout ypc_preview ypc_vid".split(" "),Oga="author cc_asr cc_load_policy iv_load_policy iv_new_window keywords oauth_token requires_purchase rvs subscribed title ttsurl ypc_buy_url ypc_full_video_length ypc_item_thumbnail ypc_item_title ypc_item_url ypc_offer_button_text ypc_offer_button_formatted_text ypc_offer_description ypc_offer_headline ypc_offer_id ypc_preview ypc_price_string ypc_video_rental_bar_text".split(" "),
Yz=["annotations","captions","storyboard","chapterMarkers"];KA.prototype.isEmpty=function(){return this.endTime==this.startTime};MA.prototype.update=function(){if(!g.R(this.l.g.experiments,"html5_ignore_updates_before_initial_ping")||this.H){var a=this.l.l()||0,b=g.SA(this.l);if(a!=this.g||QA(this,a,b)){var c;if(!(c=a<this.g||a-this.g>b-this.C+2||QA(this,a,b))){var d=this.l.kd();c=d.volume;var e=c!=this.L;d=d.muted;d!=this.J?(this.J=d,c=!0):(!e||0<=this.B||(this.L=c,this.B=b),c=b-this.B,0<=this.B&&2<c?(this.B=-1,c=!0):c=!1)}c&&(g.NA(this),this.o=a);this.C=b;this.g=a}}};var UA={other:1,none:2,wifi:3,cellular:7};g.OG=mc(function(){var a="";try{var b=g.vd("CANVAS").getContext("webgl");b&&(b.getExtension("WEBGL_debug_renderer_info"),a=b.getParameter(37446),a=a.replace(/[ :]/g,"_"))}catch(c){}return a});var Lia,fU,gha;
Lia={VN:"ALREADY_PINNED_ON_A_DEVICE",AUTHENTICATION_EXPIRED:"AUTHENTICATION_EXPIRED",XN:"AUTHENTICATION_MALFORMED",YN:"AUTHENTICATION_MISSING",bO:"BAD_REQUEST",jO:"CAST_SESSION_DEVICE_MISMATCHED",kO:"CAST_SESSION_VIDEO_MISMATCHED",lO:"CAST_TOKEN_EXPIRED",mO:"CAST_TOKEN_FAILED",nO:"CAST_TOKEN_MALFORMED",oO:"CGI_PARAMS_MALFORMED",pO:"CGI_PARAMS_MISSING",CO:"DEVICE_FALLBACK",KO:"GENERIC_WITH_LINK_AND_CPN",LO:"LICENSE",MO:"VIDEO_UNAVAILABLE",QO:"FORMAT_UNAVALIABLE",SO:"GEO_FAILURE",eP:"HTML5_AUDIO_RENDERER_ERROR",fP:"GENERIC_WITHOUT_LINK",
gP:"HTML5_FLASH_DEPRECATED",hP:"HTML5_NO_AVAILABLE_FORMATS_FALLBACK",iP:"HTML5_NO_AVAILABLE_FORMATS_FALLBACK_WITH_LINK",oP:"INVALID_DRM_MESSAGE",aQ:"PURCHASE_NOT_FOUND",bQ:"PURCHASE_REFUNDED",eQ:"RENTAL_EXPIRED",gQ:"RETRYABLE_ERROR",iQ:"SERVER_ERROR",pQ:"STOPPED_BY_ANOTHER_PLAYBACK",qQ:"STREAMING_DEVICES_QUOTA_PER_24H_EXCEEDED",rQ:"STREAMING_NOT_ALLOWED",sQ:"STREAM_LICENSE_NOT_FOUND",xQ:"TOO_MANY_STREAMS_PER_ENTITLEMENT",yQ:"TOO_MANY_STREAMS_PER_USER",CQ:"UNSUPPORTED_DEVICE",DQ:"VIDEO_FORBIDDEN",
EQ:"VIDEO_NOT_FOUND"};fU={};
g.eH=(fU.ALREADY_PINNED_ON_A_DEVICE="This video has already been downloaded on the maximum number of devices allowed by the copyright holder. Before you can play the video here, it needs to be unpinned on another device.",fU.DEVICE_FALLBACK="Sorry, this video is not available on this device.",fU.GENERIC_WITH_LINK_AND_CPN="An error occurred. Please try again later. (Playback ID: $CPN) $BEGIN_LINKLearn More$END_LINK",fU.LICENSE="Sorry, there was an error licensing this video.",fU.VIDEO_UNAVAILABLE=
"Video unavailable",fU.FORMAT_UNAVALIABLE="This video isn't avaliable at the selected quality. Please try again later.",fU.GEO_FAILURE="This video isn't available in your country.",fU.HTML5_AUDIO_RENDERER_ERROR="Audio renderer error. Please restart your computer.",fU.GENERIC_WITHOUT_LINK="An error occurred. Please try again later.",fU.HTML5_FLASH_DEPRECATED="Flash videos are no longer supported. For the best experience, please upgrade your browser to the latest version. $BEGIN_LINKLEARN MORE$END_LINK",
fU.HTML5_NO_AVAILABLE_FORMATS_FALLBACK="This video format is not supported.",fU.HTML5_NO_AVAILABLE_FORMATS_FALLBACK_WITH_LINK="Your browser does not currently recognize any of the video formats available. $BEGIN_LINKClick here to visit our frequently asked questions about HTML5 video.$END_LINK",fU.INVALID_DRM_MESSAGE="The DRM system specific message is invalid.",fU.PURCHASE_NOT_FOUND="This video requires payment.",fU.PURCHASE_REFUNDED="This video's purchase has been refunded.",fU.RENTAL_EXPIRED="This video's rental has expired.",
fU.CAST_SESSION_DEVICE_MISMATCHED="The device in the cast session doesn't match the requested one.",fU.CAST_SESSION_VIDEO_MISMATCHED="The video in the cast session doesn't match the requested one.",fU.CAST_TOKEN_FAILED="Cast session not available. Please refresh or try again later.",fU.CAST_TOKEN_EXPIRED="Cast session was expired. Please refresh.",fU.CAST_TOKEN_MALFORMED="Invalid cast session. Please refresh or try again later.",fU.SERVER_ERROR="There was an internal server error. Please try again later.",
fU.STOPPED_BY_ANOTHER_PLAYBACK="Your account is playing this video in another location. Please reload this page to resume watching.",fU.STREAM_LICENSE_NOT_FOUND="Video playback interrupted. Please try again.",fU.STREAMING_DEVICES_QUOTA_PER_24H_EXCEEDED="Too many devices/IP addresses have been used over the 24 hour period.",fU.STREAMING_NOT_ALLOWED="Playback not allowed because this video is pinned on another device.",fU.RETRYABLE_ERROR="There was a temporary server error. Please try again later.",
fU.TOO_MANY_STREAMS_PER_USER="Playback stopped because too many videos belonging to the same account are playing.",fU.TOO_MANY_STREAMS_PER_ENTITLEMENT="Playback stopped because this video has been played on too many devices.",fU.UNSUPPORTED_DEVICE="Playback isn't supported on this device.",fU.VIDEO_FORBIDDEN="Access to this video is forbidden.",fU.VIDEO_NOT_FOUND="This video can not be found.",fU);
gha={300:"STREAMING_DEVICES_QUOTA_PER_24H_EXCEEDED",301:"ALREADY_PINNED_ON_A_DEVICE",303:"STOPPED_BY_ANOTHER_PLAYBACK",304:"TOO_MANY_STREAMS_PER_USER",305:"TOO_MANY_STREAMS_PER_ENTITLEMENT",400:"VIDEO_NOT_FOUND",401:"GEO_FAILURE",402:"STREAMING_NOT_ALLOWED",403:"UNSUPPORTED_DEVICE",405:"VIDEO_FORBIDDEN",500:"PURCHASE_NOT_FOUND",501:"RENTAL_EXPIRED",502:"PURCHASE_REFUNDED",5E3:"BAD_REQUEST",5001:"CGI_PARAMS_MISSING",5002:"CGI_PARAMS_MALFORMED",5100:"AUTHENTICATION_MISSING",5101:"AUTHENTICATION_MALFORMED",
5102:"AUTHENTICATION_EXPIRED",5200:"CAST_TOKEN_MALFORMED",5201:"CAST_TOKEN_EXPIRED",5202:"CAST_TOKEN_FAILED",5203:"CAST_SESSION_VIDEO_MISMATCHED",5204:"CAST_SESSION_DEVICE_MISMATCHED",6E3:"INVALID_DRM_MESSAGE",7E3:"SERVER_ERROR",8E3:"RETRYABLE_ERROR"};var Vla=g.cU&&4>g.vR?.1:0,Uka=new XA;XA.prototype.g=null;XA.prototype.gf=function(a){var b="";a&&(YA(this,a),b=a.g);this.src&&""==b||(b&&this.src!=b&&(this.src=b),a&&a.l||this.load())};
XA.prototype.l=function(){this.hasAttribute("controls")&&this.setAttribute("controls","true")};g.r(g.ZA,g.G);g.h=g.ZA.prototype;g.h.th=ba(7);g.h.qm=function(){return this.A};
g.h.gf=function(a){var b="";a&&(aB(this,a),b=a.g);this.Rc()&&""==b||(b&&this.Rc()!=b&&(this.sm(b),this.o&&(this.o.dispose(),this.o=null)),a&&a.l||this.load(),this.J||(this.addEventListener("volumechange",this.Jt),this.J=!0))};
g.h.Xm=function(){if(!this.o||this.o.ea()){var a=this.ia();a=window.MediaSource?new window.MediaSource:window.WebKitMediaSource?new window.WebKitMediaSource:new It(a);a=new Vt(a);this.gf(a.Fj);this.o=a}};
g.h.bi=function(){this.G||(this.B=null);if(this.B)return this.B;this.Xm();var a=this.o;this.o=null;return this.B=a};
g.h.Kb=function(){this.Sg()&&this.Ab(0);!this.Rc()&&this.A&&(g.M(Error("playVideo without src")),this.sm(this.A.g),this.A.l||this.load());var a=this.play();!a&&g.cU&&7<=g.vR&&g.Mq(this,"playing",(0,g.z)(function(){g.op((0,g.z)(this.tu,this,this.ya(),0),500)},this));
return a};
g.h.tu=function(a,b){this.ah()||this.ya()>a||10<b||(this.play(),g.op((0,g.z)(this.tu,this,this.ya(),b+1),500))};
g.h.Ab=function(a){0<this.ae()&&(g.cU&&4>g.vR&&(a=Math.max(.1,a)),this.jn(a))};
g.h.Kc=function(){!this.o&&this.Rc()&&(cu&&0<this.ya()&&this.Ab(0),this.lr(),this.load(),aB(this,null))};
g.h.Zh=function(){try{return{vct:this.ya().toFixed(3),vd:this.ec().toFixed(3),vpl:Mt(this.hj()),vbu:Mt(this.Le()),vpa:""+ +this.ah(),vsk:""+ +this.dm(),ven:""+ +this.Sg(),vpr:""+this.Pb(),vrs:""+this.ae(),vns:""+this.Kl(),vec:""+this.Ue(),vvol:""+this.Jb()}}catch(a){return{}}};
g.h.addEventListener=function(a,b){this.F.fa(a,b,!1,this);this.wo(a)};
g.h.removeEventListener=function(a,b){this.F.Pa(a,b,!1,this)};
g.h.dispatchEvent=function(a){return this.F.dispatchEvent(a)};
g.h.vo=function(){this.H=!1};
g.h.to=function(){this.H=!0;this.ci(!0)};
g.h.Jt=function(){this.H&&!this.pm()&&this.ci(!0)};
g.h.U=function(){this.J&&this.removeEventListener("volumechange",this.Jt);this.B&&this.B.dispose();this.o&&this.o.dispose();g.G.prototype.U.call(this)};g.r(fB,g.Ze);fB.prototype.preventDefault=function(){g.Ze.prototype.preventDefault.call(this);this.g&&this.g.preventDefault()};
fB.prototype.stopPropagation=function(){g.Ze.prototype.stopPropagation.call(this);this.g&&this.g.stopPropagation()};g.iB.prototype.isError=function(){return g.U(this,128)};g.r(xB,g.G);
xB.prototype.B=function(a){if(!this.ea()&&(a=0<=a?a:g.SA(this.g),-1<["PL","B","S"].indexOf(this.o)&&(!g.Qb(this.l)||a>=this.A+30)&&(g.wB(this,a,"vps",[this.o]),this.A=a),!g.Qb(this.l))){AB(this,a);var b=a,c=this.g.F(),d=c.droppedVideoFrames,e=d-this.ba;if(d>c.totalVideoFrames||5E3<e)this.onError("html5.badframedropcount","df."+d+";tf."+c.totalVideoFrames);else 0<e&&g.wB(this,b,"df",[e]);this.ba=d;!g.R(this.g.g.experiments,"disable_webgl_reporting")&&0<this.C&&(g.wB(this,a,"glf",[this.C]),this.C=0);
a={event:"streamingstats"};this.g.videoData.ua&&(a.fmt=g.ot(this.g.videoData.ua),(b=this.g.videoData.Yb)&&g.ot(b)!=a.fmt&&(a.afmt=g.ot(b)));a.cpn=this.g.videoData.clientPlaybackNonce;a.ei=this.g.videoData.eventId;a.el=DA(this.g.videoData);a.docid=this.g.videoData.videoId;a.ns=this.g.g.Z;a.fexp=this.g.g.experiments.experimentIds.toString();a.cl="223881213";this.g.videoData.adFormat&&(a.adformat=this.g.videoData.adFormat);(b=tA(this.g.videoData))&&(a.live=b);a.seq=this.J++;if(!g.R(this.g.g.experiments,
"html5_prevent_qoe_spam_killswitch")&&(7E3==this.J&&g.M(Error("Sent over 7000 pings"),"WARNING"),7E3<=this.J))return;g.Zb(a,this.g.g.l);b=g.Ig("//"+this.g.g.Of+"/api/stats/qoe",a);a=c="";for(var f in this.l)null==this.l[f]?g.M(Error("Stats report key has invalid value: "+f),"WARNING"):(d="&"+f+"="+this.l[f].join(","),100<d.length?a+=d:c+=d);f=b+c;a=a.replace(/ /g,"%20");b=HA(this.g.videoData);c=this.g.videoData.visitorData;d=b&&zp();e=c&&this.g.g.sa;if(d||e){var k={};d&&(k.Authorization="Bearer "+
b);e&&(k["X-Goog-Visitor-Id"]=c);g.Fp(f,{headers:k,withCredentials:!0,method:"POST",postBody:a})}else Wp(f,void 0,a);this.l={}}};
xB.prototype.sa=function(){if(this.g.videoData.Re){var a=this.g.videoData.Re;DB(this,"drm-"+a.flavor);DB(this,"eme-"+(a.l?"final":yy(a)?"ms":"com.youtube.fairplay"==a.g?"ytfp":By(a)?"safarifp":"nonfinal"))}};
xB.prototype.onError=function(a,b){var c=g.SA(this.g);CB(this,c,a,b);AB(this,c);BB(this)};
xB.prototype.U=function(){g.G.prototype.U.call(this);window.clearInterval(this.X)};
var gU={},iha=(gU[5]="N",gU[-1]="N",gU[3]="B",gU[0]="EN",gU[2]="PA",gU[1]="PL",gU);EB.prototype.send=function(a){if(!this.R){var b=HB(this);b=g.Ig(this.oa,b);if(this.C)this.H&&(a=(this.ka?FB(this):null)||{},a.method="POST",a.qb={atr:this.H},this.xi&&this.visitorData&&(a.headers={"X-Goog-Visitor-Id":this.visitorData}),g.Fp(b,a));else{var c=FB(this,a);c?g.Fp(b,c):g.Vp(b,a)}this.R=!0}};
EB.prototype.g=function(a){void 0==a&&(a=window.NaN);return(1*a.toFixed(3)).toString()};g.r(JB,g.G);JB.prototype.da=function(a,b){if(!this.ea()){this.F=window.NaN;this.o.update();var c=PA(this.o),d=MB(this,c);b&&(d.B=a);var e=400<this.L;!(1<c.length)&&c[0].isEmpty()||e||(d.l=KB(this,!0,a));d.send();this.L++}};
JB.prototype.onError=function(a,b){if(!this.ea())this.l.onError(a,b)};
JB.prototype.G=function(a){var b=this.g.g,c=this.g.videoData,d={ns:b.Z,el:DA(c),eurl:b.pa,fmt:c.ua?g.ot(c.ua):0,html5:1,list:c.playlistId,plid:c.playbackId,cpn:c.clientPlaybackNonce,ei:c.eventId,ps:b.playerStyle,noflv:1,st:this.g.l(),video_id:c.videoId,metric:a};GA(c)&&(d.autoplay="1");"heartbeat"==a&&(d.tpmt=OA(this.o));g.Fa(d,b.l);OB(this,g.Ig(g.R(b.experiments,"cardio_base_url_killswitch")?(b.o?b.protocol+"://www.youtube.com/":b.baseYtUrl)+"live_204":b.baseYtUrl+"live_204",d))};
JB.prototype.U=function(){g.G.prototype.U.call(this);g.qp(this.F);this.F=window.NaN;var a=this.o;window.clearInterval(a.F);a.F=window.NaN;g.qp(this.A)};g.hU={"default":0,monoSerif:1,propSerif:2,monoSans:3,propSans:4,casual:5,cursive:6,smallCaps:7};g.Wla=Object.keys(g.hU).reduce(function(a,b){a[g.hU[b]]=b;return a},{});
g.iU={none:0,raised:1,depressed:2,uniform:3,dropShadow:4};g.Xla=Object.keys(g.iU).reduce(function(a,b){a[g.iU[b]]=b;return a},{});
g.jU={normal:0,bold:1,italic:2,bold_italic:3};g.Yla=Object.keys(g.jU).reduce(function(a,b){a[g.jU[b]]=b;return a},{});g.r(SB,Ts);g.h=SB.prototype;g.h.Da=function(){var a=lI(this.app);2==a&&$M(this.app)&&(a=1);return a};
g.h.hw=function(a,b,c,d,e){return QS(this.app,a,b,c,d,e)};
g.h.kF=function(a,b,c){this.app.g.G.add(a,{ql:b,Nr:c})};
g.h.wm=function(a,b){MS(this.app,a,b||this.playerType)};
g.h.Kd=function(a){return yS(this.app,a)};
g.h.Tj=function(a,b,c,d){g.IS(this.app,a,c||this.playerType,b,d)};
g.h.xm=function(a,b,c,d){c=void 0===c?window.NaN:c;var e=this.app;b=b||this.playerType;d=void 0===d?"":d;b=void 0===b?1:b;c=void 0===c?window.NaN:c;d=void 0===d?"":d;var f=Lx(a);e.Va.get(b+f)||e.o&&e.o.getVideoData().videoId==f||(e.g.Sb&&Yy(a),a=new g.Xz(e.g,a),f=c,c=d,a.mh=!0,d=XQ(e,b),JG(d,a,(0,g.z)(e.kd,e)),!g.R(e.g.experiments,"unplugged_tvhtml5_video_preload_no_dryrun")&&1==b&&"TVHTML5_UNPLUGGED"==e.g.l.c||PG(d,!0),g.R(e.g.experiments,"html5_expire_preloaded_players")&&!f&&(f=3600),e.Va.set(b+
a.videoId,d,f),d="prefetch_"+a.videoId,Jz("prefetch",["pfp"],void 0,d),(0,g.WB)("docid",a.videoId,d),(0,g.WB)("plt",b,d),(0,g.WB)("c",e.g.l.c,d),(0,g.WB)("cver",e.g.l.cver,d),c&&(0,g.WB)("pftr",c,d))};
g.h.gi=function(a,b){aS(this.app,a,b)};
g.h.Qj=function(a){PS(this.app,a)};
g.h.zd=function(a,b,c){YS(this.app,sS(this.app)+a,b,c,this.playerType)};
g.h.Ab=function(a,b,c,d){YS(this.app,a,b,c,d||this.playerType)};
g.h.NF=function(a){if(a){var b=this.getPlaylistId();if(!b||b==a.list){var c=a.video;(b=this.app.F)?this.isFullscreen()&&((c=c[b.Ua])&&c.encrypted_id!=b.za().videoId||(a.index=b.Ua)):iS(this.app,{list:a.list,index:a.index,playlist_length:c.length});iC(this.app.F,a);this.na("onPlaylistUpdate")}}else a=this.app,jS(a),a.l.na("onPlaylistUpdate")};
g.h.MF=function(){Cr()};
g.h.OF=function(a,b){var c=g.W(this.app,this.playerType||1);c&&c.getVideoData().Lf(a,b)};
g.h.getPlayerResponse=function(){var a=g.W(this.app,this.playerType);return a?a.getVideoData().getPlayerResponse():null};
g.h.getStoryboardFormat=function(){return this.app.getStoryboardFormat()};
g.h.qF=function(a,b){var c=this.app.Xd();if(!c)return null;c=c.g[b];return c?(c=g.$y(c,a))?{column:c.column,columns:c.columns,height:c.height,row:c.row,rows:c.rows,url:c.url,width:c.width}:null:null};
g.h.rF=function(a,b){var c=this.app.Xd();return c?(c=c.g[b])?c.Im(a):-1:-1};
g.h.sF=function(a){var b=this.app.Xd();return b?(b=b.g[a])?{index:a,intervalMs:b.g,maxFrameIndex:b.ak(),minFrameIndex:b.uq()}:null:null};
g.h.pF=function(){var a=this.app.Xd();return a?a.g.length:0};
g.h.nF=function(){var a=this.app.g;return{Sb:a.Sb,sb:a.sb}};
g.h.getVideoData=function(){var a=Ts.prototype.getVideoData.call(this),b=g.W(this.app,this.playerType);b&&(b=b.getVideoData(),a.backgroundable=b.backgroundable,a.eventId=b.eventId,a.cpn=b.clientPlaybackNonce,a.hasVideoContentProtection=!!g.qA(b),a.isLive=b.ra,a.itct=b.Ph,a.paidContentOverlayText=g.rA(b),a.paidContentOverlayDurationMs=g.sA(b),null!=b.liveUtcStartSeconds&&(a.liveUtcStartSeconds=b.liveUtcStartSeconds));return a};
g.h.ya=function(a,b){return a?sS(this.app,a,b):Ts.prototype.ya.call(this)};
g.h.ec=function(a,b){return a?tS(this.app,a,b):Ts.prototype.ec.call(this)};
g.h.fh=function(a){if(3==this.Da())return g.$H(this.app.C).fG();var b=this.app.getVideoData(),c=g.W(this.app,a)||g.W(this.app),d=c.getPlayerType(),e=this.ya(a);a=this.ec(a);var f=uS(this.app,d);c=g.R(this.app.g.experiments,"web_player_pegged_to_live_killswitch")?pH(c):this.app.isPeggedToLive(d);var k=this.app;var l=g.W(k,void 0);if(l){l=dS(k,l);var m=window.NaN;l.l&&(m=cB(l.l));m=0<=m?m:l.tb();k=rS(k,m,l)}else k=0;l=this.app.zb(d);m=this.app;(d=g.W(m,d))?(d=cS(m,d),d=rS(m,NH(d),d)):d=0;return{allowSeeking:this.app.ac(),
clipEnd:b.clipEnd,clipStart:b.clipStart,current:e,displayedStart:-1,duration:a,ingestionTime:f,isPeggedToLive:c,loaded:k,seekableEnd:d,seekableStart:l}};
g.h.Up=function(a){return gS(this.app,a)};
g.h.Ij=function(a){return Bt(a)};
g.h.Sj=function(){var a=g.W(this.app);if(a)if(a.O){var b=a.sa;a=a.O;var c=Cu(a.videoData.En,a.videoData.Yn);"auto"!=sx()||(c=Cu(c,FF(b,a)));b=Du(c)}else b="auto";else b="unknown";return b};
g.h.uw=function(a,b){var c=g.W(this.app,this.playerType);if(c){var d=zu(a,b||a,!0,"m");c.g.En=d;if(c.O){var e=c.O;if(e.xa.g){var f=g.jt[sx()];e=e.xa.videoInfos[0].za().g;f>e&&0!=e&&d.g==e||g.os("yt-player-quality",Du(d),2592E3)}}sH(c)}};
g.h.mF=function(){return g.W(this.app).getPlaylistSequenceForTime(sS(this.app))};
g.h.getPlaylistSequenceForTime=function(a){return g.W(this.app).getPlaylistSequenceForTime(a)};
g.h.we=function(a){var b=this.app,c=g.W(b,this.playerType);c&&b.g.nb.has(a.toString())&&c.A&&(b=LB(c.A,"engage"),b.o=a,b.send(void 0))};
g.h.Uj=function(a,b,c){var d=this.app.C.o;d&&d.Hj()&&d.Mp(a,b,c)};
g.h.vF=function(a,b){var c=g.bt(this);c&&c.iq(a,b)};
g.h.wF=function(a){var b=g.bt(this);b&&b.jq(a)};
g.h.getAudioTrack=function(){var a=g.W(this.app,this.playerType);return a?a.getAudioTrack():this.app.getVideoData().Vi};
g.h.Zp=function(a){3==this.Da()&&g.$H(this.app.C).Wj("control_set_audio_track",a);var b=g.W(this.app,this.playerType);if(b&&!b.ea()&&!g.U(b.o,128))if(b.g.xa.g){if(b=b.B,!b.ea()){var c=b.F;c.B=c.C.g[a.id];c.O=c.B;b.P("audioformatchange",new kC(c.O,c.A,"m"));b.P("reattachrequired")}}else{a:if(c=b.g,c.Yb&&!ut(c.Yb)||a==c.rk||!c.De||0>=c.De.length)c=!1;else{for(var d=g.q(c.De),e=d.next();!e.done;e=d.next()){e=e.value;if(!(e instanceof Ty)){c=!1;break a}var f=a.ib.getId();e.l&&(e.l.l=f,e.g=null)}c.rk=
a;c=!0}c&&(b.P("internalaudioformatchange",b.g,!0),RG(b)&&b.Za("hlsaudio",a.id))}};
g.h.getAvailableAudioTracks=function(){return g.W(this.app,this.playerType).getAvailableAudioTracks()};
g.h.oF=function(){var a=g.W(this.app,this.playerType);return a&&a.getVideoData().ua?Du(a.O?HF(a.sa,a.O,dH(a)):Bu):"unknown"};
g.h.tF=function(){var a=g.W(this.app,this.playerType);return a?a.g.xa&&!a.g.xa.g?Du(a.g.En):sx():"auto"};
g.h.GF=function(a,b){var c=this.app;c.ie=a;c.cd=b;c.l.P("sizestylechange",a,b);c.G.xe()};
g.h.lF=function(){var a=this.app.C.G;a&&a.pC()};
g.h.ww=function(){var a=g.bt(this);a&&a.Bm(!0)};
g.h.rw=function(){var a=g.bt(this);a&&a.Bm(!1)};
g.h.Cf=function(){var a=this.app.g;a=this.app.H.g&&!g.R(a.experiments,"kevlar_miniplayer_disable_vis");var b=this.isFullscreen()||g.Yx(this.app.g);return this.Zg()?4:kG()?3:b?2:a?1:this.app.H.A?5:this.app.H.C?7:0};
g.h.isFullscreen=function(){return this.app.isFullscreen()};
g.h.yF=function(){return this.app.H.A};
g.h.Zg=function(){var a=g.W(this.app,this.playerType);return!!a&&a.L.l};
g.h.JF=function(){return!0};
g.h.qw=function(a){a=g.hK(this.app.G,a);return{left:a.left,top:a.top,width:a.width,height:a.height}};
g.h.FF=function(a){this.app.g.enableSafetyMode=a};
g.h.IF=function(a){this.app.g.Oc!=a&&(this.app.g.Oc=a,(a=g.W(this.app,this.playerType))&&sH(a))};
g.h.AF=function(a){g.tq();VS(this.app,a?2:0)};
g.h.Ad=function(){this.app.g.externalFullscreen?this.isFullscreen()?vq(window.document.documentElement):sq(window.document.documentElement):g.tq()?this.isFullscreen()?vq(SS(this.app)):sq(this.app.G.element):this.na("onFullscreenToggled",this.isFullscreen())};
g.h.Xp=function(){var a=this.app.C.A;a&&a.created&&(a.unload(),a.created=!1);(a=g.W(this.app))&&FH(a);(a=this.app.C.J)&&a.qD()&&g.WH(this.app.Z,!0)};
g.h.Kc=function(){var a=this.app.g;!g.R(a.experiments,"disable_new_pause_state3")&&g.ny(a)&&"blazer"!=a.playerStyle?this.Xp():Ts.prototype.Kc.call(this)};
g.h.Lu=function(){return IH(g.W(this.app,this.playerType),!0)};
g.h.ym=function(a){this.app.C.l.Vr(a,!0)};
g.h.gh=function(){var a=this.app.C.l;return a?a.Io():null};
g.h.Yp=function(){this.app.C.l.iz()};
g.h.xF=function(){var a=g.W(this.app,this.playerType);if(!a)return!1;a=a.getVideoData();return!!a&&a.ld()&&!!a.ua&&a.ua.video.isAccelerated&&a.ua.video.o};
g.h.isPeggedToLive=function(a){return this.app.isPeggedToLive(void 0,void 0===a?!0:a)};
g.h.EF=function(a){var b=this.app,c=b.H;c.g!=a&&(c.g=a,c.B());a=b.C;(a=g.V(a.g).useMiniplayerUi?a.da:null)&&(b.H.g?a.load():a.unload());b.l.P("minimized")};
g.h.CF=function(a){var b=this.app.H;b.A!=a&&(b.A=a,b.B())};
g.h.Oj=function(a){return xS(this.app,a)};
g.h.Wp=function(a){if(a){var b=this.app.C.B;b&&b.aw(a)}};
g.h.Tp=function(){var a=this.app.C.B;return a?a.Zv():{}};
g.h.zF=function(a){var b=this.app;b.g.Rf=a;b.o&&(a=b.o,a.A&&g.NA(a.A.o),b.g.L&&$S(b))};
g.h.nd=function(a){this.P("aduxclicked",a)};
g.h.setVolume=function(a,b){Ys(this,a,b)};
g.h.mute=function(a){Zs(this,a)};
g.h.We=function(a){$s(this,a)};
g.h.sD=function(){return this.app.da};
g.h.fi=function(a){if("annotations_module"==a){var b=this.app.C.o;b&&!b.loaded&&b.load()}Ts.prototype.fi.call(this,a)};
g.h.Rj=function(a){if("annotations_module"==a){var b=this.app.C.o;b&&b.loaded&&b.unload()}Ts.prototype.Rj.call(this,a)};
g.h.md=function(a,b,c){if(!b)return null;var d=this.app.C;switch(a){case "ad":return(a=d.A)&&a.Bw&&a.Bw(b,c);case "remote":return(a=g.$H(d))&&a.eG(b,c);case "unplugged":return(a=g.hy(g.V(d.g))?d.C:null)&&a.o(b,c);case "spacecast":return(c=d.Z)&&c.B(b);case "annotations_module":return(a=d.o)&&a.gE(b,c);case "creatorendscreen":return(a=d.F)&&a.mE(b,c)}return Ts.prototype.md.call(this,a,b,c)};
g.h.bh=function(a){var b=this.app.C;switch(a){case "ad":return(b=b.A)&&b.Cw&&b.Cw();case "remote":return g.$H(b)&&["casting","receivers","currentReceiver","quickCast"];case "annotations_module":return(b=b.o)&&b.hE();case "creatorendscreen":return(b=b.F)&&b.nE();case "unplugged":return(g.hy(g.V(b.g))?b.C:null)&&"settingsMenuShown hideSettingsMenu setSettingsMenuParentNode showSettingsMenu getStoryboardFrameData getStoryboardFrameIndex getStoryboardFrameIntervalSeconds getStoryboardMaxFrameIndex".split(" ")}return a?
Ts.prototype.bh.call(this,a):(a=Ts.prototype.bh.call(this),b.A&&a.push("ad"),g.$H(b)&&a.push("remote"),b.o&&a.push("annotations_module"),b.F&&a.push("creatorendscreen"),g.hy(g.V(b.g))&&b.C&&a.push("unplugged"),a)};
g.h.eh=function(){var a=this.app.G.Ha();return{width:a.width,height:a.height}};
g.h.BF=function(a){var b=this.app.G;b.L=Kx(a,!0);b.xe()};
g.h.oN=function(){var a=g.bt(this);a&&a.kq()};
g.h.uF=function(){return g.DR(this.app.G)};
g.h.HF=function(a){var b=this.app.G;b.Y!=a&&(b.Y=a,b.xe())};
g.h.DF=function(a,b){var c=this.app.G,d=new g.ad(a,b);g.bd(c.B,d)||(c.B=d,c.xe())};
g.h.tw=function(){return $M(this.app)};
g.h.LF=function(a){var b=TB(this);b&&b.H(a)};
g.h.KF=function(a){var b=TB(this);b&&b.J(a)};UB.prototype.reset=function(){Bz("")};
UB.prototype.info=function(a,b){(0,g.WB)(a,b,"")};g.r(g.YB,g.G);g.YB.prototype.getId=function(){return this.Ga};
g.YB.prototype.toString=function(){return"CueRange{"+this.namespace+":"+this.Ga+"}["+ZB(this.start)+", "+ZB(this.end)+"]"};
g.YB.prototype.contains=function(a,b){return a>=this.start&&(a<this.end||a==this.end&&this.start==this.end)&&(null==b||a<b&&b<=this.end)};
var lha=1;g.YB.prototype.getId=g.YB.prototype.getId;g.bC.prototype.toString=function(){return this.type+this.id};g.r(g.dC,g.N);g.h=g.dC.prototype;g.h.hasNext=function(a){return this.loop||!!a||this.Ua+1<this.kg};
g.h.Pe=function(a){return this.loop||!!a||0<=this.Ua-1};
g.h.za=function(a,b,c){a=void 0!=a?a:this.Ua;a=this.Ea&&a in this.Ea?this.Ea[this.Cd[a]]:null;var d=null;a&&(b&&(a.autoplay="1"),c&&(a.autonav="1"),d=new g.Xz(this.Ra,a),g.I(this,d),d.startSeconds=this.startSeconds||d.clipStart||0,this.listId&&(d.playlistId=this.listId.toString()));return d};
g.h.setShuffle=function(a){this.Lz=a;a=this.Cd&&null!=this.Cd[this.Ua]?this.Cd[this.Ua]:this.Ua;this.Cd=[];for(var b=0;b<this.Ea.length;b++)this.Cd.push(b);this.Ua=a;this.im++;if(this.Lz){a=this.Cd[this.Ua];for(b=1;b<this.Cd.length;b++){var c=Math.floor(Math.random()*(b+1)),d=this.Cd[b];this.Cd[b]=this.Cd[c];this.Cd[c]=d}for(b=0;b<this.Cd.length;b++)this.Cd[b]==a&&(this.Ua=b);this.im++}this.P("shuffle")};
g.h.tc=function(a){a=a||"hqdefault.jpg";var b=this.tg[a];if(b||this.Ra.F||"sddefault.jpg"==a||"hq720.jpg"==a||"maxresdefault.jpg"==a)return b;if(this.Tz.length)return g.my(this.Ra,this.Tz[0],a)};
g.h.getLength=function(){return this.kg};
g.h.cj=function(a){if(a&&(a=a.videoId,!this.Ea[this.Ua]||this.Ea[this.Ua].video_id!=a))for(var b=0;b<this.Ea.length;b++)if(this.Ea[b].video_id==a){this.Ua=b;break}};
g.h.onReady=function(a){this.pk=a;this.Te&&g.op(this.pk,0)};
g.h.getPlaylistId=function(){return this.listId?this.listId.toString():null};
g.h.kj=function(){return this.Ra.getVideoUrl(this.za().videoId,this.getPlaylistId())};
g.h.U=function(){this.pk=null;g.Ye(this.Ea);g.N.prototype.U.call(this)};g.r(g.jC,g.ZA);g.h=g.jC.prototype;g.h.hg=function(){return!0};
g.h.ue=function(){return!1};
g.h.ia=function(){return this.g};
g.h.Rc=function(){return this.g.src};
g.h.sm=function(a){var b=this.Pb();this.g.src=a;this.be(b)};
g.h.lr=function(){this.g.removeAttribute("src")};
g.h.Pb=function(){try{return 0<=this.g.playbackRate?this.g.playbackRate:1}catch(a){return 1}};
g.h.be=function(a){this.Pb()!=a&&(this.g.playbackRate=a);return a};
g.h.nm=function(){return this.g.loop};
g.h.rm=function(a){this.g.loop=a};
g.h.Ij=function(a,b){return this.g.canPlayType(a,b)};
g.h.ah=function(){return this.g.paused};
g.h.dm=function(){return this.g.seeking};
g.h.Sg=function(){return this.g.ended};
g.h.pm=function(){return this.g.muted};
g.h.ci=function(a){Gt();this.g.muted=a};
g.h.hj=function(){return this.g.played||Lt([],[])};
g.h.Le=function(){try{var a=this.g.buffered}catch(b){}return a||Lt([],[])};
g.h.Ml=function(){return this.g.seekable||Lt([],[])};
g.h.Lj=function(){return this.g.getStartDate?this.g.getStartDate():null};
g.h.ya=function(){return this.g.currentTime};
g.h.jn=function(a){this.g.currentTime=a};
g.h.ec=function(){return this.g.duration};
g.h.load=function(){var a=this.g.playbackRate;this.g.load&&this.g.load();this.g.playbackRate=a};
g.h.pause=function(){this.g.pause()};
g.h.play=function(){var a=this.g.play();return a&&a.then?a:null};
g.h.ae=function(){return this.g.readyState};
g.h.Kl=function(){return this.g.networkState};
g.h.Ue=function(){return this.g.error?this.g.error.code:null};
g.h.Jj=function(){return this.g.error?this.g.error.message:""};
g.h.Rp=function(){var a={};if(this.g){if(this.g.getVideoPlaybackQuality)return this.g.getVideoPlaybackQuality();this.g.webkitDecodedFrameCount&&(a.totalVideoFrames=this.g.webkitDecodedFrameCount,a.droppedVideoFrames=this.g.webkitDroppedFrameCount)}return a};
g.h.Zg=function(){return!!this.g.webkitCurrentPlaybackTargetIsWireless};
g.h.Mj=ba(9);g.h.Nj=ba(11);g.h.Qp=function(){return qh(this.g)};
g.h.Kj=function(){return g.Bh(this.g)};
g.h.Jb=function(){return this.g.volume};
g.h.setVolume=function(a){Gt();this.g.volume=a};
g.h.wo=function(a){if(!this.C[a]){var b=(0,g.z)(this.LE,this);this.g.addEventListener(a,b);this.C[a]=b}};
g.h.LE=function(a){this.dispatchEvent(new fB(this,a.type,a))};
g.h.setAttribute=function(a,b){this.g.setAttribute(a,b)};
g.h.removeAttribute=function(a){this.g.removeAttribute(a)};
g.h.hasAttribute=function(a){return this.g.hasAttribute(a)};
g.h.Ji=ba(13);g.h.yk=ba(15);g.h.th=ba(6);g.h.Si=ba(17);g.h.Yi=function(){vq(this.g)};
g.h.ij=function(a){return lh(this.g,a)};
g.h.U=function(){for(var a in this.C)this.g.removeEventListener(a,this.C[a]);g.ZA.prototype.U.call(this)};pC.prototype.reset=function(){this.Z=sC(this);rC(this);this.g=new oC(0,0,null);this.A=8;this.o=[];this.F=[];this.B=this.H=window.NaN;this.l=this.J=0;this.O=!1};
pC.prototype.process=function(a){var b=!1;if(this.o.length){if(vC(this)&&this.o.length+a.byteLength<this.A)return wC(this,a,0),0;b=this.o.length;var c=new window.Uint8Array(b+a.byteLength);c.set(this.o,0);c.set(new window.Uint8Array(a.buffer,a.byteOffset,a.byteLength),b);this.o=[];a=new window.DataView(c.buffer);b=!0}for(var d=c=0;c<a.byteLength;){var e=a.byteLength-c,f=window.NaN;if(vC(this)){if(e<this.A)return wC(this,a,c),0;switch(this.g.type){case 0:f=tC(this,a,c);b||0!=c||(d=this.g.type);break;
case 1836019574:case 1836019558:f=tC(this,a,c);break;case 1953653094:e=a;f=c;if(!this.J){var k=this.R.Kk?this.l:1;this.J=Xu(xC(this,e,f),k)}f=tC(this,e,f);break;case 1836476516:this.l=Zu(xC(this,a,c));uC(this);f=this.g.size-8;break;case 1952867444:e=void 0;(0,window.isNaN)(this.B)||(f=xC(this,a,c),this.R.Ja?e=this.Y(ev(f),this.l):e=this.B,dv(f,e),(0,window.isNaN)(this.C)&&(this.C=e),this.B+=this.J,this.T+=this.J);f=this.g.size-8;break;case 1936286840:e=xC(this,a,c),f=fv(e).wk[0],this.l=gv(e),uC(this),
this.J=f,f=this.g.size-8}}else f=Math.min(this.A,e);this.g.offset+=f;this.A-=f;c+=f;if(0==this.A){for(;0!=this.g.type&&this.g.offset==this.g.size&&this.g.parent;)1835295092==this.g.type&&(this.O=!0),this.g.parent.offset+=this.g.size,this.g=this.g.parent;switch(this.g.type){case 0:case 1836019574:case 1836019558:case 1953653094:this.A=8;break;default:this.A=this.g.size-8}}}0<a.byteLength&&this.F.push(a);return d};var zha=0;g.h=PC.prototype;g.h.xM=function(a){this.status=a.status;a.ok?(this.B=a.body.getReader(),this.F?this.B.cancel("Cancelling"):(this.J=a.headers,this.Z(),this.o=new window.Uint8Array(RC(this)),VC(this))):XC(this)};
g.h.MI=function(a){if(!this.F){var b;window.performance&&window.performance.now&&(b=window.performance.now());var c=(0,g.D)(),d=a.value?a.value:null;(0,g.D)();a.done?(this.B=null,XC(this)):(WC(this)?(UC(this,d),this.T(c,this.l,b)):(a=this.l,this.C.Cs&&(a+=d.length),this.T(c,a,b),UC(this,d)),VC(this))}};
g.h.Aw=function(a){this.L=""+a;this.G=!0;XC(this)};
g.h.Bd=function(a){return this.J.get(a)};
g.h.rj=function(){return!!this.J};
g.h.zo=function(){return this.l};
g.h.Il=function(){return+this.Bd("content-length")};
g.h.Zu=function(){return 200<=this.status&&300>this.status&&!!this.l};
g.h.Ug=function(){return!!this.A.length||(this.H||WC(this))&&0<this.g};
g.h.Fz=function(){this.Ug();this.A.length||SC(this);return this.A.shift()};
g.h.xw=function(){this.Ug();this.A.length||SC(this);return this.A[0]};
g.h.abort=function(){this.B&&this.B.cancel("Cancelling");this.F=!0};
g.h.Pz=function(){return!0};
g.h.bz=function(){return this.G};
g.h.cq=function(){return this.L};g.h=YC.prototype;g.h.PF=function(){if(!this.l){this.status=this.g.status;try{this.response=this.g.response}catch(a){}this.o=!0;this.A()}};
g.h.RF=function(){2==this.g.readyState&&this.B()};
g.h.QF=function(a){this.l||(this.status=this.g.status,this.C(a.timeStamp,a.loaded))};
g.h.rj=function(){return 2<=this.g.readyState};
g.h.Bd=function(a){try{return this.g.getResponseHeader(a)}catch(b){return g.M(b),""}};
g.h.Il=function(){return+this.Bd("content-length")};
g.h.zo=function(){return this.response.byteLength};
g.h.Zu=function(){return 200<=this.status&&300>this.status&&!!this.response&&!!this.response.byteLength};
g.h.Ug=function(){return this.o&&!!this.response&&!!this.response.byteLength};
g.h.Fz=function(){this.Ug();var a=this.response;this.response=null;return new window.Uint8Array(a)};
g.h.xw=function(){this.Ug();return new window.Uint8Array(this.response)};
g.h.abort=function(){this.l=!0;this.g.abort()};
g.h.Pz=function(){return!1};
g.h.bz=function(){return!1};
g.h.cq=function(){return""};g.h=ZC.prototype;g.h.Ib=function(){return this.B?this.B.Ib():""};
g.h.start=function(a){cD(this,2);this.G=ZC.g();this.l?(this.O=vfa(this.info,this.l.o,this.l.length),this.B=g.zw(this.info,this.o,this.Z,this.O)):(this.O=this.info.range,this.B=g.zw(this.info,this.o,this.Z));var b=!1;if(this.o.sa&&2>this.info.l.g&&this.J){var c=this.B.get("aitags");if(c&&(yw(this.info)||xw(this.info))&&this.Y&&"auto"==sx()&&ux()){var d=kb(c).split(","),e=[];(0,g.C)(this.Y,function(a){g.Ma(d,a)&&e.push(a)});
0<e.length&&(this.B.set("altitags",g.jb(e.join(","))),b=!0)}}b||(this.J=!1);this.B.set("rn",this.G.toString());0<=a&&this.B.set("rbuf",(1E3*a).toFixed().toString());a=this.B.Ib();try{this.g=Bha(this,a)}catch(f){this.A="net.ssl";dD(this);return}0<this.o.H&&this.R.start()};
g.h.iM=function(){this.F=0;this.info.l.A=g.qr();var a=bD(this);a.B=g.qr();a.o+=1;a=this.timing;a.g=(0,g.D)();a.C=a.g;a.o=0;a.ha=a.g;a.R=0;a.G&&(a.G=[]);a.ga=!1;a.ka=!1;a.B=0;a.da=Fx(a.l);a.H=window.Infinity;a.L=window.Infinity;KC(a);MC(a,a.g);a.X=(a.T-a.g)/1E3;a.J=window.NaN;a.Y=null};
g.h.hM=function(a,b,c){if(!this.ea()&&this.g){this.C=this.g.status;lD(this,!1);var d=this.timing;a=a>d.g&&4E12>a?a:(0,g.D)();IC(d,a,b);50>a-d.C&&JC(d)&&3!=CC(d)||GC(d,a,b,c);b=this.timing;b.o>b.Ca&&DC(b,b.o)&&4>this.state?cD(this,4):iD(this)&&kD(this)&&cD(this,Math.max(3,this.state))}};
g.h.gM=function(){if(!this.ea()&&this.g){if(!this.T&&this.g.rj()&&this.g.Bd("X-Walltime-Ms")){var a=(0,window.parseInt)(this.g.Bd("X-Walltime-Ms"),10);this.T=((0,g.D)()-a)/1E3}this.g.rj()&&this.g.Bd("X-Restrict-Formats-Hint")&&this.o.As&&!ux()&&g.os("yt-player-headers-readable",!0,2592E3)}};
g.h.fM=function(){var a=this.g;if(!this.ea()&&a){this.R.stop();this.C=a.status;var b=!1;if(400<=a.status)b=!0,this.A="net.badstatus";else if(a.Zu()){var c="";jD(this)&&(c=a.xw(),2048<c.length?c="":(c=lv(c),c=As(c)?c:""));if(c){a=bD(this);g.qr();a.o=0;a.l=0;a.g=0;a=this.info;var d=this.B;g.uw(a.l,d,c);a.requestId=d.get("req_id");cD(this,5)}else if(c=a.zo(),(d=!!this.O&&this.O.length)&&d!=c||a.bz())b=!0,this.A="net.closed";else{lD(this,!0);var e=hD(this)?a.Bd("X-Bandwidth-Est"):0;if(a=hD(this)?a.Bd("X-Bandwidth-Est3"):
0)this.X=!0,this.o.yA&&(e=a);a=this.timing;d=(0,g.D)();e=e?(0,window.parseInt)(e,10):0;if(!a.ga){a.ga=!0;d=d>a.g&&4E12>d?d:(0,g.D)();IC(a,d,c);GC(a,d,c);var f=CC(a);if(2==f&&e)FC(a,a.o/e,a.o);else if(2==f||1==f)e=(d-a.g)/1E3,(e<=a.l.policy.B||!a.l.policy.B)&&!a.ka&&JC(a)&&FC(a,e,c),JC(a)&&Ax(a.l,c,a.B);c=a.l;d=(d-a.g)/1E3;e=a.X;f=xw(a.Z);c.C.l(d,a.o/d);c.o=g.qr();f||c.l.l(1,d-e);a.A&&(a.A=!1)}a=bD(this);g.qr();a.o=0;a.l=0;a.g=0;this.info.l.g=0;cD(this,6)}}else b=!0,this.A=204==a.status?"net.nocontent":
"net.connect";b&&dD(this)}};
g.h.DM=function(){if(!this.ea()){var a=(0,g.D)(),b=!1;JC(this.timing)?(a=this.timing.T,MC(this.timing),this.timing.T-a>=.8*this.o.H?(this.F++,b=5<=this.F):this.F=0):(b=this.timing,b.F&&LC(b,(0,g.D)()),a-=b.O,this.o.cd&&0<a&&(this.F+=1),b=a>1E3*this.o.Cb);this.F&&this.H&&this.H(this);b?gD(this,!1):this.R.start()}};
g.h.ea=function(){return-1==this.state};
g.h.dispose=function(){xw(this.info)&&6!=this.state&&(this.info.g[0].g.C=!1);cD(this,-1);this.H=null;this.R.dispose();fD(this)};
ZC.g=function(){return++ZC.l};
ZC.DEBUG=!1;ZC.l=0;g.r(mD,g.N);BD.prototype.Z=function(a,b){switch(b.info.type){case 1:case 2:rD(this.o,b);break;case 4:var c=b.info.g.Uv(b),d=b.info,e=this.l;e&&e.g==d.g&&e.type==d.type&&(d.range&&e.range?e.range.start==d.range.start&&e.range.end==d.range.end:e.range==d.range)&&e.l==d.l&&e.o==d.o&&e.Na==d.Na&&(this.l=g.Ha(c).info);(0,g.C)(c,(0,g.z)(this.Z,this,a));break;case 3:Eha(this.o,a,b)}};
BD.prototype.Y=function(a){a=a.info;this.B&&(this.R=this.B);this.B=a;a.g.info.g>=this.J&&(this.J=a.g.info.g)};iE.prototype.send=function(){g.Fp(this.l,{format:"RAW",responseType:"arraybuffer",timeout:1E4,Yc:this.o,pd:this.o,context:this});this.g=g.qr()};
iE.prototype.o=function(a){var b={rc:a.status,lb:a.response?a.response.byteLength:0,rt:((g.qr()-this.g)/1E3).toFixed(3),shost:g.yg(this.l),trigger:this.C};204==a.status||a.response?this.A&&this.A(Py(b)):this.B(new g.Oy("pathprobe.net",!1,b))};g.r(jE,g.N);g.r(tE,g.G);tE.prototype.A=function(a){if(!this.ea()){for(var b=arguments.length-1;0<=b;b--){var c=arguments[b];if(c){g.Qa(this.o,c);var d=this.g,e=d.g;c=g.Za(e,c,d.l);0<=c&&g.Pa(e,c)}}this.l()}};
tE.prototype.reset=function(){this.C=!1;this.F.stop();this.g.g=[];this.o=[];this.l()};
tE.prototype.l=function(){this.G=!0;if(!this.H){for(var a=3;this.G&&a;)this.G=!1,this.H=!0,Yha(this),this.H=!1,a--;g.pB(this.J())&&(a=rE(this.g,this.B),!(0,window.isNaN)(a)&&0x7ffffffffffff>a&&(a=(a-this.B)/this.T(),this.F.start(a)))}};
tE.prototype.U=function(){this.o=[];this.g.g=[];g.G.prototype.U.call(this)};xE.prototype.then=function(a,b){return this.o.then(a,b)};
xE.prototype.resolve=function(a){this.l(a)};
xE.prototype.reject=function(a){this.g(a)};g.r(zE,g.N);g.h=zE.prototype;
g.h.initialize=function(a,b,c,d){a=a||0;var e=this.F;d=d&&d.id;$D(e,b);Mha(e,d);e.O=e.B;Nha(e);e.A=e.o;b=eE(e);this.o=new BD(this.l,b.audio,(0,g.z)(this.mt,this));this.g=new BD(this.l,b.video,(0,g.z)(this.mt,this));this.l.ha&&this.C.l&&(this.nb=new tha(this.l,this.g.g.index));VE(this,this.o);VE(this,this.g);this.g.o.R=this.o.o;this.P("videoformatchange",b);this.L=this.g.F;this.G&&kE(this.G,this.g.g);this.l.F&&NC()&&this.Wc("streaming","1",!0);this.B=this.C.l?0:a;c?(BE(this,!1),g.In(this.pa)):(a=0==
this.B,XE(this,this.g,this.g.g,a),XE(this,this.o,this.o.g,a),this.seek(this.B),this.yc("gv"))};
g.h.resume=function(){if(this.Y||this.Z)this.Ca=this.Z=this.Y=!1,this.Ld()};
g.h.cL=function(a){var b=this.l.cd;if(!(!(b&&2<=a.state)||5<=a.state||a.F<b||qw(a.info.l,this.l,this.ba))){b=this.ba;var c=gw(pw(a.info.l));b=bw(b,c);b.g||b.l||b.o||NE(this,a,!0)}if(!this.ea()&&3<=a.state)if(c=a.info.g[0].g,b=!this.wa&&c.info.video,c=!this.ka&&c.info.audio,5==a.state?b?this.yc("vrr"):c&&this.yc("arr"):6==a.state?b?(this.wa=a.Ib(),Br(4)):c&&(this.ka=a.Ib()):4==a.state&&b&&Br(4),5<=a.state&&(this.l.ba&&(b=BC(a.timing),c=a.timing,b={rn:a.G.toString(),rt:b.rt,pt:b.pt,stall:b.stall,elt:b.elbowTime,
elb:b.elbowBytes,rqd:c.G?c.G.join(""):""},c=b.rqd,delete b.rqd,c&&this.Wc("rqd",Py({rn:b.rn,d:c})),this.Wc("rqs",Py(b))),a.X&&this.Wc("sbwe3","1",!0)),5==a.state)a.start(Math.max(0,a.info.g[0].C-this.B));else if(5<=a.state&&5==a.info.g[0].type)6==a.state&&(b=(a.info.g[0].g.info.video?this.g:this.o).A[0]||null)&&b.F&&gD(b,!0),a.dispose();else{if(this.l.sa&&a.J&&4<=a.state&&5!=a.state)if(b=a.g?a.g.Bd("X-Response-Itag"):null){b=Oha(this.F,b);c=a.info.range.length-b.Jl();b.C=!0;a.info.g[0].g.C=!1;var d=
b.Ih(c)[0];a.info=d;if(a.l){c=a.l;d=d.g;c.l=d;for(var e=0;e<c.g.length;e++)c.g[e].info=d[e],c.g[e].range=d[e].range}a.J=!1;c=this.g;c.g!=b&&(c.g=b);c=this.g;c.l&&(c.l.g=b);this.P("constraint",b.info.za().quality);(c=a.g?a.g.Bd("X-Segment-Lmt"):null)&&b instanceof g.Tw&&((0,window.isNaN)(b.lastModified)||b.lastModified==c||MD(this.g,a))}else a.J=!1;6==a.state||this.l.F&&3<=a.state&&!(5<=a.state)?aia(this,a):7==a.state&&(b=a.info.g[0].g,eD(a)?(c=(b.info.video&&1<b.A.g||410==a.C||500==a.C||503==a.C)&&
!gE(this.F),d=aD(a),e=b.info.video?this.g:this.o,c&&(d.stun="1"),PE(this,!1,a.A,d),this.ea()||(c&&fE(this.F,b),this.l.dd&&1==a.info.g.length&&0<a.info.g[0].o&&b!=e.g&&this.Z?this.P("reattachrequired"):(MD(e,a),this.Ld()))):(PE(this,!1,a.A,aD(a)),xw(a.info)?(b.B=a.A,this.Ld()):PE(this,!0,"net.retryexhausted",{})));this.Ld();this.l.Ca&&5<=a.state&&eD(a)&&qw(a.info.l,this.l,this.ba)&&(b=this.ba,c=gw(a.info.l.o),b=bw(b,c),c=b.o+=b.A,c=this.l.Ca*Math.pow(1.6,c),b.g||b.B+c>g.qr()||NE(this,a,!1))}};
g.h.Ld=function(){FE(this);if(this.A&&Wt(this.A)&&!Zt(this.A)){var a=this.l.Tk&&this.g.B&&this.g.B.G;this.C.isLive&&!a?(0,window.isNaN)(this.J)?(this.J=this.B+3600,this.A.o.duration=this.J):this.J<=this.B+1800&&(this.J=Math.max(this.J+1800,this.B+3600),this.A.o.duration=this.J):this.A.C||(a=Math.max(this.o.g.index.Jg(),this.g.g.index.Jg()),(!(0,window.isFinite)(this.J)||this.J!=a)&&0<a&&(this.J=this.A.o.duration=a))}if(!this.ea())if(jx(this.C)&&3==this.C.C)PE(this,!0,"manifest.net.retryexhausted",
{rc:this.C.O.toString()});else if(this.C.o&&(TD(this.g)||TD(this.o)))DE(this),this.P("seekplayerrequired",window.Infinity);else if(FE(this),ED(this.g),!this.ea()&&(ED(this.o),!this.ea())){this.C.l&&(UD(this.g),UD(this.o),cia(this),(a=nD(this.g.o))&&a.l&&(a=a.l.B&&!this.l.Y,this.Wc(a==this.l.g?"strm":"strmbug","strm."+(a?"1":"0")+";sfmp4."+(this.l.g?"1":"0")+";dfs."+(this.l.Y?"1":"0"),!0)));if(this.A){a=this.A.g;var b=this.A.l;if(dia(this)){if(this.l.he){if(!a.pf()){var c=nD(this.o.o);c&&QE(this,a,
c)}b.pf()||(a=nD(this.g.o))&&QE(this,b,a)}}else{if(this.G){c=this.G;var d=this.o,e=Pt(this.A.l.Nb());if(c.B)c=Rha(c,e);else{if(e=nD(d.o)){var f=e.l;f&&f.B&&f.o&&(d=d.A.length?d.A[0]:null)&&3<=d.state&&7!=d.state&&0==d.info.o&&iD(d)&&(c.B=d,c.H=f,c.o=e.info,c.C=(0,g.D)()/1E3,c.G=c.C,c.F=c.o.startTime)}c=window.NaN}c&&this.P("seekplayerrequired",c,!0)}(c=TE(this,this.g,b,null))&&!this.Ta&&(this.Ta=(0,g.D)(),this.yc("vda"),Pz("vda"),this.Ja&&Br(4));if(!Yt(this.A)){b=Ot(b.Nb(),this.B+KE);if(!(0,window.isNaN)(b)||
GD(this.g)||!a.Nb().length){if(GD(this.g)||this.l.az)b=window.NaN;a=TE(this,this.o,a,b);c=c||a;a&&!this.Ja&&(this.Ja=(0,g.D)(),this.yc("ada"),Pz("ada"),this.Ta&&Br(4))}this.ea()||(!this.l.zs&&GD(this.g)&&GD(this.o)&&Wt(this.A)&&!Zt(this.A)&&(a=this.A,Wt(a)&&a.o.endOfStream(),a=this.O,rx(Fx(a)),a.B=g.qr()),c&&!au(this.A)&&g.In(this.da))}}}AE(this);XE(this,this.g,this.g.g,!1);XE(this,this.o,this.o.g,!1);a=this.o.g.B;b=this.g.g.B;if(a||b){c="net.retryexhausted";if("fmt.unparseable"==a||"fmt.unparseable"==
b)c="fmt.unparseable";PE(this,!0,c,{metadata:"1",video:this.g.g.B||"",audio:this.o.g.B||""})}else HE(this,this.g,this.o)&&LE(this,this.g,this.o),HE(this,this.o,this.g)&&LE(this,this.o,this.g),this.l.mz&&this.oa&&!this.Y&&Gx(this.O)&&(a=this.oa,b=(0,g.z)(this.P,this,"error"),c=this.l.os?(0,g.z)(this.Wc,this,"pathprobe"):null,(new iE(a,"cms",c,b)).send(),this.oa=""),this.l.Nk&&this.C.o&&g.In(this.pa),this.G&&(a=this.G,a.B?(b=a.G+a.g.fd,a.A||(b=Math.min(b,a.C+a.g.Ya)),a=Math.max(0,1E3*b-(0,g.D)())):
a=window.NaN,(0,window.isNaN)(a)||g.In(this.Mb,a)),g.In(this.Ya)}};
g.h.Nm=function(a){var b=a?this.o:this.g;a=b&&b.B;var c=b&&b.R;b=void 0;a&&(b=Nv(a));if(c){b=b||{};a=Nv(c);for(var d in a)b["prev_"+d]=a[d]}PE(this,!0,"fmt.unplayable",b)};
g.h.QJ=function(a){PE(this,!0,"fmt.unparseable",a)};
g.h.VJ=function(a,b,c){if(b){var d=Nv(b.info);d.dRange=""+b.range.start+"-"+b.range.end}else a?d=Nv(a.info.g[a.info.g.length-1]):d=[];d.warning=c;this.Wc("msw",Py(d))};
g.h.UJ=function(a){PE(this,!1,"qoe.avsync",a)};
g.h.RJ=function(a,b){this.C.l&&UE(this,b,a==this.g)};
g.h.SJ=function(a,b){this.C.l&&nx(this.C,b.vb,a==this.g)};
g.h.TJ=function(a,b){this.C.l&&UE(this,b,a==this.g)};
g.h.PJ=function(a,b){if(this.g&&this.g.g.index.rb()<=b){a.g+=(0,window.isNaN)(this.R)?0:this.R;var c=this.C;c.L.push(a);c.P("cuepointsadded")}};
g.h.seek=function(a){if(this.ea())return Uf();if(this.g.F||this.o.F)return Tf();FE(this);this.ab=g.qr();AE(this,a);var b=this.g.l,c=WE(this.g,a,this.A&&this.A.l),d=WE(this.o,this.l.wa?a:c,this.A&&this.A.g);this.B=Math.max(a,c,d);this.T=!0;this.C.l&&this.l.T&&(c=this.g.l.l,Gw(this.g.g.index,c)||b&&b.l==c||(this.L=!0));g.In(this.da);return Tf(a)};
g.h.U=function(){EE(this);this.o&&KD(this.o);this.g&&KD(this.g);g.N.prototype.U.call(this)};
g.h.yc=function(a,b){this.Wb[a]=b?window.performance.timing.navigationStart+b:g.qr()};
g.h.Wc=function(a,b,c){this.P("ctmp",a,b,void 0===c?!1:c)};
g.h.mt=function(a,b){var c=a/b;(0,window.isNaN)(this.R)&&(this.R=c-Math.min(c,18E3),this.P("timestamp",this.R));return(c-this.R)*b};
var KE=2/24;g.r(ZE,g.N);g.r(aF,ZE);aF.prototype.C=function(a,b){if(a&&b){var c=1*Mg(a,"cpi")+1;(0,window.isNaN)(c)||0>=c||c<this.o?(this.A.stop(),this.l.stop(),this.o=-1,this.g={}):(c>this.o&&(this.o=c,g.Qb(this.g)||(this.g={},this.A.stop(),this.l.stop())),this.g[b]=a,g.In(this.l))}};
aF.prototype.B=function(){for(var a in this.g)this.P("rotated_need_key_info_ready",new $E(gia(this.g[a],this.o,a),"fairplay",!0));this.g={}};var kU={},Zla=(kU.DRM_TRACK_TYPE_AUDIO="AUDIO",kU.DRM_TRACK_TYPE_SD="SD",kU.DRM_TRACK_TYPE_HD="HD",kU.DRM_TRACK_TYPE_UHD1="UHD1",kU);g.r(dF,g.G);dF.prototype.B=function(a){this.ea()||(0!=a.status&&a.response?((0,g.VB)("drm_net_r"),a=new window.Uint8Array(a.response),(a=cF(a))?this.o(a):this.g(this,"drm.net","t.p")):this.A(a))};
dF.prototype.A=function(a){this.ea()||this.g(this,a.status?"drm.net.badstatus":"drm.net.connect","t.r;c."+a.status)};
dF.prototype.F=function(a){if(!this.ea()){(0,g.VB)("drm_net_r");var b="LICENSE_STATUS_OK"==a.status?0:9999,c=null;try{c=g.Wd(a.license)}catch(m){}if(0!=b||c){c=new bF(b,c);0!=b&&a.reason&&(c.errorMessage=a.reason);if(a.authorizedFormats){b={};for(var d=[],e={},f=g.q(a.authorizedFormats),k=f.next();!k.done;k=f.next()){k=k.value;var l=Zla[k.trackType];l&&("HD"==l&&a.isHd720&&(l="HD720"),b[l]||(d.push(l),b[l]=!0),e[k.keyId]=l)}c.g=d;c.l=e}a=c}else a=null;a?this.o(a):this.g(this,"drm.net","t.p;p.i")}};
dF.prototype.C=function(a){this.ea()||(a=a.error,this.g(this,"drm.net.badstatus","t.r;p.i;c."+a.code+";s."+a.status))};g.r(eF,g.G);g.h=eF.prototype;g.h.XF=function(a){if(this.B){var b=a.messageType||"license-request";this.B.call(this.o,new window.Uint8Array(a.message),b)}};
g.h.YF=function(){this.G&&this.G.call(this.o,this.g.keyStatuses)};
g.h.Kx=function(a,b){g.M(b);if(this.A){var c=a;b instanceof window.DOMException&&(c+=";n."+b.name+";m."+b.message);this.A.call(this.o,c)}};
g.h.WF=function(){this.ea()||g.Kp("xboxone")&&this.A&&this.A.call(this.o,"closed")};
g.h.jy=function(a){this.B&&this.B.call(this.o,a.message,"license-request")};
g.h.iy=function(a){if(this.A){if(this.l){var b=this.l.error.code;a=this.l.error.systemCode}else b=a.errorCode&&a.errorCode.code,a=a.systemCode;this.A.call(this.o,"t.prefixedKeyError;c."+b+";sc."+a)}};
g.h.hy=function(){this.F&&this.F.call(this.o)};
g.h.update=function(a){if(this.g)return this.g.update(a).then(null,jp((0,g.z)(this.Kx,this,"t.update")));this.l?this.l.update(a):this.C.addKey?this.C.addKey(this.J.g,a,this.H,this.sessionId):this.C.webkitAddKey(this.J.g,a,this.H,this.sessionId);return cq()};
g.h.U=function(){this.g&&this.g.close();this.C=null;g.G.prototype.U.call(this)};g.r(fF,g.G);g.h=fF.prototype;
g.h.createSession=function(a){var b=a.initData;if(this.g.l){var c=this.B.createSession();"com.youtube.fairplay"==this.g.g&&(b=hF(this,b));b=c.generateRequest(a.contentType,b);c=new eF(null,null,null,c,null);b.then(null,jp((0,g.z)(c.Kx,c,"t.generateRequest")));return c}if(yy(this.g)){c=new window.Uint8Array(270);for(a=0;135>a;a++)c[2*a]='<PlayReadyCDMData type="LicenseAcquisition"><LicenseAcquisition version="1.0" Proactive="true"></LicenseAcquisition></PlayReadyCDMData>'.charCodeAt(a);b=this.o.createSession("video/mp4",
b,c);return new eF(null,null,null,null,b)}if(By(this.g))return b=hF(this,b),b=this.o.createSession("video/mp4",b),new eF(null,null,null,null,b);this.l.generateKeyRequest?this.l.generateKeyRequest(this.g.g,b):this.l.webkitGenerateKeyRequest(this.g.g,b);return this.A=new eF(this.l,this.g,b,null,null)};
g.h.cG=function(a){var b=iF(this,a);b&&b.jy(a)};
g.h.bG=function(a){var b=iF(this,a);b&&b.iy(a)};
g.h.aG=function(a){var b=iF(this,a);b&&b.hy(a)};
g.h.U=function(){g.G.prototype.U.call(this);delete this.l};var lU={},oia=(lU.widevine="DRM_SYSTEM_WIDEVINE",lU.fairplay="DRM_SYSTEM_FAIRPLAY",lU.playready="DRM_SYSTEM_PLAYREADY",lU);g.r(kF,g.G);g.h=kF.prototype;
g.h.UF=function(a,b){if(!this.ea()){if(!g.R(this.A.experiments,"html5_provisioning_killswitch"))switch(b){case "license-request":case "license-renewal":case "license-release":break;case "individualization-request":nia(this,a);return;default:this.o.P("ctmp","message_type","t."+b+";l."+a.byteLength)}this.O||((0,g.VB)("drm_gk_f"),this.O=!0,this.o.P("newsession",this));if(zy(this.l)){var c=lF(a);if(!c)return;a=c}"fairplay"==this.l.flavor&&(a=kv(g.Ud(a)));c=new dF(a,++this.R,(0,g.z)(this.EJ,this),(0,g.z)(this.DJ,
this));g.I(this,c);nF(this,c)}};
g.h.SF=function(){this.ea()||this.H||(this.o.P("sessionready"),this.H=!0)};
g.h.VF=function(a){var b=this;this.ea()||(a.forEach(function(a,d){var c=zy(b.l)?d:a,f=new window.Uint8Array(zy(b.l)?a:d);zy(b.l)&&qF(f);var k=zC(f);qF(f);f=zC(f);b.g[k]?b.g[k].status=c:b.g[f]?b.g[f].status=c:b.g[k]={type:"",status:c}}),this.o.P("keystatuseschange",this))};
g.h.TF=function(a){this.ea()||jF(this,"drm.keyerror",!0,a)};
g.h.EJ=function(a){if(!this.ea())if(0!=a.statusCode)jF(this,"drm.auth",!0,"t.f;c."+a.statusCode,a.errorMessage||void 0);else{(0,g.VB)("drm_kr_s");a.heartbeatParams&&this.o.P("newlicense",a.heartbeatParams);if(a.g&&(this.F=a.g,!mF(this)))if(Ay(this.l)){var b=oF(this.F);480<g.jt[b]&&this.o.P("hdentitled",this)}else this.o.P("keystatuseschange",this);a.l&&(this.g=g.Eb(a.l,function(a){return{type:a,status:"unknown"}}));
By(this.l)&&(a.message=g.Wd(lv(a.message)));this.B&&this.B.update(a.message).then(function(){(0,g.VB)("drm_kr_f")});
this.H&&(this.T=g.qr());"fairplay"==this.l.flavor&&this.o.P("fairplay_next_need_key_info",this.L,a.o)}};
g.h.DJ=function(a,b,c){if(!this.ea()){var d=!1;if(3<=a.l.l||this.Z&&36E4<g.qr()-this.T)d=!0,b="drm.net.retryexhausted";jF(this,b,d,c);(this.Z&&this.H?0:!d&&this.R==a.number)&&pia(this,a)}};
g.h.U=function(){g.G.prototype.U.call(this)};
g.h.Me=function(){var a=this.F.join();if(mF(this)){var b=[],c;for(c in this.g)"usable"!=this.g[c].status&&b.push(this.g[c].type);a+="/UKS:"+b}return a+="/"+this.cryptoPeriodIndex};tF.prototype.get=function(a){a=this.cj(a);return-1!=a?this.values[a]:null};
tF.prototype.remove=function(a){a=this.cj(a);-1!=a&&(this.keys.splice(a,1),this.values.splice(a,1))};
tF.prototype.set=function(a,b){var c=this.cj(a);-1!=c?this.values[c]=b:(this.keys.push(a),this.values.push(b))};
tF.prototype.cj=function(a){return g.Ka(this.keys,function(b){return g.cb(a,b)})};g.r(uF,ZE);uF.prototype.B=function(a){var b=(0,g.D)(),c;if(!(c=this.A)){a:{c=a.cryptoPeriodIndex;if(!(0,window.isNaN)(c))for(var d=g.q(this.o.values),e=d.next();!e.done;e=d.next())if(1>=Math.abs(e.value.cryptoPeriodIndex-c)){c=!0;break a}c=!1}c=!c}c?c=0:(c=a.g,c=1E3*Math.max(0,Math.random()*(((0,window.isNaN)(c)?120:c)-30)));this.g.push({time:b+c,info:a});g.In(this.l,c)};g.r(wF,g.N);g.h=wF.prototype;g.h.ia=function(){return this.G};
g.h.kJ=function(a){zF(this,new window.Uint8Array(a.initData),a.initDataType)};
g.h.jK=function(a){zF(this,a.initData,a.contentType)};
g.h.OJ=function(){var a=this;if(!this.ea())if(g.R(this.A.experiments,"html5_drm_set_server_cert")){var b=jia(this.L);b?b.then(jp(function(b){a.P("ctmp","setServerCertificate",b)}),jp(function(b){a.P("ctmp","setServerCertificateError","n."+b.name+";m."+b.message)})).then(jp(function(){return BF(a)})):BF(this)}else BF(this)};
g.h.vI=function(a){if(!this.ea()){g.M(a);var b="t.a";a instanceof window.DOMException&&(b+=";n."+a.name+";m."+a.message);this.P("licenseerror","drm.unavailable",!0,b,"HTML5_NO_AVAILABLE_FORMATS_FALLBACK")}};
g.h.Rn=function(a){this.o.push(a);yF(this)};
g.h.mK=function(a){this.ea()||!a||this.da||(this.da=a,this.P("heartbeatparams",a))};
g.h.nK=function(){this.ea()||(this.o.shift(),this.O=!1,yF(this))};
g.h.rL=function(){if(yy(this.g)&&(this.ba--,0==this.ba&&this.F)){var a=this.F;a.l.msSetMediaKeys(a.o)}};
g.h.dG=function(a){this.ea()||AF(this,pF(a,this.Y))};
g.h.uJ=function(){this.ea()||this.Z||!Ay(this.g)||(this.T=Pla,this.P("hdproberequired"),this.P("qualitychange"))};
g.h.U=function(){this.g.l&&this.G&&this.G.setMediaKeys(null);this.G=null;this.o=[];for(var a=g.q(this.l.values),b=a.next();!b.done;b=a.next())b.value.dispose();a=this.l;a.keys=[];a.values=[];this.B&&(this.B.dispose(),this.B=null);this.H=null;g.N.prototype.U.call(this)};
g.h.Me=function(){return 0>=this.l.values.length?"no session":this.l.values[0].Me()+(this.C?"/KR":"")};CF.prototype.la=function(a){return g.R(this.g.experiments,a)};KF.prototype.C=function(){var a=g.y("yt.abuse.player.botguardInitialized");if(!a||!a())return null;a="";this.g&&this.g.Bg&&(a=this.g.Bg+("&r1b="+this.g.clientPlaybackNonce));var b={};return(a=g.y("yt.abuse.player.invokeBotguard")((b.atr_challenge=a,b)))?"r1a="+a:null};
KF.prototype.F=function(a){return"r3a="+Math.floor(this.g.lengthSeconds%wb(a.c3a))};
KF.prototype.B=function(a){a=wb(a.c);var b=g.y("yt.abuse.dclkstatus.checkDclkStatus")();return"r6a="+(a^b)};g.r(g.LF,g.ZA);g.h=g.LF.prototype;g.h.ue=function(){return!0};
g.h.hj=function(){return Rt(this.l.hj(),this.g,this.C)};
g.h.Le=function(){return Rt(this.l.Le(),this.g,this.C)};
g.h.Ml=function(){return Rt(this.l.Ml(),this.g,this.C)};
g.h.ya=function(){return this.l.ya()-this.g};
g.h.jn=function(a){this.l.jn(a+this.g)};
g.h.ec=function(){return(0,window.isFinite)(this.C)?this.C-this.g:this.l.ec()-this.g};
g.h.play=function(){this.l.ya()<this.g&&this.l.jn(this.g);return this.l.play()};
g.h.Zh=function(){var a=g.ZA.prototype.Zh.call(this);a.view=this.g+"-"+this.C;return a};
g.h.addEventListener=function(a,b){this.l.addEventListener(a,b)};
g.h.removeEventListener=function(a,b){this.l.removeEventListener(a,b)};
g.h.qm=function(){return this.l.qm()};
g.h.gf=function(a){this.l.gf(a)};
g.h.Xm=function(){this.l.Xm()};
g.h.bi=function(){return this.l.bi()};
g.h.Kb=function(){return this.l.Kb()};
g.h.vo=function(){this.l.vo()};
g.h.to=function(){this.l.to()};
g.h.hg=function(){return this.l.hg()};
g.h.ia=function(){return this.l.ia()};
g.h.Rc=function(){return this.l.Rc()};
g.h.sm=function(a){this.l.sm(a)};
g.h.lr=function(){this.l.lr()};
g.h.Pb=function(){return this.l.Pb()};
g.h.be=function(a){return this.l.be(a)};
g.h.nm=function(){return this.l.nm()};
g.h.rm=function(a){this.l.rm(a)};
g.h.Ij=function(a,b){return this.l.Ij(a,b)};
g.h.ah=function(){return this.l.ah()};
g.h.dm=function(){return this.l.dm()};
g.h.Sg=function(){return this.l.Sg()};
g.h.pm=function(){return this.l.pm()};
g.h.ci=function(a){this.l.ci(a)};
g.h.Lj=function(){return this.l.Lj()};
g.h.load=function(){this.l.load()};
g.h.pause=function(){this.l.pause()};
g.h.ae=function(){return this.l.ae()};
g.h.Kl=function(){return this.l.Kl()};
g.h.Ue=function(){return this.l.Ue()};
g.h.Jj=function(){return this.l.Jj()};
g.h.Rp=function(){return this.l.Rp()};
g.h.Zg=function(){return this.l.Zg()};
g.h.Mj=ba(8);g.h.Nj=ba(10);g.h.Qp=function(){return this.l.Qp()};
g.h.Kj=function(){return this.l.Kj()};
g.h.Jb=function(){return this.l.Jb()};
g.h.setVolume=function(a){this.l.setVolume(a)};
g.h.setAttribute=function(a,b){this.l.setAttribute(a,b)};
g.h.removeAttribute=function(a){this.l.removeAttribute(a)};
g.h.hasAttribute=function(a){return this.l.hasAttribute(a)};
g.h.Ji=ba(12);g.h.yk=ba(14);g.h.th=ba(5);g.h.Si=ba(16);g.h.Yi=function(){this.l.Yi()};
g.h.ij=function(a){return this.l.ij(a)};
g.h.Kc=function(){this.l.Kc()};
g.h.wo=function(a){this.l.wo(a)};MF.prototype.add=function(a){this.g=(this.g+1)%this.l.length;this.l[this.g]=a};
MF.prototype.clear=function(){for(var a=this.l.length,b=0;b<a;b++)this.l[b]=0;this.o=this.g=this.l.length-1};g.r(PF,g.N);PF.prototype.isPeggedToLive=function(){return this.C};g.r(YF,g.N);g.h=YF.prototype;g.h.isPeggedToLive=function(){return!!this.B&&this.B.isPeggedToLive()};
g.h.Gc=function(a){this.g.ra?this.g&&this.g.xa&&this.g.xa.g?a=!a&&this.B?SF(this.B):this.g.Gc()+this.A:this.l?Op()?(a=this.l.Lj().getTime(),a=(0,window.isNaN)(a)?0:Math.max(((0,g.D)()-a)/1E3-30,0)):a=$A(this.l)+this.A||this.A:a=this.A:a=this.g.Gc();return a};
g.h.zb=function(){return this.g?this.g.zb()+this.A:this.A};
g.h.U=function(){bG(this,null);g.N.prototype.U.call(this)};
g.h.JM=function(){var a=cG(this)+.1;this.J=Tf(a-this.A);gG(this,a,!0)};
g.h.IM=function(a,b){gG(this,a+this.A,!0,void 0===b?!1:b)};
g.h.SM=function(a){this.A=a};
g.h.EG=function(a){this.H&&(this.H.g=a.audio.index)};
g.h.la=function(a){return this.da&&g.R(this.da.experiments,a)};jG.prototype.isActive=function(){return 0!=this.g||window.Infinity!=this.l};g.r(oG,g.N);oG.prototype.isFullscreen=function(){return 0!=this.o};
oG.prototype.isBackground=function(){return kG()};
oG.prototype.B=function(){this.P("visibilitychange");var a=this.isFullscreen();a=this.l?4:kG()?3:a?2:this.g?1:this.A?5:this.C?7:0;a!=this.G&&this.P("visibilitystatechange");this.G=a};
oG.prototype.U=function(){nG(this.F);g.N.prototype.U.call(this)};g.r(qG,g.G);qG.prototype.start=function(){this.l.start()};
qG.prototype.stop=function(){this.l.stop()};
qG.prototype.clear=function(){for(var a in this.g)this.g[a].clear()};
qG.prototype.A=function(){for(var a in this.o)this.g[a].update(this.o[a]());this.l.start()};
rG.prototype.update=function(a){this.o?(this.g.add(a-this.l||0),this.l=a):this.g.add(a)};
rG.prototype.clear=function(){this.g.clear();this.l=0};var DG={"ad-trueview-indisplay-pv":6,"ad-trueview-insearch":7},EG={"ad-trueview-indisplay-pv":2,"ad-trueview-insearch":2},FG=/^(\d*)_((\d*)_?(\d*))$/;vG.prototype.start=function(){this.l=!0};
vG.prototype.reset=function(){this.g=this.l=!1};g.r(xG,g.N);g.h=xG.prototype;g.h.U=function(){window.clearInterval(this.Cb);nG(this.Va);this.L.unsubscribe("visibilitystatechange",this.Va);AG(this);BG(this);yG(this);lH(this);this.F&&(this.F.dispose(),delete this.F);delete this.O;g.Xe(this.g);this.T=null;this.Oa=!1;g.N.prototype.U.call(this)};
g.h.getVideoData=function(){return this.g};
g.h.ko=function(){if(this.g.Ob())Kia(this);else if(this.g.zh||this.g.Vh){if(!this.ga||!NG(this))if(this.g.zh){var a=this.g;a.Af=!0;a.zh=!1;As(a.Ud)||g.M(Error("DASH MPD Origin invalid: "+a.Ud),"WARNING");var b=a.Ud,c=g.S(a.Ra.experiments,"dash_manifest_version")||4;b=g.Ig(b,{mpd_version:c});a.isLowLatencyLiveStream&&"NORMAL"!=a.latencyClass||(b=g.Ig(b,{pacing:0}));hx(new Xw(b,a.Ra.experiments,a.ra),b).then(a.bJ,a.aJ,a);(0,g.VB)("mrs")}else this.A&&(a=this.A.l,DB(a,"protected"),a.g.videoData.Re?a.sa():
a.g.videoData.subscribe("dataloaded",a.sa,a)),a=this.g,a.fairPlayCert||a.ma&&Yw(a.ma),b={},a.ma&&(b=Gy(dA(a),a.Ra.T,a.ma)),b=new Ly(b,a.Ra.experiments,a.Hz),g.I(a,b),a.Vh=!1,a.Af=!0,a=(0,g.z)(a.wD,a),b.C=a,b.o=[],Cy(b.B)?Ny(b):qga(b)}else if(!this.g.Af&&this.Wb){b=this.C;a=this.g;var d=this.ab.Ha(),e=this.ie();this.L.isFullscreen();if(38==a.Ce&&"books"==b.playerStyle)b=a.videoId.indexOf(":"),a=g.Ig("//play.google.com/books/volumes/"+a.videoId.slice(0,b)+"/content/media",{aid:a.videoId.slice(b+1),
sig:a.YH});else if(30==a.Ce&&"docs"==b.playerStyle)a=g.Ig("https://docs.google.com/get_video_info",{docid:a.videoId,authuser:a.Dc,authkey:a.authKey,eurl:b.pa});else if(33==a.Ce&&"google-live"==b.playerStyle)a=g.Ig("//google-liveplayer.appspot.com/get_video_info",{key:a.videoId});else{c={html5:"1",video_id:a.videoId,cpn:a.clientPlaybackNonce,eurl:b.pa,ps:b.playerStyle,el:DA(a),hl:b.Mb,list:a.playlistId,agcid:a.NB,aqi:a.adQueryId,sts:17869,lact:Gr()};g.Fa(c,b.l);b.Nc&&(c.ecver=b.Nc);b.forcedExperiments&&
(c.forced_experiments=b.forcedExperiments);a.df?(c.vvt=a.df,a.mdxEnvironment&&(c.mdx_environment=a.mdxEnvironment)):HA(a)&&(c.access_token=HA(a));a.revocableUnlistedToken&&(c.ut=a.revocableUnlistedToken);a.adFormat&&(c.adformat=a.adFormat);0<=a.slotPosition&&(c.slot_pos=a.slotPosition);a.breakType&&(c.break_type=a.breakType);null!=a.adIds&&(c.ad_id=a.adIds);null!=a.adSystems&&(c.ad_sys=a.adSystems);null!=a.gu&&(c.encoded_ad_playback_context=a.gu);b.Sf&&(c.cc_lang_pref=b.Sf);b.Tf&&2!=b.Tf&&(c.cc_load_policy=
b.Tf);b.mute&&(c.mute=b.mute);a.Qf&&2!=b.Qf&&(c.iv_load_policy=a.Qf);a.Ph&&(c.itct=a.Ph);GA(a)&&(c.autoplay="1");a.Qh&&(c.autonav="1");a.pp&&(c.noiba="1");a.isMdxPlayback&&(c.mdx="1",c.ytr=a.Fe);a.mdxControlMode&&(c.mdx_control_mode=a.mdxControlMode);a.vl&&(c.ytrcc=a.vl);a.vp&&(c.utpsa="1");a.isFling&&(c.is_fling="1");a.np&&(c.mute="1");a.vnd&&(c.vnd=a.vnd);a.yo&&(c.force_ad_param_ad_type="video_ad",c.force_ad_param_url=a.yo,c.force_ad_param_break_type="1",c.force_ad_param_offset_value=0);d.width&&
(c.width=d.width);d.height&&(c.height=d.height);a.jg&&(c.splay="1");a.ypcPreview&&(c.ypc_preview="1");EA(a)&&(c.content_v=EA(a));a.wj&&(c.livemonitor=1);b.Dc&&(c.authuser=b.Dc);b.pageId&&(c.pageid=b.pageId);b.Ta&&(c.ei=b.Ta);b.g&&(c.iframe="1");a.contentCheckOk&&(c.cco="1");a.racyCheckOk&&(c.rco="1");b.sb&&a.liveStartWalltime&&(c.live_start_walltime=a.liveStartWalltime);b.sb&&a.yp&&(c.live_manifest_duration=a.yp);b.sb&&a.playerParams&&(c.player_params=a.playerParams);b.sb&&a.cycToken&&(c.cyc=a.cycToken);
b.sb&&a.Zz&&(c.tkn=a.Zz);0!=e&&(c.vis=e);b.enableSafetyMode&&(c.enable_safety_mode="1");a.fm&&(c.kpt=a.fm);a.gm&&(c.kids_age_up_mode=a.gm);a.Cn&&(c.upg_content_filter_mode="1");b.widgetReferrer&&(c.widget_referrer=b.widgetReferrer.substring(0,128));(d=b.Kk)&&(c.embedding_app=d);(d=g.lA(a))&&(c.uloc=d);a.tj&&(c.internalipoverride=a.tj);b.sb&&a.ag&&(c.wpid=a.ag);b.dd&&(c.embed_config=b.dd);b.Vk&&(c.co_rel="1");0<b.Cb.length&&(c.ancestor_origins=Array.from(b.Cb).join(","));void 0!=a.uj&&(c.is_home_group=
a.uj?"1":"0");for(var f in c)c[f]&&512<c[f].length&&(g.M(Error("GVI param too long: "+f)),c[f]="");a=g.Ig(b.baseYtUrl+"get_video_info",c)}b=2;this.g.isAd()&&(b=0);c=this.g;f=this.C.sa;d=this.C.Sb;c.ea()||(c.Ju=a,c.rr=b,c.xi=f,c.kv=d,c.fz=!c.la("disable_gvi_cors"),c.Lo=g.S(c.Ra.experiments,"html5_get_video_info_timeout_ms")||0,c.Ku=c.la("html5_get_video_info_promiseajax"),c.Af=!0,c.rz())}};
g.h.yK=function(a){this.ea()||a.videoData.ea()||(this.O=a,Cia(this.F,this.O),!this.g.ra||0<this.g.wf&&!gA(this.g)||(YG(this,vH(this),!0),ZG(this,"playbackData")),this.g.xa.g&&g.tH(this),sH(this))};
g.h.zK=function(a){this.ea()||(a instanceof g.Oy?this.L.isBackground()?(MH(this,"vp_none_avail"),this.nb=null,this.Y.reset()):(this.Y.g=!0,g.LG(this,a.errorCode,"HTML5_NO_AVAILABLE_FORMATS_FALLBACK",Py(a.details))):g.M(a))};
g.h.logEvent=function(a,b){if(this.A){var c=this.A,d={};d.rt=g.SA(c.g).toFixed(3);g.Fa(d,TA(c.g));var e=c.g.g,f=c.g.videoData;e={ns:e.Z,html5:"1",el:DA(f),ps:e.playerStyle,fexp:e.experiments.experimentIds.join(",")||void 0,feature:f.kr||f.ri||void 0,ctrl:f.Ee||void 0,ytr:f.Fe||void 0,list:f.playlistId};GA(f)&&(e.autoplay="1");f.subscribed&&(e.subscribed=f.subscribed);g.Fa(d,e);delete d.fexp;g.Fa(d,a);d=g.wp(c.g.g.baseYtUrl+"player_204",d);OB(c,d,b)}};
g.h.isPeggedToLive=function(){return this.F.isPeggedToLive()};
g.h.aE=function(){return this.o};
g.h.getPlayerType=function(){return this.Ya};
g.h.FM=function(){this.g.xa.g&&Yw(this.g.ma)?EH(this):(nH(this),IG(this,lB(this.o,16)),RG(this),g.qB(this.o)&&qH(this))};
g.h.getAvailableAudioTracks=function(){return this.g.getAvailableAudioTracks()};
g.h.getAudioTrack=function(){return this.g.getAudioTrack()};
g.h.fE=function(){g.S(this.C.experiments,"html5_background_quality_cap")&&this.B&&sH(this);g.R(this.C.experiments,"html5_cut_vss_on_visibility")&&this.A&&g.NA(this.A.o);this.C.Ok&&!this.g.backgroundable&&this.l&&!this.L.l&&(this.L.isBackground()&&this.l.qm()?(this.Za("bgmobile","suspend"),g.fH(this,!0)):this.L.isBackground()||RG(this)&&this.Za("bgmobile","resume"))};
g.h.wJ=function(a){if(this.G){var b=this.G;yy(b.g)&&(a=yC(a),xF(b,new $E(a)))}};
g.h.lK=function(a,b){this.G?xF(this.G,new $E(b,a)):this.ob.push({type:a,info:b})};
g.h.ey=function(){g.uu&&this.ka&&this.ka.g&&this.G&&(uia(this.G,this.ka.g),this.ka=null)};
g.h.SL=function(a){this.g.sA=zu("auto",a,!1,"u");sH(this)};
g.h.dE=function(a){cH(this,a.reason,a.video.info,a.audio.info)};
g.h.JJ=function(a){aH(this,a.reason,a.audio.info)};
g.h.Gj=function(a){Pia(this,a);if("html5.invalidstate"!=a.errorCode&&"fmt.unplayable"!=a.errorCode&&"fmt.unparseable"!=a.errorCode||!AH(this,a.errorCode,a.details)){var b=/^pp/.test(this.g.clientPlaybackNonce);if(Oia(a)){a.details.sts="17869";if(BH(this)){g.U(this.o,4)?(this.fd=!0,BG(this)):(this.A&&(a.g&&(a.details.e=a.errorCode,a.errorCode="qoe.restart",a.g=!1),this.A.onError(a.errorCode,Py(a.details))),oH(this));return}a:if(!(6048E5>g.qr()-this.C.ed)){try{window.location.reload(!0);break a}catch(c){}this.la("tvhtml5_retire_old_players")&&
g.gy(this.C)&&DH(this)}}if(CH(a)&&this.g.xa.l){if(this.A)this.A.onError(a.errorCode,Py(a.details));this.Za("highrepfallback","1",!0);!this.la("html5_hr_logging")&&/^hr/.test(this.g.clientPlaybackNonce)&&window.btoa&&this.Za("afmts",(0,window.btoa)(this.g.adaptiveFormats));eha(this.g);zG(this);BG(this);zH(this);qH(this)}else a.g?(b=this.B?this.B.F.l:null,b=CH(a)&&b&&b.isLocked()?"FORMAT_UNAVALIABLE":void 0,g.LG(this,a.errorCode,b,Py(a.details))):this.A&&(this.A.onError(a.errorCode,Py(a.details)),b&&
"manifest.net.connect"==a.errorCode&&(a="https://www.youtube.com/generate_204?cpn="+this.g.clientPlaybackNonce+"&t="+g.qr(),(new iE(a,"manifest",(0,g.z)(function(a){this.Za("pathprobe",a)},this),(0,g.z)(function(a){this.onError(a.errorCode,Py(a.details))},this.A))).send()))}};
g.h.tb=function(){return cG(this.F)};
g.h.getPlaylistSequenceForTime=function(a){return this.g.getPlaylistSequenceForTime(a-(this.F?this.F.A:0))};
g.h.Xg=function(){return this.g.lengthSeconds?this.g.lengthSeconds+(this.F?this.F.A:0):vH(this)?vH(this):0};
g.h.uC=function(){var a=new Xfa;if(this.B){var b=this.C.schedule;a.o=b.H;a.B=b.J;a.bandwidthEstimate=g.Ex(b);a.g="d."+Bx(b).toFixed(2)+";st."+(1E9*(b.A.g()||0)).toFixed(2)+";bw."+b.g.g().toFixed(0)+";abw."+b.C.g().toFixed(0)+";v50."+yx(b.l,.5).toFixed(2)+";v92."+yx(b.l,.92).toFixed(2)+";v96."+yx(b.l,.96).toFixed(2)+";v98."+yx(b.l,.98).toFixed(2);b=this.B;if(b.A&&!Yt(b.A)&&(a.l=GD(b.g)?b.g.B.B:Qt(b.A.l.Nb(),b.B),a.A=GD(b.o)?b.o.B.B:Qt(b.A.g.Nb(),b.B),b.l.ba)){var c=JD(b.g),d=JD(b.o),e=Mt(b.A.l.Nb(),
"_"),f=Mt(b.A.g.Nb(),"_");a.g=(a.g||"")+(";lvq."+c+";laq."+d+";lvb."+e+";lab."+f)}a.bandwidthEstimate=WD(b.H)}else this.l&&(a.l=bB(this.l));a.C=this.Cu();return a};
g.h.UL=function(){HG(this)};
g.h.TL=function(a){g.LG(this,"auth",(0,window.unescape)(a.reason),a.errordetail||"sec."+a.errorcode,a.subreason)};
g.h.eE=function(a){var b=a.target.Rc();if(this.l&&this.l.Rc()&&this.l.Rc()==b){SH(this,a.type);switch(a.type){case "error":var c=eB(this.l)||"";if("capability.changed"==c){QG(this);return}if(0<this.l.Ue()&&AH(this,c,{msg:this.l.Jj()}))return;if(this.L.isBackground()&&4==this.l.Ue()){g.fH(this);MH(this,"unplayable");return}break;case "durationchange":c=this.l.ec();(!this.J||(0,window.isFinite)(c)&&0<c)&&1!=c&&this.g.lengthSeconds!=c&&(this.g.lengthSeconds=c,HG(this));break;case "ratechange":if(this.B){c=
this.B;var d=this.l.Pb();if(d!=c.H.o&&(c.H.o=Math.max(1,d),c.l.Nf)){var e=c.F.l,f=c.F;if(d!=f.da){f.da=d;var k=f.l;k&&"m"!=k.reason&&(1<d&&480<k.g?(dE(f,new xu(0,Math.min(k.g,480),!0,"o")),f.J=k):1>=d&&f.J!=Bu&&(dE(f,new xu(0,f.J.g,f.J.o,"o")),f.J=Bu))}e&&!yu(c.F.l,e)&&(c.Wc("varispeedFormat","1"),c.P("reattachrequired"))}}c=this.H;c.C=!0;c.l();this.A&&(c=this.A.l,d=this.pa,e=g.SA(c.g),d&&d!=c.ga&&(g.wB(c,e,"rate",[d]),c.ga=d),c.B(e));break;case "loadedmetadata":this.P("onLoadedMetadata");case "loadstart":window.clearInterval(this.Cb);
this.jo()||(this.Cb=g.pp((0,g.z)(this.jo,this),100));break;case "progress":case "suspend":GH(this);this.P("onLoadProgress",this,this.l?g.AA(this.g)?1:BA(this.g)?pH(this)||this.isPeggedToLive()?1:Hia(this.F):dB(this.l):0);break;case "playing":(0,g.VB)("plev",void 0,"");Pz("plev");this.ed&&(this.ed=!1,pH(this)||(YG(this,window.Infinity,!0),ZG(this,"onPlaying")));break;case "timeupdate":c=this.l&&!this.l.ya();d=this.l&&0==this.l.ae();if(c&&(!this.Ja||d))return;this.Ja=this.Ja||!!this.l.ya();this.jo();
GH(this);if(!this.l||this.l.Rc()!=b)return;this.P("onVideoProgress",this,this.tb());break;case "waiting":if(0<this.l.hj().length&&0==this.l.Le().length&&0<this.l.ya()&&5>this.l.ya()&&this.B)return;break;case "resize":g.Kp("cobalt")&&g.Kp("nintendo switch")&&(c=!window.matchMedia("screen and (max-height: 720px) and (min-resolution: 200dpi)").matches,this.Za("nxdock",""+ +c));this.g.ua&&"auto"==this.g.ua.video.quality&&this.P("internalvideoformatchange",this.g,!1);break;case "pause":if(this.Qd&&g.U(this.o,
8)&&!g.U(this.o,1024)&&0==this.tb()&&g.ry){MH(this,"safari_autoplay_disabled");return}}if(this.l&&this.l.Rc()==b){this.P("videoelementevent",a);b=this.o;if(!g.U(b,128)){c=this.Ia;f=this.l;d=this.C.experiments;e=b.g;f=f?f:a.target;k=f.ya();if(!g.U(b,64)||"ended"!=a.type&&"pause"!=a.type){var l=f.Sg()||k&&1.1>Math.abs(k-f.ec()),m="pause"==a.type&&f.Sg(),n="ended"==a.type;d&&g.R(d,"html5_waiting_before_ended")&&(n=n||"waiting"==a.type||"timeupdate"==a.type&&!g.U(b,4)&&!gB(c,k));if(m||l&&n)0<f.Kl()&&
f.Rc()&&(e=14);else switch(a.type){case "error":eB(f)&&(e|=128);break;case "pause":g.U(b,256)?(e^=256)||(e=64):g.U(b,32)||g.U(b,2)||g.U(b,4)||(e=4,g.U(b,1)&&g.U(b,8)&&(e|=1));break;case "playing":e=(e|8)&-1029;d&&g.R(d,"html5_playing_clears_unstarted_killswitch")||(e&=-65);gB(c,f.ya())&&(e&=-2);g.U(b,1)&&jB(c,f)&&(e|=1);break;case "seeking":e|=16;d&&g.R(d,"html5_seeking_buffering_only_playing")&&!g.U(b,8)||(e|=1);e&=-3;break;case "seeked":e&=-17;break;case "waiting":g.U(b,2)||(e|=1);jB(c,f);break;
case "timeupdate":k=g.U(b,8),l=g.U(b,16),m=g.U(b,4),(d&&g.R(d,"html5_paused_timeupdate_killswitch2")?k&&!m||l:(k||l)&&!m)&&gB(c,f.ya())&&(e=8),jB(c,f)&&(e|=1)}}c=e;d=null;if(c&128)if(k=a.target,d=eB(k)){e="GENERIC_WITHOUT_LINK";f="mediaElem.1";if(k=k.Jj())f+=";msg."+k,/AUDIO_RENDERER/.test(k)&&(e="HTML5_AUDIO_RENDERER_ERROR");.001>Math.random()&&(f+=";gpu."+(0,g.OG)());d={errorCode:d,errorDetail:f,message:g.eH[e]||"",messageKey:e}}else d=null;b=kB(b,c,d)}!g.U(this.o,1)&&g.U(b,1)&&RH(this,"evt_"+a.type);
IG(this,b)}}};
g.h.mI=function(a){a="available"==a.g.availability;a!=this.Cc&&(this.Cc=a,this.P("airplayavailabilitychange"))};
g.h.nI=function(){var a=g.qr();if(this.la("html5_hlsvp_airplay_killswitch")||(0,window.isNaN)(this.Lc)||!(2E3>a-this.Lc)){var b=this.l.Zg();this.Lc=a;b!=this.L.l&&(a=this.L,a.l!=b&&(a.l=b,a.B()),this.la("html5_hlsvp_airplay_killswitch")&&!b||QG(this));this.P("airplayactivechange")}};
g.h.jo=function(){var a=this.l;a&&this.Ja&&!this.g.Gd&&!Oz("vfp","")&&2<=a.ae()&&!a.Sg()&&0<Pt(a.Le())&&(0,g.VB)("vfp",void 0,"");return(a=this.l)&&!this.g.Gd&&0<a.ec()&&(!Oz("pbp","")&&a.ah()&&2<=a.ae()&&0<Pt(a.Le())&&(0,g.VB)("pbp",void 0,""),a=a.ya(),gB(this.Ia,a))?(KH(this),!0):!1};
g.h.QC=function(){if(this.l&&!g.U(this.o,128)){this.g.ig&&g.S(this.C.experiments,"html5_log_rebuffer_events")&&SH(this,"pfx");var a=this.tb();if(g.U(this.o,8)&&gB(this.Ia,a))IG(this,mB(this.o,1));else if(g.U(this.o,8)&&hB(this.Ia,a,g.qr(),bB(this.l))){var b=this.Xg();!this.g.ra&&b&&1.1>Math.abs(b-a)?this.l.nm()?YG(this,0,!0):wG(this):(g.sB(this.o)||RH(this,"progress_fix"),IG(this,lB(this.o,1)))}else g.U(this.o,4)&&g.sB(this.o)&&5<bB(this.l)&&IG(this,mB(this.o,1));GH(this)}};
g.h.qC=function(){return this.B?WD(this.B.H):g.Ex(this.C.schedule)};
g.h.tC=function(){return this.C.schedule.H};
g.h.Cu=function(){return pH(this)&&g.pB(this.o)?this.Eu():window.NaN};
g.h.Eu=function(){if(!this.g.ra||!this.g.ma||!this.B)return window.NaN;var a=gA(this.g)?this.B.sa.g()||0:this.g.ma.G;return(0,g.D)()/1E3-HH(this)-a};
g.h.FC=function(){this.g.ra||this.P("connectionissue")};
g.h.Tm=function(){var a=this;if(this.yb=this.l.Kb()){var b=this.yb;b.then(void 0,function(c){if(!(g.U(a.o,4)||g.U(a.o,256)||a.yb!=b||!a.la("html5_ignore_mediaelement_playerror_killswitch")&&c&&"AbortError"==c.name&&c.message&&c.message.includes("load"))){var d="promise";!a.la("html5_log_dompause_err_killswitch")&&c&&c.name&&(d+=";m."+c.name);MH(a,d);a.Qd=!0}})}};
g.h.AJ=function(a,b,c,d){d=void 0===d?"LICENSE":d;c=c.substr(0,256);if("drm.keyerror"==a&&1<this.G.l.keys.length&&96>this.ge)a="drm.sessionlimitexhausted",b=!1;else if(this.la("html5_drm_fallback_to_playready_on_retry")&&"drm.keyerror"==a&&2>this.he&&(this.he++,zG(this),1<this.g.mk.length&&(this.g.Re=this.g.mk[1]),AH(this,a,{detail:c})))return;if(b)g.LG(this,a,d,c);else if(this.A)this.A.onError(a,c);"drm.sessionlimitexhausted"==a&&(this.ge++,this.l&&(this.J?(zG(this),BG(this),zH(this)):(this.g.Dd&&
this.g.Dd.ur(),this.l.Kc()),qH(this)))};
g.h.CJ=function(){var a=this,b=g.S(this.C.experiments,"html5_license_constraint_delay"),c=Up();b&&c?(b=new g.L(function(){sH(a);HG(a)},b),g.I(this,b),b.start()):(sH(this),HG(this))};
g.h.BJ=function(){var a=this;g.uu&&(this.ka=Vfa(this.g.ma))&&(this.ka.g?g.Jf(function(){a.ey()}):eia(this.B,this.ka))};
g.h.bE=function(a){this.P("heartbeatparams",a)};
g.h.cE=function(a){this.Za("keystatuses",qia(a));if(this.la("html5_drm_output_restricted_killswitch")){var b=0;this.g.ua&&(b=this.g.ua.video.g);var c=this.la("html5_drm_start_from_null_constraint"),d=c&&!(sF(a,"AUDIO")&&sF(a,"SD"));rF(a)&&(!c&&480<b||d)&&this.P("drmoutputrestricted")}else b="auto",this.g.ua&&(b=this.g.ua.video.quality),!rF(a,b)||this.la("html5_drm_start_from_null_constraint")&&sF(a,"AUDIO")&&sF(a,"SD")||this.P("drmoutputrestricted")};
g.h.HJ=function(){if(!this.g.Gd&&this.l&&!this.L.isBackground()){var a="0";0<this.l.ae()&&5<=bB(this.l)&&this.g.xa.g&&(IG(this,lB(this.o,1)),RH(this,"load_soft_timeout"),this.P("playbackstalledatstart"),a="1");this.A&&(LH(this),a={restartmsg:a},XG(this)&&(a.prerolls=this.Z.join(",")),this.B&&g.Fa(a,YE(this.B)),this.l&&g.Fa(a,this.l.Zh()),this.A.onError("qoe.start15s",Py(a)));this.P("loadsofttimeout")}};
g.h.vr=function(){if(!this.Oa){var a=new KF(this.g,this.xh);if("c1a"in a.l){var b=g.y("yt.abuse.player.botguardInitialized");b=!(b&&b())}else b=!1;if(b)g.op((0,g.z)(this.vr,this),4500);else{if(a.g&&a.g.Bg){a.A&&(a.A.value=a.g.Bg+("&r1b="+a.g.clientPlaybackNonce));b=[a.g.Bg];for(var c in a.o)if(a.l[c]&&a.o[c]){var d=a.o[c](a.l);d&&b.push(d)}a=b.join("&")}else a=null;a&&this.A&&(c=this.A,c.O||(b=LB(c,"atr"),b.H=a,b.send(),c.O=!0),this.Oa=!0)}}};
g.h.zb=function(){return this.F.zb()};
g.h.Sv=function(){return this.pa};
g.h.Ko=function(){return this.l?this.l.Rp():{}};
g.h.HD=function(a){this.la("html5_unrewrite_timestamps")&&this.Za("timestamp",a.toString())};
g.h.Za=function(a,b,c){if(this.A){var d=this.A;d.ea()||yB(d.l,a,b,void 0===c?!1:c)}};
g.h.la=function(a){return g.R(this.C.experiments,a)};g.r(g.TH,SB);g.h=g.TH.prototype;g.h.getPlayerType=function(){return this.playerType};
g.h.getRootNode=function(){return g.ZH(this).element};
g.h.Ve=function(){return this.app.F};
g.h.getVideoData=function(a){return(a=g.W(this.app,a||this.playerType))&&a.getVideoData()};
g.h.Xd=function(a){return this.app.Xd(a||this.playerType)};
g.h.isWidescreen=function(){return this.app.isWidescreen()};
g.h.Kb=function(a){3==this.Da()?g.$H(this.app.C).Wj("control_play"):XS(this.app,a)};
g.h.Kc=function(a){FH(g.W(this.app,a))};
g.h.addEventListener=function(a,b){this.app.ba.subscribe(a,b)};
g.h.removeEventListener=function(a,b){this.app.ba.unsubscribe(a,b)};
g.h.tm=function(a){this.uw(a,a)};
g.h.Oj=function(a){return xS(this.app,a)};
g.h.getVideoUrl=function(a,b,c,d){var e=this.Da(),f=2==e;if(d&&f||3==e)f=!1,e=1;d=this.getVideoData(e);if(!d)return"";var k;a||d.ra||(k=Math.floor(this.ya(e)));return this.app.g.getVideoUrl(d.videoId,f?void 0:this.getPlaylistId()||void 0,k,b,c)};
g.h.Uj=function(a,b,c){var d=g.UH(this).o;d&&d.Mp(a,b,c)};
g.h.ac=function(){if(g.V(this).H)return!1;var a=g.W(this.app,1);if(!a)return!1;var b=a.getVideoData();return!b.ld()||g.AA(b)||2==this.Da()&&!$M(this.app)||XG(a)&&3!=this.Da()?!1:!0};
g.h.Kp=ba(18);g.h.we=function(a,b,c){var d=this.app;(c=g.W(d,c||this.playerType))&&d.g.nb.has(a.toString())?c.A?(d=LB(c.A,"engage"),d.o=a,d.send(b)):b&&b():b&&b()};
g.h.be=function(a,b){qS(this.app,a,b)};
g.h.setVolume=function(a){a=g.Uc(a,0,100);Xs(this.app,{volume:a,muted:this.isMuted()},!0)};
g.h.mute=function(){Xs(this.app,{muted:!0,volume:this.Jb()},!0)};
g.h.We=function(){Xs(this.app,{muted:!1,volume:Math.max(5,this.Jb())},!0)};
g.h.xb=function(){return g.W(this.app)};
g.h.Da=function(){return lI(this.app)};
g.h.la=function(a){return g.R(g.V(this).experiments,a)};EI.prototype.fetch=function(a,b){var c=this;if(!a.match(/\[BISCOTTI_ID\]/g))return FI(this,a,b);var d=1===this.l;d&&(0,g.VB)("a_bid_s",void 0,"");var e=Sia();if(null!==e)return d&&(0,g.VB)("a_bid_f",void 0,""),FI(this,a,b,e);e=Tia();d&&$f(e,function(){(0,g.VB)("a_bid_f",void 0,"")});
return e.then(function(d){return FI(c,a,b,d)})};var $la={fQ:"replaceUrlMacros",pP:"isExternalShelfAllowedFor"};g.A(g.GI,g.N);g.h=g.GI.prototype;g.h.load=function(){this.loaded=!0};
g.h.unload=function(){this.loaded=!1};
g.h.Xb=function(){return!0};
g.h.U=function(){this.loaded&&this.unload();g.GI.Aa.U.call(this)};
g.h.KA=function(){return{}};g.r(II,g.YB);PI.prototype.g=function(){return"adLifecycleCommand"};
PI.prototype.l=function(a){var b=this;switch(a.action){case "START_LINEAR_AD":g.Jf(function(){var c=b.o,d=a.playAdIndex||0;c.l&&c.l.Ye()&&c.l.Nw(d)});
break;case "END_LINEAR_AD":g.Jf(function(){var a=b.o;a.l&&a.l.Ye()&&a.l.qq()});
break;case "END_LINEAR_AD_PLACEMENT":g.Jf(function(){var a=b.o;a.l&&a.l.Ye()&&a.l.Zj()});
break;case "CLEAR_ABOVE_FEED_SLOT":g.Jf(function(){RM(b.o)})}};QI.prototype.g=function(){return"adPlayerControlsCommand"};
QI.prototype.l=function(a){switch(a.action){case "AD_PLAYER_CONTROLS_ACTION_SEEK_TO_END":var b=this.o;var c=bN(b)?b.g.ec(2):0;if(0>=c)break;b=this.o;a=g.Uc(c-(Number(a.seekOffsetMilliseconds)||0)/1E3,0,c);bN(b)&&YG(b.g.xb(),a,!0);break;case "AD_PLAYER_CONTROLS_ACTION_RESUME":this.o.resume()}};RI.prototype.vj=function(){return!1};
RI.prototype.O=function(){return function(){return null}};
RI.prototype.Rh=function(){return!1};g.r(TI,RI);g.h=TI.prototype;g.h.Vc=function(){return!0};
g.h.isSkippable=function(){return null!=this.Z};
g.h.getVideoUrl=function(){return this.J};
g.h.vj=function(){return!0};
g.h.Rh=function(){return!0};g.r(WI,RI);WI.prototype.Vc=function(){return!1};g.r(XI,RI);XI.prototype.Vc=function(){return!1};YI.prototype.Rh=function(){return!1};g.r($I,RI);$I.prototype.Vc=function(){return!1};
$I.prototype.Rh=function(){return!0};g.r(bJ,RI);g.r(cJ,g.P);cJ.prototype.lf=function(a){var b=this;if(a=void 0===a?null:a){var c=this.B;a.forEach(function(a){return b.A.Ka(a,c)})}};
cJ.prototype.Ka=function(a){(a=void 0===a?null:a)&&this.A.Ka(a,this.B)};g.r(dJ,g.G);dJ.prototype.append=function(a){if(!this.G)throw Error("This does not support the append operation");this.al(a.ia())};
dJ.prototype.al=function(a){this.ia().appendChild(a)};
g.r(eJ,dJ);eJ.prototype.ia=function(){return this.g};g.r(gJ,g.G);var mU=new window.WeakSet;g.r(Y,g.Ns);g.h=Y.prototype;g.h.Ah=function(a){a.append(this.Ia)};
g.h.bind=function(a){if(this.ga)this.Km(a);else if(a.renderer){var b=Object.assign({},fJ(this.api,this.l),a.macros);this.init(a.id,a.renderer,b,a)}return window.Promise.resolve()};
g.h.init=function(a,b,c){this.ga=a;this.element.setAttribute("id",this.ga);this.sa&&g.J(this.element,this.sa);this.L=b&&b.adRendererCommands;this.macros=c;this.G=b.trackingParams||null;null!=this.G&&mJ(this,this.element,this.G)};
g.h.Km=function(){};
g.h.clear=function(){};
g.h.hide=function(){g.Ns.prototype.hide.call(this);null!=this.G&&nJ(this,this.element,!1)};
g.h.show=function(){g.Ns.prototype.show.call(this);if(!this.Oa){this.Oa=!0;var a=this.L&&this.L.impressionCommand;a&&this.l.Ka(a,this.macros,null)}null!=this.G&&nJ(this,this.element,!0)};
g.h.onClick=function(a){if(this.G&&!mU.has(a)){var b=this.element;yI(this.api,b)&&this.Ma()&&g.vI(this.api,b);mU.add(a)}(a=this.L&&this.L.clickCommand)&&this.l.Ka(a,this.macros,this.zu())};
g.h.zu=function(){return null};
g.h.MH=function(a){var b=this.O;b.F=!0;b.l=a.touches.length;b.g.isActive()&&(b.g.stop(),b.B=!0);a=a.touches;b.C=hJ(b,a)||1!=a.length;var c=a.item(0);b.C||!c?(b.G=window.Infinity,b.H=window.Infinity):(b.G=c.clientX,b.H=c.clientY);for(c=b.o.length=0;c<a.length;c++){var d=a.item(c);b.o.push(d.identifier)}};
g.h.LH=function(a){var b=this.O;a=a.changedTouches.item(0);var c;if(c=g.ec()){c=g.zb;var d="";Ab("Windows")?(d=/Windows (?:NT|Phone) ([0-9.]+)/,d=(c=d.exec(c))?c[1]:"0.0"):g.ec()?(d=/(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/,d=(c=d.exec(c))&&c[1].replace(/_/g,".")):Ab("Macintosh")?(d=/Mac OS X ([0-9_.]+)/,d=(c=d.exec(c))?c[1].replace(/_/g,"."):"10"):Ab("Android")?(d=/Android\s+([^\);]+)(\)|;)/,d=(c=d.exec(c))&&c[1]):Ab("CrOS")&&(d=/(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/,d=(c=d.exec(c))&&c[1]);c=!(0<=
g.ub(d||"",8))}if(c||a&&Math.pow(a.clientX-b.G,2)+Math.pow(a.clientY-b.H,2)>Math.pow(5,2))b.A=!0};
g.h.KH=function(a){if(this.O){var b=this.O,c=a.changedTouches;c&&b.F&&1==b.l&&!b.A&&!b.B&&!b.C&&hJ(b,c)&&(b.J=a,b.g.start());b.l=a.touches.length;0===b.l&&(b.F=!1,b.A=!1,b.o.length=0);b.B=!1}};
g.h.U=function(){this.clear(null);this.Pa(this.pa);for(var a=g.q(this.T),b=a.next();!b.done;b=a.next())this.Pa(b.value);g.Ns.prototype.U.call(this)};g.r(pJ,g.G);pJ.prototype.U=function(){this.l&&g.Dq(this.l);this.g.clear();qJ=null;g.G.prototype.U.call(this)};
pJ.prototype.register=function(a,b){b&&this.g.set(a,b)};
var qJ=null;g.r(uJ,dJ);uJ.prototype.addEventListener=function(a,b){this.C.subscribe(a,b)};
uJ.prototype.removeEventListener=function(a,b){this.C.unsubscribe(a,b)};
uJ.prototype.dispatchEvent=function(a){this.C.P(a.type,a)};g.r(vJ,g.G);g.h=vJ.prototype;g.h.Ah=function(a){a.append(this.view)};
g.h.bind=function(a){var b=a.renderer,c=b.trackingParams;if(this.o&&this.o!=c)throw Error("Cannot re-bind presenter with new tracking params");if(c){this.o=c;var d=this.view,e=this.Bb,f=d.ia();g.V(e).C&&g.kJ(e.app.L,f,d);g.V(e).C&&g.lJ(e.app.L,f,c)}this.l=b.impressionEndpoints||[];this.macros=Object.assign({},a.macros);return this.Li(a)};
g.h.Ma=function(){return this.A};
g.h.show=function(){this.view.show();this.A=!0;var a=this.Bb,b=this.view.ia();yI(a,b)&&g.xI(a,b,!0);this.lf(this.l);this.l=[]};
g.h.hide=function(){this.bp();this.A=!1;var a=this.Bb,b=this.view.ia();yI(a,b)&&g.xI(a,b,!1)};
g.h.bp=function(){this.view.hide()};
g.h.onClick=function(a){a=void 0===a?{}:a;this.jk(a);if(this.Ma()){a=this.Bb;var b=this.view.ia();yI(a,b)&&g.vI(a,b)}};
g.h.Ka=function(a){this.Ii.Ka(a,wJ(this))};
g.h.lf=function(a){var b=this,c=wJ(this);a.forEach(function(a){return b.Ii.Ka(a,c)})};g.r(xJ,g.N);g.h=xJ.prototype;g.h.ia=function(){return this.g.element};
g.h.show=function(){if(!this.g.Ma()){this.ca.M(window.document,"click",this.ME);this.g.show();var a=this.ia(),b=g.Bh(g.sh(this.A)).width,c=g.Bh(this.A),d=qh(this.A);a.style.top=d.y+c.height+"px";a.style.right=b-d.x-c.width+"px"}};
g.h.hide=function(){this.g.Ma()&&(this.g.hide(),g.Rq(this.ca))};
g.h.setTitle=function(a){a?this.o.show():this.o.hide();this.o.jb(zJ(a))};
g.h.ME=function(a){this.g.Ma()&&(a=a.target,g.Fd(this.A,a)||(g.Fd(this.l.g["ytp-ad-info-dialog-confirm-button"],a)?this.P("confirmClick"):g.Fd(this.g.element,a)||this.P("externalClick")))};
var aja={tO:"confirmClick",PO:"externalClick"};g.r(AJ,uJ);AJ.prototype.setTitle=function(a){this.g.setTitle(a)};
AJ.prototype.show=function(){this.g.show()};
AJ.prototype.hide=function(){this.g.hide()};
AJ.prototype.ia=function(){return this.g.ia()};var bja={TA:AJ},ama=["confirmClick","externalClick"];g.r(BJ,vJ);g.h=BJ.prototype;g.h.Li=function(a){var b=this.Hc();a=a.renderer;var c=b.g,d=a.confirmLabel||null;d?c.l.show():c.l.hide();c.l.jb(zJ(d));b.setTitle(a.title||null);b.g.g.jb(zJ(a.dialogMessage||null));g.yd(yJ(b.g));c=g.q(a.adReasons||[]);for(d=c.next();!d.done;d=c.next())d=d.value,yJ(b.g).appendChild(g.ud("li",null,zJ(d)));this.g=a.confirmServiceEndpoint||null;return window.Promise.resolve()};
g.h.bp=function(){vJ.prototype.bp.call(this);this.g&&(this.Ka(this.g),this.g=null)};
g.h.jk=function(a){switch(a.type){case "confirmClick":case "externalClick":this.hide()}};
g.h.Hc=function(){return this.view};
g.h.gd=function(){function a(a){return b.onClick(a)}
for(var b=this,c=g.q(ama),d=c.next();!d.done;d=c.next())this.ca.M(this.view,d.value,a)};g.r(CJ,Y);CJ.prototype.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);(a=(a=b.button&&b.button.buttonRenderer&&b.button.buttonRenderer.navigationEndpoint&&b.button.buttonRenderer.navigationEndpoint.adInfoDialogEndpoint)&&a.dialog&&a.dialog.adInfoDialogRenderer)?(b.hoverText?(b=tJ(b.hoverText),zd(this.o,b,0)):this.o=null,this.je.bind({renderer:a,macros:c}),this.show()):g.M(Error("adInfoDialogRenderer is missing in AdHoverTextButtonRenderer"))};
CJ.prototype.B=function(){this.o&&g.Ch(this.o,!1)};
CJ.prototype.J=function(){this.je.Ma()||this.o&&g.Ch(this.o,!0)};
CJ.prototype.H=function(){this.je.show();this.B()};g.r(DJ,cJ);DJ.prototype.C=function(a){g.Fd(this.qc.element,a.target)||(g.Iq(a),this.lf(this.l.onClickCommands),this.Ka(this.l.clickthroughEndpoint),this.o.nd("image-companion"))};g.r(EJ,bJ);EJ.prototype.Vc=function(){return!1};
EJ.prototype.B=function(){var a=new aJ;a.imageCompanionAdRenderer=this.g;return a};
EJ.prototype.A=function(){return this.C};
EJ.prototype.o=function(a,b,c){return new DJ(a,b,this.g,c)};g.r(FJ,RI);FJ.prototype.Vc=function(){return!1};g.r(GJ,cJ);g.r(HJ,bJ);HJ.prototype.Vc=function(){return!1};
HJ.prototype.B=function(){var a=this.g,b=new Xia;b.url=a.iframeUrl||null;b.width=a.iframeWidth||0;b.height=a.iframeHeight||0;b.impressionTrackingUrls=IJ(a.impressionCommands||[]);b.clickTrackingUrls=IJ(a.onClickCommands||[]);b.adInfoRenderer=a.adInfoRenderer||null;a=new aJ;a.iframeCompanionRenderer=b;return a};
HJ.prototype.A=function(){return[new g.ad(300,60)]};
HJ.prototype.o=function(a,b){return new GJ(a,b,this.g)};g.r(JJ,YI);JJ.prototype.Rh=function(){return!0};g.r(KJ,RI);KJ.prototype.Vc=function(){return!0};g.r(LJ,RI);LJ.prototype.Vc=function(){return!1};g.r(NJ,RI);NJ.prototype.Vc=function(){return!0};g.r(OJ,RI);OJ.prototype.Vc=function(){return!0};g.r(PJ,RI);PJ.prototype.Vc=function(){return!0};g.r(QJ,RI);QJ.prototype.Vc=function(){return!0};g.r(UJ,RI);UJ.prototype.Vc=function(){return!0};
UJ.prototype.vj=function(){return!0};
UJ.prototype.O=function(){return function(){return g.jd("video-ads")}};g.r(VJ,RI);VJ.prototype.Vc=function(){return!0};g.r(WJ,RI);WJ.prototype.Vc=function(){return!0};g.r(XJ,YI);YJ.prototype.wb=function(){return this.H};var kja=["FINAL","CPN","MIDROLL_POS","SDKV","SLOT_POS"];iK.prototype.send=function(a,b,c){try{var d=g.wg(a);if("https"===d[1])var e=a;else d[1]="https",e=g.vg("https",d[2],d[3],d[4],d[5],d[6],d[7]);var f=this.g?Pm.l:Ym.up(e),k=g.Lm(e,lja(b,c,f));a=void 0;if(Ap(e)){k=Jg(k,"abv","45");var l=this.l.getVideoData();l&&l.oauthToken&&this.o&&(a={Authorization:"Bearer "+l.oauthToken})}this.g?Zm(k,b,void 0,f):g.Vp(k,void 0,f,a)}catch(m){}};jK.prototype.g=function(){return"loggingUrls"};
jK.prototype.l=function(a,b,c){c=void 0===c?{}:c;a=g.q(a);for(var d=a.next();!d.done;d=a.next())d=d.value,d.baseUrl&&this.o.send(d.baseUrl,b,c)};kK.prototype.g=function(){return"muteAdEndpoint"};
kK.prototype.l=function(a){var b=this;switch(a.type){case "SKIP":g.Jf(function(){var a=b.o;a.l&&a.l.Ye()&&a.l.Zj()})}};lK.prototype.g=function(){return"pingingEndpoint"};
lK.prototype.l=function(){};g.r(nK,g.G);nK.prototype.U=function(){this.g={};g.G.prototype.U.call(this)};
nK.prototype.lf=function(a,b,c){var d=this;c=void 0===c?{}:c;a.forEach(function(a){return d.Ka(a,b,c)})};
nK.prototype.Ka=function(a,b,c){var d=this;c=void 0===c?{}:c;a.loggingUrls&&pK(this,"loggingUrls",a,b,c);Object.keys(a).filter(function(a){return"loggingUrls"!==a}).forEach(function(e){return pK(d,e,a,b,c)})};uK.prototype.g=function(){return"urlEndpoint"};
uK.prototype.l=function(a,b){if(a.url){var c=g.Lm(a.url,b);g.tK(c)}};vK.prototype.showCompanion=function(a,b,c){return wK(this).then(function(){return AK(a,b,c)})};BK.prototype.showCompanion=function(a,b){b.contentVideoId||(b.contentVideoId=a);this.l.na("updateKevlarOrC3Companion",b)};g.r(CK,g.N);CK.prototype.reduce=function(a){a=g.q(a);for(var b=a.next();!b.done;b=a.next())pja(this,b.value)};g.r(DK,g.G);DK.prototype.l=function(a){g.db(this.g,1E3*a)};g.r(EK,g.G);EK.prototype.U=function(){this.g=null;g.G.prototype.U.call(this)};g.r(FK,g.N);FK.prototype.dispose=function(){this.g.clear();g.N.prototype.dispose.call(this)};
var GK=null;g.ua("ytads.bulleit.getVideoMetadata",function(a){return(a=HK().g.get(a))?a.Lw():{}},void 0);
g.ua("ytads.bulleit.triggerExternalActivityEvent",function(a,b,c){var d=HK();c=qja(c);null!=c&&d.P(c,{queryId:a,viewabilityString:b})},void 0);g.r(NK,g.G);g.r(OK,g.G);g.r(eL,g.N);g.h=eL.prototype;g.h.Lw=function(){return{}};
g.h.gn=function(){};
g.h.fb=function(a){iL(this);this.P(a)};
g.h.Yu=function(){};
g.h.Yj=function(){return this.g.ec(2,!1)};
g.h.Uo=function(){var a=this.l;PK(a)||!bL(a,"impression")&&!bL(a,"start")||bL(a,"abandon")||bL(a,"complete")||bL(a,"skip")||(RK(a)?XK(a,"pause"):WK(a,"pause"))};
g.h.Ql=function(){this.T?g.R(g.V(this.g).experiments,"bulleit_add_post_play_adblock_error")&&this.Rb("ui_unstable"):this.F||this.Eb()};
g.h.yd=function(){ZK(this.l,this.Yj())};
g.h.Tc=function(){var a=this.l;!bL(a,"impression")||bL(a,"skip")||bL(a,"complete")||XK(a,"abandon")};
g.h.Ng=function(){var a=this.l;g.R(g.V(a.g).experiments,"ensure_only_one_ads_termination_ping_for_bulleit_living_room")?!bL(a,"impression")||bL(a,"abandon")||bL(a,"complete")||WK(a,"skip"):WK(a,"skip")};
g.h.Eb=function(){if(!this.F){var a=kL(this);this.l.o.AD_CPN=a;YK(this.l);this.F=!0}};
g.h.Rb=function(a){a=a||"";var b="",c="",d="";IK(this.g)&&(b=g.YH(this.g,2).g,this.g.app.B&&(c=this.g.app.B.ae(),null!=this.g.app.B.Ue()&&(d=this.g.app.B.Ue())));var e=this.l;e.o=fK(e.o,dK(3,"There was an error playing the video ad. "+("Error code: "+a+"; s:"+b+"; ")+("rs:"+c+"; ec:"+d)));WK(e,"error")};
g.h.Mh=function(){};
g.h.Sy=function(){this.P("c")};
g.h.Ty=function(){this.P("h")};
g.h.Uy=function(){this.P("i")};
g.h.Vy=function(){this.P("j")};
g.h.Wy=function(){this.P("k")};
g.h.Xy=function(){this.P("l")};
g.h.Yy=function(){this.P("q")};
g.h.dispose=function(){if(!this.ea()){iL(this);this.A.unsubscribe("c",this.Sy,this);this.A.unsubscribe("h",this.Ty,this);this.A.unsubscribe("i",this.Uy,this);this.A.unsubscribe("j",this.Vy,this);this.A.unsubscribe("k",this.Wy,this);this.A.unsubscribe("l",this.Xy,this);this.A.unsubscribe("q",this.Yy,this);for(var a=this.A,b=[],c=g.q(a.g),d=c.next();!d.done;d=c.next()){d=g.q(d.value);var e=d.next().value;d.next().value==this&&b.push(e)}b=g.q(b);for(c=b.next();!c.done;c=b.next())a.g["delete"](c.value);
g.N.prototype.dispose.call(this)}};
g.h.ju=function(){return""};g.r(lL,NI);g.r(nL,eL);nL.prototype.Vb=function(){var a=this,b=new lL(this.C.g,this.macros),c=this.g.getVideoData(2);c&&c.profilePicture&&oL(c,b)?pL(this,c,b):(this.o=function(c,e,f){e&&2==f&&oL(e,b)&&e.profilePicture&&(a.o&&(a.g.removeEventListener("videodatachange",a.o),a.o=null),pL(a,e,b))},this.g.addEventListener("videodatachange",this.o))};
nL.prototype.Mh=function(a){cL(this.l,a)};
nL.prototype.U=function(){this.o&&(this.g.removeEventListener("videodatachange",this.o),this.o=null);eL.prototype.U.call(this)};g.r(qL,NI);g.r(rL,eL);g.h=rL.prototype;g.h.Vb=function(){0<this.o&&this.Eb()};
g.h.Eb=function(){this.Fa=new g.L(g.Ea(this.fb,"f"),this.o,this);g.I(this,this.Fa);this.Fa.start();hL(this,[new qL(this.B.g,this.macros)]);eL.prototype.Eb.call(this)};
g.h.Tc=function(){eL.prototype.Tc.call(this);this.fb("a")};
g.h.yd=function(){eL.prototype.yd.call(this);for(var a=g.q(this.B.g.completionCommands||[]),b=a.next();!b.done;b=a.next())this.G.Ka(b.value,this.macros)};
g.h.fb=function(a){this.Fa&&this.Fa.stop();"f"==a&&this.yd();eL.prototype.fb.call(this,a)};g.r(sL,NI);g.r(tL,eL);tL.prototype.Vb=function(){this.Eb()};
tL.prototype.Eb=function(){hL(this,[new sL(this.o.g,this.macros)]);eL.prototype.Eb.call(this)};
tL.prototype.Tc=function(){eL.prototype.Tc.call(this);this.fb("a")};
tL.prototype.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};g.r(uL,NI);g.r(vL,eL);g.h=vL.prototype;g.h.Vb=function(){0>=this.G&&(g.M(Error("durationMs was specified incorrectly with a value of: "+this.G)),this.yd());this.Eb();this.g.addEventListener("progresssync",this.H)};
g.h.Tc=function(){eL.prototype.Tc.call(this);this.fb("b")};
g.h.Eb=function(){eL.prototype.Eb.call(this);this.o=Math.floor(this.g.ya());this.B=this.o+this.G/1E3;hL(this,[new uL(this.J.g)]);var a=this.g.getVideoData(1);a=a&&a.clientPlaybackNonce||"";var b=g.js();b&&Nr("adNotify",{clientScreenNonce:b,adMediaTimeSec:this.o,timeToAdBreakSec:Math.ceil(this.B-this.o),clientPlaybackNonce:a})};
g.h.yd=function(){eL.prototype.yd.call(this);this.fb("f")};
g.h.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};
g.h.fb=function(a){this.g.removeEventListener("progresssync",this.H);iL(this);this.P(a)};g.r(wL,NI);g.r(xL,eL);xL.prototype.Vb=function(){var a=new wL(this.C.g,this.macros);hL(this,[a])};g.r(yL,eL);yL.prototype.Vb=function(){var a=kL(this);this.l.o.AD_CPN=a;YK(this.l)};g.r(zL,NI);g.r(AL,eL);AL.prototype.Vb=function(){var a=new zL(this.o.g,this.macros);hL(this,[a])};g.r(BL,NI);g.r(CL,eL);CL.prototype.Vb=function(){this.Eb()};
CL.prototype.Eb=function(){hL(this,[new BL(this.o.g,this.macros)]);eL.prototype.Eb.call(this)};
CL.prototype.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};g.r(DL,NI);g.r(EL,eL);EL.prototype.Vb=function(){var a=new DL(this.o.g,this.macros);hL(this,[a])};g.r(FL,NI);g.r(GL,eL);GL.prototype.Vb=function(){var a=new FL(this.C.g,this.macros);hL(this,[a])};
GL.prototype.Mh=function(a){cL(this.l,a)};g.r(HL,NI);g.r(IL,eL);g.h=IL.prototype;g.h.Vb=function(){this.Eb()};
g.h.gn=function(){this.o&&(this.o.g=!0,tja(this,[this.o]))};
g.h.Eb=function(){this.o=new HL(this.B.g);this.o.g=this.B.A;hL(this,[this.o]);eL.prototype.Eb.call(this)};
g.h.Yj=function(){return this.B.o};
g.h.Tc=function(){eL.prototype.Tc.call(this);this.fb("a")};
g.h.Ng=function(){eL.prototype.Ng.call(this);this.fb("f")};
g.h.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};
g.h.fb=function(a){iL(this);"a"!=a&&IM(this.G.da);this.P(a)};
g.h.Mh=function(a){switch(a){case "skip-button":this.Ng();break;case "survey-submit":this.fb("f")}};g.r(JL,NI);g.r(KL,eL);KL.prototype.Vb=function(){this.Eb()};
KL.prototype.Eb=function(){hL(this,[new JL(this.o.g,this.macros)]);eL.prototype.Eb.call(this)};
KL.prototype.Tc=function(){eL.prototype.Tc.call(this);this.fb("a")};
KL.prototype.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};g.r(LL,NI);g.r(ML,eL);g.h=ML.prototype;g.h.Vb=function(){0<this.o&&this.Eb()};
g.h.Eb=function(){this.Fa=new g.L(this.yd,this.o,this);g.I(this,this.Fa);this.Fa.start();hL(this,[new LL(this.B.g)]);eL.prototype.Eb.call(this)};
g.h.yd=function(){eL.prototype.yd.call(this);this.fb("f");for(var a=g.q(this.B.g.completeCommands||[]),b=a.next();!b.done;b=a.next())this.G.Ka(b.value,this.macros)};
g.h.Tc=function(){eL.prototype.Tc.call(this);this.fb("a")};
g.h.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};
g.h.fb=function(a){this.Fa&&this.Fa.stop();eL.prototype.fb.call(this,a)};g.r(RL,g.G);RL.prototype.start=function(){this.ea()||this.g||(this.o=(0,g.D)(),this.g=new g.L(this.B,Math.max(0,this.A-this.l),this),g.I(this,this.g),this.g.start())};
RL.prototype.stop=function(){this.g&&(this.o=this.l=0,SL(this))};
RL.prototype.pause=function(){this.g&&(this.l+=(0,g.D)()-this.o,SL(this))};
RL.prototype.U=function(){SL(this);g.G.prototype.U.call(this)};g.r(TL,NI);g.r(UL,NI);g.r(VL,NI);g.r(WL,NI);g.r(XL,NI);g.r(YL,NI);g.r(ZL,NI);g.r(aM,eL);g.h=aM.prototype;g.h.Lw=function(){return{currentTime:this.g.ya(2,!1),duration:this.o.l,isPlaying:JK(this.g),isVpaid:!1,isYouTube:!0,volume:this.g.Jb()/100}};
g.h.Vb=function(){if(this.o.H)jL(this),this.fb("g");else{var a=this.o.g.legacyInfoCardVastExtension,b=this.o.B;a&&b&&g.V(this.g).G.add(b,{pl:a});try{var c=this.o.g.sodarExtensionData;if(c&&c.siub&&c.bgub&&c.scs&&c.bgp){var d=c.scs,e=c.bgub,f=c.bgp;a=window;var k="//tpc.googlesyndication.com/sodar/"+g.lb(c.siub)+".js",l="//pagead2.googlesyndication.com/bg/"+g.lb(e)+".js",m=a.document;c={};d&&(c._scs_=d);c._bgu_=l;c._bgp_=f;c._li_="v_h.3.0.0.0";var n=a.GoogleTyFxhY;n&&"function"==typeof n.push||(n=
a.GoogleTyFxhY=[]);n.push(c);var p=g.fd(m).createElement("SCRIPT");p.type="text/javascript";p.async=!0;g.Sc(p,g.Od(k));m.getElementsByTagName("head")[0].appendChild(p)}}catch(u){g.M(u)}MK(this.g,!1);d=UI(this.o);f=g.V(this.g);g.R(g.V(this.g).experiments,"disable_force_iv_load_policy_on_bulleit")||(f.o||g.gy(f)||g.py(f)?d.iv_load_policy=3:d.iv_load_policy=1);g.R(g.V(this.g).experiments,"mdx_player_vars_killswitch")||(k=this.g.getVideoData(),k.Ee&&(d.ctrl=k.Ee),k.Fe&&(d.ytr=k.Fe),k.vl&&(d.ytrcc=k.vl),
k.isMdxPlayback&&(d.mdx="1"));this.X&&this.P("p",-1);if(fM(f)){l=eM(this);k=this.Y;f=Bja();if(l.skipOrPreviewRenderer)switch(Object.keys(l.skipOrPreviewRenderer)[0]){case "skipAdRenderer":xja(k,f,l.skipOrPreviewRenderer.skipAdRenderer)}if(l.adInfoRenderer)switch(Object.keys(l.adInfoRenderer)[0]){case "adHoverTextButtonRenderer":l=l.adInfoRenderer.adHoverTextButtonRenderer,l.button&&l.button.buttonRenderer&&l.button.buttonRenderer.serviceEndpoint&&l.button.buttonRenderer.serviceEndpoint.adInfoDialogEndpoint&&
(m=l.button.buttonRenderer.serviceEndpoint.adInfoDialogEndpoint.dialog)&&m.adInfoDialogRenderer&&(yja(k,f,m.adInfoDialogRenderer),f.whyThisAdInfo.menuTitle=NL(l.hoverText)||"",m.adInfoDialogRenderer.muteAdRenderer&&(l=m.adInfoDialogRenderer.muteAdRenderer.buttonRenderer)&&Aja(k,f,l))}f.isBumper=VI(k.g)&&!f.isSkippable;k.g.isSkippable();l=k.g.B;m=k.g.getVideoUrl();l?f.videoId=l:m&&(f.videoUrl=m);if(k=(k=k.g.C)&&k.urlEndpoint)f.clickThroughUrl=k.url||"";f.sendAdsPing=g.Vp;f.attributionInfo=bM(this);
this.g.na("onAdInfoChange",f)}hM(this.H)?this.G.start():(this.g.wm(d,2),this.G.start(),this.g.Kb(2))}};
g.h.Uo=function(){eL.prototype.Uo.call(this);this.P("m",2)};
g.h.Ql=function(){eL.prototype.Ql.call(this);this.P("n",1)};
g.h.Eb=function(){eL.prototype.Eb.call(this);this.G.stop();if(this.da){this.O.M(this.g,g.aC("bltplayback"),this.ZI);var a=new g.YB(0x7ffffffffffff,0x8000000000000,{id:"bltcompletion",namespace:"bltplayback",priority:1});g.kI(this.g,[a],2)}a=this.H;var b=this.g.getVideoData(2);a.X=b?b.clientPlaybackNonce:null;a=[];var c=g.V(this.g);b=this.g.getVideoData(2);if(fM(c)){var d=b&&b.isListed?{channelId:b.vh,channelThumbnailUrl:b.profilePicture||"",channelTitle:b.author,videoTitle:b.title,channelVideoCount:0,
showAdInfoIcon:!1,whyThisAdInfo:null,muteAdInfo:null}:null;d&&this.g.na("onAdMetadataAvailable",d)}g.R(c.experiments,"tv_html5_bulleit_unify_adinfo")?d=!g.gy(c):(d=g.py(c)&&g.gy(c),d=!g.gy(c)||d);d&&(g.py(c)&&(b&&b.videoId&&b.isListed&&b.videoId==this.o.B&&(c=b.title,d=b.author,b=b.profilePicture,c&&d&&b?b=[new VL(c),new UL(b),new WL(d)]:(g.M(Error("Channel metadata contains null for "+(c?d?"channel icon thumbnail.":"channel name.":"video title."),"WARNING")),b=[]),hL(this,b)),a.push(bM(this)),b=
this.o.C,null==b?b=null:(c={},b.urlEndpoint&&(c.url=b.urlEndpoint.url,c.target="TARGET_NEW_WINDOW"),b=new ZL({navigationEndpoint:{urlEndpoint:c}})),b&&a.push(b),this.o.isSkippable()&&!VI(this.o)&&(b=eM(this),(b=b.skipOrPreviewRenderer&&b.skipOrPreviewRenderer.skipAdRenderer)||(b=cM(this)),a.push(new YL(b)))),b=eM(this),a.push(new XL(b)),hL(this,a));this.g.isMuted()&&(a=this.l,b=this.g.isMuted(),RK(a)||WK(a,b?"mute":"unmute"));this.P("n",1);this.R&&this.g.na("onAdStart");a=this.Z;b=this.o.B||"";(c=
a.l.xb())&&c.getVideoData().videoId===b?(c.A?(c=c.A,b=LB(c,"engage"),b.o=1,c=RA(c.g),b=g.Ea(kha,b.oa,HB(b),FB(b),c)):b=null,a.g=b):a.g=null};
g.h.ZI=function(a){"bltcompletion"==a.getId()&&(g.oI(this.g,"bltplayback",2),ZK(this.l,this.Yj()))};
g.h.yd=function(){eL.prototype.yd.call(this);this.fb("f");for(var a=g.q(this.o.g.completeCommands||[]),b=a.next();!b.done;b=a.next())this.H.Ka(b.value,this.macros)};
g.h.Tc=function(){eL.prototype.Tc.call(this);this.fb("a")};
g.h.Ng=function(){eL.prototype.Ng.call(this);this.fb("f")};
g.h.Rb=function(a){eL.prototype.Rb.call(this,a);this.fb("g")};
g.h.fb=function(a){this.G.stop();this.B&&this.B.stop();iL(this);MK(this.g,!0);"a"!=a&&IM(this.H.da);this.R&&("a"!=a&&this.g.na("onAdComplete"),this.g.na("onAdEnd"));this.P(a)};
g.h.gn=function(){this.tv&&this.g.Kb()};
g.h.Yu=function(a){this.B&&(g.sB(a.state)?this.B.start():this.B.pause())};
g.h.tv=function(){return 2==this.g.Kd(2)};
g.h.Mh=function(a){var b=this.l;if(!g.R(g.V(b.g).experiments,"disable_vss2_engage_for_bulleit")&&IK(b.g))switch(a){case "ad-title":b.g.we(14,void 0,2);break;case "ad-channel-thumbnail":case "advertiser-name":b.g.we(15,void 0,2);break;case "visit-advertiser":b.g.we(3,void 0,2)}switch(a){case "ad-mute-confirm-dialog-confirm-button":case "ad-feedback-dialog-close-button":case "ad-feedback-dialog-confirm-button":g.R(g.V(this.g).experiments,"enable_mute_ad_endpoint_resolution_on_bulleit")||this.fb("f");
break;case "ad-mute-confirm-dialog-close-button":case "ad-feedback-undo-mute-button":case "ad-info-dialog-close-button":this.J||this.gn();break;case "ad-info-icon-button":(this.J=this.tv())||this.g.Lb();break;case "ad-channel-thumbnail":case "advertiser-name":a=g.V(this.g).protocol+"://"+g.ky(g.V(this.g))+"/channel/"+this.o.R;g.tK(a);break;case "ad-title":this.g.Lb();g.tK(this.g.getVideoUrl());break;case "visit-advertiser":this.g.Lb();g.py(g.V(this.g))&&(a=this.o.C)&&(sja(this.l,a.loggingUrls||null),
a.urlEndpoint&&a.urlEndpoint.url&&g.tK(a.urlEndpoint.url));a=this.l;PK(a)||XK(a,"clickthrough");break;case "skip-button":this.Ng()}};
g.h.ju=function(a,b){if(this.o.H)return jL(this),this.fb("g"),"";if(!Number.isFinite(a))return g.M(Error("Playing the video after the current media has finished is not supported")),"";if(a>b)return g.M(Error("Start time is later then end time")),"";var c=1E3*this.o.l,d=UI(this.o);d=Qka(this.g.app.sa,d,c,a,b);if(a+c>b){c=b-a;for(var e=this.g.app.sa,f,k=g.q(e.l),l=k.next();!l.done;l=k.next())if(l=l.value,l.qd==d){f=l;break}hR(e,f,c,f.Be)}return d};
g.h.dispose=function(){JK(this.g)&&!hM(this.H)&&this.g.Kc(2);eL.prototype.dispose.call(this)};g.r(rM,g.N);g.h=rM.prototype;g.h.Ye=function(){var a=this.A;return a.g instanceof TI||a.g instanceof UJ||a.g instanceof YI};
g.h.wb=function(){return this.A.wb()};
g.h.Hm=function(){return $J(this.A)};
g.h.pq=function(){return ZJ(this.A)};
g.h.Vo=function(a){JI(a)||(this.Z&&(this.ga=this.g.isPeggedToLive(),this.da=Math.ceil((0,g.D)()/1E3)),qM(a,this.o));UM(this.o,this);if(!this.A.o.hasOwnProperty("ad_placement_start")){a=g.q(this.A.G);for(var b=a.next();!b.done;b=a.next())tM(b.value);this.A.o.ad_placement_start=!0}a=this.J;a.o=!1;a=g.R(g.V(a.l).experiments,"video_to_ad_use_gel")||!1;Jz("video_to_ad",["apbs"],void 0,void 0,a);this.Iy()};
g.h.Xl=function(){return this.C instanceof FJ||this.C instanceof XI||this.C instanceof WI||this.C instanceof bJ};
g.h.ov=function(){return!(this.C instanceof LJ)&&!this.Xl()};
g.h.Aj=function(){return this.C instanceof TI};
g.h.Iy=function(){this.C?this.Vb(this.C):this.kf()};
g.h.kh=function(a,b){a=void 0===a?!1:a;b=void 0===b?!1:b;aN(this.o,0);this.kf(a,b)};
g.h.Hx=function(){this.kh()};
g.h.aI=function(){WK(this.l.l,"active_view_measurable")};
g.h.bI=function(){var a=this.l.l;PK(a)||dL(a)||WK(a,"active_view_fully_viewable_audible_half_duration")};
g.h.eI=function(){};
g.h.fI=function(){};
g.h.gI=function(){};
g.h.hI=function(){};
g.h.jI=function(){var a=this.l.l;PK(a)||dL(a)||WK(a,"active_view_viewable")};
g.h.tq=function(a){if(null!==this.l){this.X||(a=new g.uB(a.state,new g.iB),this.X=!0);this.l.Yu(a);var b=a.state;if(this.ka&&g.U(b,1024))this.l.Rb("dom_paused");else{var c=a;(g.R(g.V(this.g).experiments,"html5_bulleit_handle_gained_ended_state")?0<g.vB(c,2):g.U(c.state,2))?(b=this.J,b.o=!1,b.L?(b=b.l&&g.V(b.l)&&g.R(g.V(b.l).experiments,"ad_to_video_use_gel")||!1,Jz("ad_to_video",["pbresume"],void 0,void 0,b)):Jz("ad_to_ad",["apbs"]),this.l.yd()):(c=a,(g.R(g.V(this.g).experiments,"html5_bulleit_handle_gained_playing_state")?
g.pB(c.state)&&!g.pB(c.g):g.pB(c.state))?(b=this.J,b.F&&!b.o&&(b.J=!1,b.o=!0,"ad_to_video"!=b.g&&(0,g.VB)("apbs",void 0,b.g)),this.l.Ql()):b.isError()?this.l.Rb(b.l.errorCode):(b=a,(g.R(g.V(this.g).experiments,"html5_bulleit_handle_gained_paused_state")?0<g.vB(b,4):g.U(b.state,4))&&(this.Y||this.l.Uo())))}if(0<g.vB(a,16)&&(b=this.l.l,!PK(b))){c=b.l;if(c.vj()){c=c.G;var d=void 0===d?{}:d;(d=gm.getInstance().Ol(c,d))&&Dk(d)}b.l.F.seek=!0}0>g.vB(a,4)&&!(0>g.vB(a,2))&&(a=this.l.l,PK(a)||(RK(a)?XK(a,"resume"):
WK(a,"resume")))}};
g.h.Nw=function(){};
g.h.resume=function(){this.l&&this.l.gn()};
g.h.qq=function(){this.ba?this.l&&this.l.fb("f"):this.Ye()&&this.kf()};
g.h.Zj=function(){this.qq()};
g.h.Mw=function(a){var b=this.o;hM(b)||b.g.na("onAdUxUpdate",a)};
g.h.ki=function(a){this.l.Mh(a)};
g.h.vu=function(){return 0};
g.h.xu=function(){return 1};
g.h.ku=function(){if(this.Aj()){var a=this.Go(),b=this.wb().start,c=1E3*a.l;xM(this,a,b,b+c);lM(this.L,LI(this.wb()),c)}};
g.h.Vb=function(a){g.Xe(this.l);this.l=a=gM(this.g,a,this.macros,this.H,this.o);a.subscribe("a",g.Ea(this.kh,!0),this);a.subscribe("b",g.Ea(this.kh,!0,!0),this);a.subscribe("c",this.aI,this);a.subscribe("f",this.kh,this);a.subscribe("g",this.Hx,this);a.subscribe("h",this.bI,this);a.subscribe("i",this.eI,this);a.subscribe("j",this.fI,this);a.subscribe("k",this.gI,this);a.subscribe("l",this.hI,this);a.subscribe("m",this.rq,this);a.subscribe("n",this.rq,this);a.subscribe("p",this.rq,this);a.subscribe("onAdUxUpdate",
this.Mw,this);a.subscribe("q",this.jI,this);fL(a);uM(this,!1)};
g.h.kf=function(a,b){a=void 0===a?!1:a;b=void 0===b?!1:b;this.Y=!0;g.Xe(this.l);if(a)var c=!1;else hM(this.o)?(c=this.g.ya(2,!0),c=1>=Math.abs(c-this.A.wb().end/1E3)):c=!0;if(c&&!this.A.o.hasOwnProperty("ad_placement_end")){c=g.q(this.A.F);for(var d=c.next();!d.done;d=c.next())tM(d.value);this.A.o.ad_placement_end=!0}b||hM(this.o)?SM(this.o,!0):this.Z&&this.pq()&&this.Aj()?SM(this.o,!1,Gja(this)):SM(this.o,!1);uM(this,!0)};
g.h.rq=function(a){aN(this.o,a)};
g.h.Go=function(){return this.C};
g.h.isLiveStream=function(){return this.Z};
g.h.reset=function(){return new rM(this.o,this.g,new mM(this.g),this.A,eK(cK(this.g)),this.L,this.R,this.H)};
g.h.U=function(){g.Xe(this.l);this.l=null;g.N.prototype.U.call(this)};g.r(yM,eL);g.h=yM.prototype;g.h.Vo=function(a){var b=this;JI(a)||qM(a,this.J);if(this.o instanceof HJ){a=this.g.getVideoData(2);if(!a||a.Af||null==this.o.g||this.o.g.adVideoId!=a.videoId){this.B=function(a,d,e){d&&2==e&&null!=b.o.g&&b.o.g.adVideoId==d.videoId&&(b.B&&(b.g.removeEventListener("videodatachange",b.B),b.B=null),d.isListed&&fL(b))};
this.g.addEventListener("videodatachange",this.B);return}if(!a.isListed)return}fL(this)};
g.h.Vb=function(){var a=this;UM(this.J,this);if(KK(this.g)){var b=this.g.getVideoData(1),c=this.o.B();null!=c&&(c.macros=Object.assign({},this.macros),this.O.showCompanion(b.videoId,c))}else{var d=this.o.A();oja(this.O).then(function(b){a:{if(d&&b){b=g.q(b);for(var c=b.next();!c.done;c=b.next()){c=c.value;for(var e=g.q(d),l=e.next();!l.done;l=e.next())if(l=l.value,l.width==c.width&&l.height==c.height){b=l;break a}}}b=null}b&&(c=a.o.o(a.g,a.J,b),null!=c&&(g.I(a,c),e=a.O,e.g&&e.g.showCompanion(c.element,
b.width,b.height)))})}if(this.o instanceof HJ){this.G=function(b){var c;
if(c=b.data)a:{try{if(Ap(b.source.document.location.origin)){c=!0;break a}}catch(l){g.M(l)}c=!1}if(c)if(c=a.o.g,"companion-setup-complete"==b.data)try{b.source.postMessage(JSON.stringify(c),"*");var d=b.source.frameElement;d.parentNode.style.cssText="";d.width=String(c.iframeWidth);d.height=String(c.iframeHeight)}catch(l){g.M(l)}else"pause-video"==b.data&&a.g.Lb()};
try{window.addEventListener("message",this.G)}catch(e){g.M(e)}}};
g.h.ki=function(a){cL(this.l,a)};
g.h.wb=function(){return this.H.wb()};
g.h.Hm=function(){return $J(this.H)};
g.h.pq=function(){return ZJ(this.H)};
g.h.Xl=function(){return!0};
g.h.U=function(){if(this.G)try{window.removeEventListener("message",this.G),this.G=null}catch(a){g.M(a)}this.B&&(this.g.removeEventListener("videodatachange",this.B),this.B=null);eL.prototype.U.call(this)};g.r(AM,g.N);g.h=AM.prototype;g.h.wb=function(){return this.g.wb()};
g.h.Hm=function(){return $J(this.g)};
g.h.pq=function(){return ZJ(this.g)};
g.h.Xl=function(){return!1};
g.h.ki=function(){};
g.h.Vo=function(a){var b=this,c=[];this.Hm()||(c=oM(a));a=this.g.l;g.R(g.V(this.C).experiments,"update_index_for_live_midrolls_on_bulleit")&&this.g.A&&(a=a.replace(/index=1/,"index=[LIVE_INDEX]"));$f(this.B.fetch(a,{WB:this.g.A||void 0,hd:this.g.wb(),Vz:Pja(this.l.da)}).then(function(a){if(!b.ea()){var d=c;a=Lja(b,a);var f=b.A,k=!a.isEmpty;hM(f.g)&&!k&&kM("DAI_ERROR_TYPE_NO_AD_BREAK_RENDERER",iM(f));a.qv||!zM(b.g.l)&&a.isEmpty&&b.F||(pM(d,b.l),zM(b.g.l)&&(d=b.l,f=d.R,d.R=null,f&&(a.Qn.some(Ija)&&
(f.renderer.backfillMpuCompanionAdRenderer.type="BACKFILL_MPU_TYPE_AFV"),QM(b.l,[f]),b.o=!0)),a.isEmpty||QM(b.l,a.Qn))}},function(){pM(c,b.l);
var a=b.A;hM(a.g)&&kM("DAI_ERROR_TYPE_AD_REQUEST_FAIL",iM(a))}),function(){(b.Hm()||b.o)&&PM(b.l)})};var Mja=Object.freeze([NJ,OJ,UJ,VJ,WJ,TI]);g.r(CM,rM);g.h=CM.prototype;g.h.ku=function(){for(var a=this.wb().start,b=g.q(EM(this)),c=b.next();!c.done;c=b.next()){c=c.value[0];var d=a+1E3*c.l;if(!xM(this,c,a,d))break;a=d}a=1E3*EM(this).reduce(function(a,b){return a+b[0].l},0);
lM(this.L,LI(this.wb()),a)};
g.h.ov=function(){for(var a=g.q(EM(this)),b=a.next();!b.done;b=a.next())if(b.value.some(function(a){return a.Vc()}))return!0;
return!1};
g.h.Aj=function(){return this.T instanceof TI};
g.h.Iy=function(){hM(this.o)?sM(this):(this.F.A||DM(this),FM(this))};
g.h.Vb=function(a){if(g.R(g.V(this.g).experiments,"enable_composite_ad_player_presentation_for_bulleit")){var b=BM(a);this.T&&b&&this.O!==b&&(b?TM(this.o):XM(this.o),this.O=b)}this.T=a;hM(this.o)&&(this.G=this.F.g.findIndex(function(b){return b.some(function(b){return b===a})}));
rM.prototype.Vb.call(this,a)};
g.h.kf=function(a,b){a=void 0===a?!1:a;b=void 0===b?!1:b;this.B&&(g.Xe(this.B),this.B=null);rM.prototype.kf.call(this,a,b)};
g.h.Zj=function(){this.ba&&(this.G=this.F.g.length,this.B&&this.B.fb("f"),this.l&&this.l.fb("f"));this.kf()};
g.h.Nw=function(a){FM(this,a)};
g.h.qq=function(){this.kh()};
g.h.tq=function(a){rM.prototype.tq.call(this,a);a=a.state;g.U(a,2)&&this.B?this.B.yd():g.pB(a)?(null==this.B&&DM(this),this.B&&this.B.Ql()):a.isError()&&this.B&&this.B.Rb(a.l.errorCode)};
g.h.kh=function(a,b){a=void 0===a?!1:a;b=void 0===b?!1:b;hM(this.o)||(aN(this.o,0),a?this.kf(a,b):FM(this))};
g.h.Hx=function(){1==this.F.o?this.kf():this.kh()};
g.h.ki=function(a){rM.prototype.ki.call(this,a);this.B&&this.B.Mh(a)};
g.h.Go=function(){var a=EM(this);return a.length&&a[0].length?a[0][0]:null};
g.h.U=function(){g.Xe(this.B);this.B=null;rM.prototype.U.call(this)};
g.h.Ye=function(){return g.R(g.V(this.g).experiments,"enable_composite_ad_player_presentation_for_bulleit")?this.O:rM.prototype.Ye.call(this)};
g.h.reset=function(){return new CM(this.o,this.g,new mM(this.g),this.A,eK(cK(this.g)),this.L,this.R,this.H)};
g.h.vu=function(){return this.G};
g.h.xu=function(){return this.F.g.length};g.r(GM,g.G);GM.prototype.addEventListener=function(a,b){this.g=b};
GM.prototype.removeEventListener=function(){this.g=null};
g.r(HM,g.G);HM.prototype.addEventListener=function(a,b,c){this.g.addEventListener(a,b,c)};
HM.prototype.removeEventListener=function(a,b){this.g.removeEventListener(a,b)};var JM=null,LM=null;g.ua("yt.www.ads.eventcache.getLastCompanionData",function(){return JM},void 0);
g.ua("yt.www.ads.eventcache.getLastPlaShelfData",function(){return LM},void 0);g.r(OM,g.N);g.h=OM.prototype;
g.h.init=function(){var a=this.g.getVideoData();if(a.Zn||g.ep("SERVED_VIA_SPF_HISTORY"))g.R(g.V(this.g).experiments,"directly_unlock_preroll_on_cached_playbacks_for_bulleit")?this.O():PM(this);else{if(KK(this.g)){var b=Vs(this.g);b.addEventListener("updateKevlarOrC3Companion",KM);b.addEventListener("onPlaShelfInfoCardsReady",MM);window.addEventListener("yt-navigate-start",NM)}this.ca.M(this.g,"applicationplayerstatechange",this.FG);this.ca.M(this.g,g.aC("ad"),this.Gm,this);this.ca.M(this.g,"crx_ad",
this.GG,this);this.ca.M(this.g,"aduxclicked",this.iI);this.ca.M(this.g,"videodatachange",this.JG);b=a.getPlayerResponse()||{};b=Qja(b);b=Rja(this,b);0<b.length&&QM(this,b);this.G&&a.subscribe("cuepointupdated",this.Uq,this);this.L&&a.liveUtcStartSeconds&&!a.ra&&a.ma&&this.Uq(dx(a.ma,0));PM(this);g.Jf(this.jN,this)}};
g.h.U=function(){this.Z=!0;g.Rq(this.ca);this.G&&this.g.getVideoData(1).unsubscribe("cuepointupdated",this.Uq,this);if(KK(this.g)){var a=Vs(this.g);a.removeEventListener("updateKevlarOrC3Companion",KM);a.removeEventListener("onPlaShelfInfoCardsReady",MM);window.removeEventListener("yt-navigate-start",NM);JM=null}a=g.q(this.A.values());for(var b=a.next();!b.done;b=a.next())WM(this,b.value);SM(this,!1);this.C.clear();this.F=[];this.J.clear();g.Xe(this.o);this.o=null;this.A.clear();g.N.prototype.U.call(this)};
g.h.Gm=function(a){if(!a.l&&(!KI(a)||a.contains(1E3*this.g.ya()||0))){var b=g.YH(this.g);g.U(b,32)||g.U(b,16)?this.J.add(a):(b=this.A.get(a))?b.Vo(a):g.M(Error("coordinator not found for "+a.toString()))}};
g.h.GG=function(a){a.l&&(a.l=!1);this.J["delete"](a)};
g.h.Uq=function(a){Eja(this.pa,a);null==this.G?g.M(Error("Dynamically inserted ad was requested, but no cuepoint AdPlacementRenderer was present to fulfill the request.")):g.py(g.V(this.g))&&this.g.getVideoData(1).xf()?this.H.reduce(a):0!=(this.g.ya()||0)&&(a=a.filter(function(a){return"start"==a.event}),QM(this,[this.G],a))};
g.h.kK=function(a){QM(this,[this.G],[a])};
g.h.zJ=function(a){a*=1E3;a=void 0===a?-1:a;iR(this.g.app.sa,void 0===a?-1:a)};
g.h.IG=function(a){this.l&&this.l.tq(a)};
g.h.FG=function(a){0>g.vB(a,16)&&(this.J.forEach(this.Gm,this),this.J.clear())};
g.h.JG=function(){if(this.l){var a=this.l;hM(a.o)&&sM(a)}if(hM(this)){hM(this);a=1E3*this.g.ya();for(var b=g.q(this.A.keys()),c=b.next();!c.done;c=b.next())if(c=c.value,c.start<=a&&a<c.end){this.Gm(c);break}}};
g.h.XL=function(){if(IK(this.g)&&this.l){var a=this.g.ya(2,!1),b=this.l.l;b.F&&UK(b.l,a,b.Yj())}};
g.h.ZH=function(){this.ga=!0;this.l&&this.l.l.Tc()};
g.h.iI=function(a){this.l&&this.l.ki(a);this.o&&this.o.ki(a)};
g.h.KG=function(){if(2==this.g.Da()&&this.l){var a=this.l.l,b=a.l;a=a.g.isMuted();RK(b)||WK(b,a?"mute":"unmute")}};
g.h.HG=function(a){if(this.l){var b=this.l.l.l;PK(b)||XK(b,a?"fullscreen":"end_fullscreen")}};
g.h.jN=function(){for(var a=[],b=g.q(this.C),c=b.next();!c.done;c=b.next())c=c.value,JI(c)||a.push(c);c=this.g;b=c.app;(c=c.playerType)&&lI(b)!=c||mI(b,"cuerangemarkersupdated",a)};
g.h.resume=function(){this.l&&this.l.resume()};
g.h.Ka=function(a,b,c){this.sa.Ka(a,b,Uja(this,void 0===c?null:c))};g.r(dN,Y);dN.prototype.init=function(a,b,c){var d=b.thumbnail,e=d&&cN(d)||"";g.ib(e)?g.M(Error("Found AdImage without valid image URL"),"WARNING"):(this.o?g.hh(this.element,"backgroundImage","url("+e+")"):g.ld(this.element,{src:e}),g.R(g.V(this.api).experiments,"enable_endcap_on_mweb")&&g.ld(this.element,{alt:d&&d.accessibility&&d.accessibility.label||""}),Y.prototype.init.call(this,a,b,c),this.show())};
dN.prototype.clear=function(){this.hide()};g.r(xN,Y);
xN.prototype.init=function(a,b,c){this.A=b;if(null==b.text&&null==b.icon)g.M(Error("ButtonRenderer did not have text or an icon set."),"WARNING");else{switch(b.style||null){case "STYLE_UNKNOWN":var d="ytp-ad-button-link";break;default:d=null}null!=d&&g.J(this.element,d);null!=b.text&&(d=g.Wz(b.text),g.ib(d)||(this.element.setAttribute("aria-label",d),this.C=new g.Ns({D:"span",I:"ytp-ad-button-text",V:d}),g.I(this,this.C),this.C.aa(this.element)));null!=b.icon&&(d=wN(b.icon),null!=d&&(this.o=new g.Ns({D:"span",
I:"ytp-ad-button-icon",K:[d]}),g.I(this,this.o)),this.F?zd(this.element,this.o.element,0):this.o.aa(this.element));Y.prototype.init.call(this,a,b,c)}};
xN.prototype.clear=function(){this.hide()};
xN.prototype.onClick=function(a){var b=this;Y.prototype.onClick.call(this,a);Vja(this).forEach(function(a){return b.l.Ka(a,b.macros)});
this.api.nd(this.componentType)};var Lka={seekableStart:0,seekableEnd:1,current:0};g.r(yN,Y);yN.prototype.clear=function(){this.dispose()};g.r(BN,yN);g.h=BN.prototype;g.h.init=function(a,b,c){yN.prototype.init.call(this,a,b,c);g.hh(this.B,"stroke-dasharray","0 "+this.A);this.show()};
g.h.clear=function(){this.hide()};
g.h.hide=function(){AN(this);yN.prototype.hide.call(this)};
g.h.show=function(){zN(this);yN.prototype.show.call(this)};
g.h.pi=function(){this.hide()};
g.h.nh=function(){if(this.o){var a=this.o.Ze();null!=a&&null!=a.current&&g.hh(this.B,"stroke-dasharray",a.current/a.seekableEnd*this.A+" "+this.A)}};g.r(CN,Y);CN.prototype.init=function(a,b,c){this.o=b;this.isTemplated()||g.Gd(this.element,iJ(this.o));if(b.backgroundImage){var d=(d=b.backgroundImage.thumbnail)?cN(d):"";var e=this.api.getVideoData()&&this.api.getVideoData().pn;d&&e&&(this.element.style.backgroundImage="url("+d+")",this.element.style.backgroundSize="100%");if(b.style&&b.style.adTextStyle)switch(b.style.adTextStyle.fontSize){case "AD_FONT_SIZE_MEDIUM":this.element.style.fontSize="26px"}}Y.prototype.init.call(this,a,b,c);this.show()};
CN.prototype.isTemplated=function(){return this.o.isTemplated||!1};
CN.prototype.clear=function(){this.hide()};g.r(g.EN,g.G);g.h=g.EN.prototype;g.h.show=function(a){1!=this.g&&2!=this.g&&(4==this.g&&this.An(),5==this.g?(this.o.show(),this.g=null,this.l.stop(),this.A&&this.A()):this.o.Ma()||(FN(this,!0),this.g=1,a?this.l.start(a):this.An()))};
g.h.hide=function(){4!=this.g&&(1==this.g||2==this.g?(this.o.hide(),this.g=null,this.l.stop()):this.o.Ma()&&(FN(this,!0),this.g=4,this.l.start(this.F)))};
g.h.An=function(){switch(this.g){case 1:this.o.show();this.g=2;this.l.start(10);break;case 2:FN(this,!1);this.g=3;this.l.start(this.C);break;case 3:this.g=null;this.A&&this.A();break;case 4:this.o.hide();FN(this,!1);this.g=5;this.l.start(0);break;case 5:this.g=null,this.B&&this.B()}};
g.h.stop=function(){for(;null!=this.g&&5!=this.g;)this.l.stop(),this.An()};
g.h.U=function(){this.o.ea()||this.o.element.removeAttribute("aria-hidden");g.G.prototype.U.call(this)};g.r(GN,yN);g.h=GN.prototype;
g.h.init=function(a,b,c){var d=b.durationMilliseconds;g.ta(d)&&0>d&&g.M(Error("durationMilliseconds was specified incorrectly in AdPreviewRenderer with a value of: "+d));this.ka&&g.J(this.A.element,"countdown-next-to-thumbnail");d=b.durationMilliseconds;this.J=null==d||0===d?this.o.mx():d;if(b.templatedCountdown)var e=b.templatedCountdown.templatedAdText;else b.staticPreview&&(e=b.staticPreview);this.B.init(X("ad-text"),e,c);this.api.getVideoData()&&this.api.getVideoData().pn&&b.thumbnail?this.C.init(X("ad-image"),
b.thumbnail,c):this.R.hide();yN.prototype.init.call(this,a,b,c)};
g.h.af=function(){this.H.show(100);this.show()};
g.h.clear=function(){this.hide()};
g.h.hide=function(){this.A.hide();this.B.hide();this.C.hide();AN(this);yN.prototype.hide.call(this)};
g.h.show=function(){zN(this);this.A.show();this.B.show();this.C.show();yN.prototype.show.call(this)};
g.h.pi=function(){this.hide()};
g.h.nh=function(){if(null!=this.o){var a=this.o.Ze();null!=a&&null!=a.current&&(a=1E3*a.current,!this.X&&a>=this.J?(g.R(g.V(this.api).experiments,"enable_pubsub_for_skip_transition_bulleit")||this.H.hide(),this.X=!0,this.P("t")):this.B&&this.B.isTemplated()&&(a=Math.max(0,Math.ceil((this.J-a)/1E3)),a!=this.ba&&(DN(this.B,{TIME_REMAINING:String(a)}),this.ba=a)))}};g.r(HN,g.N);g.h=HN.prototype;g.h.mx=function(){return this.l};
g.h.start=function(){this.o||(this.o=!0,this.Fa.start())};
g.h.stop=function(){this.o&&(this.o=!1,this.Fa.stop())};
g.h.IH=function(){this.g+=100;var a=!1;this.g>this.l&&(this.g=this.l,this.Fa.stop(),a=!0);this.A={seekableStart:0,seekableEnd:this.l/1E3,current:this.g/1E3};if(this.B){var b=this.B,c=this.A.current;b.l&&(b=b.l.l,b.F&&UK(b.l,c,b.Yj()))}this.P("s");a&&this.P("r")};
g.h.Ze=function(){return this.A};g.r(IN,Y);g.h=IN.prototype;
g.h.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);if(b.image&&b.image.thumbnail)if(b.headline)if(b.description)if(b.backgroundImage&&b.backgroundImage.thumbnail)if(b.actionButton&&b.actionButton.buttonRenderer)if(a=b.durationMilliseconds||0,!g.ta(a)||0>=a)g.M(Error("durationMilliseconds was specified incorrectly in AdActionInterstitialRenderer with a value of: "+a));else if(b.navigationEndpoint){var d=this.api.getVideoData(2);if(null!=d){var e=b.image.thumbnail.thumbnails;null!=e&&0<e.length&&
g.ib(g.qb(e[0].url))&&(e[0].url=d.profilePicture);e=b.backgroundImage.thumbnail.thumbnails;null!=e&&0<e.length&&g.ib(g.qb(e[0].url))&&(e[0].url=d.tc());e=b.headline;null!=e&&g.ib(g.qb(e.text))&&(e.text=d.author)}this.C.init(X("ad-image"),b.image,c);this.J.init(X("ad-text"),b.headline,c);this.H.init(X("ad-text"),b.description,c);this.F.init(X("ad-image"),b.backgroundImage,c);this.o=new xN(this.api,this.l,["ytp-ad-action-interstitial-action-button"]);g.I(this,this.o);this.o.aa(this.ka);this.o.init(X("button"),
b.actionButton.buttonRenderer,c);this.R=b.navigationEndpoint;g.V(this.api).o||(this.ca.M(this.ha,"click",this.xo,this),this.ca.M(this.ba,"click",this.xo,this),this.ca.M(this.X,"click",this.xo,this));this.B=new HN(a);g.I(this,this.B);b.nonskippableOverlayRenderer&&(a=b.nonskippableOverlayRenderer.adPreviewRenderer)&&this.B&&(this.A=new GN(this.api,this.l,this.B,!1),g.I(this,this.A),this.A.aa(this.element),this.A.init(X("ad-preview"),a,c));(b=b.countdownRenderer)&&b.timedPieCountdownRenderer&&this.B&&
(c=new BN(this.api,this.l,this.B),g.I(this,c),c.aa(this.element),c.init(X("timed-pie-countdown"),b.timedPieCountdownRenderer,this.macros));this.show();g.R(g.V(this.api).experiments,"enable_endcap_on_mweb")&&this.element.focus()}else g.M(Error("AdActionInterstitialRenderer has no navigation endpoint."));else g.M(Error("AdActionInterstitialRenderer has no button."));else g.M(Error("AdActionInterstitialRenderer has no background AdImage."));else g.M(Error("AdActionInterstitialRenderer has no description AdText."));
else g.M(Error("AdActionInterstitialRenderer has no headline AdText."));else g.M(Error("AdActionInterstitialRenderer has no image."))};
g.h.clear=function(){g.Rq(this.ca);this.hide()};
g.h.show=function(){JN(!0);this.o&&this.o.show();this.A&&this.A.show();Y.prototype.show.call(this)};
g.h.hide=function(){JN(!1);this.o&&this.o.hide();this.A&&this.A.hide();Y.prototype.hide.call(this)};
g.h.xo=function(){this.R&&this.l.Ka(this.R,this.macros)};g.r(KN,Y);KN.prototype.init=function(a,b,c){var d=b.text;if(g.ib(iJ(d)))g.M(Error("SimpleAdBadgeRenderer has invalid or empty text"),"WARNING");else{if(d&&d.text){var e=d.text;this.o&&(e=g.V(this.api),e=d.text+" "+(e&&e.o?"\u2022":"\u00b7"));e={text:e,isTemplated:d.isTemplated};d.style&&(e.style=d.style);d=new CN(this.api,this.l);d.init(X("simple-ad-badge"),e,c);d.aa(this.element);g.I(this,d)}Y.prototype.init.call(this,a,b,c);this.show()}};
KN.prototype.clear=function(){this.hide()};g.r(LN,Y);LN.prototype.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);this.o=b;if(b.image){c=this.g["ytp-ad-image-button-thumbnail"];a=this.g["ytp-ad-image-button-text"];var d=new dN(this.api,this.l);g.I(this,d);d.init(X("ad-image"),b.image,this.macros);d.aa(c);b.text&&(c=new KN(this.api,this.l),g.I(this,c),c.init(X("simple-ad-badge"),b.adBadgeRenderer.simpleAdBadgeRenderer,this.macros),c.aa(a),c=new CN(this.api,this.l),g.I(this,c),c.init(X("ad-text"),b.text,this.macros),c.aa(a));this.show()}else g.kp(Error("AdImageButtonRenderer has no image."))};
LN.prototype.clear=function(){this.hide()};
LN.prototype.onClick=function(a){Y.prototype.onClick.call(this,a);this.o&&this.o.clickCommand&&this.l.Ka(this.o?this.o.clickCommand:null,this.macros)};g.r(ON,yN);g.h=ON.prototype;g.h.init=function(a,b,c){if(b.templatedCountdown){var d=b.templatedCountdown.templatedAdText;if(!d.isTemplated){g.M(Error("AdDurationRemainingRenderer has no templated ad text."),"WARNING");return}this.A=new CN(this.api,this.l);this.A.init(X("ad-text"),d,{});this.A.aa(this.element);g.I(this,this.A)}yN.prototype.init.call(this,a,b,c);this.show()};
g.h.clear=function(){this.hide()};
g.h.hide=function(){AN(this);yN.prototype.hide.call(this)};
g.h.pi=function(){this.hide()};
g.h.nh=function(){if(null!=this.o){var a=this.o.Ze();if(null!=a&&null!=a.current&&this.A){a=(this.o instanceof HN?a.seekableEnd:this.api.ec(2))-a.current;var b=g.MN(a);DN(this.A,{FORMATTED_AD_DURATION_REMAINING:String(b),TIME_REMAINING:String(Math.ceil(a))})}}};
g.h.show=function(){zN(this);yN.prototype.show.call(this)};g.r(PN,Y);
PN.prototype.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);a=b.hoverText||null;b=b.button&&b.button.buttonRenderer||null;null==b?g.M(Error("AdHoverTextButtonRenderer.button was not set in response.")):(this.button=new xN(this.api,this.l),g.I(this,this.button),this.button.init(X("button"),b,this.macros),this.button.aa(this.element),this.F&&!g.wn(this.button.element,"ytp-ad-clickable")&&g.J(this.button.element,"ytp-ad-clickable"),a&&(this.A=new g.Ns({D:"div",I:"ytp-ad-hover-text-container"}),this.C&&
(b=new g.Ns({D:"div",I:"ytp-ad-hover-text-callout"}),b.aa(this.A.element),g.I(this,b)),g.I(this,this.A),this.A.aa(this.element),b=tJ(a),zd(this.A.element,b,0)),this.show())};
PN.prototype.hide=function(){this.button&&this.button.hide();this.A&&this.A.hide();Y.prototype.hide.call(this)};
PN.prototype.show=function(){this.button&&this.button.show();Y.prototype.show.call(this)};g.r(QN,Y);g.h=QN.prototype;g.h.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);b.reasons?null==b.confirmLabel?g.M(Error("AdFeedbackRenderer.confirmLabel was not set."),"ERROR"):(null==b.cancelLabel&&g.M(Error("AdFeedbackRenderer.cancelLabel was not set."),"WARNING"),null==b.title&&g.M(Error("AdFeedbackRenderer.title was not set."),"WARNING"),Zja(this,b)):g.M(Error("AdFeedbackRenderer.reasons were not set."),"ERROR")};
g.h.clear=function(){Nq(this.C);Nq(this.F);this.B.length=0;this.hide()};
g.h.hide=function(){this.o&&this.o.hide();this.A&&this.A.hide();Y.prototype.hide.call(this)};
g.h.show=function(){this.o&&this.o.show();this.A&&this.A.show();Y.prototype.show.call(this)};
g.h.rx=function(){this.api.nd("ad-feedback-dialog-close-button");this.P("u");this.hide()};
g.h.PL=function(){this.hide()};
RN.prototype.ia=function(){return this.g.element};g.r(SN,Y);g.h=SN.prototype;g.h.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);this.o=b;b.dialogMessages||null!=b.title?null==b.confirmLabel?g.M(Error("ConfirmDialogRenderer.confirmLabel was not set."),"ERROR"):null==b.cancelLabel?g.M(Error("ConfirmDialogRenderer.cancelLabel was not set."),"ERROR"):$ja(this,b):g.M(Error("Neither ConfirmDialogRenderer.title nor ConfirmDialogRenderer.dialogMessages were set."),"ERROR")};
g.h.clear=function(){g.Rq(this.ca);this.hide()};
g.h.Sq=function(){this.hide()};
g.h.Rq=function(){var a=this.o.cancelEndpoint;a&&this.l.Ka(a,this.macros);this.hide()};
g.h.Tq=function(){var a=this.o.confirmNavigationEndpoint||this.o.confirmEndpoint;a&&this.l.Ka(a,this.macros);this.hide()};g.r(TN,SN);TN.prototype.Sq=function(a){SN.prototype.Sq.call(this,a);this.api.nd("ad-mute-confirm-dialog-close-button")};
TN.prototype.Rq=function(a){SN.prototype.Rq.call(this,a);this.api.nd("ad-mute-confirm-dialog-close-button")};
TN.prototype.Tq=function(a){SN.prototype.Tq.call(this,a);this.api.nd("ad-mute-confirm-dialog-confirm-button");this.P("v")};g.r(UN,Y);g.h=UN.prototype;
g.h.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);this.F=b;if(null==b.dialogMessage&&null==b.title)g.M(Error("Neither AdInfoDialogRenderer.dialogMessage nor AdInfoDialogRenderer.title was set."),"ERROR");else{null==b.confirmLabel&&g.M(Error("AdInfoDialogRenderer.confirmLabel was not set."),"WARNING");if(a=b.closeOverlayRenderer&&b.closeOverlayRenderer.buttonRenderer||null)this.o=new xN(this.api,this.l,["ytp-ad-info-dialog-close-button"],"ad-info-dialog-close-button"),g.I(this,this.o),this.o.init(X("button"),
a,this.macros),this.o.aa(this.element);b.title&&(a=g.Wz(b.title),this.updateValue("title",a));if(b.adReasons)for(a=b.adReasons,c=0;c<a.length;c++){var d=tJ(a[c]);if(!g.ib(d.textContent)){var e=g.ud("LI");e.appendChild(d);this.H.appendChild(e)}}else g.Ch(this.H,!1);b.dialogMessage&&(a=tJ(b.dialogMessage,!0),this.ba.appendChild(a));b.confirmLabel&&(a=g.Wz(b.confirmLabel),this.updateValue("confirmLabel",a));b.muteAdRenderer&&(b=(b=b.muteAdRenderer)&&b.buttonRenderer||null)&&(a=b.navigationEndpoint&&
b.navigationEndpoint.adFeedbackEndpoint||null,c=b.navigationEndpoint&&b.navigationEndpoint.confirmDialogEndpoint||null,null==a&&null==c?g.M(Error("AdInfoDialogRenderer.muteAdRenderer was specified but contains neither an AdFeedbackEndpoint, nor a ConfirmDialogEndpoint."),"WARNING"):(a?bka(this,a):c&&cka(this,c),this.B=new xN(this.api,this.l,["ytp-ad-info-dialog-mute-button"],"button",!0),g.I(this,this.B),this.B.init(X("button"),b,this.macros),this.B.fa("click",this.OH,this),this.B.aa(this.ha)));dka(this)}};
g.h.clear=function(){Nq(this.R);this.hide()};
g.h.hide=function(){this.A?this.A.hide():this.C&&this.C.hide();this.o&&this.o.hide();this.B&&this.B.hide();Y.prototype.hide.call(this)};
g.h.show=function(){this.o&&this.o.show();this.B&&this.B.show();this.J||(aka(this),this.J=!0);Y.prototype.show.call(this)};
g.h.tx=function(){this.F&&this.F.confirmServiceEndpoint&&this.l.Ka(this.F.confirmServiceEndpoint,this.macros);this.api.nd("ad-info-dialog-close-button");this.P("x");this.hide()};
g.h.OH=function(){var a=this.A?this.A:this.C;a&&!a.Ma()&&(this.hide(),a.show())};g.r(VN,PN);VN.prototype.init=function(a,b,c){PN.prototype.init.call(this,a,b,c);a=b.button&&b.button.buttonRenderer||null;null!=a&&(fka(this,a,c),this.show())};
VN.prototype.hide=function(){this.button&&this.button.hide();this.o&&this.o.hide();PN.prototype.hide.call(this)};
VN.prototype.show=function(){this.button&&this.button.show();PN.prototype.show.call(this)};g.r(WN,Y);
WN.prototype.init=function(a,b,c){var d=this;Y.prototype.init.call(this,a,b,c);var e=b.durationMilliseconds||0;if(!g.ta(e)||0>e)g.M(Error("timeoutSeconds was specified incorrectly in AdChoiceInterstitialRenderer with a value of: "+e));else if(b.completeCommands)if(b.text)if(b.adChoiceButtons&&2==b.adChoiceButtons.length)if(b.adChoiceButtons[0].adImageButtonRenderer&&b.adChoiceButtons[1].adImageButtonRenderer)if(b.adDurationRemaining&&b.adDurationRemaining.adDurationRemainingRenderer){g.Gd(this.g["ytp-ad-choice-interstitial-head-title"],g.Wz(b.text));
var f=this.g["ytp-ad-choice-interstitial-left-button"],k=this.g["ytp-ad-choice-interstitial-right-button"];a=this.g["ytp-ad-choice-interstitial-countdown-text"];this.A=new LN(this.api,this.l);g.I(this,this.A);this.A.init(X("ad-image-button"),b.adChoiceButtons[0].adImageButtonRenderer,this.macros);this.A.aa(f);this.C=new LN(this.api,this.l);g.I(this,this.C);this.C.init(X("ad-image-button"),b.adChoiceButtons[1].adImageButtonRenderer,this.macros);this.C.aa(k);var l=b.completeCommands;this.B=new HN(e);
this.B.subscribe("r",function(){d.F.hide();l.forEach(function(a){return d.l.Ka(a,c)})});
g.I(this,this.B);e=b.adInfoRenderer.adHoverTextButtonRenderer;f=new VN(this.api,this.l,this.element);g.I(this,f);f.aa(a);f.init(X("ad-info-hover-text-button"),e,this.macros);e=b.adDurationRemaining.adDurationRemainingRenderer;this.o=new ON(this.api,this.l,this.B);g.I(this,this.o);this.o.init(X("ad-duration-remaining"),e,this.macros);this.o.aa(a);b.impressionCommands&&b.impressionCommands.forEach(function(a){return d.l.Ka(a,c)});
this.show()}else g.M(Error("AdChoiceInterstitialRenderer has no count down text."));else g.M(Error("AdChoiceInterstitialRenderer should have two ad image buttons."));else g.M(Error("AdChoiceInterstitialRenderer should have two choices."));else g.M(Error("AdChoiceInterstitialRenderer has no title."));else g.M(Error("timeoutSeconds was specified yet no completeCommands where specified"))};
WN.prototype.clear=function(){this.hide()};g.r(XN,Y);g.h=XN.prototype;g.h.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);b.text?(a=b.durationMilliseconds||0,!g.ta(a)||0>=a?g.M(Error("durationMilliseconds was specified incorrectly in AdTextInterstitialRenderer with a value of: "+a)):(this.o.init(X("ad-text"),b.text,c),this.show())):g.M(Error("AdTextInterstitialRenderer has no message AdText."))};
g.h.clear=function(){this.hide()};
g.h.show=function(){YN(!0);Y.prototype.show.call(this)};
g.h.hide=function(){YN(!1);Y.prototype.hide.call(this)};
g.h.onClick=function(){};g.r(ZN,g.G);g.h=ZN.prototype;g.h.U=function(){this.reset();g.G.prototype.U.call(this)};
g.h.reset=function(){g.Rq(this.ca);this.B=!1;this.g&&this.g.stop();this.A.stop();this.l&&(this.l=!1,this.C.play())};
g.h.start=function(){this.reset();this.ca.M(this.o,"mouseover",this.eK,this);this.ca.M(this.o,"mouseout",this.bK,this);this.g?this.g.start():(this.B=this.l=!0,g.hh(this.o,{opacity:this.G}))};
g.h.eK=function(){this.l&&(this.l=!1,this.C.play());this.A.stop();this.g&&this.g.stop()};
g.h.bK=function(){this.B?this.A.start():this.g&&this.g.start()};
g.h.ot=function(){this.l||(this.l=!0,this.F.play(),this.B=!0)};var aO={iconType:"CLOSE"};g.r($N,Y);g.h=$N.prototype;
g.h.init=function(a,b,c){this.C=b;this.J=g.Ta(this.C.onClickCommands||[]);var d;if(d=this.C.contentSupportedRenderer){d=this.C.contentSupportedRenderer;var e=this.C.adInfoRenderer||null;d.textOverlayAdContentRenderer?(this.F=g.jd("ytp-ad-overlay-ad-info-button-container",this.B.element),cO(this,e),d=kka(this,d.textOverlayAdContentRenderer)):d.enhancedTextOverlayAdContentRenderer?(this.F=g.jd("ytp-ad-overlay-ad-info-button-container",this.A.element),cO(this,e),d=lka(this,d.enhancedTextOverlayAdContentRenderer)):
d.imageOverlayAdContentRenderer?(this.F=g.jd("ytp-ad-overlay-ad-info-button-container",this.o.element),cO(this,e),d=mka(this,d.imageOverlayAdContentRenderer)):(g.M(Error("InvideoOverlayAdRenderer content could not be initialized.")),d=!1)}d&&(Y.prototype.init.call(this,a,b,c),this.show(),eO(this,!0))};
g.h.Gb=function(a){dO(this,a)&&this.clear()};
g.h.clear=function(){eO(this,!1);this.ba.reset();this.H=0;this.B.hide();nJ(this,this.B.element,!1);this.A.hide();nJ(this,this.A.element,!1);this.o.hide();nJ(this,this.o.element,!1);this.hide();this.dispose()};
g.h.FL=function(){this.ka&&this.l.Ka(this.ka,this.macros);this.api.Lb()};
g.h.Gq=function(){var a=this;this.clear();jka(this).forEach(function(b){return a.l.Ka(b,a.macros)})};
g.h.NH=function(){this.ha=2==this.api.Kd(1);this.api.Lb()};
g.h.cI=function(){this.ha||2!=this.api.Kd(1)||this.api.Kb()};
g.h.hK=function(){this.ha||2!=this.api.Kd(1)||this.api.Kb();this.clear()};
g.h.dI=function(a){a.target===this.F&&g.jd("ytp-ad-button",this.oa.element).click()};g.r(fO,yN);g.h=fO.prototype;g.h.init=function(a,b,c){var d=b.durationMs;g.ta(d)&&0>=d&&g.M(Error("durationMs was specified incorrectly in AdMessageRenderer with a value of: "+d));yN.prototype.init.call(this,a,b,c);a=b.durationMs;this.C=null==a||0===a?0:a+1E3*this.o.Ze().current;if(b.text)var e=b.text.templatedAdText;else b.staticMessage&&(e=b.staticMessage);this.A.init(X("ad-text"),e,c);this.A.aa(this.B.element);this.H.show(100);this.show()};
g.h.clear=function(){this.hide()};
g.h.hide=function(){gO(this,!1);yN.prototype.hide.call(this);this.B.hide();this.A.hide();AN(this)};
g.h.show=function(){gO(this,!0);yN.prototype.show.call(this);zN(this);this.B.show();this.A.show()};
g.h.pi=function(){this.hide()};
g.h.nh=function(){if(null!=this.o){var a=this.o.Ze();null!=a&&null!=a.current&&(a=1E3*a.current,!this.J&&a>=this.C?(this.H.hide(),this.J=!0):this.A&&this.A.isTemplated()&&(a=Math.max(0,Math.ceil((this.C-a)/1E3)),a!=this.R&&(DN(this.A,{TIME_REMAINING:String(a)}),this.R=a)))}};var rka=mc(function(){return new oka(mc(function(){return new nka}))});g.r(jO,yN);g.h=jO.prototype;
g.h.init=function(a,b,c){this.A=b;this.wa=ska(this);if(!b||g.Qb(b))g.M(Error("SkipButtonRenderer was not specified or empty."),"ERROR");else if(!b.message||g.Qb(b.message))g.M(Error("SkipButtonRenderer.message was not specified or empty."),"ERROR");else{var d={iconType:"SKIP_NEXT"},e=wN(d);null==e?g.M(Error("Icon for SkipButton was unable to be retrieved. yt.innertube.Icon.IconType: "+d.iconType+".")):(this.H=new g.Ns({D:"button",W:["ytp-ad-skip-button","ytp-button"],K:[{D:"span",I:"ytp-ad-skip-button-icon",
K:[e]}]}),g.I(this,this.H),this.H.aa(this.C.element),this.B=new CN(this.api,this.l,"ytp-ad-skip-button-text"),this.B.init(X("ad-text"),this.A.message,c),g.I(this,this.B),zd(this.H.element,this.B.element,0));yN.prototype.init.call(this,a,b,c);g.R(g.V(this.api).experiments,"bulleit_use_touch_events_for_skip")&&oJ(this)}};
g.h.af=function(){this.R.show();this.show()};
g.h.clear=function(){this.X.reset();this.Ja&&this.Pa(this.Ja);this.hide()};
g.h.hide=function(){this.C.hide();this.B&&this.B.hide();AN(this);yN.prototype.hide.call(this);kO(this)};
g.h.onClick=function(a){var b=this;null!=this.H&&(a&&g.Iq(a),yN.prototype.onClick.call(this,a),this.P("A"),(this.A&&this.A.onClickCommands||[]).forEach(function(a){return b.l.Ka(a,b.macros,"skip")}),this.wa||this.api.nd(this.componentType))};
g.h.zu=function(){return"skip"};
g.h.show=function(){var a=this;this.X.start();this.Ca||((this.A&&this.A.impressionCommands||[]).forEach(function(b){return a.l.Ka(b,a.macros)}),this.Ca=!0);
this.C.show();this.B&&this.B.show();zN(this);yN.prototype.show.call(this);g.In(this.oa)};
g.h.pi=function(){this.ba=!0;this.P("B")};
g.h.nh=function(){!this.ba&&this.ka&&1E3*this.o.Ze().current>=this.ka&&(this.ba=!0,this.P("B"))};g.r(lO,Y);g.h=lO.prototype;
g.h.init=function(a,b,c){this.J=b;var d=this.J.seekableDurationMilliseconds;this.R=g.ta(d)?d:5E3;var e=b&&b.preSeekRenderer&&b.preSeekRenderer.adPreviewRenderer||null,f=b&&b.seekableRenderer&&b.seekableRenderer.skipButtonRenderer||null;if(null==f)g.M(Error("SeekableRenderer was not set in SeekAdRenderer."));else if(d=b&&b.notSeekedRenderer&&b.notSeekedRenderer.skipButtonRenderer||null,null==d)g.M(Error("NotSeekedRenderer was not set in SeekAdRenderer."));else if(b&&b.postSeekRenderer&&b.postSeekRenderer.adPreviewRenderer||
b&&b.postSeekRenderer&&b.postSeekRenderer.skipButtonRenderer){e&&(this.A=new GN(this.api,this.l,this.F,!1),this.A.init(X("ad-preview"),e,c),this.A.subscribe("t",this.DK,this),g.I(this,this.A),this.A.aa(this.element),this.A.af());this.o=new jO(this.api,this.l,this.F);this.o.init(X("skip-button"),f,c);this.o.subscribe("A",this.nL,this);e=this.R;this.A&&(e+=this.A.J);this.o.ka=e;this.o.subscribe("B",this.oL,this);g.I(this,this.o);this.o.aa(this.element);null==this.A&&this.o.af();this.C=new jO(this.api,
this.l,this.F);this.C.init(X("skip-button"),d,c);g.I(this,this.C);this.C.aa(this.element);a:{d=b.postSeekRenderer;if(d.adPreviewRenderer){d=d.adPreviewRenderer;e=this.F;if(this.ba){e=d.durationMilliseconds;if(null==e||0==e){g.M(Error("durationMilliseconds must be specified for persistingAdPreviewRenderer"));break a}this.H=new HN(e,this.l,!1);g.I(this,this.H);e=this.H}this.B=new GN(this.api,this.l,e,!1);this.B.init(X("ad-preview"),d,c)}else d.skipButtonRenderer&&(this.B=new jO(this.api,this.l,this.F),
this.B.init(X("skip-button"),d.skipButtonRenderer,c));g.I(this,this.B);this.B.aa(this.element)}Y.prototype.init.call(this,a,b,c);this.show()}else g.M(Error("PostSeekRenderer was not set in SeekAdRenderer."))};
g.h.show=function(){this.A?this.A.show():this.o&&!this.o.Ma()&&this.o.show();Y.prototype.show.call(this)};
g.h.clear=function(){this.A&&this.A.clear();this.o&&this.o.clear();this.C&&this.C.clear();this.B&&this.B.clear();Y.prototype.hide.call(this)};
g.h.hide=function(){this.A&&this.A.hide();this.o&&this.o.hide();this.C&&this.C.hide();this.B&&this.B.hide();Y.prototype.hide.call(this)};
g.h.DK=function(){this.A&&this.A.H.hide();this.o&&this.o.af()};
g.h.nL=function(){this.X=!0;if(this.o){var a=this.o;a.R.hide();kO(a)}this.B&&(this.H&&this.H.start(),this.B.af())};
g.h.oL=function(){if(!this.X){if(this.o){var a=this.o;a.R.hide();kO(a)}this.C&&this.C.af()}};g.r(mO,yN);g.h=mO.prototype;
g.h.init=function(a,b,c){var d=b&&b.preskipRenderer&&b.preskipRenderer.adPreviewRenderer||{};if(d=g.Qb(d)?null:d){this.C=null!=d.durationMilliseconds&&void 0!==d.durationMilliseconds?d.durationMilliseconds:5E3;var e="countdown_next_to_thumbnail"==g.zt(g.V(this.api).experiments,"preskip_button_style_ads_backend")&&ey(g.V(this.api));this.A=new GN(this.api,this.l,this.o,e);this.A.init(X("preskip-component"),d,c);this.A.af();g.I(this,this.A);this.A.aa(this.element);g.R(g.V(this.api).experiments,"enable_pubsub_for_skip_transition_bulleit")&&
this.A.subscribe("t",this.GK,this)}else b.skipOffsetMilliseconds&&(this.C=b.skipOffsetMilliseconds);d=b&&b.skippableRenderer&&b.skippableRenderer.skipButtonRenderer||{};d=g.Qb(d)?null:d;null==d?g.M(Error("SkipButtonRenderer was not set in player response."),"ERROR"):(this.B=new jO(this.api,this.l,this.o),this.B.init(X("skip-button"),d,c),g.I(this,this.B),this.B.aa(this.element),yN.prototype.init.call(this,a,b,c),this.show())};
g.h.show=function(){this.H&&this.B?this.B.show():this.A&&this.A.show();zN(this);yN.prototype.show.call(this)};
g.h.pi=function(){};
g.h.clear=function(){this.A&&this.A.clear();this.B&&this.B.clear();AN(this);yN.prototype.hide.call(this)};
g.h.hide=function(){this.A&&this.A.hide();this.B&&this.B.hide();AN(this);yN.prototype.hide.call(this)};
g.h.GK=function(){nO(this,!0)};
g.h.nh=function(){g.R(g.V(this.api).experiments,"enable_pubsub_for_skip_transition_bulleit")?this.A||1E3*this.o.Ze().current>=this.C&&nO(this,!0):1E3*this.o.Ze().current>=this.C&&nO(this,!0)};g.r(oO,Y);oO.prototype.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);b.skipAd&&(a=b.skipAd,a.seekAdRenderer?(b=new lO(this.api,this.l,this.o,!0),b.aa(this.A),b.init(X("seek-ad"),a.seekAdRenderer,this.macros),g.I(this,b)):a.skipAdRenderer&&(b=new mO(this.api,this.l,this.o),b.aa(this.A),b.init(X("skip-button"),a.skipAdRenderer,this.macros),g.I(this,b)));this.show()};g.r(pO,Y);g.h=pO.prototype;
g.h.init=function(a,b,c){this.A=b;if(null==b.defaultText&&null==b.defaultIcon)g.M(Error("ToggleButtonRenderer must have either text or icon set."));else if(null==b.defaultIcon&&null!=b.toggledIcon)g.M(Error("ToggleButtonRenderer cannot have toggled icon set without a default icon."));else{if(b.style){switch(b.style.styleType){case "STYLE_UNKNOWN":case "STYLE_DEFAULT":var d="ytp-ad-toggle-button-default-style";break;default:d=null}null!=d&&g.J(this.B,d)}d={};if(b.defaultText){var e=g.Wz(b.defaultText);
g.ib(e)||(d.buttonText=e,this.o.setAttribute("aria-label",e))}else g.Ch(this.R,!1);b.defaultTooltip&&(d.tooltipText=b.defaultTooltip);b.defaultIcon?(e=wN(b.defaultIcon),this.updateValue("untoggledIconTemplateSpec",e),b.toggledIcon?(this.H=!0,e=wN(b.toggledIcon),this.updateValue("toggledIconTemplateSpec",e)):(g.Ch(this.F,!0),g.Ch(this.C,!1)),g.Ch(this.o,!1)):g.Ch(this.X,!1);g.Qb(d)||this.update(d);b.isToggled&&(g.J(this.B,"ytp-ad-toggle-button-toggled"),this.toggleButton(b.isToggled));qO(this);this.J=
this.M(this.element,"change",this.ox);Y.prototype.init.call(this,a,b,c);g.R(g.V(this.api).experiments,"bulleit_use_touch_events_for_magpie")&&oJ(this,this.J);this.show()}};
g.h.onClick=function(a){0<this.T.length&&(this.toggleButton(!this.isToggled()),this.ox());Y.prototype.onClick.call(this,a)};
g.h.ox=function(){var a=this;g.K(this.B,"ytp-ad-toggle-button-toggled",this.isToggled());tka(this,this.isToggled()).forEach(function(b){return a.l.Ka(b,a.macros)});
this.isToggled()&&this.api.nd("toggle-button");qO(this)};
g.h.clear=function(){this.hide()};
g.h.toggleButton=function(a){g.K(this.B,"ytp-ad-toggle-button-toggled",a);this.o.checked=a;qO(this)};
g.h.isToggled=function(){return this.o.checked};g.r(rO,Y);g.h=rO.prototype;g.h.init=function(a,b,c){var d=this;this.o=b;this.o.rectangle&&(uka(this,c),Y.prototype.init.call(this,a,b,c),g.R(g.V(this.api).experiments,"bulleit_use_touch_events_for_magpie")&&oJ(this,this.F),this.C.show(100),this.show(),(this.o&&this.o.impressionCommands||[]).forEach(function(a){return d.l.Ka(a,d.macros)}))};
g.h.clear=function(){this.hide()};
g.h.hide=function(){this.B.hide();this.A.hide();Y.prototype.hide.call(this)};
g.h.show=function(){this.B.show();this.A.show();Y.prototype.show.call(this)};
g.h.qx=function(){g.An(this.element,"ytp-ad-instream-user-sentiment-selected");this.o.postMessageAction&&this.api.na("onYtShowToast",this.o.postMessageAction);this.C.hide()};
g.h.onClick=function(a){0<this.T.length&&this.qx();Y.prototype.onClick.call(this,a)};g.r(sO,xN);
sO.prototype.init=function(a,b,c){var d=!1;null!=b.text&&(d=g.Wz(b.text),d=!g.ib(d));d?null==b.navigationEndpoint?g.M(Error("No visit advertiser clickthrough provided in renderer,"),"WARNING"):"STYLE_UNKNOWN"!==b.style?g.M(Error("Button style was not a link-style type in renderer,"),"WARNING"):(xN.prototype.init.call(this,a,b,c),g.R(g.V(this.api).experiments,"bulleit_use_touch_events_for_visit_advertiser")&&oJ(this),this.show(),a=g.V(this.api).experiments,g.R(a,"enable_visibility_check_for_visit_advertiser_in_bulleit")&&(this.B=
iO(this.element,"visit_advertiser",g.S(a,"visibility_error_html_dump_sample_rate")))):g.M(Error("No visit advertiser text was present in the renderer."),"WARNING")};
sO.prototype.hide=function(){xN.prototype.hide.call(this);this.B&&(this.B(),this.B=null)};tO.prototype.getLength=function(){return this.g-this.l};g.r(g.wO,g.Ns);g.wO.prototype.B=function(){var a=this.o.Ze();a=vO(new tO(a.seekableStart,a.seekableEnd),a.current,0);this.F.style.width=100*a+"%"};
g.wO.prototype.C=function(){g.hy(g.V(this.A))||(2==this.A.Da()?-1===this.l&&(this.show(),this.l=this.o.subscribe("s",this.B,this),this.B()):-1!==this.l&&(this.hide(),this.o.Ac(this.l),this.l=-1))};g.r(xO,Y);
xO.prototype.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);b.skipOrPreviewRenderer&&(a=b.skipOrPreviewRenderer,a.seekAdRenderer?(c=new lO(this.api,this.l,this.o),c.aa(this.B),c.init(X("seek-ad"),a.seekAdRenderer,this.macros),g.I(this,c)):a.skipAdRenderer?(c=new mO(this.api,this.l,this.o),c.aa(this.B),c.init(X("skip-button"),a.skipAdRenderer,this.macros),g.I(this,c)):a.adPreviewRenderer&&(c=new GN(this.api,this.l,this.o,!1),c.aa(this.B),c.init(X("ad-preview"),a.adPreviewRenderer,this.macros),
c.af(),g.I(this,c)));b.brandInteractionRenderer&&(a=b.brandInteractionRenderer.brandInteractionRenderer,c=new rO(this.api,this.l),c.aa(this.C),c.init(X("instream-user-sentiment"),a,this.macros),g.I(this,c));b.adBadgeRenderer&&(a=b.adBadgeRenderer.simpleAdBadgeRenderer,null==a&&(a={text:{text:"Ad",isTemplated:!1}}),c=new KN(this.api,this.l,!g.R(g.V(this.api).experiments,"hide_top_countdown")),g.I(this,c),c.aa(this.A),c.init(X("simple-ad-badge"),a,this.macros));b.adDurationRemaining&&(a=b.adDurationRemaining.adDurationRemainingRenderer,
null==a&&(a={templatedCountdown:{templatedAdText:{text:"{FORMATTED_AD_DURATION_REMAINING}",isTemplated:!0}}}),c=new ON(this.api,this.l,this.o),g.I(this,c),c.aa(this.A),c.init(X("ad-duration-remaining"),a,this.macros));b.adInfoRenderer&&(a=b.adInfoRenderer,a.adHoverTextButtonRenderer&&(c=new VN(this.api,this.l,this.element),g.I(this,c),c.aa(this.A),c.init(X("ad-info-hover-text-button"),a.adHoverTextButtonRenderer,this.macros)));b.visitAdvertiserRenderer&&(b=b.visitAdvertiserRenderer,b.buttonRenderer&&
(a=this.A))&&(c=new sO(this.api,this.l),g.I(this,c),c.aa(a),c.init(X("visit-advertiser"),b.buttonRenderer,this.macros));(b=g.V(this.api))&&!g.Yx(b)&&"3"==b.A&&(b=new g.wO(this.api,this.o),b.aa(this.F),g.I(this,b));this.show()};g.r(yO,Y);
yO.prototype.init=function(a,b,c){b.toggledLoggingParams&&(this.B=b.toggledLoggingParams);if(b.answer&&b.answer.buttonRenderer){var d=new xN(this.api,this.l,["ytp-ad-survey-answer-button"],"survey-single-select-answer-button");d.aa(this.A);d.init(X("ytp-ad-survey-answer-button"),b.answer.buttonRenderer,c);d.show()}else b.answer&&b.answer.toggleButtonRenderer&&(this.o=new pO(this.api,this.l,["ytp-ad-survey-answer-toggle-button"]),this.o.aa(this.A),g.I(this,this.o),this.o.init(X("survey-answer-button"),b.answer.toggleButtonRenderer,
c));Y.prototype.init.call(this,a,b,c);this.show()};g.r(zO,Y);zO.prototype.init=function(a,b,c){b.answer&&b.answer.toggleButtonRenderer&&(this.o=new pO(this.api,this.l,["ytp-ad-survey-answer-toggle-button","ytp-ad-survey-none-of-the-above-button"]),this.o.aa(this.A),this.o.init(X("survey-none-of-the-above-button"),b.answer.toggleButtonRenderer,c));Y.prototype.init.call(this,a,b,c);this.show()};g.r(AO,xN);AO.prototype.init=function(a,b,c){var d=!1;b.text&&(d=g.Wz(b.text),d=!g.ib(d));d?xN.prototype.init.call(this,a,b,c):g.M(Error("No submit text was present in the renderer."),"WARNING")};
AO.prototype.onClick=function(a){this.P("C");xN.prototype.onClick.call(this,a)};g.r(BO,Y);
BO.prototype.init=function(a,b,c){this.A=c;var d=b.skipOrPreviewRenderer;if(d)if(d.skipAdRenderer){d=d.skipAdRenderer;var e=new mO(this.api,this.l,this.C);e.aa(this.H);e.init(X("skip-button"),d,this.A);g.I(this,e);this.o=e}else d.adPreviewRenderer&&(d=d.adPreviewRenderer,e=new GN(this.api,this.l,this.C,!1),e.aa(this.H),e.init(X("ad-preview"),d,this.A),e.af(),g.I(this,e),this.o=e);null==this.o&&g.M(Error("ISAPOR.skipOrPreviewRenderer was not initialized properly.ISAPOR: "+JSON.stringify(b)));b.brandInteractionRenderer&&
(d=b.brandInteractionRenderer.brandInteractionRenderer,e=new rO(this.api,this.l),e.aa(this.J),e.init(X("instream-user-sentiment"),d,this.macros),g.I(this,e));b.submitButton&&(d=b.submitButton,d.buttonRenderer&&(d=d.buttonRenderer,e=new AO(this.api,this.l),e.aa(this.R),e.init(X("survey-submit"),d,this.A),g.I(this,e),this.B=e));if(d=b.adBadgeRenderer)d=d.simpleAdBadgeRenderer,e=new KN(this.api,this.l,!0),e.aa(this.F),e.init(X("simple-ad-badge"),d,this.A),g.I(this,e);if(d=b.adDurationRemaining)d=d.adDurationRemainingRenderer,
e=new ON(this.api,this.l,this.C),e.aa(this.F),e.init(X("ad-duration-remaining"),d,this.A),g.I(this,e);(d=b.adInfoRenderer)&&d.adHoverTextButtonRenderer&&(e=new VN(this.api,this.l,this.element),g.I(this,e),e.aa(this.F),e.init(X("ad-info-hover-text-button"),d.adHoverTextButtonRenderer,this.macros));Y.prototype.init.call(this,a,b,c);this.show()};g.r(CO,Y);CO.prototype.init=function(a,b,c){Y.prototype.init.call(this,a,b,c);wka(this)};
CO.prototype.show=function(){this.C=(0,g.D)();Y.prototype.show.call(this)};
CO.prototype.cz=function(){};
CO.prototype.Km=function(a){a instanceof HL&&a.g&&(this.o.start(),this.C=(0,g.D)())};g.r(FO,CO);g.h=FO.prototype;g.h.init=function(a,b,c){var d=this;CO.prototype.init.call(this,a,b,c);b.questionText&&g.Gd(this.R,g.Wz(b.questionText));b.answers&&b.answers.forEach(function(a){a.instreamSurveyAdAnswerRenderer&&DO(d,a.instreamSurveyAdAnswerRenderer,c)});
this.H=new window.Set(this.B.map(function(a){return a.o.o}));
(a=b.noneOfTheAbove)&&(a=a.instreamSurveyAdAnswerNoneOfTheAboveRenderer)&&xka(this,a,c);b.surveyAdQuestionCommon?EO(this,b.surveyAdQuestionCommon):g.M(Error("SurveyAdQuestionCommon was not sent.MultiSelectQuestionRenderer: "+JSON.stringify(b)));b.submitEndpoints&&(this.X=b.submitEndpoints);this.M(this.element,"change",this.PH);this.show()};
g.h.cz=function(){GO(this,!1);this.F.B.subscribe("C",this.CL,this)};
g.h.PH=function(a){a.target==this.A.o.o?yka(this):this.H.has(a.target)&&(this.A.o.toggleButton(!1),GO(this,!0))};
g.h.CL=function(){var a=this,b=this.B.reduce(function(a,b){var c=b.B;b.o&&b.o.isToggled()&&c&&a.push(c);return a},[]).join("&"),c=this.X.map(function(a){if(!a.loggingUrls)return a;
a=g.Xb(a);a.loggingUrls=a.loggingUrls.map(function(a){a.baseUrl&&(a.baseUrl=Jg(a.baseUrl,b));return a});
return a});
c&&c.forEach(function(b){return a.l.Ka(b,a.macros)})};
g.h.clear=function(){this.dispose()};g.r(HO,CO);HO.prototype.init=function(a,b,c){var d=this;CO.prototype.init.call(this,a,b,c);b.questionText&&g.Gd(this.R,g.Wz(b.questionText));b.answers&&b.answers.forEach(function(a){a.instreamSurveyAdAnswerRenderer&&DO(d,a.instreamSurveyAdAnswerRenderer,c)});
b.surveyAdQuestionCommon?EO(this,b.surveyAdQuestionCommon):g.M(Error("SurveyAdQuestionCommon was not sent.SingleSelectQuestionRenderer: "+JSON.stringify(b)));this.show()};
HO.prototype.clear=function(){this.dispose()};g.r(IO,Y);
IO.prototype.init=function(a,b,c,d){var e=this;null!=d&&d instanceof HL&&(b.titleText&&g.Gd(this.B,g.Wz(b.titleText)),b.questions.forEach(function(a){if(a.instreamSurveyAdSingleSelectQuestionRenderer){a=a.instreamSurveyAdSingleSelectQuestionRenderer;var b=new HO(e.api,e.l,d.g);b.aa(e.A);b.init(X("survey-question-single-select"),a,c);e.o.push(b);g.I(e,b)}else a.instreamSurveyAdMultiSelectQuestionRenderer&&(a=a.instreamSurveyAdMultiSelectQuestionRenderer,b=new FO(e.api,e.l,d.g),b.aa(e.A),b.init(X("survey-question-multi-select"),
a,c),e.o.push(b),g.I(e,b))}),Y.prototype.init.call(this,a,b,c),this.show())};
IO.prototype.Km=function(a){this.o.forEach(function(b){return b.Km(a)})};
IO.prototype.clear=function(){this.hide();this.dispose()};g.r(JO,Y);
JO.prototype.init=function(a,b,c){var d=this;Y.prototype.init.call(this,a,b,c);a=b.timeoutSeconds||0;if(!g.ta(a)||0>a)g.M(Error("timeoutSeconds was specified incorrectly in SurveyTextInterstitialRenderer with a value of: "+a));else if(b.timeoutCommands)if(b.text)if(b.ctaButton&&b.ctaButton.buttonRenderer)if(b.brandImage)if(b.backgroundImage&&b.backgroundImage.thumbnailLandscapePortraitRenderer&&b.backgroundImage.thumbnailLandscapePortraitRenderer.landscape){KO(this.H,b.backgroundImage.thumbnailLandscapePortraitRenderer.landscape);KO(this.F,
b.brandImage);g.Gd(this.R,g.Wz(b.text));this.o=new xN(this.api,this.l,["ytp-ad-survey-interstitial-action-button"]);g.I(this,this.o);this.o.aa(this.C);this.o.init(X("button"),b.ctaButton.buttonRenderer,c);this.o.show();var e=b.timeoutCommands;this.B=new HN(1E3*a);this.B.subscribe("r",function(){d.A.hide();e.forEach(function(a){return d.l.Ka(a,c)})});
g.I(this,this.B);this.M(this.element,"click",function(a){return Aka(d,a,b)});
this.A.show(100);b.impressionCommands&&b.impressionCommands.forEach(function(a){return d.l.Ka(a,c)})}else g.M(Error("SurveyTextInterstitialRenderer has no landscape background image."));
else g.M(Error("SurveyTextInterstitialRenderer has no brandImage."));else g.M(Error("SurveyTextInterstitialRenderer has no button."));else g.M(Error("SurveyTextInterstitialRenderer has no text."));else g.M(Error("timeoutSeconds was specified yet no timeoutCommands where specified"))};
JO.prototype.clear=function(){this.hide()};g.r(LO,Y);g.h=LO.prototype;
g.h.init=function(a,b,c){var d=this;Y.prototype.init.call(this,a,b,c);this.o&&(this.o.cancel(),this.o=null);this.o=new g.Pf(g.va);b.bannerImage?b.iconImage?b.headline?b.description?b.actionButton&&b.actionButton.buttonRenderer?b.navigationEndpoint?(b.adInfoRenderer&&b.adInfoRenderer.adHoverTextButtonRenderer?this.qc.init(X("watch-ad-info-hover-button"),b.adInfoRenderer.adHoverTextButtonRenderer,c):g.M(Error("ActionCompanionAdRenderer has no ad info renderer.")),this.B.init(X("ad-image"),b.bannerImage,
c),this.R.init(X("ad-image"),b.iconImage,c),this.F.init(X("ad-text"),b.headline,c),this.C.init(X("ad-text"),b.description,c),this.A.init(X("button"),b.actionButton.buttonRenderer,c),g.Gd(this.g["yt-badge-ad"],"Ad"),this.X=b.impressionCommands||[],this.H=b.navigationEndpoint,this.ca.M(this.element,"click",this.iK,this),window.Promise.race([this.o,this.ba.showCompanion(this.element,300,250)]).then(function(){return d.show()})):g.M(Error("ActionCompanionAdRenderer has no navigation endpoint.")):g.M(Error("ActionCompanionAdRenderer has no button.")):
g.M(Error("ActionCompanionAdRenderer has no description string.")):g.M(Error("ActionCompanionAdRenderer has no headline string.")):g.M(Error("ActionCompanionAdRenderer has no icon image.")):g.M(Error("ActionCompanionAdRenderer has no banner image."))};
g.h.clear=function(){g.Rq(this.ca);this.hide()};
g.h.show=function(){var a=this;this.A.show();Y.prototype.show.call(this);this.X.forEach(function(b){return a.l.Ka(b,a.macros)})};
g.h.hide=function(){this.A.hide();Y.prototype.hide.call(this)};
g.h.iK=function(a){a=a.target;g.Fd(this.qc.element,a)||(this.H&&!g.Fd(this.A.element,a)&&this.l.Ka(this.H,this.macros),this.api.nd("action-companion"))};
g.h.U=function(){this.o&&(this.o.cancel(),this.o=null);Y.prototype.U.call(this)};g.r(MO,g.G);MO.prototype.U=function(){this.C&&g.er(this.C);this.o&&(this.o.cancel(),this.o=null);this.B&&g.er(this.B);this.g&&(this.g.cancel(),this.g=null);this.l&&(this.l.cancel(),this.l=null);this.A&&(this.A.stop(),this.A=null);g.G.prototype.U.call(this)};g.r(SO,Y);SO.prototype.init=function(a,b,c){var d=this;Y.prototype.init.call(this,a,b,c);this.o&&(this.o.cancel(),this.o=null);this.o=new g.Pf(g.va);"BACKFILL_MPU_TYPE_AFV"==b.type?window.Promise.race([this.o,Eka(this.A)]).then(function(){d.show()}):"BACKFILL_MPU_TYPE_AFC"==b.type&&window.Promise.race([this.o,
Fka(this.A)]).then(function(){d.show()},function(a){a instanceof gg||Hka(d,b)})};
SO.prototype.U=function(){this.o&&(this.o.cancel(),this.o=null);Y.prototype.U.call(this)};g.r(TO,g.P);TO.prototype.clear=function(){for(var a=g.q(this.Ea),b=a.next();!b.done;b=a.next())g.Xe(b.value);this.Ea=[]};
TO.prototype.F=function(a){g.Iq(a);this.l=Math.max(0,this.l-UO(this));VO(this)};
TO.prototype.C=function(a){g.Iq(a);this.l=Math.min(this.Ea.length-1,this.l+UO(this));VO(this)};
TO.prototype.U=function(){this.clear();g.P.prototype.U.call(this)};g.r(WO,uJ);g.h=WO.prototype;g.h.ia=function(){return this.td.element};
g.h.al=function(a){var b=this.td,c=new g.P({D:"li",I:"ad-carousel-listitem",K:[{D:"div",I:"ad-carousel-item"}]});c.g["ad-carousel-item"].appendChild(a);b.Ea.push(c);b.B.appendChild(c.element)};
g.h.show=function(){this.td.show()};
g.h.hide=function(){this.td.hide()};
g.h.clear=function(){this.td.clear()};var bma={IN:"adinfoclick",HP:"offerclick",IP:"offernavclick"};g.r(XO,uJ);XO.prototype.show=function(){this.l.show()};
XO.prototype.hide=function(){this.l.hide()};
XO.prototype.gd=function(){var a=this;this.l.fa("click",function(){a.dispatchEvent({type:"offerclick"})});
for(var b=g.q((this.l.element||window.document).getElementsByTagName("A")),c=b.next();!c.done;c=b.next())this.l.M(c.value,"click",function(){a.dispatchEvent({type:"offernavclick"})})};
XO.prototype.ia=function(){return this.l.element};var Ika={On:XO};g.r(ZO,vJ);
ZO.prototype.Li=function(a){var b=this.Hc();a=a.renderer;this.g=a.clickthroughEndpoint||null;var c=a.headline||null;YO(b.o,"headline",c);YO(b.g,"headline",c);c=a.merchant||null;YO(b.A,"merchant",c);YO(b.o,"merchant",c);YO(b.g,"merchant",c);c=a.priceText||null;YO(b.A,"price",c);YO(b.o,"price",c);YO(b.g,"price",c);c=(c=a.image&&0<a.image.thumbnails.length?a.image.thumbnails[0].url||null:null)?{D:"img",N:{src:c}}:null;b.A.updateValue("image",c);b.g.updateValue("image",c);a.rating?(c=a.reviewText||null,
g.zh(b.B.element,Math.floor(100*a.rating/5)+"%"),YO(b.B,"reviewText",c),b.o.updateValue("review",b.B),b.g.updateValue("review",b.B)):(b.o.updateValue("review",null),b.g.updateValue("review",null));this.show();return window.Promise.resolve()};
ZO.prototype.gd=function(){for(var a=this,b=g.q(Object.values(bma)),c=b.next();!c.done;c=b.next())this.Hc().addEventListener(c.value,function(b){return a.onClick(b)})};
ZO.prototype.jk=function(a){switch(void 0===a.type?void 0:a.type){case "offernavclick":this.g&&this.Ka(this.g)}};
ZO.prototype.Hc=function(){return this.view};g.r($O,uJ);g.h=$O.prototype;g.h.ia=function(){return this.g.element};
g.h.show=function(){this.g.show()};
g.h.hide=function(){this.g.hide()};
g.h.gd=function(){var a=this;this.g.fa("click",function(b){g.Fd(a.g.g["ad-info-icon"],b.target)&&a.dispatchEvent({type:"adinfoclick"})})};
g.h.U=function(){Cka(this.l);uJ.prototype.U.call(this)};var aP={SA:BJ,CB:$O,Nn:ZO,Kn:WO};g.r(bP,vJ);g.h=bP.prototype;g.h.Hc=function(){return this.view};
g.h.Li=function(a){var b=this;this.Oi();this.Td=new g.Pf(g.va);return window.Promise.race([this.Td,this.Hc().A]).then(function(){return b.Vn(a.renderer)})};
g.h.Vn=function(a){var b=this.Hc(),c=a.shopText||null;c=c?tJ(c):null;b.g.updateValue("shopText",c);c=(c=a.sponsoredText||null)?tJ(c):null;b.g.updateValue("sponsoredText",c);a.adInfoButton?this.je.bind({renderer:a.adInfoButton.buttonRenderer.navigationEndpoint.adInfoDialogEndpoint.dialog.adInfoDialogRenderer,macros:this.macros}):this.je.bind({renderer:{dialogMessage:a.adInfoText},macros:this.macros});a=a.itemList.horizontalListRenderer||null;this.Ri();this.td.clear();a=g.q(a&&a.items||[]);for(b=a.next();!b.done;b=
a.next())b=b.value.plaShelfItemRenderer,c=new aP.Nn(this.Bb,this.Ii),this.jh.push(c),c.Ah(this.td),c.bind({renderer:b,macros:this.macros});VO(this.td.td);Jka(this);this.show()};
g.h.gd=function(){var a=this;this.ca.M(this.Bb,"appresize",this.Gb);this.ca.M(this.view,"adinfoclick",function(b){return a.onClick(b)})};
g.h.Gb=function(){VO(this.td.td)};
g.h.jk=function(a){"adinfoclick"==a.type&&this.je.show()};
g.h.Oi=function(){this.Td&&(this.Td.cancel(),this.Td=null)};
g.h.Ri=function(){g.Ye(this.jh);this.jh=[]};
g.h.U=function(){this.Oi();this.Ri();vJ.prototype.U.call(this)};g.r(cP,uJ);g.h=cP.prototype;g.h.ia=function(){return this.g.element};
g.h.al=function(a){this.A++;this.F.appendChild(a);dP(this)};
g.h.show=function(){this.g.show()};
g.h.hide=function(){this.g.hide()};
g.h.clear=function(){this.A=0;g.yd(this.F)};
g.h.scrollLeft=function(){this.l=Math.max(0,this.l-1);dP(this)};
g.h.U=function(){uJ.prototype.U.call(this)};g.r(eP,uJ);g.h=eP.prototype;g.h.ia=function(){return this.g.element};
g.h.show=function(){this.g.show()};
g.h.hide=function(){this.g.hide()};
g.h.al=function(a){this.g.jb(a)};
g.h.gd=function(){var a=this;this.g.fa("click",function(){a.dispatchEvent({type:"companionclick"})});
var b=g.jd("ad-companion-clickthrough",this.g.element);b&&this.g.M(b,"click",function(){a.dispatchEvent({type:"shoptextclick"})})};
g.h.U=function(){uJ.prototype.U.call(this);g.Xe(this.l)};g.r(fP,uJ);fP.prototype.show=function(){this.g.show()};
fP.prototype.hide=function(){this.g.hide()};
fP.prototype.gd=function(){var a=this;this.g.fa("click",function(){a.dispatchEvent({type:"offerclick"})})};
fP.prototype.ia=function(){return this.g.element};var Kka={On:fP};g.r(gP,vJ);gP.prototype.Li=function(a){var b=this.Hc();a=a.renderer;this.g=a.clickthroughEndpoint||null;var c=a.headline||null;c&&g.Gd(b.g.g["iv-cards-slider-text"],g.Wz(c));(c=a.priceText||null)&&g.Gd(b.g.g["iv-cards-slider-action"],g.Wz(c));a=a.image&&0<a.image.thumbnails.length?a.image.thumbnails[0].url||null:null;b.g.updateValue("image",a?{D:"img",N:{src:a}}:null);this.show();return window.Promise.resolve()};
gP.prototype.jk=function(){this.g&&this.Ka(this.g)};
gP.prototype.Hc=function(){return this.view};var hP={YA:eP,Nn:gP,Kn:cP};g.r(iP,vJ);g.h=iP.prototype;g.h.Hc=function(){return this.view};
g.h.Li=function(a){var b=this;this.Oi();this.Td=new g.Pf(g.va);return window.Promise.race([this.Td,this.Hc().o]).then(function(){return b.Vn(a.renderer)})};
g.h.Vn=function(a){this.Mt=a.clickTrackingEndpoints||[];this.Mq=a.clickToAdvSiteEndpoint||null;var b=this.Hc(),c=a.adBadgeText||null;c&&g.Gd(b.g.g["yt-badge-ad"],g.Wz(c));(c=a.shopText||null)&&g.Gd(b.g.g["ad-companion-clickthrough"],g.Wz(c));a.adInfoRenderer&&a.adInfoRenderer.adHoverTextButtonRenderer?this.qc.init(X("watch-ad-info-hover-button"),a.adInfoRenderer.adHoverTextButtonRenderer,this.macros):g.M(Error("ShoppingCompanionCarouselRenderer has no ad info renderer."));a=a.itemList.horizontalListRenderer||
null;this.Ri();this.Uf.clear();a=g.q(a&&a.items||[]);for(b=a.next();!b.done;b=a.next())b=b.value.shoppingCompanionCarouselItemRenderer,c=new hP.Nn(this.Bb,this.Ii),this.jh.push(c),c.Ah(this.Uf),c.bind({renderer:b,macros:this.macros});this.show()};
g.h.gd=function(){function a(a){return b.onClick(a)}
var b=this;this.Hc().addEventListener("shoptextclick",a);this.Hc().addEventListener("companionclick",a);this.Uf.addEventListener("nextbuttonclick",a);this.Uf.addEventListener("prevbuttonclick",a)};
g.h.jk=function(a){switch(void 0===a.type?void 0:a.type){case "companionclick":this.lf(this.Mt);this.Bb.nd("shopping-companion");break;case "nextbuttonclick":a=this.Uf;a.l=Math.min(a.A-3,a.l+1);dP(a);break;case "prevbuttonclick":this.Uf.scrollLeft();break;case "shoptextclick":this.Mq&&this.Ka(this.Mq)}};
g.h.Ri=function(){g.Ye(this.jh);this.jh=[]};
g.h.Oi=function(){this.Td&&(this.Td.cancel(),this.Td=null)};
g.h.U=function(){this.Oi();this.Ri();vJ.prototype.U.call(this)};g.r(g.jP,g.N);g.h=g.jP.prototype;g.h.mx=function(){return 1E3*this.g.ec(this.A)};
g.h.stop=function(){this.o&&this.l.Pa(this.o)};
g.h.nx=function(){var a=this.g.fh(this.A);this.B={seekableStart:a.seekableStart,seekableEnd:a.seekableEnd,current:a.current};this.P("s")};
g.h.Ze=function(){return this.B};
g.h.JH=function(a){0<g.vB(a,2)&&this.P("r")};g.r(lP,g.Pq);lP.prototype.C=function(a){if(Array.isArray(a)){a=g.q(a);for(var b=a.next();!b.done;b=a.next())b=b.value,b instanceof OI&&this.l(b)}};var cma=["pla-shelf","shopping-companion","backfill-mpu-companion","action-companion"];g.r(mP,lP);mP.prototype.l=function(a){var b=a.id,c=a.content,d=c.componentType;if(cma.includes(d)){var e=this.o();switch(a.actionType){case 1:if(this.g.has(b))break;a=kP(d,this.Bb,e);if(!a){g.kp(Error("Unable to create component with type: "+d));break}this.g.set(b,a);case 2:b=this.g.get(b);if(!b)break;b.bind(c);break;case 3:if(c=this.g.get(b))c.dispose(),this.g["delete"](b)}}};
mP.prototype.U=function(){g.Ye([].concat(g.ea(this.g.values())))};g.r(nP,lP);
nP.prototype.l=function(a){var b=a.content;switch(b.componentType){case "pla-shelf":switch(a.actionType){case 1:case 2:this.Bb.na("onPlaShelfInfoCardsReady",{renderer:b.renderer,macros:b.macros});break;case 3:this.Bb.na("onPlaShelfInfoCardsReady",{})}break;case "shopping-companion":switch(a.actionType){case 1:case 2:a=this.Bb.getVideoData(1);this.Bb.na("updateKevlarOrC3Companion",{contentVideoId:a&&a.videoId,shoppingCompanionCarouselRenderer:b.renderer,macros:b.macros});break;case 3:this.Bb.na("updateKevlarOrC3Companion",{})}break;
case "action-companion":switch(a.actionType){case 1:case 2:a=this.Bb.getVideoData(1);g.R(g.V(this.Bb).experiments,"enable_kevlar_action_companion_cleanup")?this.Bb.na("updateKevlarOrC3Companion",{contentVideoId:a&&a.videoId,actionCompanionAdRenderer:b.renderer,macros:b.macros}):this.Bb.na("updateKevlarOrC3Companion",{contentVideoId:a&&a.videoId,actionCompanionRenderer:uja(b),macros:b.macros});break;case 3:this.Bb.na("updateKevlarOrC3Companion",{})}break;case "backfill-mpu-companion":switch(a.actionType){case 1:case 2:if(!b.renderer)break;
var c=this.g(),d=Object.assign({},fJ(this.Bb,c),b.macros);a=this.Bb.getVideoData(1);a={contentVideoId:a&&a.videoId,backfillMpuCompanionAdRenderer:b.renderer};"BACKFILL_MPU_TYPE_AFV"==b.renderer.type?oP(c,b.renderer,d):"BACKFILL_MPU_TYPE_AFC"==b.renderer.type&&(a.afcMpu={logImpression:function(){c.ea()||oP(c,b.renderer,d)},
logNoAd:function(){c.ea()||(b.renderer.noAdEndpoints||[]).forEach(function(a){return c.Ka(a,d)})}});
this.Bb.na("updateKevlarOrC3Companion",a);break;case 3:this.Bb.na("updateKevlarOrC3Companion",{})}}};var dma="ad-attribution-bar ad-channel-thumbnail advertiser-name ad-preview ad-title skip-button visit-advertiser".split(" ").concat(["pla-shelf","shopping-companion","backfill-mpu-companion","action-companion"]);g.r(pP,lP);
pP.prototype.l=function(a){var b=a.id,c=a.content;if(c){var d=c.componentType;if(!dma.includes(d))switch(a.actionType){case 1:a=this.B();a=kP(d,this.o,a);if(!a){g.M(Error("No UI component returned from ComponentFactory for type: "+d),"WARNING");break}Mb(this.g,b)?g.M(Error("Ad UI component already registered: "+b),"WARNING"):this.g[b]=a;a.bind(c);a.Ah(this.A);break;case 2:b=qP(this,a);if(null==b)break;b.bind(c);break;case 3:c=qP(this,a),null!=c&&(g.Xe(c),Mb(this.g,b)?Sb(this.g,b):g.M(Error("Ad UI component does not exist: "+
b),"WARNING"))}}};
pP.prototype.U=function(){g.Ye(Object.values(this.g));this.g={};lP.prototype.U.call(this)};g.r(rP,g.GI);g.h=rP.prototype;g.h.create=function(){this.load();this.created=!0};
g.h.load=function(){g.GI.prototype.load.call(this);this.player.getRootNode().classList.add("ad-created");var a=new EI(this.player);this.g=new OM(this.player,a);this.g.init()};
g.h.unload=function(){g.GI.prototype.unload.call(this);this.player.getRootNode().classList.remove("ad-created");var a=this.g;this.g=null;a.dispose()};
g.h.Xb=function(){return!1};
g.h.Cw=function(){return Object.values($la)};
g.h.Bw=function(a,b){b=void 0===b?{}:b;switch(a){case "replaceUrlMacros":var c=b;if(c.url){var d=cK(this.player);Object.assign(d,c.additionalMapping);this.g&&!d.AD_CPN&&(d.AD_CPN=this.g.X);c=g.Lm(c.url,d)}else c=null;return c;case "isExternalShelfAllowedFor":a:if(b.playerResponse){c=b.playerResponse.adPlacements||[];for(d=0;d<c.length;d++){var e=c[d];if(e.adPlacementRenderer&&e.adPlacementRenderer.renderer&&e.adPlacementRenderer.renderer.plaShelfRenderer){c=!1;break a}}c=!0}else c=!1;return c;default:return null}};g.zP={};var ema=[2,5];var nU=!1,oU=!1;g.dr("showCompanionAdLoaded",function(){if(oU){var a=g.y("window.google_show_companion_ad");var b=g.y("yt.www.watch.ads.getGlobals");g.Aa(a)&&g.Aa(b)?(b=b(),b=!(!b||!b.length)):b=!1;b?a():oU=!0;oU=!1}});
g.dr("watchAdsInit",function(){if(nU){nU=!1;var a=g.y("yt.www.watch.ads.loadAfc");g.Aa(a)?a():nU=!0}});new function(){this.l=1;this.g=g.ta(void 0)?void 0:null;if(g.Ma(ema,this.l)){if(!g.ta(this.g)||0>this.g)throw Error("Must have valid offset");}else if(null!==this.g)throw Error("Must not have offset");};g.r(uP,g.G);g.h=uP.prototype;g.h.Tt=function(){if(!this.l){var a=this.Tt;if("lb3"==g.V(this.g).playerStyle)var b=!1;else b=this.g.getVideoData(),b=b.ol||b.captionTracks.length||b.ma&&Gfa(b.ma)?!0:!1;(a=BP(this,"captions",a,b))&&!this.l&&(this.l=a,a.Yv()&&a.load(),this.g.na("onApiChange"))}};
g.h.po=function(){this.J=this.J||BP(this,"endscreen",this.po,g.vP(this))};
g.h.Yt=function(){this.B=BP(this,"webgl",this.Yt,Mka(this))};
g.h.sk=function(){return this.g.getVideoData().sk()};
g.h.au=function(){(this.T=this.T||BP(this,"ypc",this.au,this.sk()))&&this.T.load()};
g.h.Zt=function(){this.X=this.X||BP(this,"ypc_clickwrap",this.Zt,g.zA(this.g.getVideoData(),"ypc_clickwrap_module"))};
g.h.St=function(){this.Z=this.Z||BP(this,"spacecast",this.St,this.g.getVideoData().spacecastModule)};
g.h.Qt=function(){var a=!this.L;this.L=this.L||BP(this,"heartbeat",this.Qt,g.zA(this.g.getVideoData(),"ypc_license_checker_module"));a&&this.L&&this.g.P("offlineslatestatechange")};
g.h.no=function(){if(!this.o){var a=this.no;var b=g.V(this.g);if("3"==b.A)b=!1;else if(b.G.isEmpty()&&"annotation-editor"!=b.playerStyle&&"live-dashboard"!=b.playerStyle){var c=this.g.getVideoData();b=g.R(b.experiments,"disable_new_iv_module_create_logic")?g.zA(c,"iv3_module"):!!c.Ie}else b=!0;if(this.o=BP(this,"annotations_module",a,b)){a=this.o;for(var d in this.ka)b=d,a.subscribe(b,this.ka[b]);this.g.na("onApiChange")}}};
g.h.Pt=function(){this.G=this.G||BP(this,"fresca",this.Pt,g.zA(this.g.getVideoData(),"fresca_module"))};
g.h.qo=function(){this.O||(this.O=BP(this,"remote",this.qo,g.V(this.g).ab))&&this.O.create()};
g.h.Ut=function(){this.C||(this.C=BP(this,"unplugged",this.Ut,g.hy(g.V(this.g))))&&this.C.init()};
g.h.Vt=function(){xP(this);!this.H&&(this.H=BP(this,"ux",this.Vt,g.V(this.g).wa))&&(this.H.init(),this.g.na("onApiChange"))};
g.h.Rt=function(){this.da||(this.da=BP(this,"miniplayer",this.Rt,g.V(this.g).useMiniplayerUi))&&this.da.init()};
g.h.oo=function(){if(!this.F){var a=this.oo;var b=g.V(this.g);"3"==b.A?b=!1:"creator-endscreen-editor"==b.playerStyle?b=!0:(b=this.g.getVideoData(),b=!!b&&!!g.CA(b));(this.F=BP(this,"creatorendscreen",a,b))&&this.g.na("onApiChange")}};
g.h.bu=function(){(this.R=this.R||BP(this,"yto",this.bu,!!this.g.getVideoData().xc.includes("yto")))&&this.R.init()};
g.h.Xt=function(){var a=this.Xt;var b=g.V(this.g);b=this.g.getVideoData().isVisualizerEligible&&ty(b)&&g.R(b.experiments,"web_player_music_visualizer")&&"desktop-polymer"==b.playerStyle&&g.sy(b)&&!(g.uu&&!g.jc(42));(this.Y=BP(this,"visualizer",a,b))&&this.Y.gf()};
g.h.U=function(){g.G.prototype.U.call(this);CP(this,1,!0)};g.r(g.FP,g.Ns);g.h=g.FP.prototype;g.h.show=function(){var a=g.HP(this);g.Ns.prototype.show.call(this);this.ba&&(this.H.M(window,"blur",this.ub),this.H.M(window.document,"click",this.kH));a||this.P("show",!0)};
g.h.hide=function(){var a=g.HP(this);g.Ns.prototype.hide.call(this);GP(this);a&&this.P("show",!1)};
g.h.ce=function(a,b){this.l=a;this.L.show();b?(this.J||(this.J=this.H.M(this.R,"appresize",this.kt)),this.kt()):this.J&&(this.H.Pa(this.J),this.J=null)};
g.h.nC=function(){this.l&&(this.l.getAttribute("aria-haspopup"),this.l.setAttribute("aria-expanded",!0),g.R(g.V(this.R).experiments,"embeds_enable_new_playlist_killswitch")?window.document.activeElement&&g.Fd(this.l,window.document.activeElement)&&this.focus():this.focus())};
g.h.kt=function(){g.bt(this.R).Um(this.element,this.l)};
g.h.ub=function(){var a=g.HP(this);GP(this);this.L.hide();a&&this.P("show",!1)};
g.h.Kf=ba(19);g.h.kH=function(a){var b=g.Fq(a);b&&(g.Fd(this.element,b)||this.l&&g.Fd(this.l,b)||!g.NN(a))||this.ub()};g.r(g.IP,g.G);g.IP.prototype.l=function(){var a=g.qr()-this.A;a=a<this.g?a/this.g:1;this.B(g.$n(fma,a));1>a&&this.o.start()};
var fma=new g.Zn(0,0,.4,0,.2,1,1,1),Nka=/[0-9.-]+|[^0-9.-]+/g;g.r(g.PP,g.P);g.PP.prototype.G=function(a){OP(this,a.state)};
g.PP.prototype.F=function(){g.K(this.element,"ytp-play-button-playlist",g.aI(this.o))};
g.PP.prototype.H=function(){g.qB(g.YH(this.o))?this.o.Lb():this.o.Kb()};
g.PP.prototype.U=function(){this.l&&this.l();g.P.prototype.U.call(this)};g.r(g.UP,g.P);g.h=g.UP.prototype;g.h.mi=function(){VP(this);this.G&&(this.Pa(this.G),this.G=null);this.F=this.l.getVideoData(1);if(this.A=this.l.Ve())this.A.subscribe("shuffle",this.mi,this),this.G=this.M(this.l,"progresssync",this.iH);this.C=WP(this);TP(this);this.kc(g.ZH(this.l).Ha())};
g.h.kc=function(a){a=void 0===a?g.ZH(this.l).Ha():a;var b=g.aI(this.l)||this.o&&g.uI(this.l)||XP(this);g.Ms(this,b&&(this.o||400<=a.width))};
g.h.jH=function(a){var b=!0;this.J?b=g.tP(a,this.l):g.Iq(a);b&&(this.o&&5==this.l.Da()?this.l.P("ytoprerollinternstitialnext"):this.o?this.l.gi(!0):this.C?this.l.Ab(0):this.l.Qj(!0))};
g.h.iH=function(){var a=WP(this);a!=this.C&&(this.C=a,TP(this))};
g.h.U=function(){this.B&&(this.B(),this.B=null);VP(this);g.P.prototype.U.call(this)};YP.prototype.update=function(a,b,c,d){this.width=b;this.o=c;this.B=d;this.g=b-c-d;this.position=g.Uc(a,c,c+this.g);this.A=this.position-c;this.l=this.A/this.g};g.r(g.$P,g.Ns);g.h=g.$P.prototype;g.h.mH=function(a){if(!g.Jq(a)){var b=!1;switch(g.Kq(a)){case 36:this.l.Ab(0);b=!0;break;case 35:this.l.Ab(window.Infinity);b=!0;break;case 34:this.l.zd(-60);b=!0;break;case 33:this.l.zd(60);b=!0;break;case 38:this.l.zd(5);b=!0;break;case 40:this.l.zd(-5),b=!0}b&&g.Iq(a)}};
g.h.LI=function(a){switch(g.Kq(a)){case 13:this.l.Ab(Number(a.currentTarget.getAttribute("data-position")))}};
g.h.Yw=function(a,b){ZP(this,b,"newdata"==a)};
g.h.NC=function(){this.Yw("newdata",this.l.getVideoData())};
g.h.RC=function(){hQ(this.l.getVideoData())?g.pB(g.YH(this.l))&&iQ(this,!0):iQ(this,!1)};
g.h.lH=function(a){0<g.vB(a,64)||!hQ(this.l.getVideoData())?iQ(this,!1):g.qB(a.state)&&0>g.vB(a,64)&&iQ(this,!0);this.C&&!g.U(a.state,32)&&3!=this.l.Da()&&this.C.cancel()};
g.h.KK=function(a,b,c){var d=g.th(this.element),e=kQ(this).g,f=c?c.getAttribute("data-tooltip"):void 0,k=c?c.getAttribute("data-position"):void 0,l=c?c.getAttribute("data-offset-y"):void 0;k&&(a=vO(this.o,Number(c.getAttribute("data-position")),0)*e+g.th(this.zc).x);this.Ia.x=a-d.x;this.Ia.y=b-d.y;a=kQ(this);c=uO(this.o,a.l);b=f||g.MN(this.Oa?c-this.o.g:c);a=a.position+this.Ja;c=g.R(g.V(this.l).experiments,"web_player_storyboard_timestamp_killswitch")?c:c-g.tI(this.l);d=this.pa;f=!!f;l=l?(0,window.parseInt)(l,
10):0;d.ga||(3==d.o&&d.Zd(),1!=d.o&&(d.element.className="ytp-tooltip ytp-bottom",d.o=1,d.O&&d.J.show(),d.A=d.R.Xd(),d.A&&d.A.subscribe("l",d.Vx,d)),d.update({text:b,title:""}),g.K(d.element,"ytp-text-detail",!!f),b=-1,d.A&&(b=g.bz(d.A,160*d.B),b=g.gz(d.A,b,c)),QQ(d,b),PQ(d,!!f,a,l));g.K(this.l.getRootNode(),"ytp-progress-bar-hover",!g.U(g.YH(this.l),64));eQ(this)};
g.h.JK=function(){var a=this.pa;1==a.o&&a.Zd();g.yn(this.l.getRootNode(),"ytp-progress-bar-hover")};
g.h.IK=function(a,b){this.A&&(this.A.dispose(),this.A=null);this.Cc=b;this.l.Ab(uO(this.o,kQ(this).l),!1);g.J(this.element,"ytp-drag");(this.Va=g.qB(g.YH(this.l)))&&this.l.Lb()};
g.h.LK=function(){this.sa=0;g.yn(this.element,"ytp-pull-ui");g.yn(this.element,"ytp-pulling");this.A&&(this.A.dispose(),this.A=null);0<this.H&&(this.A=new g.Fn((0,g.z)(this.PB,this,g.qr(),this.H,kQ(this).position)),this.A.start());if(g.U(g.YH(this.l),32)||3==this.l.Da())this.l.Ab(uO(this.o,kQ(this).l)),g.yn(this.element,"ytp-drag"),this.Va&&!g.U(g.YH(this.l),2)&&this.l.Kb()};
g.h.PB=function(a,b,c){a=1-Math.pow(1-(g.qr()-a)/200,3);c+=a*(this.G*this.B-c);if(0>a||1<a)a=1;jQ(this,(1-a)*b,c,this.G);1>a&&this.A.start()};
g.h.MK=function(a,b){var c=!1,d=!1,e=kQ(this);3600<=this.o.getLength()&&(jQ(this,this.Cc-b-10,e.position,e.l),d=!0,c=this.H>.1*(this.F?60:40),e=kQ(this));g.K(this.element,"ytp-pull-ui",d);c&&g.J(this.element,"ytp-pulling");c=0;e.o&&0>=e.position?c=-1:e.B&&e.position>=e.width&&(c=1);this.sa!=c&&(this.sa=c,this.A&&(this.A.dispose(),this.A=null),c&&(this.A=new g.Fn((0,g.z)(this.HM,this,g.qr(),this.J)),this.A.start()));this.l.Ab(uO(this.o,e.l),!1)};
g.h.HM=function(a,b){var c=this.B*(this.X-1);this.J=g.Uc(b+this.sa*(g.qr()-a)*.3,0,c);g.dQ(this);this.l.Ab(uO(this.o,kQ(this).l),!1);0<this.J&&this.J<c&&this.A.start()};
g.h.Qx=function(){this.updateValue("clipstarticon",iN());this.updateValue("clipendicon",iN());g.J(this.element,"ytp-clip-hover")};
g.h.Px=function(){this.updateValue("clipstarticon",kN());this.updateValue("clipendicon",jN());g.yn(this.element,"ytp-clip-hover")};
g.h.dn=function(){this.O=0;this.L=window.Infinity;gQ(this);cQ(this,this.G,this.ka)};
g.h.oA=function(a){a=g.q(a);for(var b=a.next();!b.done;b=a.next())if(b=b.value,b.visible){var c=b.getId();if(!this.R[c]){var d=g.vd("DIV");("ytp-chapter-marker"==b.style||b.tooltip)&&d.setAttribute("data-position",b.start/1E3);b.tooltip&&d.setAttribute("data-tooltip",b.tooltip);b.icons&&d.setAttribute("data-offset-y",-12-24*b.icons.length);this.R[c]=b;this.oa[c]=d;if(b.icons&&b.icons.length){for(var e=g.vd("DIV"),f=g.q(b.icons),k=f.next();!k.done;k=f.next()){k=k.value;var l=g.vd("IMG");l.src=k.thumbnails[0].url;
l.setAttribute("data-position",b.start/1E3);b.tooltip&&l.setAttribute("data-tooltip",b.tooltip);l.setAttribute("data-offset-y",-12-24*b.icons.length);l.setAttribute("tabindex",0);k.accessibility&&k.accessibility.accessibilityData&&k.accessibility.accessibilityData.label&&(l.alt=k.accessibility.accessibilityData.label);this.Ya.M(l,"keydown",this.LI,void 0,!0);e.appendChild(l)}e.className="ytp-marker-icon";g.db(this.ba,b,g.$B);this.T[c]=e;this.Nc.appendChild(e)}d.className=b.style;lQ(this,c);"ytp-chapter-marker"==
b.style?this.Mc.appendChild(d):g.R(g.V(this.l).experiments,"disable_ad_markers_on_content_progress_bar")||this.Lc.appendChild(d)}}else pQ(this,b);mQ(this)};
g.h.BM=function(a){a=g.q(a);for(var b=a.next();!b.done;b=a.next())pQ(this,b.value);mQ(this)};
g.h.U=function(){fQ(this,!1);g.Ns.prototype.U.call(this)};g.r(g.qQ,g.Ns);g.qQ.prototype.ka=function(){this.P("size-change")};
g.qQ.prototype.focus=function(){this.X.focus()};
g.qQ.prototype.oa=function(){this.P("back")};g.r(g.rQ,g.qQ);g.rQ.prototype.ba=function(){this.F.P("size-change")};
g.rQ.prototype.focus=function(){for(var a=0,b=0;b<this.Ea.length;b++)if("true"==this.Ea[b].element.getAttribute("aria-checked")){a=b;break}this.Ea[a].focus()};g.r(g.vQ,g.Ps);g.h=g.vQ.prototype;g.h.open=function(){g.BQ(this.A,this.C)};
g.h.ze=function(a){if(this.F){var b=this.o[this.F];b.element.getAttribute("aria-checked");b.element.removeAttribute("aria-checked")}this.o[a].element.setAttribute("aria-checked",!0);this.jb(this.ye(a));this.F=a};
g.h.Xn=function(a,b,c){b=new g.Ps({D:"div",W:["ytp-menuitem"],N:{tabindex:"0",role:"menuitemradio","aria-checked":c?"true":void 0},K:[{D:"div",W:["ytp-menuitem-label"],V:"{{label}}"}]},b,this.ye(a,!0));b.fa("click",(0,g.z)(this.rH,this,a));return b};
g.h.enable=function(a){this.H?a||(this.H=!1,this.ni(!1)):a&&(this.H=!0,this.ni(!0))};
g.h.ni=function(a){a?this.A.yq(this):this.A.li(this)};
g.h.Xc=function(a){this.P("select",a)};
g.h.rH=function(a){"true"!=this.o[a].element.getAttribute("aria-disabled")&&this.Xc(a)};
g.h.ye=function(a){return a.toString()};
g.h.qH=function(a){g.Jq(a)||39!=g.Kq(a)||(this.open(),g.Iq(a))};
g.h.U=function(){this.H&&this.A.li(this);g.Ps.prototype.U.call(this);for(var a in this.o)this.o[a].dispose()};g.r(g.xQ,g.FP);g.h=g.xQ.prototype;g.h.show=function(){g.FP.prototype.show.call(this);this.Bk()};
g.h.hide=function(){g.FP.prototype.hide.call(this);1<this.A.length&&g.CQ(this)};
g.h.Bk=function(){DQ(this);this.Ma()&&(zQ(this),g.Ah(this.element,this.size))};
g.h.ee=function(){var a=this.A.pop(),b=yQ(this);AQ(this,a,b,!0)};
g.h.VM=function(a,b,c){this.F.dispose();this.F=null;g.J(this.element,"ytp-popup-animating");c?(g.J(a.element,"ytp-panel-animate-forward"),g.yn(b.element,"ytp-panel-animate-back")):(g.J(a.element,"ytp-panel-animate-back"),g.yn(b.element,"ytp-panel-animate-forward"));g.Ah(this.element,this.size);this.C=new g.L(g.Ea(this.oI,a,b),250,this);this.C.start()};
g.h.oI=function(a){g.yn(this.element,"ytp-popup-animating");g.Ad(a.element);g.zn(a.element,["ytp-panel-animate-back","ytp-panel-animate-forward"]);this.C.dispose();this.C=null};
g.h.bH=function(a){if(!g.Jq(a))switch(g.Kq(a)){case 27:this.ub();g.Iq(a);break;case 37:1<this.A.length&&this.ee();g.Iq(a);break;case 39:g.Iq(a)}};
g.h.focus=function(){yQ(this).focus()};
g.h.U=function(){g.FP.prototype.U.call(this);this.F&&this.F.dispose();this.C&&this.C.dispose()};var pU,qU;pU=[{option:"#fff",text:"White"},{option:"#ff0",text:"Yellow"},{option:"#0f0",text:"Green"},{option:"#0ff",text:"Cyan"},{option:"#00f",text:"Blue"},{option:"#f0f",text:"Magenta"},{option:"#f00",text:"Red"},{option:"#080808",text:"Black"}];qU=[{option:0,text:EQ(0)},{option:.25,text:EQ(.25)},{option:.5,text:EQ(.5)},{option:.75,text:EQ(.75)},{option:1,text:EQ(1)}];
g.rU=[{option:"fontFamily",text:"Font family",options:[{option:1,text:"Monospaced Serif"},{option:2,text:"Proportional Serif"},{option:3,text:"Monospaced Sans-Serif"},{option:4,text:"Proportional Sans-Serif"},{option:5,text:"Casual"},{option:6,text:"Cursive"},{option:7,text:"Small Capitals"}]},{option:"color",text:"Font color",options:pU},{option:"fontSizeIncrement",text:"Font size",options:[{option:-2,text:EQ(.5)},{option:-1,text:EQ(.75)},{option:0,text:EQ(1)},{option:1,text:EQ(1.5)},{option:2,text:EQ(2)},
{option:3,text:EQ(3)},{option:4,text:EQ(4)}]},{option:"background",text:"Background color",options:pU},{option:"backgroundOpacity",text:"Background opacity",options:qU},{option:"windowColor",text:"Window color",options:pU},{option:"windowOpacity",text:"Window opacity",options:qU},{option:"charEdgeStyle",text:"Character edge style",options:[{option:0,text:"None"},{option:4,text:"Drop Shadow"},{option:1,text:"Raised"},{option:2,text:"Depressed"},{option:3,text:"Outline"}]},{option:"textOpacity",text:"Font opacity",
options:[{option:.25,text:EQ(.25)},{option:.5,text:EQ(.5)},{option:.75,text:EQ(.75)},{option:1,text:EQ(1)}]}];g.r(g.GQ,g.P);
g.GQ.prototype.o=function(){var a=g.ZH(this.B).Ha().width,b=350<=a&&(!this.C||!g.U(g.YH(this.B),64));g.Ms(this,b);g.K(this.element,"ytp-time-display-allow-autohide",b&&400>a);a=this.B.fh();b&&(b=g.MN(a.current),this.F!=b&&(this.updateValue("currenttime",b),this.F=b),b=g.MN(a.duration),this.G!=b&&(this.updateValue("duration",b),this.G=b));this.C&&(a=a.isPeggedToLive,this.H!=a&&(this.H=a,this.o(),b=this.l.element,b.disabled=a,g.R(g.V(this.B).experiments,"enable_live_premiere_web_player_indicator")&&this.l.jb(this.J?
"Premiere":"Live"),a?this.A&&(this.A(),this.A=null,b.removeAttribute("title")):(b.title="Skip ahead to live broadcast.",this.A=g.RP(this.L,this.l.element))))};
g.GQ.prototype.T=function(a,b){FQ(this,b);this.o()};
g.GQ.prototype.O=function(a){a.target==this.l.element&&(this.B.Ab(window.Infinity),this.B.Kb())};
g.GQ.prototype.U=function(){this.A&&this.A();g.P.prototype.U.call(this)};g.r(g.HQ,g.P);g.HQ.prototype.show=function(){g.P.prototype.show.call(this);g.In(this.l)};
g.HQ.prototype.hide=function(){this.o.stop();g.P.prototype.hide.call(this)};g.r(g.JQ,g.P);g.JQ.prototype.o=function(){g.J(this.element,"ytp-sb-subscribed")};
g.JQ.prototype.A=function(){g.yn(this.element,"ytp-sb-subscribed")};g.ua("yt.pubsub.publish",g.gr,void 0);g.r(g.MQ,g.P);g.h=g.MQ.prototype;g.h.fK=function(a){3==this.o&&this.Zd();a=a.currentTarget;this.o||(a.removeEventListener("mouseover",this.F),a.addEventListener("mouseout",this.Y),g.R(this.L.experiments,"show_tooltip_on_tab_killswitch")||(a.removeEventListener("focus",this.F),a.addEventListener("blur",this.Y)),g.OQ(this,a,2))};
g.h.cK=function(a){(a=g.Gq(a))&&g.Fd(this.l,a)||this.Zd()};
g.h.Vx=function(a,b){if(a<=this.C&&this.C<=b){var c=this.C;this.C=window.NaN;QQ(this,c)}};
g.h.AD=function(){g.ez(this.A,this.C,160*this.B)};
g.h.Zd=function(){switch(this.o){case 2:this.l.removeEventListener("mouseout",this.Y),this.l.addEventListener("mouseover",this.F),g.R(this.L.experiments,"show_tooltip_on_tab_killswitch")||(this.l.removeEventListener("blur",this.Y),this.l.addEventListener("focus",this.F));case 3:3==this.o&&this.ha.stop();this.R.removeEventListener("appresize",this.X);this.T||this.l.setAttribute("title",this.G);this.G="";this.l=null;break;case 1:this.A&&(this.A.unsubscribe("l",this.Vx,this),this.A=null),this.R.removeEventListener("videoready",
this.X),this.ba.stop()}this.o=null;this.O&&this.J.hide()};
g.h.Dg=ba(20);g.h.U=function(){null!=this.o&&this.Zd();g.P.prototype.U.call(this)};g.r(TQ,g.G);TQ.prototype.O=function(a){if(this.o==this.g.xb()){var b=this.F.get(a);YQ(this,b.target,b.Bi)}else{b=this.l.find(function(b){return b.Xf.hd==a});
var c=b.Xf,d=c.target;c=c.Bi;d?YQ(this,d,c):Ria(this.g,this.o,c,b.Be)}};
TQ.prototype.R=function(){if(this.B){var a=this.B;aR(this);ZQ(this,a);$G(this.g.xb(),a.Xf.hd)}};
TQ.prototype.T=function(a){var b=this;if(0<g.vB(a,128)){var c=this.l.find(function(a){return ZQ(b,a)});
c&&(a=new g.iB(8),c=bR(this,c)/1E3,eR(this,c,a))}};
TQ.prototype.U=function(){dR(this,!1);iR(this);g.G.prototype.U.call(this)};
var Pka=0;jR.prototype.getStatus=function(){return this.A};
jR.prototype.o=function(){var a=this.g.getVideoData(),b=this.l.getVideoData();if(a.xa&&b.xa)if(a=RQ(this.g,this.l,this.B,this.g.C))nR(this,"Can not apply gapless "+a);else if(a=this.g.J,!a)nR(this,"Could not find a media source.");else if(a.g||a.l){b=this.g.l;var c=kR(this),d=c.ZB,e=c.Ex,f=c.YB;c=c.Dx;0>e?nR(this,"Next player is to far in the future"):(hH(this.g,bu(a,d,f)),gH(this.g,new g.LF(b.ue()?b.l:b,d,f)),hH(this.l,bu(a,e,c)),lR(this,"success"),mR(this))}};g.r(sR,g.G);sR.prototype.get=function(a){qR(this);var b=this.g.find(function(b){return b.key==a});
return b?b.value:null};
sR.prototype.set=function(a,b,c){this.remove(a,!0);qR(this);a={key:a,value:b,expire:window.Infinity};c&&(0,window.isFinite)(c)&&(c*=1E3,a.expire=g.qr()+c);for(this.g.push(a);this.g.length>this.A;)c=this.g.shift(),tR(this,c,!0);rR(this)};
sR.prototype.remove=function(a,b){b=void 0===b?!1:b;var c=this.g.find(function(b){return b.key==a});
c&&(tR(this,c,b),g.Ra(this.g,function(b){return b.key==a}),rR(this))};
sR.prototype.U=function(){var a=this;g.G.prototype.U.call(this);this.g.forEach(function(b){tR(a,b,!0)});
this.g=[]};g.wa(uR);var UR=g.y("ytPlayerUtilsVideoTagPoolInstance")||uR.getInstance();g.ua("ytPlayerUtilsVideoTagPoolInstance",UR,void 0);g.h=uR.prototype;g.h.ou=function(a){if(!(this.g.length>=a)){a-=this.g.length;for(var b=0;b<a;b++)xR(this)}};
g.h.wC=function(a,b){if(this.g.length)return this.g.pop();var c=xR(this,a,b);a||g.Qa(this.g,c);return c};
g.h.zM=function(a){a&&g.Ma(this.l,a)&&(a.src&&(cu&&0<a.readyState&&(a.currentTime=Math.max(Vla,0)),a.removeAttribute("src"),a.load(),a.g&&a.g.l&&YA(a,null)),Nq(a),g.Qa(this.l,a),g.Qa(this.o,a))};
g.h.hD=function(a){return this.g.length>=(a||1)};
g.h.LB=function(){for(var a=this.o.length-1;0<=a;a--)wR(this,this.o[a]);this.g.length==this.l.length&&4<=this.g.length||(4>this.l.length?this.ou(4):(this.g=[],(0,g.C)(this.l,function(a){wR(this,a)},this)))};
uR.prototype.fillPool=uR.prototype.ou;uR.prototype.getTag=uR.prototype.wC;uR.prototype.releaseTag=uR.prototype.zM;uR.prototype.hasTags=uR.prototype.hD;uR.prototype.activateTags=uR.prototype.LB;g.r(yR,g.G);yR.prototype.o=function(a){this.l=a[a.length-1].intersectionRatio};
yR.prototype.U=function(){g.G.prototype.U.call(this);this.l=null;this.g&&this.g.disconnect()};g.gma=mc(function(){var a=window.AudioContext||window.webkitAudioContext;try{return new a}catch(b){return b.name}});g.r(zR,g.P);g.h=zR.prototype;g.h.fD=function(){this.H=new g.Tg(0,0,0,0);this.o=new g.Tg(0,0,0,0)};
g.h.Jm=function(a){g.xn(this.element,arguments)};
g.h.xe=function(){if(this.l){var a=this.Ha();if(!a.isEmpty()){var b=!g.bd(a,g.Xg(this.o)),c=IR(this);b&&(this.o.width=a.width,this.o.height=a.height);a=this.app.g;(c||b||a.X)&&this.app.l.P("resize",this.Ha())}}};
g.h.TG=function(a,b){BR(this,b)};
g.h.gD=function(a){a.getVideoData()&&BR(this,a.getVideoData())};
g.h.Ha=function(){var a=this.app.g,b=this.app.Z.isFullscreen();if(b&&Mp())return new g.ad(window.outerWidth,window.outerHeight);if(b||a.Mk){if(window.matchMedia){a="(width: "+window.innerWidth+"px) and (height: "+window.innerHeight+"px)";this.F&&this.F.media==a||(this.F=window.matchMedia(a));var c=this.F&&this.F.matches}if(c)return new g.ad(window.innerWidth,window.innerHeight)}else{if(!(0,window.isNaN)(this.B.width)&&!(0,window.isNaN)(this.B.height))return this.B.clone();if(this.X&&this.Y&&!this.app.isWidescreen())for(a=
0;a<this.X.length;a++)if(b=this.X[a],b.query.matches)return new g.ad(b.size.width,b.size.height)}return new g.ad(this.element.clientWidth,this.element.clientHeight)};
g.h.PC=function(){this.l&&g.LK(this);HR(this)!=this.O&&this.xe()};
g.h.UG=function(){g.LK(this)};
g.h.U=function(){this.J&&g.er(this.J);AR(this);g.P.prototype.U.call(this)};JR.prototype.click=function(a){var b=a.getAttribute("data-visual-id");g.Ma(this.g,a);g.Ma(this.o,b)&&g.Ma(this.A,a);this.l?(b=g.js())&&a.visualElement&&g.Vr(b,a.visualElement):g.wI(this,"onLogVeClicked",{id:b})};
JR.prototype.H=function(a){g.Ma(this.g,a);var b=a.getAttribute("data-visual-id");g.Qa(this.g,a);g.Qa(this.C,b);g.Qa(this.o,b);g.Qa(this.A,a);a.removeAttribute("data-visual-id")};
JR.prototype.pause=function(){this.F=!0};
JR.prototype.resume=function(){this.F=!1;for(var a=g.q(this.G),b=a.next();!b.done;b=a.next())b=b.value,g.wI(this,b.type,b.data);this.G.length=0};g.r(LR,g.P);g.r(NR,g.P);g.h=NR.prototype;g.h.show=function(){g.P.prototype.show.call(this);this.Fq()};
g.h.hide=function(){g.P.prototype.hide.call(this);this.l.stop()};
g.h.stop=function(){this.l.stop()};
g.h.start=function(){this.l.isActive()||this.Fq()};
g.h.Fq=function(){var a=g.qr(),b=g.W(this.o),c=this.o.getVideoData(),d=this.o.l,e=d.app.B.ia(),f=b.Ko(),k=b.da,l=8*uG(k,"bandwidth")/1024,m=uG(k,"networkactivity")/1024,n=uG(k,"bufferhealth");if(b.G){var p=b.G.g.g+"/"+Du(dH(b));p=p+"/"+b.G.Me()}else p="";var u=g.oy();d=g.dI(d).nD;var x=c.xa&&!c.xa.g?"display:none":"",B;if((B=c.clientPlaybackNonce)&&16==B.length){for(var F=0,H="",Q=0;10>Q;Q++)if(F=(F<<6)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".indexOf(B.charAt(Q)),4==Q%5){for(var O=
"",ab=0;6>ab;ab++)O="0123456789ABCDEFGHJKMNPQRSTVWXYZ".charAt(F&31)+O,F>>=5;H+=O}B=H.substr(0,4)+" "+H.substr(4,4)+" "+(""+H.substr(8,4))}else B="";f={video_id_and_cpn:c.videoId+" / "+B,codecs:"",dropped_frames:f.totalVideoFrames?""+(f.droppedVideoFrames||0)+"/"+f.totalVideoFrames:"-",stream_host:b.B?b.B.Va:"",dimensions:e.clientWidth+"x"+e.clientHeight+(1<u?"*"+u:""),bandwidth_kbps:l.toFixed(0)+" Kbps",buffer_health_seconds:n.toFixed(2)+" s",drm_style:p?"":"display:none",drm:p,host_style:x,bandwidth_style:x,
network_activity_style:x,network_activity_bytes:m.toFixed(0)+" KB",shader_info:d,shader_info_style:d?"":"display:none",playback_categories:""};l=this.o.Z.Jb();m=IA(c);l=Math.round(l)+"% / "+Math.round(l*m)+"%";m=c.relativeLoudness.toFixed(1);(0,window.isFinite)(m)&&(l+=" (content loudness "+m+"dB)");f.volume=l;f.resolution=e.videoWidth+"x"+e.videoHeight;if(c.ua){e=c.ua.video.fps;1<e&&(f.resolution+="@"+e);(e=g.bH(b))&&e.video&&(f.resolution+=" / "+e.video.width+"x"+e.video.height,1<e.video.fps&&(f.resolution+=
"@"+e.video.fps));f.codecs=OR(c.ua);if(e=c.Yb)e=c.ua,e=!(e.audio&&e.video);e&&(f.codecs+=" / "+OR(c.Yb));c.ua.video.l||c.ua.video.primaries?(e=c.ua.video.l||"unknown","smpte2084"==e?e+=" (PQ)":"arib-std-b67"==e&&(e+=" (HLG)"),f.color=e+" / "+(c.ua.video.primaries||"unknown"),f.color_style=""):f.color_style="display:none"}if(c.yj)f.live_mode="Post-Live"+(gA(c)?" Manifestless":"");else if(e=c.ra,f.live_latency_style=e?"":"display:none",f.live_mode_style=e?"":"display:none",e){e=uG(k,"livelatency");
f.live_latency_secs=e.toFixed(2)+"s";l=gA(c)?"Manifestless, ":"";m="Uncertain";if(0<=e&&120>e)if(c.latencyClass&&"UNKNOWN"!=c.latencyClass)switch(c.latencyClass){case "NORMAL":m="Optimized for Normal Latency";break;case "LOW":m="Optimized for Low Latency";break;case "ULTRALOW":m="Optimized for Ultra Low Latency";break;default:m="Unknown Latency Setting"}else m=c.isLowLatencyLiveStream?"Optimized for Low Latency":"Optimized for Smooth Streaming";f.live_mode=l+m}jH(b)&&(f.playback_categories+="Gapless ");
f.playback_categories_style=f.playback_categories?"":"display:none";MR(this.A,tG(k,"bandwidth"));MR(this.F,tG(k,"networkactivity"));MR(this.C,tG(k,"livelatency"));MR(this.B,tG(k,"bufferhealth"));this.update(f);a=25<g.qr()-a?5E3:500;this.l.start(a)};g.r(QR,g.G);g.h=QR.prototype;g.h.tI=function(){SR(this)||g.mS(this,5)};
g.h.AK=function(a){SR(this)||(RS(this),g.qB(a.o)&&XS(this))};
g.h.getVideoData=function(){return this.o.getVideoData()};
g.h.kd=function(){var a=this.C,b={};a.l&&g.Fa(b,a.l.zE());this.C.A&&g.Fa(b,{});b.fs=this.l.isFullscreen();b.volume=Math.round(this.Z.Jb());b.mos=this.Z.isMuted()?1:0;if(g.R(this.g.experiments,"html5_enable_embedded_player_visibility_signals")&&this.g.g&&(this.Oc&&(a=this.Oc,a=null==a.l?null:Math.round(100*a.l)/100,null!=a&&(b.inview=a)),a=this.G.Ha(),0<a.height&&0<a.width)){a=[Math.round(a.height),Math.round(a.width)];var c=g.oy();1<c&&a.push(c);b.size=a.join(":")}return b};
g.h.zb=function(a){a=g.W(this,a);if(!a)return 0;a=cS(this,a);return rS(this,a.zb(),a)};
g.h.YD=function(a){switch(a.type){case "loadedmetadata":Oz("fvb","")||(0,g.VB)("fvb",void 0,"");Pz("fvb");this.Mb.start();break;case "loadstart":Oz("gv","")||(0,g.VB)("gv",void 0,"");Pz("gv");break;case "progress":case "timeupdate":!Oz("l2s","")&&2<=Pt(a.target.Le())&&(0,g.VB)("l2s",void 0,"");break;case "playing":g.Js&&this.Mb.start();if(g.gy(this.g))a=!1;else{var b=this.C.B;a="none"==this.B.ij("display")||0==this.B.Kj().ke();var c=HR(this.G),d=this.o.getVideoData(),e=!this.la("web_player_music_reload_hidden_killswitch")&&
qy(this.g);d=cA(d);b=!c||b||e||d||this.g.Rf;a=a&&!b}a&&(this.o.Za("hidden","1",!0),this.getVideoData().bf||(this.la("html5_new_elem_on_hidden")?(this.getVideoData().bf=1,this.fy(null),qH(g.W(this))):WS(this,"hidden",!0)))}};
g.h.GJ=function(a,b){this.l.na("onLoadProgress",b)};
g.h.BL=function(){this.l.P("playbackstalledatstart")};
g.h.ZD=function(a,b){this.l.na("onVideoProgress",b)};
g.h.gJ=function(){this.l.na("onDompaused")};
g.h.NK=function(){this.Z.P("progresssync")};
g.h.TD=function(a){if(1==lI(this)){0<g.vB(a,1)&&!g.U(a.state,64)&&fS(this).ra&&pH(this.A)&&1<this.l.Pb()&&qS(this,1,!0);0<g.vB(a,2)&&ZR(this);if(g.U(a.state,128)){var b=a.state;JS(this);b=b.l;this.l.na("onError",KT[b.errorCode]||5);this.l.na("onDetailedError",b);6048E5<g.qr()-this.g.ed&&this.l.na("onReloadRequired")}g.pB(a.state)&&!g.sB(a.state)&&!Oz("pbresume","ad_to_video")&&Oz("_start","ad_to_video")&&(b=this.getVideoData(),(0,g.WB)("cpn",b.clientPlaybackNonce,"ad_to_video"),b.videoId&&(0,g.WB)("docid",
b.videoId,"ad_to_video"),b.playbackId&&(0,g.WB)("plid",b.playbackId,"ad_to_video"),(0,g.VB)("pbresume",void 0,"ad_to_video"));this.l.P("applicationplayerstatechange",a)}};
g.h.Ay=function(a){3!=lI(this)&&this.l.P("presentingplayerstatechange",a)};
g.h.VD=function(a){bS(this,tB(a.state));g.U(a.state,1024)&&this.l.app.da&&(Xs(this,{muted:!1,volume:this.R.volume},!1),nS(this,!1))};
g.h.FK=function(a){g.pB(a.state)&&!g.sB(a.state)&&(wP(this.C),g.Rq(this.dd))};
g.h.sI=function(a){"newdata"==a&&AS(this)};
g.h.wI=function(){this.l.na("onPlaybackAudioChange",this.l.getAudioTrack().ib.name)};
g.h.VL=function(a){var b=this.o.getVideoData();a==b&&this.l.na("onPlaybackQualityChange",a.ua.video.quality)};
g.h.Jp=function(a,b,c){this.la("html5_app_oauth_update_killswitch")||b!=this.A||(this.g.Oa=c.oauthToken);if("newdata"==a)CP(this.C,2),this.l.P("videoplayerreset",b);else{if(!this.B)return;if("dataloaded"==a)if(this.o==this.A){if(b.C.Lf(c.Nd),!this.A.o.isError()){var d=SR(this);fS(this).Ob();d&&g.mS(this,6);eS(this);d||(d=this.C.A)&&!d.created&&yP(this.C)&&d.create()}}else eS(this);if(1==b.getPlayerType()&&(this.g.L&&$S(this),this.getVideoData().ra&&!this.g.Uk&&g.LG(this.A,"html5.unsupportedlive",
"DEVICE_FALLBACK",void 0),c.Ob())){if(c.Ym||c.Ep||c.Qc.focEnabled||c.Qc.rmktEnabled||this.getVideoData().jt)d=this.getVideoData(),DS(this,"part2viewed",1,0x8000000000000),DS(this,"engagedview",Math.max(1,1E3*d.ne),0x8000000000000),d.ra||(d=1E3*d.lengthSeconds,DS(this,"videoplaytime25",.25*d,d),DS(this,"videoplaytime50",.5*d,d),DS(this,"videoplaytime75",.75*d,d),DS(this,"videoplaytime100",d,0x8000000000000),DS(this,"conversionview",d,0x8000000000000));if(c.chapterMarkers.length&&g.R(this.g.experiments,
"enable_player_chapter_markers")){d=this.getVideoData();for(var e=[],f=0;f<d.chapterMarkers.length;f++){var k=d.chapterMarkers[f].playerChapterMarkerRenderer;if(k){var l={id:"__chapterMarker"+f+"__",style:"ytp-chapter-marker",visible:!0};k.color&&(l.color=k.color);k.tooltip&&(l.tooltip=k.tooltip);k.icons&&(l.icons=k.icons);var m=k.startTimeMs;k=new g.YB(m,k.endTimeMs||m,l);k.namespace="appchaptermarker";e.push(k)}}jI(this,e,1)}}this.l.P("videodatachange",a,c,b.getPlayerType())}this.g.sb&&this.l.na("onVideoDataChange",
{type:a,playertype:b.getPlayerType()});a=c.clientScreenNonce;c=c.rootVeType;if(a&&c){if(b=this.L,b.l?a!=g.js():a!=b.B)b.l?(ls(a,c),KR(b)):(g.wI(b,"onScreenChanged",{csn:a,root_ve_type:c}),b.o.length&&g.wI(b,"onLogVesShown",{ids:b.o}),b.C=g.Ta(b.o),b.B=a)}else KR(this.L)};
g.h.rl=function(){iS(this,null);this.l.na("onPlaylistUpdate")};
g.h.Ix=function(a){var b=a.getId(),c=fS(this);if("part2viewed"==b)c.Ny&&g.Vp(c.Ny),c.Ep&&g.Vp(c.Ep);else if("conversionview"==b){var d=this.A;d.A&&PB(d.A)}else"engagedview"==b&&g.Vp(c.Ym);if(c.Zm){d=c.Zm;var e={label:a.getId()};if(g.R(this.g.experiments,"send_pyv_ad_mt_and_abandon_pings")){var f=1E3*sS(this);e.ad_mt=Math.round(Math.max(0,f)).toString()}d=g.wp(d,e);g.Vp(d)}switch(b){case "videoplaytime25":c.Iv&&g.Vp(c.Iv);c.Py&&g.Vp(c.Py);break;case "videoplaytime50":c.Jv&&g.Vp(c.Jv);c.Qy&&g.Vp(c.Qy);
break;case "videoplaytime75":c.Kv&&g.Vp(c.Kv);c.Ry&&g.Vp(c.Ry);break;case "videoplaytime100":c.Hv&&g.Vp(c.Hv),c.Oy&&g.Vp(c.Oy)}(b=this.getVideoData().jt)&&b[a.getId()]&&(c=b[a.getId()],g.Vp(c,void 0,ys(c)||zs(c)||xs(c)),b=b[a.getId()+"gaia"],g.Vp(b,void 0,ys(b)||zs(b)||xs(b)));this.A.H.A(a)};
g.h.isPeggedToLive=function(a,b){b=void 0===b?!1:b;var c=g.W(this,a);return c?pH(cS(this,c),void 0,b):!1};
g.h.WD=function(){this.l.P("seekcomplete")};
g.h.XD=function(a,b){var c=a.getVideoData();if(1==this.Y||2==this.Y)c.startSeconds=b;2==this.Y?kS(this):this.l.P("seekto",b)};
g.h.kI=function(){this.l.P("airplayactivechange")};
g.h.lI=function(){this.l.P("airplayavailabilitychange")};
g.h.BI=function(){this.l.P("beginseeking")};
g.h.lJ=function(){this.l.P("endseeking")};
g.h.getStoryboardFormat=function(a){return(a=g.W(this,a))?cS(this,a).getVideoData().getStoryboardFormat():null};
g.h.Xd=function(a){return(a=g.W(this,a))?cS(this,a).getVideoData().Xd():null};
g.h.Ag=function(){if(this.J){var a=this.J.getVideoData(),b=this.o.getVideoData();if(a.xa&&b.xa)if(RQ(this.o,this.J,FS(this),this.g))GS(this);else if(this.B.G=!0,a=this.B.bi(),a.g){this.o.getVideoData();this.J.getVideoData();GS(this);b=this.o.ba.g;var c=b+FS(this)/1E3;CG(this.o,b,c);CG(this.J,c,window.Infinity);hH(this.J,a);this.J.Za("gapless",this.o.getVideoData().clientPlaybackNonce)}}else GS(this)};
g.h.QK=function(){HS(this)};
g.h.kL=function(){"picture-in-picture"==this.B.ia().webkitPresentationMode?pG(this.H,!0):pG(this.H,!1)};
g.h.Wq=function(){var a=this.F.za();if(a){var b=this.getVideoData();b.oi||!this.oa?(b=b.jg,a=gR(this,a),b&&KS(this,a)):LS(this,a)}this.l.na("onPlaylistUpdate")};
g.h.qI=function(a){this.l.na("onCueRangeEnter",a.getId())};
g.h.rI=function(a){this.l.na("onCueRangeExit",a.getId())};
g.h.uI=function(){lI(this);this.wa||(this.wa=vz(this.Rx,this));XB(this.pa,this.o.getVideoData(),ZM(this));hS(this)&&this.g.g&&"embedded"==DA(fS(this))&&this.ge&&.01>Math.random()&&Ws(this.nb,"autoplayTriggered",{intentional:this.Fd});this.ge=!1;var a=g.js();a&&Ws(this.nb,"playbackAssociated",{cpn:this.getVideoData().clientPlaybackNonce,csn:a})};
g.h.xJ=function(){this.Z.P("internalAbandon")};
g.h.Rx=function(a){a=a.g;if(!(0,window.isNaN)(a)&&0<a&&this.A){var b=this.A;b.A&&0<a&&(b.A.l.l.aft=[a])}};
g.h.YJ=function(){this.Pq()};
g.h.ZJ=function(){this.Pq()};
g.h.Pq=function(){this.g.sb&&this.o?this.l.na("onApiChange",this.o.getPlayerType()):this.l.na("onApiChange")};
g.h.WJ=function(){var a=this.B;a={volume:g.Uc(Math.floor(100*a.Jb()),0,100),muted:a.pm()};a.muted||nS(this,!1);this.R=g.Wb(a);this.l.na("onVolumeChange",a)};
g.h.oJ=function(){VS(this,SS(this)?1:0);var a=g.uq();US(this,!!a&&g.Fd(this.G.element,a))};
g.h.isFullscreen=function(){return this.H.isFullscreen()};
g.h.eL=function(){2!=this.H.o&&VS(this,SS(this)?1:0);this.g.xh&&this.getVideoData()&&!this.getVideoData().backgroundable&&this.B&&.33>window.outerHeight*window.outerWidth/(window.screen.width*window.screen.height)&&this.B.Yi()};
g.h.FJ=function(a){3!=lI(this)&&this.l.P("liveviewshift",a)};
g.h.isWidescreen=function(){return this.cd};
g.h.dL=function(a){var b=g.hK(this.G);g.Vg(this.Qd,b)||(this.Qd=b,this.o&&sH(this.o),this.A&&this.A!=this.o&&sH(this.A),1==this.H.o&&this.Oa&&US(this,!0));this.Mc&&g.bd(this.Mc,a)||(this.l.P("appresize",a),this.Mc=a)};
g.h.ac=function(){return this.Z.ac()};
g.h.wL=function(){lI(this);WS(this,"signature",void 0,!0)};
g.h.fy=function(){XR(this);WR(this)};
g.h.bL=function(a){hH(a,this.B.bi())};
g.h.VI=function(){this.l.na("CONNECTION_ISSUE")};
g.h.UD=function(a){this.l.P("heartbeatparams",a)};
g.h.pK=function(){var a=g.W(this);a&&g.PH(a,!g.iI(this.l))};
g.h.IJ=function(){this.l.na("onLoadedMetadata")};
g.h.iJ=function(){this.l.na("onDrmOutputRestricted")};
g.h.U=function(){this.C.dispose();this.sa.dispose();this.J&&this.J.dispose();this.A.dispose();XR(this);g.Ye(g.Jb(this.Nc),this.F);g.uz(this.wa);this.wa=0;g.G.prototype.U.call(this)};
g.h.la=function(a){return g.R(this.g.experiments,a)};
var sU={};g.ua("yt.player.Application.create",function(a,b){try{var c=g.v(a)?a:"player"+g.Da(a),d=sU[c];if(d){try{d.dispose()}catch(f){g.M(f)}sU[c]=null}var e=new QR(a,b);g.We(e,function(){sU[c]=null});
return sU[c]=e}catch(f){throw g.M(f),f.stack;}},void 0);
var tU=g.y("ytcsi.tick");tU&&tU("pe");})(_yt_player);
