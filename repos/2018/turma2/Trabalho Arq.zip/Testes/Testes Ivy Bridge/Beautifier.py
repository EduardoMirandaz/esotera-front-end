import re
from math import floor, log10

# Função auxiliar para a formatação dos números
def mul(x):
	return floor(log10(abs(x)))

# Arredonda para o primeiro decimal significativo
def round_first(x):
	if(x==0):
		return x

	return round(x, -mul(x))

# Itera entre as linhas do arquivo
counter=0

# Variáveis para o cálculo do erro
x=y=ex=ey=1

# Sufixos para notação computacional
sigla=['', 'k', 'M', 'G', 'T']

# Lista de nomes
name=['L1 dCache Load Misses', 'Cycles', 'Instructions', '', 'Branches', 'Branch Misses', 'L1 dCache Load']

# Arquivo de entrada
f=open('Teste Ivy Bridge.txt', 'r')

for line in f:
	line=line.rstrip()
	
	# Procura por linhas que contêm a string media
	match=re.search(r'media\s*=\s*(\S+)', line)
	
	# Verifica se deu match com linhas que contêm a string media
	if(match):
		counter+=1
		
		if(counter%7==3):
			# Cálculo do CPI
			avg=x/y
			e=abs((ex*y - x*ey)/(y*y))
			dec=-mul(e)
			
			print('CPI;' + '{:.{prec}f}'.format(round(avg, dec), prec=dec), '±', round_first(e))
			
			# Cálculo do IPC
			avg=y/x
			e=abs((ey*x - y*ex)/(x*x))
			dec=-mul(e)
			
			print('IPC;' + '{:.{prec}f}'.format(round(avg, dec), prec=dec), '±', round_first(e))
			
			continue
		
		# Média arredondada depois da vírgula
		avg=round(float(match.group(1)))

	# Procura por linhas que contêm a string range	
	match=re.search(r'range\s*=\s*\[(\S+)\s*;\s*(\S+)\]', line)
	
	# Verifica se deu match com linhas que contêm a string range
	if(match):
		if(counter%7==3):
			continue
		
		# Lower bound
		a=float(match.group(1))
		
		# Upper bound
		b=float(match.group(2))
		
		# Erro arredondado depois da vírgula
		e=round((b-a)/2)
		
		# Erro arredondado antes da vírgula
		e=round(e, -len(str(e))+1)
		
		# Cálculo do rank
		rank=0
		while(e>1000):
			rank+=1
			e/=1000
			
		# Média final
		avg/=(1000**rank)
		avg=round(avg, -len(str(int(e)))+1)
		
		# Definição das variáveis para o cálculo do erro
		if(counter%7==1):
			rx=rank
			x=avg
			ex=e
		
		if(counter%7==2):
			ry=rank
			y=avg
			ey=e
		
		# Imprime o resultado final
		# print(name[(counter)%7] + ';' + str(int(avg))+sigla[rank],'±', str(int(e))+sigla[rank])
		
		if(counter%7==0):
			print('')

f.close()