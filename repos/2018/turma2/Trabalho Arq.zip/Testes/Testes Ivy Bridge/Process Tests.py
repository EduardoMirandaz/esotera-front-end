import re
import numpy as np
import scipy.stats


def mean_confidence_interval(data, confidence=0.95):
    a = 1.0 * np.array(data)
    n = len(a)
    m, se = np.mean(a), scipy.stats.sem(a)
    h = se * scipy.stats.t.ppf((1 + confidence) / 2., n-1)
    return m, m-h, m+h

def data_mean(data):
	sum = 0
	for i in data:
		sum += i
	return sum/len(data)

folders = {'LoC_Bench', 'Loop_Bench', 'MMA_Bench', 'SM_Bench'}

for folder in folders:
	cycles = []
	instructions = []
	ipc = []
	branches = []
	branch_misses = []
	cache_loads = []
	cache_load_misses = []

	for i in range(10):
		with open(folder + '/teste' + str(i) + '.txt') as f:
		    for line in f:
		        match = re.search(r'([\d,.]+)\s*cycles', line)
		        if match:
		        	cycles.append( int(match.group(1).replace(',', '')))

		        match = re.search(r'([\d,.]+)\s*instructions', line)
		        if match:
		        	instructions.append( int(match.group(1).replace(',', '')))

		        match = re.search(r'.*#\s*([\d,.]+)\s*insn', line)
		        if match:
		        	ipc.append(float( match.group(1).replace(',','.')))

		        match = re.search(r'([\d,.]+)\s*branches', line)
		        if match:
		        	branches.append(int( match.group(1).replace(',','')))

		        match = re.search(r'([\d,.]+)\s*branch-misses', line)
		        if match:
		        	branch_misses.append(int( match.group(1).replace(',','')))

		        match = re.search(r'([\d,.]+)\s*L1-dcache-loads', line)
		        if match:
		        	cache_loads.append(int( match.group(1).replace(',','')))

		        match = re.search(r'([\d,.]+)\s*L1-dcache-load-misses', line)
		        if match:
		        	cache_load_misses.append(int( match.group(1).replace(',','')))

	print('Teste: ' + folder + '\n')

	mean = mean_confidence_interval(cycles)
	print('Numero de ciclos:')
	print('\tmedia = ' + str(mean[0]) )
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )
	
	mean = mean_confidence_interval(instructions)
	print('Numero de instrucoes:')
	print('\tmedia = ' + str(mean[0]))
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )

	mean = mean_confidence_interval(ipc)
	print('Instrucoes por ciclo:')
	print('\tmedia = ' + str(mean[0]))
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )
	
	mean = mean_confidence_interval(branches)
	print('Desvios:')
	print('\tmedia = ' + str(mean[0]))
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )

	mean = mean_confidence_interval(branch_misses)
	print('Desvios errados:')
	print('\tmedia = ' + str(mean[0]))
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )

	mean = mean_confidence_interval(cache_loads)
	print('Loads na cache:')
	print('\tmedia = ' + str(mean[0]))
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )

	mean = mean_confidence_interval(cache_load_misses)
	print('Falhas de load na cache:')
	print('\tmedia = ' + str(mean[0]))
	print('\trange = [' + str(mean[1]) + ' ; ' + str(mean[2]) + ']' )

	print('')
