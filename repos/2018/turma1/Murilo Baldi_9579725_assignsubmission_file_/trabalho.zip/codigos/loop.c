int main() {
    long double a, b;

    for(int i = 0; i < 1000; i++) {
        for(int j = 0; j < 1000; j++) {
            b = a;
            for(int k = 0; k < 1000; k++) {
                a = i * j * k;
            }
        }
    }
}
