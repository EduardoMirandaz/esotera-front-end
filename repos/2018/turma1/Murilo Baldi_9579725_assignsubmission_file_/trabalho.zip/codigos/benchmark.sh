#! /bin/sh
i=50
while [ $i -ne 0 ]; do
	echo $i
    perf stat -e cycles,instructions,cache-misses ./$1 2>&1 | grep -e "cycles" -e "instructions" -e "cache-misses" -e "time elapsed" | sed -e "s/^ \+//g" | sed -e "s/ \+/ /g" | sed -e "s/,//g" | cut -f1,2 -d' ' | sed -e "s/ /,/g"
    i=$((i-1))
done
