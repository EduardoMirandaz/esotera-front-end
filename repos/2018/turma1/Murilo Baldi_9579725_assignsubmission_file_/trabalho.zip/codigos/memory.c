#include <stdlib.h>

void att(long double *v, int n, int idx) {
    v[idx] = n;
}

int main() {
    long double *a, *b, *c;
    a = (long double *) malloc (sizeof(long double)*1000);
    b = (long double *) malloc (sizeof(long double)*1000);
    c = (long double *) malloc (sizeof(long double)*1000);

    for(int i = 0; i < 1000; i++) {
        att(a, i, i);
        att(b, 1000-i, i);
        att(c, a[i]*b[i], i);
    }
}