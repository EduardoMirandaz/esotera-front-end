#include <math.h>
#include <stdlib.h>
#include <stdio.h>

long double potencial(int n) {
    if(n == 0 || n == 1)
        return 1;
    return pow(n, potencial(n-1));
}

int main(int argc, char *argv[]) {
    printf("%Lf\n", potencial(atoi(argv[1])));
}
