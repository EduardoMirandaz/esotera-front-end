#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <float.h>
#include <limits.h>

using namespace std;

#define INFI	INT_MAX
#define	INFF	FLT_MAX

#define	NINST	6
#define NREG	6
#define	NPFREG	5

#define NPOSMEM	16

#define NCCLOAD	1
#define NCCADD	2
#define NCCMULT	10

typedef struct {
	int tipo, dest, fnt1, fnt2, imm;
} t_instrucao;

typedef struct {
	int desp, exi, exf, mem, er;
} t_istatus;

typedef struct {
	bool ocupado;
	int op, D, A, Qj, Qk;
	float Vj, Vk, result;
	int estado, inst;
} t_rs;

typedef struct {
	vector<t_istatus> istatus;
	vector<t_rs> rs;
	vector<float> registrador, memoria;
	vector<int> Qi;
	bool CBD;
	int acessoMem, somador, multiplicador;
} t_clock;

typedef struct {
	int nInst, nLoadRS, nAddRS, nMultRS;
	vector<t_clock> cc;
} t_tomasulo;

void print_string_vector(vector<string> v) {
	for(vector<string>::iterator it = v.begin(); it != v.end(); it++) {
		cout << *it << "\n";
	}
}

void print_instrucao(t_instrucao instrucao) {
	cout << instrucao.tipo << "\t" << instrucao.dest << "\t" << instrucao.fnt1 << "\t" << instrucao.fnt2 << "\t" << instrucao.imm << "\n";
}

void print_prog(vector<string> prog) {
	/*for(vector<string>::iterator it = prog.begin(); it != prog.end(); it++) {
		cout << *it << "\n";
	}*/
	for(int i = 0; i < prog.size(); i++)
		cout << prog[i] << "\n";
}

void print_coluna_int(int valor, char sep) {
	if(valor == INFI)
		cout << "-" << sep;
	else
		cout << valor << sep;
}

void print_coluna_float(float valor, char sep) {
	if(valor == INFF)
		cout << "-" << sep;
	else
		cout << valor << sep;
}

void print_coluna_bool(bool valor, char sep) {
	if(valor == false)
		cout << "N" << sep;
	else 
		cout << "Y" << sep;
}

void print_Q(int valor, char sep, vector<string> nomesRS) {
	if(valor == -1)
		cout << "-" << sep;
	else
		cout << nomesRS[valor] << sep;
}

void print_op(int valor, char sep, vector<string> nomesInst) {
	if(valor == -1)
		cout << "-" << sep;
	else
		cout << nomesInst[valor] << sep;
}

void print_dest(int valor, char sep, vector<string> nomesReg, int estado_rs, float resultado, int tipo) {
	if(valor == -1)
		cout << "-" << sep;
	else if(((tipo == 0 or tipo == 1) and estado_rs < 3) or estado_rs < 2)
		cout << nomesReg[valor] << sep;
	else
		cout << resultado << sep;
}

// desp exi exf mem er
void print_istatus(t_istatus istatus, string linha) {
	cout << linha << "\t";
	print_coluna_int(istatus.desp, '\t');
	print_coluna_int(istatus.exi, '\t');
	print_coluna_int(istatus.exf, '\t');
	print_coluna_int(istatus.mem, '\t');
	print_coluna_int(istatus.er, '\n');
}

// ocupado op D Vj Vk Qj Qk A
void print_rs(t_rs rs, vector<string> nomesReg, vector<string> nomesRS, vector<string> nomesInst) {
	print_coluna_bool(rs.ocupado, '\t');
	print_op(rs.op, '\t', nomesInst);
	print_dest(rs.D, '\t', nomesReg, rs.estado, rs.result, rs.op);
	print_coluna_float(rs.Vj, '\t');
	print_coluna_float(rs.Vk, '\t');
	print_Q(rs.Qj, '\t', nomesRS);
	print_Q(rs.Qk, '\t', nomesRS);
	print_coluna_int(rs.A, '\n');
}

// istatus rs Qi registradores memoria
void print_clock(t_clock clock, vector<string> prog, vector<string> regStr, vector<string> nomesRS, vector<string> nomesInst) {
	cout << "STATUS DAS INSTRUÇÕES:\n";
	cout << "\t\t\tDESP\tEXi\tEXf\tMEM\tER\n";
	for(int i = 0; i < prog.size(); i++)
		print_istatus(clock.istatus[i], prog[i]);
	cout << "\n\n";
	cout << "STATUS DAS ESTAÇÕES DE RESERVA:\n";	
	cout << "\tOCUP\tOP\tDEST\tVj\tVk\tQj\tQk\tA\n";
	for(int i = 0; i < clock.rs.size(); i++) {
		cout << nomesRS[i] << "\t";
		print_rs(clock.rs[i], regStr, nomesRS, nomesInst);
	}
	cout << "\n\n";
	cout << "\t";
	for(int i = 0; i < NPFREG; i++)
		cout << regStr[i] << "\t";
	cout << "\nQi:\t";
	for(int i = 0; i < clock.Qi.size(); i++)
		print_Q(clock.Qi[i], '\t', nomesRS);
	cout << "\n\n";
	cout << "\t";
	for(int i = 0; i < NREG; i++)
		cout << regStr[i] << "\t";
	cout << "\nReg:\t";
	for(vector<float>::iterator it = clock.registrador.begin(); it != clock.registrador.end(); it++)
		print_coluna_float(*it, '\t');
	cout << "\n\n";
	cout << "\t";
	for(int i = 0; i < NPOSMEM; i++)
		cout << i*4 << "\t";
	cout << "\nmem:\t";
	for(vector<float>::iterator it = clock.memoria.begin(); it != clock.memoria.end(); it++)
		print_coluna_int(*it, '\t');
	cout << "\n";
}


void print_tomasulo(t_tomasulo tomasulo, int cc, vector<string> prog, vector<string> regStr, vector<string> nomesRS, vector<string> nomesInst) {
	system("clear");
	cout << "CC: " << cc << "\n";
	print_clock(tomasulo.cc[cc], prog, regStr, nomesRS, nomesInst);
}

string le_linha(FILE *fp, char sep) {
	char c;
	string str;
	do {
		fread(&c, sizeof(char), 1, fp);
		if(c != sep)
			str.append(1, c);
	} while(!feof(fp) and c != sep);
	return str;
}

void inicializa_inst_strings(vector<string> *iStr) {
	(*iStr)[0] = "LOAD.D"; (*iStr)[1] = "STORE.D";
	(*iStr)[2] = "ADD.D"; (*iStr)[3] = "SUB.D";
	(*iStr)[4] = "MUL.D"; (*iStr)[5] = "DIV.D";
}

void inicializa_reg_strings(vector<string> *regStr) {
	(*regStr)[0] = "F0"; (*regStr)[1] = "F2";
	(*regStr)[2] = "F4"; (*regStr)[3] = "F6";
	(*regStr)[4] = "F8"; (*regStr)[5] = "R2";
}

void inicializa_nomes_rs(vector<string> *nomesRS, int nLoadRS, int nAddRS, int nMultRS) {
	int total = nLoadRS + nAddRS + nMultRS;
	int i, j;
	char aux[2];
	string str;
	
	aux[1] = '\0';
	for(i = 0, j = 0; j < nLoadRS; j++, i++) {
		(*nomesRS).push_back("Load");
		aux[0] = j+'0';
		(*nomesRS)[i].append(aux);
	}
	for(j = 0; j < nAddRS; j++, i++) {
		(*nomesRS).push_back("Add");
		aux[0] = j+'0';
		(*nomesRS)[i].append(aux);
	}
	for(j = 0; j < nMultRS; j++, i++) {
		(*nomesRS).push_back("Mult");
		aux[0] = j+'0';
		(*nomesRS)[i].append(aux);
	}
}

void inicializa_nomes_instrucoes(vector<string> *nomesInst) {
	(*nomesInst).push_back("load"); (*nomesInst).push_back("store");
	(*nomesInst).push_back("add"); (*nomesInst).push_back("sub");
	(*nomesInst).push_back("mult"); (*nomesInst).push_back("div");
}

int determina_tipo_inst(string instrucao, vector<string> iStr) {
	for(int i = 0; i < NINST; i++) {
		if(instrucao.find(iStr[i]) != -1) {
			return i;
		}
	}
	return -1;
}

int determina_registrador(string instrucao, vector<string> regStr, int pos, int tam) {
	for(int i = 0; i < NREG; i++) {
		if(!instrucao.compare(pos, tam, regStr[i])) {
			return i;
		}
	}
	return -1;
}

int determina_imediato(string instrucao, int tipo) {
	int pos;
	if(tipo == 0)
		pos = 11;
	else
		pos = 12;
	return stoi(instrucao.substr(pos, 2), nullptr);
}

void interpreta_instrucoes(queue<t_instrucao> *instrucoes, vector<string> *iStr, vector<string> *regStr, vector<string> *prog) {
	FILE *fp;
	string linha;
	t_instrucao instrucao;
	int cont = 1;
	char aux;
	
	fp = fopen("init/programa.txt", "r");
	if(fp == NULL) {
		cout << "Não foi possível ler o arquivo de instruções\n";
		exit(-1);
	}
	
	inicializa_inst_strings(&(*iStr));
	inicializa_reg_strings(&(*regStr));
	
	//print_string_vector(*iStr);
	//print_string_vector(*regStr);
	
	while(!feof(fp)) {
		aux = fgetc(fp);
		if(!feof(fp)) {
			fseek(fp, -1, SEEK_CUR);
			linha = le_linha(fp, '\n');
			instrucao.tipo = determina_tipo_inst(linha, *iStr);
			if(instrucao.tipo == 0) {
				instrucao.dest = determina_registrador(linha, *regStr, 7, 2);
				instrucao.fnt1 = determina_registrador(linha, *regStr, 14, 2);
				instrucao.fnt2 = 0;
				instrucao.imm = determina_imediato(linha, instrucao.tipo);
			} else if(instrucao.tipo == 1) {
				instrucao.dest = 0;
				instrucao.fnt1 = determina_registrador(linha, *regStr, 15, 2);
				instrucao.fnt2 = determina_registrador(linha, *regStr, 8, 2);
				instrucao.imm = determina_imediato(linha, instrucao.tipo);
			} else if(instrucao.tipo >= 2 and instrucao.tipo <= 5) {
				instrucao.dest = determina_registrador(linha, *regStr, 6, 2);
				instrucao.fnt1 = determina_registrador(linha, *regStr, 10, 2);
				instrucao.fnt2 = determina_registrador(linha, *regStr, 14, 2);
				instrucao.imm = 0;
			}
			if(instrucao.tipo == -1 or instrucao.dest == -1 or instrucao.fnt1 == -1 or instrucao.fnt2 == -1) {
				cout << "Não foi possível interpretar o arquivo de instruções\n";
				cout << "Instrução inválida na linha " << cont << "\n";
				exit(-2);
			}
			(*prog).push_back(linha);
			linha.clear();
			cont++;
			(*instrucoes).push(instrucao);
		}
	}
	
	fclose(fp);
}

int load_rs_livre(vector<t_rs> rs, int nLoadRS, int nAddRS, int nMultRS) {
	for(int i = 0; i < nLoadRS; i++)
		if(!rs[i].ocupado)
			return i;
	return -1;
}

int add_rs_livre(vector<t_rs> rs, int nLoadRS, int nAddRS, int nMultRS) {
	for(int i = nLoadRS; i < nLoadRS+nAddRS; i++)
		if(!rs[i].ocupado)
			return i;
	return -1;
}

int mult_rs_livre(vector<t_rs> rs, int nLoadRS, int nAddRS, int nMultRS) {
	for(int i = nLoadRS+nAddRS; i < nLoadRS+nAddRS+nMultRS; i++)
		if(!rs[i].ocupado)
			return i;
	return -1;
}

bool todas_rs_livres(vector<t_rs> rs, int nLoadRS, int nAddRS, int nMultRS) {
	for(int i = 0; i < nLoadRS+nAddRS+nMultRS; i++)
		if(rs[i].ocupado)
			return false;
	return true;
}

void inicializa_qtd_rs(int *nLoadRS, int *nAddRS, int *nMultRS) {
	FILE *fp = fopen("init/qtdRS.txt", "r");
	string linha;
	char aux;
	int valor;
	
	linha = le_linha(fp, '\n');
	valor = stoi(linha, nullptr);
	(*nLoadRS) = valor;
	
	linha = le_linha(fp, '\n');
	valor = stoi(linha, nullptr);
	(*nAddRS) = valor;
	
	linha = le_linha(fp, '\n');
	valor = stoi(linha, nullptr);
	(*nMultRS) = valor;
	
	fclose(fp);
}

void inicializa_qtd_fu(int *nLoadFU, int *nAddFU, int *nMultFU) {
	FILE *fp = fopen("init/qtdFU.txt", "r");
	string linha;
	char aux;
	int valor;
	
	linha = le_linha(fp, '\n');
	valor = stoi(linha, nullptr);
	(*nLoadFU) = valor;
	
	linha = le_linha(fp, '\n');
	valor = stoi(linha, nullptr);
	(*nAddFU) = valor;
	
	linha = le_linha(fp, '\n');
	valor = stoi(linha, nullptr);
	(*nMultFU) = valor;
	
	fclose(fp);
}

void inicializa_tomasulo(t_tomasulo *tomasulo, vector<string> *nomesRS, vector<string> *nomesInst, queue<t_instrucao> *instrucoes,
						int nInst, int *nLoadRS, int *nAddRS, int *nMultRS, int *nLoadFU, int *nAddFU, int *nMultFU) {
	t_clock inicio;
	t_rs rs;
	t_istatus istatus;
	t_instrucao instrucao;
	int rs_livre;
	int totalRS;
	float valor;
	string linha;
	char aux;
	FILE *fp;
	
	inicializa_qtd_rs(&(*nLoadRS), &(*nAddRS), &(*nMultRS));
	inicializa_qtd_fu(&(*nLoadFU), &(*nAddFU), &(*nMultFU));
	
	totalRS = (*nLoadRS)+(*nAddRS)+(*nMultRS);
	
	(*tomasulo).nInst = nInst;
	(*tomasulo).nLoadRS = (*nLoadRS);
	(*tomasulo).nAddRS = (*nAddRS);
	(*tomasulo).nMultRS = (*nMultRS);
	
	inicio.acessoMem = (*nLoadFU);
	inicio.somador = (*nAddFU);
	inicio.multiplicador = (*nMultFU);
	
	for(int i = 0; i < NPFREG; i++)	
		inicio.Qi.push_back(-1);
	
	rs.ocupado = false;
	rs.op = -1;
	rs.D = -1;
	rs.A = INFI;
	rs.Vj = INFF; rs.Vk = INFF;
	rs.Qj = -1; rs.Qk = -1;
	rs.estado = 0;
	for(int i = 0; i < totalRS; i++)
		inicio.rs.push_back(rs);

	istatus.desp = INFI;
	istatus.exi = INFI;
	istatus.exf = INFI;
	istatus.mem = INFI;
	istatus.er = INFI;	
	for(int i = 0; i < nInst; i++)
		inicio.istatus.push_back(istatus);
	
	fp = fopen("init/memoria.txt", "r");
	while(!feof(fp)) {
		aux = fgetc(fp);
		if(!feof(fp)) {
			fseek(fp, -1, SEEK_CUR);
			linha = le_linha(fp, '\n');
			valor = stof(linha, nullptr);
			inicio.memoria.push_back(valor);
		}
	}
	fclose(fp);
	
	fp = fopen("init/registradores.txt", "r");
	while(!feof(fp)) {
		aux = fgetc(fp);
		if(!feof(fp)) {
			fseek(fp, -1, SEEK_CUR);
			linha = le_linha(fp, '\n');
			valor = stof(linha, nullptr);
			inicio.registrador.push_back(valor);
		}
	}
	fclose(fp);
	
	instrucao = (*instrucoes).front();
	(*instrucoes).pop();
	
	inicio.istatus[0].desp = 0;
	if(instrucao.tipo == 0) {
		rs_livre = load_rs_livre(inicio.rs, *nLoadRS, *nAddRS, *nMultRS);
		inicio.rs[rs_livre].ocupado = true;
		inicio.rs[rs_livre].op = instrucao.tipo;
		inicio.rs[rs_livre].D = instrucao.dest;
		inicio.rs[rs_livre].Vj = inicio.registrador[instrucao.fnt1];
		inicio.rs[rs_livre].A = instrucao.imm;
		inicio.rs[rs_livre].inst = 0;
		inicio.Qi[inicio.rs[rs_livre].D] = rs_livre;
	} else if(instrucao.tipo == 1) {
		rs_livre = load_rs_livre(inicio.rs, *nLoadRS, *nAddRS, *nMultRS);
		inicio.rs[rs_livre].ocupado = true;
		inicio.rs[rs_livre].op = instrucao.tipo;
		inicio.rs[rs_livre].Vj = inicio.registrador[instrucao.fnt1];
		inicio.rs[rs_livre].Vk = inicio.registrador[instrucao.fnt2];
		inicio.rs[rs_livre].A = instrucao.imm;
		inicio.rs[rs_livre].inst = 0;
	} else {
		if(instrucao.tipo == 2 or instrucao.tipo == 3)
			rs_livre = add_rs_livre(inicio.rs, *nLoadRS, *nAddRS, *nMultRS);
		else
			rs_livre = mult_rs_livre(inicio.rs, *nLoadRS, *nAddRS, *nMultRS);
		inicio.rs[rs_livre].ocupado = true;
		inicio.rs[rs_livre].op = instrucao.tipo;
		inicio.rs[rs_livre].D = instrucao.dest;
		inicio.rs[rs_livre].Vj = inicio.registrador[instrucao.fnt1];
		inicio.rs[rs_livre].Vk = inicio.registrador[instrucao.fnt2];
		inicio.rs[rs_livre].inst = 0;
		inicio.Qi[inicio.rs[rs_livre].D] = rs_livre;
	}
	inicio.CBD = false;
	
	(*tomasulo).cc.push_back(inicio);
	
	inicializa_nomes_rs(&(*nomesRS), *nLoadRS, *nAddRS, *nMultRS);
	inicializa_nomes_instrucoes(&(*nomesInst));
}

void copia_ciclo_clock(t_clock *dest, t_clock origem) {
	for(vector<t_istatus>::iterator it = origem.istatus.begin(); it != origem.istatus.end(); it++)
		(*dest).istatus.push_back(*it);
	for(vector<t_rs>::iterator it = origem.rs.begin(); it != origem.rs.end(); it++)
		(*dest).rs.push_back(*it);
	for(vector<float>::iterator it = origem.registrador.begin(); it != origem.registrador.end(); it++)
		(*dest).registrador.push_back(*it);
	for(vector<float>::iterator it = origem.memoria.begin(); it != origem.memoria.end(); it++)
		(*dest).memoria.push_back(*it);
	for(vector<int>::iterator it = origem.Qi.begin(); it != origem.Qi.end(); it++)
		(*dest).Qi.push_back(*it);
	
}

void limpa_ciclo_clock(t_clock *clock) {
	(*clock).istatus.clear();
	(*clock).rs.clear();
	(*clock).registrador.clear();
	(*clock).memoria.clear();
	(*clock).Qi.clear();
}

void libera_rs(t_clock *clock, int r) {
	(*clock).rs[r].ocupado = false;
	(*clock).rs[r].op = -1;
	(*clock).rs[r].D = -1;
	(*clock).rs[r].A = INFI;
	(*clock).rs[r].Qj = -1; (*clock).rs[r].Qk = -1;
	(*clock).rs[r].Vj = INFF; (*clock).rs[r].Vk = INFF;
	(*clock).rs[r].estado = 0;
}

void estagio_er(t_clock *clock, int r, int cc) {
	//cout << "log.d: (inicio) estagio_er\n";
	
	if((*clock).CBD) {
		//cout << "log.d: (fim) estagio_er\n";
		return;
	}
	
	(*clock).CBD = true;
	if((*clock).Qi[(*clock).rs[r].D] == r) {
		(*clock).registrador[(*clock).rs[r].D] = (*clock).rs[r].result;
		(*clock).Qi[(*clock).rs[r].D] = -1;
	}
	for(int s = 0; s < (*clock).rs.size(); s++) {
		if(s != r) {
			if((*clock).rs[s].Qj == r) {
				(*clock).rs[s].Vj = (*clock).rs[r].result;
				(*clock).rs[s].Qj = -1;	
			}
			if((*clock).rs[s].Qk == r) {
				(*clock).rs[s].Vk = (*clock).rs[r].result;
				(*clock).rs[s].Qk = -1;	
			}
		}
	}
	libera_rs(&(*clock), r);
	(*clock).istatus[(*clock).rs[r].inst].er = cc;
	
	//cout << "log.d: (fim) estagio_er\n";
}

int estagio_mem(t_clock *clock, int r, int cc) {
	//cout << "log.d: (inicio) estagio_mem\n";
	
	if((*clock).rs[r].op == 1 and (*clock).rs[r].Qk != -1) {
		//cout << "log.d: (fim) estagio_mem\n";
		return 0;
	}
	if(!(*clock).acessoMem) {
		//cout << "log.d: (fim) estagio_mem\n";
		return 0;
	}
	
	(*clock).acessoMem--;
	if((*clock).rs[r].op == 0) {
		(*clock).rs[r].result = (*clock).memoria[(*clock).rs[r].A/4];
		(*clock).rs[r].estado = 3;
	} else {
		(*clock).memoria[(*clock).rs[r].A/4] = (*clock).rs[r].Vk;
		libera_rs(&(*clock), r);
	}
	(*clock).istatus[(*clock).rs[r].inst].mem = cc;
	
	//cout << "log.d: (fim) estagio_mem\n";
	
	return 1;
}

void estagio_ex(t_clock *clock, int r, int cc, int *somador, int *multiplicador) {
	//cout << "log.d: (inicio) estagio_ex\n";
	
	if(((*clock).rs[r].op == 0 or (*clock).rs[r].op == 1) and cc - (*clock).istatus[(*clock).rs[r].inst].exi < NCCLOAD) {
		//cout << "log.d: (fim) estagio_ex\n";
		return;
	}
	if(((*clock).rs[r].op == 2 or (*clock).rs[r].op == 3) and cc - (*clock).istatus[(*clock).rs[r].inst].exi < NCCADD) {
		//cout << "log.d: (fim) estagio_ex\n";
		return;
	}
	if(((*clock).rs[r].op == 4 or (*clock).rs[r].op == 5) and cc - (*clock).istatus[(*clock).rs[r].inst].exi < NCCMULT) {
		//cout << "log.d: (fim) estagio_ex\n";
		return;
	}
	
	if((*clock).rs[r].op == 0 or (*clock).rs[r].op == 1) {
		(*clock).rs[r].A += (*clock).rs[r].Vj;
		(*clock).rs[r].estado = 2;
	} else if ((*clock).rs[r].op == 2 or (*clock).rs[r].op == 3) {
		(*somador)++;
		if((*clock).rs[r].op == 2) {
			(*clock).rs[r].result = (*clock).rs[r].Vj + (*clock).rs[r].Vk;
		} else {
			(*clock).rs[r].result = (*clock).rs[r].Vj - (*clock).rs[r].Vk;
		}
		(*clock).rs[r].estado = 3;
	} else {
		(*multiplicador)++;
		if((*clock).rs[r].op == 4) {
			(*clock).rs[r].result = (*clock).rs[r].Vj * (*clock).rs[r].Vk;
		} else {
			(*clock).rs[r].result = (*clock).rs[r].Vj / (*clock).rs[r].Vk;
		}
		(*clock).rs[r].estado = 3;
	}
	(*clock).istatus[(*clock).rs[r].inst].exf = cc;
	
	//cout << "log.d: (fim) estagio_ex\n";
}

void estagio_exi(t_clock *clock, int r, int cc) {
	//cout << "log.d: (inicio) estagio_exi\n";
	
	if(((*clock).rs[r].op == 0 or (*clock).rs[r].op == 1) and (*clock).rs[r].Qj != -1) {
		//cout << "log.d: (fim) estagio_exi\n";
		return;
	}
	if(((*clock).rs[r].op >= 2 or (*clock).rs[r].op <= 5) and ((*clock).rs[r].Qj != -1 or (*clock).rs[r].Qk != -1)) {
		//cout << "log.d: (fim) estagio_exi\n";
		return;
	}
	
	if(((*clock).rs[r].op == 2 or (*clock).rs[r].op == 3)) {
		if(!(*clock).somador) {
			//cout << "log.d: (fim) estagio_exi\n";
			return;
		}
		(*clock).somador--;
	} else if(((*clock).rs[r].op == 4 or (*clock).rs[r].op == 5)) {
		if(!(*clock).multiplicador) {
			//cout << "log.d: (fim) estagio_exi\n";
			return;
		}
		(*clock).multiplicador--;
	}
	(*clock).istatus[(*clock).rs[r].inst].exi = cc;
	(*clock).rs[r].estado = 1;
	
	//cout << "log.d: (fim) estagio_exi\n";
}

void estagio_desp(t_instrucao instrucao, t_clock *clock, int r, int cc, int inst) {
	//cout << "log.d: (inicio) estagio_desp\n";
	
	(*clock).rs[r].ocupado = true;
	(*clock).rs[r].op = instrucao.tipo;
	(*clock).rs[r].inst = inst;
	if(instrucao.tipo == 0) {
		(*clock).rs[r].D = instrucao.dest;
		if(instrucao.fnt1 != 5 and (*clock).Qi[instrucao.fnt1] != -1) {
			(*clock).rs[r].Qj = (*clock).Qi[instrucao.fnt1];
		} else {
			(*clock).rs[r].Vj = (*clock).registrador[instrucao.fnt1];
			(*clock).rs[r].Qj = -1;
		}
		(*clock).rs[r].A = instrucao.imm;
		(*clock).Qi[instrucao.dest] = r;
	} else if(instrucao.tipo == 1) {
		if(instrucao.fnt1 != 5 and (*clock).Qi[instrucao.fnt1] != -1) {
			(*clock).rs[r].Qj = (*clock).Qi[instrucao.fnt1];
		} else {
			(*clock).rs[r].Vj = (*clock).registrador[instrucao.fnt1];
			(*clock).rs[r].Qj = -1;
		}
		if(instrucao.fnt1 != 5 and (*clock).Qi[instrucao.fnt2] != -1) {
			(*clock).rs[r].Qk = (*clock).Qi[instrucao.fnt2];
		} else {
			(*clock).rs[r].Vk = (*clock).registrador[instrucao.fnt2];
			(*clock).rs[r].Qk = -1;
		}
		(*clock).rs[r].A = instrucao.imm;
	} else {
		(*clock).rs[r].D = instrucao.dest;
		if((*clock).Qi[instrucao.fnt1] != -1) {
			(*clock).rs[r].Qj = (*clock).Qi[instrucao.fnt1];
		} else {
			(*clock).rs[r].Vj = (*clock).registrador[instrucao.fnt1];
			(*clock).rs[r].Qj = -1;
		}
		if((*clock).Qi[instrucao.fnt2] != -1) {
			(*clock).rs[r].Qk = (*clock).Qi[instrucao.fnt2];
		} else {
			(*clock).rs[r].Vk = (*clock).registrador[instrucao.fnt2];
			(*clock).rs[r].Qk = -1;
		}
		(*clock).Qi[instrucao.dest] = r;
	}
	(*clock).istatus[(*clock).rs[r].inst].desp = cc;
	
	//cout << "log.d: (fim) estagio_desp\n";
}

/*
	Estados de uma RS:
		> 0: desocupada/despacho
		> 1: executando
		> 2: acesso à memória
		> 3: escrita dos resultados
*/
void executa_tomasulo(t_tomasulo *tomasulo, queue<t_instrucao> *instrucoes, int nLoadRS, int nAddRS, int nMultRS,
										int nLoadFU, int nAddFU, int nMultFU) {
	//cout << "log.d: (inicio) executa_tomasulo\n";
	
	t_instrucao instrucao;
	t_clock novo_cc;
	int i = 1, j, rs_livre, inst = 1;
	int acessoMem, somador, multiplicador;
	int nTotalRS = nLoadRS+nAddRS+nMultRS;
	
	while(!(todas_rs_livres((*tomasulo).cc[i-1].rs, nLoadRS, nAddRS, nMultRS))) {
		copia_ciclo_clock(&novo_cc, (*tomasulo).cc[i-1]);
		for(j = 0; j < nTotalRS; j++) {
			if(novo_cc.rs[j].ocupado == true and novo_cc.rs[j].estado == 3)
				estagio_er(&novo_cc, j, i);
		}
		acessoMem = 0;
		for(j = 0; j < nTotalRS; j++) {
			if(novo_cc.rs[j].ocupado == true and novo_cc.rs[j].estado == 2)
				acessoMem += estagio_mem(&novo_cc, j, i);
		}
		novo_cc.acessoMem += acessoMem;
		somador = 0; multiplicador = 0;
		for(j = 0; j < nTotalRS; j++) {
			if(novo_cc.rs[j].ocupado == true and novo_cc.rs[j].estado == 1)
				estagio_ex(&novo_cc, j, i, &somador, &multiplicador);
		}
		novo_cc.somador += somador;
		novo_cc.multiplicador += multiplicador;
		for(j = 0; j < nTotalRS; j++) {
			if(novo_cc.rs[j].ocupado == true and novo_cc.rs[j].estado == 0)
				estagio_exi(&novo_cc, j, i);
		}
		novo_cc.CBD = false;
		if(!(*instrucoes).empty()) {
			instrucao = (*instrucoes).front();
			if(instrucao.tipo == 0 or instrucao.tipo == 1)
				rs_livre = load_rs_livre(novo_cc.rs, nLoadRS, nAddRS, nMultRS);
			else if(instrucao.tipo == 2 or instrucao.tipo == 3)
				rs_livre = add_rs_livre(novo_cc.rs, nLoadRS, nAddRS, nMultRS);
			else if(instrucao.tipo == 4 or instrucao.tipo == 5)
				rs_livre = mult_rs_livre(novo_cc.rs, nLoadRS, nAddRS, nMultRS);
			if(rs_livre != -1) {
				estagio_desp(instrucao, &novo_cc, rs_livre, i, inst);
				(*instrucoes).pop();
				inst++;
			}
		}
		(*tomasulo).cc.push_back(novo_cc);
		i++;
		limpa_ciclo_clock(&novo_cc);
	}
	
	//cout << "log.d: (fim) executa_tomasulo\n";
}

void print_fila(queue<t_instrucao> instrucoes) {
	while(!instrucoes.empty()) {
		print_instrucao(instrucoes.front());
		instrucoes.pop();
	}
}

bool opcao_valida(char opcao, int cc, int nCC) {
	if(opcao != 's') {
		if((opcao == 'p' and cc == nCC-1) or (opcao == 'a' and cc == 0)) return false;
		if(opcao != 'p' and opcao != 'a') return false;
	}
	return true;
}

int main(int argc, char **argv) {
	vector<string> prog;
	vector<string> iStr(NINST);
	vector<string> regStr(NREG);
	vector<string> nomesRS;
	vector<string> nomesInst;
	queue<t_instrucao> instrucoes;
	t_tomasulo tomasulo;
	int nLoadRS, nAddRS, nMultRS, nLoadFU, nAddFU, nMultFU;
	int nCC, cc = 0;
	char opcao;
	bool sair = false;
	
	interpreta_instrucoes(&instrucoes, &iStr, &regStr, &prog);
	inicializa_tomasulo(&tomasulo, &nomesRS, &nomesInst, &instrucoes, prog.size(), &nLoadRS, &nAddRS, &nMultRS, &nLoadFU, &nAddFU, &nMultFU);
	executa_tomasulo(&tomasulo, &instrucoes, nLoadRS, nAddRS, nMultRS, nLoadFU, nAddFU, nMultFU);
	nCC = tomasulo.cc.size();
	
	while(!sair) {
		print_tomasulo(tomasulo, cc, prog, regStr, nomesRS, nomesInst);
		cout << "\n";
		if(cc > 0)
			cout << "Entre com o caracter 'a' para visualizar o ciclo de clock anterior.\n";
		if(cc < nCC-1)
			cout << "Entre com o caracter 'p' para visualizar o próximo ciclo de clock.\n";
		cout << "Entre com o caracter 's' para finalizar o programa.\n> ";
		cin >> opcao;
		while(!opcao_valida(opcao, cc, nCC)) {
			cout << "Opção inválida! Por favor, digite uma das entradas válidas citadas acima.\n> ";
			cin >> opcao;
		}
		if(opcao == 'p')
			cc++;
		else if(opcao == 'a')
			cc--;
		else sair = true;
	}
		
	return 0;
}
